/* Wellstate · acabamento da interface: progresso de leitura, cabeçalho ao rolar e contagem animada dos KPIs. */
(function () {
    "use strict";
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    /* Barra de progresso + sombra do cabeçalho (um único listener, throttled por rAF). */
    const bar = document.createElement("div");
    bar.className = "ws-progress"; bar.setAttribute("aria-hidden", "true");
    document.body.appendChild(bar);
    const header = document.querySelector(".site-header");
    let ticking = false;
    function update() {
        ticking = false;
        const doc = document.documentElement;
        const max = doc.scrollHeight - window.innerHeight;
        const ratio = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
        bar.style.transform = `scaleX(${ratio})`;
        if (header) header.classList.toggle("is-scrolled", window.scrollY > 8);
    }
    window.addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    window.addEventListener("resize", update, { passive: true });
    update();

    /* Contagem animada: só para inteiros simples e razoáveis; qualquer outro texto passa sem alteração. */
    if (reduce || !("MutationObserver" in window)) return;
    const running = new WeakMap();
    function animate(el, to) {
        const from = Number(el.__own) || 0;
        if (from === to && el.__own === String(to)) return;
        const start = performance.now(), dur = 700;
        cancelAnimationFrame(running.get(el));
        const tick = now => {
            const t = Math.min(1, (now - start) / dur), eased = 1 - Math.pow(1 - t, 3);
            const value = String(Math.round(from + (to - from) * eased));
            el.__own = value;                      // marca o que foi escrito por nós, para o observador o ignorar
            el.textContent = value;
            if (t < 1) running.set(el, requestAnimationFrame(tick));
        };
        running.set(el, requestAnimationFrame(tick));
    }
    const obs = new MutationObserver(list => {
        for (const m of list) {
            const el = m.target.nodeType === 3 ? m.target.parentElement : m.target;
            if (!el || !el.classList || !el.classList.contains("kpi-value")) continue;
            const text = el.textContent.trim();
            if (text === el.__own) continue;
            if (/^\d{1,6}$/.test(text)) animate(el, Number(text)); else el.__own = undefined;
        }
    });
    document.querySelectorAll(".kpi-value").forEach(el => obs.observe(el, { childList: true, characterData: true, subtree: true }));
})();

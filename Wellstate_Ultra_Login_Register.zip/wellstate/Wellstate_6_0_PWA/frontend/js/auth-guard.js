/* Protege as páginas do painel: sem sessão PHP, vai para o login.
   Também gere a foto de perfil guardada no dispositivo. */
(function () {
    const PHOTO_KEY = "wellstate-profile-photo";

    document.documentElement.style.visibility = "hidden";
    setTimeout(() => { document.documentElement.style.visibility = ""; }, 2500);

    function applyProfilePhoto(avatar) {
        if (!avatar) return;
        let photo = null;
        try { photo = localStorage.getItem(PHOTO_KEY); } catch {}
        if (photo) {
            avatar.style.backgroundImage = `url(${photo})`;
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
            avatar.textContent = "";
            avatar.classList.add("has-photo");
        }
    }

    function setupProfilePhotoPicker(avatar, userName) {
        if (!avatar || avatar.dataset.photoReady) return;
        avatar.dataset.photoReady = "1";
        avatar.title = "Clique para alterar a foto de perfil";
        avatar.style.cursor = "pointer";
        avatar.setAttribute("role", "button");
        avatar.setAttribute("tabindex", "0");
        avatar.setAttribute("aria-label", "Alterar foto de perfil");

        const input = document.createElement("input");
        input.type = "file";
        input.accept = "image/*";
        input.style.cssText = "position:absolute;width:1px;height:1px;opacity:0;pointer-events:none";
        document.body.appendChild(input);

        const openPicker = () => input.click();
        avatar.addEventListener("click", openPicker);
        avatar.addEventListener("keydown", e => {
            if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openPicker(); }
        });

        input.addEventListener("change", () => {
            const file = input.files?.[0];
            if (!file || !file.type.startsWith("image/")) return;
            if (file.size > 2 * 1024 * 1024) {
                window.WellstateUI?.toast?.("A imagem deve ter menos de 2 MB.", "error");
                return;
            }
            const reader = new FileReader();
            reader.onload = () => {
                const dataUrl = reader.result;
                // Redimensionar para poupar espaço
                const img = new Image();
                img.onload = () => {
                    const size = 128;
                    const canvas = document.createElement("canvas");
                    canvas.width = size;
                    canvas.height = size;
                    const ctx = canvas.getContext("2d");
                    const scale = Math.max(size / img.width, size / img.height);
                    const w = img.width * scale;
                    const h = img.height * scale;
                    ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
                    const small = canvas.toDataURL("image/jpeg", 0.85);
                    try { localStorage.setItem(PHOTO_KEY, small); } catch {}
                    applyProfilePhoto(avatar);
                    window.WellstateUI?.toast?.("Foto de perfil atualizada.", "success");
                };
                img.src = dataUrl;
            };
            reader.readAsDataURL(file);
            input.value = "";
        });

        // Clique longo / menu simples para remover foto
        avatar.addEventListener("contextmenu", e => {
            e.preventDefault();
            if (!localStorage.getItem(PHOTO_KEY)) return;
            if (confirm("Remover a foto de perfil?")) {
                try { localStorage.removeItem(PHOTO_KEY); } catch {}
                avatar.style.backgroundImage = "";
                avatar.classList.remove("has-photo");
                avatar.textContent = String(userName || "W").trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase() || "W";
                window.WellstateUI?.toast?.("Foto removida.", "success");
            }
        });
    }

    function applyUser(user, csrf, isSocial) {
        document.documentElement.style.visibility = "";
        window.addEventListener("load", () => {
            const name = document.getElementById("userName");
            if (name) name.textContent = user.name;
            const avatar = document.getElementById("userAvatar");
            if (avatar) {
                if (user.photoURL && !localStorage.getItem(PHOTO_KEY)) {
                    avatar.style.backgroundImage = `url(${user.photoURL})`;
                    avatar.style.backgroundSize = "cover";
                    avatar.style.backgroundPosition = "center";
                    avatar.textContent = "";
                    avatar.classList.add("has-photo");
                } else {
                    avatar.textContent = String(user.name || "W").trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase();
                    applyProfilePhoto(avatar);
                }
                setupProfilePhotoPicker(avatar, user.name);
            }
            const footer = document.querySelector(".sidebar-footer");
            if (!footer) return;
            const out = document.createElement("button");
            out.className = "footer-btn logout";
            out.type = "button"; out.title = "Terminar sessão"; out.setAttribute("aria-label", "Terminar sessão");
            out.innerHTML = '<i class="fa-solid fa-right-from-bracket"></i><span>Terminar sessão</span>';
            out.addEventListener("click", async () => {
                try {
                    sessionStorage.removeItem("wellstate-social-user");
                    localStorage.removeItem("wellstate-social-user");
                } catch {}
                if (!isSocial) {
                    await fetch("php/logout.php", {
                        method: "POST",
                        credentials: "same-origin",
                        headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf || "" },
                        body: "{}"
                    }).catch(() => {});
                }
                window.location.replace("login.html");
            });
            (footer.querySelector(".footer-actions") || footer).appendChild(out);
            setTimeout(() => { if (name) name.textContent = user.name; }, 0);
        });
    }

    function socialUser() {
        try {
            const raw = sessionStorage.getItem("wellstate-social-user") || localStorage.getItem("wellstate-social-user");
            if (!raw) return null;
            const u = JSON.parse(raw);
            if (!u || !u.uid || !u.name) return null;
            // Sessões sociais expiram ao fim de 12 horas no dispositivo
            if (u.at && Date.now() - u.at > 12 * 60 * 60 * 1000) {
                sessionStorage.removeItem("wellstate-social-user");
                localStorage.removeItem("wellstate-social-user");
                return null;
            }
            return u;
        } catch { return null; }
    }

    fetch("php/me.php", { credentials: "same-origin", cache: "no-store" })
        .then(r => (r.ok ? r.json() : Promise.reject()))
        .then(({ user, csrf }) => applyUser(user, csrf, false))
        .catch(() => {
            const social = socialUser();
            if (social) applyUser(social, "", true);
            else window.location.replace("login.html");
        });
})();

/* Wellstate · PWA
   Regista o service worker, guarda o evento de instalação e mostra, dentro do próprio site,
   o botão "Instalar app", o aviso de modo offline e o aviso de nova versão. */
(function () {
    "use strict";
    const LS_KEY = "wellstate-pwa";
    const listeners = new Set();
    let deferredPrompt = null;
    let registration = null;
    let reloading = false;

    /* ---------- utilitários validados ---------- */
    const safeParse = (raw, fallback) => { try { const v = JSON.parse(raw); return v && typeof v === "object" ? v : fallback; } catch { return fallback; } };
    const readState = () => {
        let raw = null;
        try { raw = localStorage.getItem(LS_KEY); } catch { /* armazenamento bloqueado */ }
        const s = safeParse(raw, {});
        return { installed: s.installed === true, at: typeof s.at === "string" && !Number.isNaN(Date.parse(s.at)) ? s.at : null };
    };
    const writeState = patch => { try { localStorage.setItem(LS_KEY, JSON.stringify({ ...readState(), ...patch })); } catch { /* ignora */ } };
    const emit = (type, detail) => { listeners.forEach(fn => { try { fn(type, detail); } catch { /* um ouvinte com erro não afeta os outros */ } }); };
    const isStandalone = () =>
        (window.matchMedia && (window.matchMedia("(display-mode: standalone)").matches || window.matchMedia("(display-mode: window-controls-overlay)").matches || window.matchMedia("(display-mode: minimal-ui)").matches)) ||
        window.navigator.standalone === true;
    const secure = () => window.isSecureContext === true;
    const supportsSW = () => "serviceWorker" in navigator;

    /** Informação do computador, só com APIs que o navegador expõe (nada é enviado para fora). */
    function env() {
        const ua = navigator.userAgent || "";
        const uad = navigator.userAgentData;
        const platformRaw = (uad && uad.platform) || navigator.platform || "";
        let os = "Desconhecido";
        if (/win/i.test(platformRaw) || /Windows/i.test(ua)) os = "Windows";
        else if (/android/i.test(ua)) os = "Android";
        else if (/iphone|ipad|ipod/i.test(ua) || (/mac/i.test(platformRaw) && navigator.maxTouchPoints > 1)) os = "iOS";
        else if (/mac/i.test(platformRaw)) os = "macOS";
        else if (/cros/i.test(ua)) os = "ChromeOS";
        else if (/linux/i.test(platformRaw) || /Linux/i.test(ua)) os = "Linux";
        let browser = "Outro";
        if (/Edg\//.test(ua)) browser = "Edge";
        else if (/OPR\/|Opera/.test(ua)) browser = "Opera";
        else if (/Firefox\//.test(ua)) browser = "Firefox";
        else if (/Chrome\//.test(ua) || /CriOS/.test(ua)) browser = "Chrome";
        else if (/Safari\//.test(ua)) browser = "Safari";
        const desktop = os === "Windows" || os === "macOS" || os === "Linux" || os === "ChromeOS";
        return {
            os, browser, desktop,
            cores: Number.isFinite(navigator.hardwareConcurrency) ? navigator.hardwareConcurrency : null,
            memoryGb: Number.isFinite(navigator.deviceMemory) ? navigator.deviceMemory : null,
            online: navigator.onLine !== false,
            secure: secure(),
            standalone: isStandalone(),
            hasPicker: typeof window.showDirectoryPicker === "function"
        };
    }

    /* ---------- API pública ---------- */
    const api = {
        env,
        isStandalone,
        isInstalled: () => isStandalone() || readState().installed,
        canPrompt: () => deferredPrompt !== null,
        on(fn) { if (typeof fn === "function") { listeners.add(fn); return () => listeners.delete(fn); } return () => {}; },
        get registration() { return registration; },
        /** Abre o pedido de instalação do navegador (só depois de o utilizador carregar num botão do site). */
        async prompt() {
            if (!deferredPrompt) return { outcome: "unavailable" };
            const evt = deferredPrompt; deferredPrompt = null;
            try {
                await evt.prompt();
                const choice = await evt.userChoice;
                if (choice && choice.outcome === "accepted") writeState({ installed: true, at: new Date().toISOString() });
                emit("prompt-result", choice);
                return { outcome: choice && choice.outcome === "accepted" ? "accepted" : "dismissed" };
            } catch (error) { return { outcome: "error", message: String(error && error.message || error) }; }
        },
        /** Pede ao service worker para descarregar tudo para uso offline. Devolve o resumo final. */
        precache(onProgress) {
            return new Promise((resolve, reject) => {
                if (!supportsSW()) { reject(new Error("Este navegador não suporta service workers.")); return; }
                navigator.serviceWorker.ready.then(reg => {
                    const worker = reg.active;
                    if (!worker) { reject(new Error("O service worker ainda não está ativo.")); return; }
                    const timer = setTimeout(() => { cleanup(); reject(new Error("Tempo esgotado a preparar o modo offline.")); }, 60000);
                    const handler = ev => {
                        const d = ev.data;
                        if (!d || typeof d.type !== "string") return;
                        if (d.type === "PRECACHE_PROGRESS" && typeof onProgress === "function") onProgress(Number(d.done) || 0, Number(d.total) || 0, Number(d.failed) || 0);
                        if (d.type === "PRECACHE_DONE") { cleanup(); resolve({ done: d.done, total: d.total, failed: d.failed }); }
                        if (d.type === "PRECACHE_ERROR") { cleanup(); reject(new Error(d.message || "Falha ao preparar o modo offline.")); }
                    };
                    const cleanup = () => { clearTimeout(timer); navigator.serviceWorker.removeEventListener("message", handler); };
                    navigator.serviceWorker.addEventListener("message", handler);
                    worker.postMessage({ type: "PRECACHE_ALL" });
                }).catch(reject);
            });
        }
    };
    /* ---------- Armazenamento local (IndexedDB) para guardar a pasta escolhida ---------- */
    const idb = {
        open() {
            return new Promise((resolve, reject) => {
                if (!("indexedDB" in window)) { reject(new Error("IndexedDB indisponível")); return; }
                const req = indexedDB.open("wellstate-pwa", 1);
                req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains("kv")) req.result.createObjectStore("kv"); };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error || new Error("Falha ao abrir IndexedDB"));
                req.onblocked = () => reject(new Error("IndexedDB bloqueado"));
            });
        },
        async run(mode, fn) {
            const db = await idb.open();
            return new Promise((resolve, reject) => {
                const tx = db.transaction("kv", mode); const store = tx.objectStore("kv");
                const req = fn(store);
                tx.oncomplete = () => { db.close(); resolve(req && "result" in req ? req.result : undefined); };
                tx.onerror = tx.onabort = () => { db.close(); reject(tx.error || new Error("Transação falhou")); };
            });
        }
    };
    api.store = {
        get: key => idb.run("readonly", s => s.get(key)).catch(() => undefined),
        set: (key, value) => idb.run("readwrite", s => s.put(value, key)).then(() => true).catch(() => false),
        del: key => idb.run("readwrite", s => s.delete(key)).then(() => true).catch(() => false)
    };

    /** Nome de pasta/ficheiro válido em Windows, macOS e Linux. Devolve "" se válido, senão a mensagem de erro. */
    api.validateFolderName = function (raw) {
        const name = typeof raw === "string" ? raw : "";
        if (!name.trim()) return "Indique um nome para a pasta.";
        if (name !== name.trim()) return "O nome não pode começar nem acabar com espaços.";
        if (name.length < 2) return "Use pelo menos 2 caracteres.";
        if (name.length > 60) return "Use no máximo 60 caracteres.";
        if (/[<>:"/\\|?*\u0000-\u001f]/.test(name)) return 'Não use os caracteres < > : " / \\ | ? *';
        if (/[. ]$/.test(name)) return "O nome não pode terminar em ponto ou espaço.";
        if (/^\.+$/.test(name)) return "Nome inválido.";
        if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(name)) return "Este nome é reservado pelo Windows. Escolha outro.";
        return "";
    };

    /** Guarda uma cópia dos dados locais na pasta escolhida (ou descarrega, se não houver pasta). */
    api.saveBackup = async function () {
        let raw = null;
        try { raw = localStorage.getItem((window.WELLSTATE_CONFIG && window.WELLSTATE_CONFIG.STORE_KEY) || "wellstate-store"); } catch { /* ignora */ }
        if (!raw) return { ok: false, message: "Ainda não há dados locais para guardar." };
        let parsed; try { parsed = JSON.parse(raw); } catch { return { ok: false, message: "Os dados locais estão corrompidos e não foram guardados." }; }
        if (!parsed || typeof parsed !== "object") return { ok: false, message: "Formato de dados inesperado." };
        const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 16);
        const fileName = `wellstate-copia-${stamp}.json`;
        const text = JSON.stringify({ app: "Wellstate", tipo: "copia-de-seguranca", criadoEm: new Date().toISOString(), dados: parsed }, null, 2);
        const dir = await api.store.get("dataDir");
        if (dir && dir.handle && typeof dir.handle.queryPermission === "function") {
            try {
                let perm = await dir.handle.queryPermission({ mode: "readwrite" });
                if (perm !== "granted") perm = await dir.handle.requestPermission({ mode: "readwrite" });
                if (perm === "granted") {
                    const sub = await dir.handle.getDirectoryHandle(dir.folderName, { create: true });
                    const file = await sub.getFileHandle(fileName, { create: true });
                    const w = await file.createWritable(); await w.write(text); await w.close();
                    const check = await (await file.getFile()).text();
                    if (check.length !== text.length) return { ok: false, message: "A cópia foi escrita mas a verificação falhou." };
                    return { ok: true, message: `Cópia guardada em “${dir.drive || ""} … ${dir.handle.name}/${dir.folderName}”.`, fileName };
                }
            } catch { /* cai para o descarregamento */ }
        }
        const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
        const a = document.createElement("a"); a.href = url; a.download = fileName; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        return { ok: true, message: "Cópia descarregada para a pasta de Transferências.", fileName };
    };

    window.WellstatePWA = api;

    /* ---------- Eventos de instalação ---------- */
    window.addEventListener("beforeinstallprompt", e => {
        e.preventDefault();                       // impede a mini-barra do navegador: a decisão é mostrada pelo site
        deferredPrompt = e;
        emit("installable", true);
        syncInstallButton();
    });
    window.addEventListener("appinstalled", () => {
        deferredPrompt = null;
        writeState({ installed: true, at: new Date().toISOString() });
        emit("installed", true);
        syncInstallButton();
    });

    /* ---------- Service worker ---------- */
    function register() {
        if (!supportsSW()) return;
        if (!secure()) return;                    // http://IP não permite service worker; o assistente explica porquê
        navigator.serviceWorker.register("sw.js", { scope: "./" }).then(reg => {
            registration = reg;
            emit("registered", true);
            const watch = worker => {
                if (!worker) return;
                worker.addEventListener("statechange", () => {
                    if (worker.state === "installed" && navigator.serviceWorker.controller) offerUpdate(worker);
                });
            };
            if (reg.waiting && navigator.serviceWorker.controller) offerUpdate(reg.waiting);
            reg.addEventListener("updatefound", () => watch(reg.installing));
            setInterval(() => { reg.update().catch(() => {}); }, 30 * 60 * 1000);
        }).catch(error => { emit("register-error", String(error && error.message || error)); });
        navigator.serviceWorker.addEventListener("controllerchange", () => {
            if (reloading) return; reloading = true; location.reload();
        });
    }

    /* ---------- Interface (dentro do site) ---------- */
    function snack(html, id) {
        let el = document.getElementById(id);
        if (!el) { el = document.createElement("div"); el.id = id; el.className = "pwa-snack"; el.setAttribute("role", "status"); el.setAttribute("aria-live", "polite"); document.body.appendChild(el); }
        el.innerHTML = html;
        requestAnimationFrame(() => el.classList.add("show"));
        return el;
    }
    function offerUpdate(worker) {
        const el = snack('<i class="fa-solid fa-arrow-rotate-right" aria-hidden="true"></i><span><strong>Nova versão disponível</strong><small>Atualize para receber as últimas melhorias.</small></span><button type="button" class="btn-primary btn-sm" data-act="update">Atualizar</button><button type="button" class="icon-btn" data-act="close" aria-label="Fechar aviso"><i class="fa-solid fa-xmark"></i></button>', "pwaUpdate");
        el.onclick = ev => {
            const act = ev.target.closest("[data-act]")?.dataset.act;
            if (act === "update") { try { worker.postMessage({ type: "SKIP_WAITING" }); } catch { location.reload(); } }
            if (act === "close") el.classList.remove("show");
        };
    }
    function syncOffline() {
        const offline = navigator.onLine === false;
        let pill = document.getElementById("pwaOffline");
        if (!offline) { if (pill) pill.classList.remove("show"); return; }
        if (!pill) { pill = document.createElement("div"); pill.id = "pwaOffline"; pill.className = "pwa-offline"; pill.setAttribute("role", "status"); pill.innerHTML = '<i class="fa-solid fa-plane-circle-xmark" aria-hidden="true"></i><span>Sem ligação · modo offline</span>'; document.body.appendChild(pill); }
        requestAnimationFrame(() => pill.classList.add("show"));
    }
    function syncInstallButton() {
        const actions = document.querySelector(".sidebar-footer .footer-actions");
        if (!actions) return;
        let btn = actions.querySelector(".pwa-install");
        if (api.isInstalled()) { if (btn) btn.remove(); return; }
        if (!btn) {
            btn = document.createElement("a");
            btn.className = "footer-btn pwa-install";
            btn.href = "install.html";
            btn.title = "Instalar o Wellstate neste computador";
            btn.setAttribute("aria-label", "Instalar aplicação");
            btn.innerHTML = '<i class="fa-solid fa-download" aria-hidden="true"></i><span>Instalar app</span>';
            actions.prepend(btn);
        }
        btn.classList.toggle("ready", api.canPrompt());
    }

    window.addEventListener("online", () => { syncOffline(); emit("online", true); });
    window.addEventListener("offline", () => { syncOffline(); emit("offline", true); });
    if (window.matchMedia) {
        const mq = window.matchMedia("(display-mode: standalone)");
        const onChange = () => { document.documentElement.classList.toggle("is-standalone", isStandalone()); syncInstallButton(); };
        (mq.addEventListener ? mq.addEventListener("change", onChange) : mq.addListener && mq.addListener(onChange));
    }
    document.documentElement.classList.toggle("is-standalone", isStandalone());

    const boot = () => { syncOffline(); window.addEventListener("load", syncInstallButton); setTimeout(syncInstallButton, 600); };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
    register();
})();

/* Wellstate · assistente de instalação (6 passos).
   Todas as mensagens aparecem dentro do site. As únicas janelas do sistema são as que o
   navegador impõe por segurança: escolher pasta e confirmar "Instalar". */
(function () {
    "use strict";
    const pwa = window.WellstatePWA;
    const $ = id => document.getElementById(id);
    const TOTAL = 6;
    const VERSION = "5.3.0";
    const SS_KEY = "wellstate-install";
    const MIN_FREE_BYTES = 50 * 1024 * 1024;
    const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    const fmtBytes = n => { if (!Number.isFinite(n) || n < 0) return "n/d"; const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0; while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; } return `${n.toFixed(n >= 10 || i === 0 ? 0 : 1)} ${u[i]}`; };
    const sleep = ms => new Promise(r => setTimeout(r, ms));

    if (!pwa) { document.body.innerHTML = '<main class="wiz-card" style="padding:40px"><h1>Erro</h1><p>Não foi possível carregar o módulo de instalação (pwa.js). Recarregue a página.</p></main>'; return; }
    const env = pwa.env();

    /* ---------- discos por sistema ---------- */
    const DRIVES = env.os === "Windows" ? [["C:", "Disco C:"], ["D:", "Disco D:"], ["E:", "Disco E:"], ["F:", "Disco F:"], ["G:", "Disco G:"], ["Externo", "USB / Rede"]]
        : env.os === "macOS" ? [["Macintosh HD", "Macintosh HD"], ["Externo", "Disco externo"]]
        : env.os === "Linux" || env.os === "ChromeOS" ? [["Principal", "Disco principal"], ["Externo", "Disco externo"]]
        : [["Dispositivo", "Armazenamento do dispositivo"]];
    const DRIVE_VALUES = DRIVES.map(d => d[0]);

    /* ---------- estado (validado ao carregar) ---------- */
    const state = { step: 1, drive: "", folderName: "Wellstate", pcName: "", opts: { offline: true, persist: true, notify: false }, useDownloads: false, folderLabel: "", checksOk: false, checksRunning: false, results: {}, phase: "prepare", picked: null };

    function loadState() {
        let raw = null; try { raw = sessionStorage.getItem(SS_KEY); } catch { /* bloqueado */ }
        if (!raw) return;
        let s; try { s = JSON.parse(raw); } catch { return; }
        if (!s || typeof s !== "object") return;
        if (Number.isInteger(s.step) && s.step >= 1 && s.step <= TOTAL) state.step = s.step;
        if (typeof s.drive === "string" && DRIVE_VALUES.includes(s.drive)) state.drive = s.drive;
        if (typeof s.folderName === "string" && !pwa.validateFolderName(s.folderName)) state.folderName = s.folderName;
        if (typeof s.pcName === "string" && s.pcName.length <= 40) state.pcName = s.pcName;
        if (s.opts && typeof s.opts === "object") for (const k of ["offline", "persist", "notify"]) if (typeof s.opts[k] === "boolean") state.opts[k] = s.opts[k];
        state.useDownloads = s.useDownloads === true;
        if (typeof s.folderLabel === "string") state.folderLabel = s.folderLabel.slice(0, 120);
    }
    function saveState() {
        try { sessionStorage.setItem(SS_KEY, JSON.stringify({ step: state.step, drive: state.drive, folderName: state.folderName, pcName: state.pcName, opts: state.opts, useDownloads: state.useDownloads, folderLabel: state.folderLabel })); } catch { /* ignora */ }
    }

    /* ---------- mensagens ---------- */
    const alertBox = $("wizAlert");
    function showAlert(msg, kind) { alertBox.textContent = msg; alertBox.className = "form-alert show" + (kind ? " " + kind : ""); }
    function clearAlert() { alertBox.className = "form-alert"; alertBox.textContent = ""; }
    function setFieldError(fieldId, errorId, msg) {
        const f = $(fieldId), e = $(errorId);
        if (f) { f.classList.toggle("invalid", !!msg); f.classList.toggle("valid", !msg && f.querySelector("input").value.trim() !== ""); }
        if (e) e.textContent = msg || "";
    }

    /* ---------- navegação ---------- */
    const stepEls = [...document.querySelectorAll(".wiz-step")];
    const stepperEls = [...document.querySelectorAll("#wizSteps li")];
    function render() {
        stepEls.forEach(el => { el.hidden = Number(el.dataset.step) !== state.step; });
        stepperEls.forEach(li => { const n = Number(li.dataset.step); li.classList.toggle("active", n === state.step); li.classList.toggle("done", n < state.step || state.step === TOTAL && n === TOTAL); if (n === state.step) li.setAttribute("aria-current", "step"); else li.removeAttribute("aria-current"); });
        $("wizCount").textContent = `Passo ${state.step} de ${TOTAL}`;
        $("wizBar").style.width = `${(state.step / TOTAL) * 100}%`;
        $("btnBack").hidden = state.step === 1 || state.step === TOTAL;
        $("btnNext").hidden = state.step === 5 || state.step === TOTAL;
        $("btnLeave").hidden = state.step === TOTAL;
        document.querySelector(".wiz-nav").hidden = state.step === TOTAL;
        updateNext();
        saveState();
    }
    function updateNext() {
        const btn = $("btnNext");
        let disabled = false, title = "";
        if (state.step === 2 && (state.checksRunning || !state.checksOk)) { disabled = true; title = state.checksRunning ? "A verificar…" : "Resolva os problemas assinalados a vermelho."; }
        btn.disabled = disabled; btn.title = title;
    }
    function go(n, { focus = true } = {}) {
        if (!Number.isInteger(n) || n < 1 || n > TOTAL) return;
        clearAlert();
        state.step = n; render();
        if (n === 2) runChecks();
        if (n === 3) renderStep3();
        if (n === 5) renderStep5();
        if (n === 6) renderSummary();
        if (focus) { const h = document.querySelector(`.wiz-step[data-step="${n}"] h2`); if (h) { h.setAttribute("tabindex", "-1"); h.focus({ preventScroll: false }); } }
    }

    /* ---------- validação por passo ---------- */
    function validateStep(n) {
        if (n === 2) { if (state.checksRunning) return "Aguarde o fim da verificação."; if (!state.checksOk) return "Há verificações com falha. Resolva-as e volte a verificar."; }
        if (n === 3) {
            let ok = true;
            if (!state.drive || !DRIVE_VALUES.includes(state.drive)) { $("driveError").textContent = "Escolha o disco onde quer guardar os ficheiros."; ok = false; } else $("driveError").textContent = "";
            const nameErr = pwa.validateFolderName($("folderName").value);
            setFieldError("folderField", "folderError", nameErr); if (nameErr) ok = false;
            const hasFolder = !!(state.picked && state.picked.folderName === $("folderName").value);
            if (!hasFolder && !(state.useDownloads && !env.hasPicker)) {
                $("pickError").textContent = env.hasPicker ? "Escolha a pasta no computador (botão “Escolher pasta”)." : "Autorize o uso da pasta de Transferências para continuar.";
                ok = false;
            } else $("pickError").textContent = "";
            if (!ok) return "Corrija os campos assinalados para continuar.";
        }
        if (n === 4) {
            const v = $("pcName").value.trim();
            const err = !v ? "Dê um nome ao computador." : v.length < 2 ? "Use pelo menos 2 caracteres." : v.length > 40 ? "Use no máximo 40 caracteres." : !/^[\p{L}\p{N}][\p{L}\p{N} ._\-·]*$/u.test(v) ? "Use apenas letras, números, espaços, ponto, hífen ou _." : "";
            setFieldError("pcNameField", "pcNameError", err);
            if (err) return "Corrija o nome do computador.";
            state.pcName = v;
        }
        return "";
    }

    /* ---------- passo 2: verificações ---------- */
    const ICON = { run: "fa-spinner", ok: "fa-check", warn: "fa-exclamation", fail: "fa-xmark", wait: "fa-ellipsis" };
    function rowHtml(id, label, status, detail) { return `<li class="${status}" data-id="${id}"><span class="ico"><i class="fa-solid ${ICON[status]}"></i></span><div><strong>${esc(label)}</strong><small>${esc(detail || "")}</small></div></li>`; }
    function validateManifest(m) {
        const errs = [];
        if (!m || typeof m !== "object") return ["Manifesto inválido."];
        if (typeof m.name !== "string" || !m.name.trim()) errs.push("falta o nome");
        if (typeof m.start_url !== "string" || !m.start_url) errs.push("falta start_url");
        if (!["standalone", "fullscreen", "minimal-ui"].includes(m.display)) errs.push("display deve ser standalone");
        const icons = Array.isArray(m.icons) ? m.icons : [];
        const has = px => icons.some(i => i && typeof i.src === "string" && typeof i.sizes === "string" && i.sizes.split(/\s+/).some(sz => sz === `${px}x${px}`));
        if (!has(192)) errs.push("falta ícone 192×192"); if (!has(512)) errs.push("falta ícone 512×512");
        return errs;
    }
    async function runChecks() {
        if (state.checksRunning) return;
        state.checksRunning = true; state.checksOk = false; updateNext();
        const list = $("checkList"), tip = $("checkTip"); tip.hidden = true;
        const defs = [
            ["secure", "Ligação segura"], ["browser", "Navegador compatível"], ["sw", "Suporte a modo offline"], ["manifest", "Manifesto da aplicação"],
            ["icons", "Ícones da aplicação"], ["worker", "Motor offline (service worker)"], ["storage", "Espaço livre no navegador"], ["server", "Servidor do Wellstate"]
        ];
        list.innerHTML = defs.map(([id, l]) => rowHtml(id, l, "wait", "Em espera")).join("");
        const set = (id, status, detail) => { const el = list.querySelector(`[data-id="${id}"]`); if (el) el.outerHTML = rowHtml(id, defs.find(d => d[0] === id)[1], status, detail); };
        const results = {};
        const step = async (id, fn) => {
            set(id, "run", "A verificar…");
            let r; try { r = await fn(); } catch (e) { r = { s: "fail", d: "Erro inesperado: " + (e && e.message || e) }; }
            results[id] = r.s; set(id, r.s, r.d); await sleep(120);
        };
        await step("secure", async () => env.secure ? { s: "ok", d: location.origin } : { s: "fail", d: `Aberto por ${location.protocol}//${location.host} (sem HTTPS).` });
        await step("browser", async () => {
            if (env.browser === "Edge" || env.browser === "Chrome" || env.browser === "Opera") return { s: "ok", d: `${env.browser} em ${env.os}` };
            if (env.browser === "Safari") return { s: "warn", d: "Safari: a instalação é manual (Adicionar ao Dock / ecrã principal)." };
            if (env.browser === "Firefox") return { s: env.desktop ? "warn" : "ok", d: env.desktop ? "O Firefox para computador não instala aplicações web. Use Edge ou Chrome." : "Firefox móvel" };
            return { s: "warn", d: "Navegador não testado. Recomendamos Edge ou Chrome." };
        });
        await step("sw", async () => ("serviceWorker" in navigator && "caches" in window) ? { s: "ok", d: "Service workers e Cache API disponíveis." } : { s: "fail", d: "Este navegador não suporta service workers/Cache API (ou é preciso HTTPS)." });
        await step("manifest", async () => {
            const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 7000);
            try {
                const r = await fetch(new URL("manifest.webmanifest", location.href), { cache: "no-store", signal: ctl.signal });
                if (!r.ok) return { s: "fail", d: `O servidor respondeu ${r.status} ao pedir o manifesto.` };
                let m; try { m = await r.json(); } catch { return { s: "fail", d: "O manifesto não é um JSON válido." }; }
                const errs = validateManifest(m);
                return errs.length ? { s: "fail", d: "Manifesto incompleto: " + errs.join(", ") + "." } : { s: "ok", d: `${m.name}` };
            } catch { return { s: "fail", d: "Não foi possível carregar o manifesto. O servidor está a correr?" }; } finally { clearTimeout(t); }
        });
        await step("icons", async () => {
            for (const px of [192, 512]) {
                const r = await fetch(new URL(`img/icons/icon-${px}.png`, location.href), { cache: "no-store" }).catch(() => null);
                if (!r || !r.ok) return { s: "fail", d: `Ícone ${px}×${px} inacessível.` };
                if (!(r.headers.get("content-type") || "").includes("image/png")) return { s: "fail", d: `Ícone ${px}×${px} não é PNG (tipo ${r.headers.get("content-type") || "desconhecido"}).` };
            }
            return { s: "ok", d: "192×192, 512×512 e versão adaptável." };
        });
        await step("worker", async () => {
            if (results.secure !== "ok" || results.sw !== "ok") return { s: "fail", d: "Requer ligação segura e suporte a service workers." };
            try {
                const reg = await navigator.serviceWorker.register("sw.js", { scope: "./" });
                const ready = await Promise.race([navigator.serviceWorker.ready, sleep(9000).then(() => null)]);
                if (!ready) return { s: "warn", d: "O motor offline está a arrancar. Pode continuar." };
                return { s: "ok", d: "Ativo (âmbito " + new URL(reg.scope).pathname + ")." };
            } catch (e) { return { s: "fail", d: "Falha ao registar: " + (e && e.message || e) }; }
        });
        await step("storage", async () => {
            if (!navigator.storage || !navigator.storage.estimate) return { s: "warn", d: "O navegador não informa o espaço livre." };
            const { quota = 0, usage = 0 } = await navigator.storage.estimate(); const free = quota - usage;
            if (!(quota > 0)) return { s: "warn", d: "Espaço desconhecido." };
            return free >= MIN_FREE_BYTES ? { s: "ok", d: `${fmtBytes(free)} livres.` } : { s: "fail", d: `Só ${fmtBytes(free)} livres. São necessários pelo menos ${fmtBytes(MIN_FREE_BYTES)}.` };
        });
        await step("server", async () => {
            if (!navigator.onLine) return { s: "fail", d: "Sem ligação de rede." };
            const t0 = performance.now();
            const r = await fetch(new URL("login.html", location.href), { cache: "no-store" }).catch(() => null);
            return r && r.ok ? { s: "ok", d: `Resposta em ${Math.round(performance.now() - t0)} ms.` } : { s: "fail", d: "O servidor não respondeu." };
        });
        const fails = Object.values(results).filter(s => s === "fail").length, warns = Object.values(results).filter(s => s === "warn").length;
        state.checksRunning = false; state.checksOk = fails === 0; state.results.checks = results;
        if (results.secure === "fail") {
            tip.className = "wiz-tip bad"; tip.hidden = false;
            tip.innerHTML = `<i class="fa-solid fa-lock-open" aria-hidden="true"></i><span><b>Porque falhou?</b> Os navegadores só instalam aplicações em <b>HTTPS</b> ou em <b>localhost</b>. Neste computador abra <code>http://localhost:8000</code>. Para outros PCs da rede, ponha o servidor atrás de HTTPS (por exemplo com mkcert ou Caddy).</span>`;
        } else if (fails) { tip.className = "wiz-tip bad"; tip.hidden = false; tip.innerHTML = `<i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i><span>${fails} verificação(ões) falharam. Corrija e carregue em “Verificar novamente”.</span>`; }
        else if (warns) { tip.className = "wiz-tip warn"; tip.hidden = false; tip.innerHTML = `<i class="fa-solid fa-circle-info" aria-hidden="true"></i><span>Pode continuar, mas leia os avisos em destaque: algumas funções podem ser manuais.</span>`; }
        else if (pwa.isInstalled()) { tip.className = "wiz-tip"; tip.hidden = false; tip.innerHTML = '<i class="fa-solid fa-circle-check" aria-hidden="true"></i><span>O Wellstate já está instalado neste computador. Pode repetir a configuração.</span>'; }
        updateNext();
    }

    /* ---------- passo 3: disco e pasta ---------- */
    let step3Ready = false;
    async function renderStep3() {
        const tiles = [["Sistema", env.os], ["Navegador", env.browser], ["Processador", env.cores ? `${env.cores} ${env.cores === 1 ? "núcleo" : "núcleos"}` : "n/d"], ["Memória", env.memoryGb ? `≈ ${env.memoryGb} GB` : "n/d"]];
        let free = "n/d"; try { if (navigator.storage && navigator.storage.estimate) { const e = await navigator.storage.estimate(); if (e.quota > 0) free = fmtBytes(e.quota - e.usage); } } catch { /* ignora */ }
        tiles.push(["Espaço do navegador", free], ["Ligação", navigator.onLine ? "Ativa" : "Sem rede"]);
        $("pcInfo").innerHTML = tiles.map(([k, v]) => `<div class="tile"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join("");
        const chips = $("driveChips");
        chips.innerHTML = DRIVES.map(([v, l]) => `<label class="chip-radio"><input type="radio" name="drive" value="${esc(v)}" ${state.drive === v ? "checked" : ""}><span><i class="fa-solid ${v === "Externo" ? "fa-usb" : "fa-hard-drive"}" aria-hidden="true"></i>${esc(l)}</span></label>`).join("");
        if (!step3Ready) {
            step3Ready = true;
            chips.addEventListener("change", e => { if (e.target.name === "drive" && DRIVE_VALUES.includes(e.target.value)) { state.drive = e.target.value; $("driveError").textContent = ""; refreshPicked(); saveState(); } });
            $("folderName").addEventListener("input", () => {
                const v = $("folderName").value, err = pwa.validateFolderName(v);
                setFieldError("folderField", "folderError", err);
                if (!err) state.folderName = v;
                if (state.picked && state.picked.folderName !== v) { state.picked = null; $("pickError").textContent = "O nome mudou. Escolha a pasta novamente para criar a nova sub-pasta."; refreshPicked(); } else if (!err) $("pickError").textContent = "";
                saveState();
            });
            $("pickFolder").addEventListener("click", pickFolder);
            $("useDownloads").addEventListener("change", e => { state.useDownloads = e.target.checked; if (e.target.checked) $("pickError").textContent = ""; saveState(); refreshPicked(); });
        }
        $("folderName").value = state.folderName;
        const noPicker = !env.hasPicker;
        $("pickFolder").disabled = noPicker; $("downloadsOpt").hidden = !noPicker; $("useDownloads").checked = state.useDownloads;
        $("pickTip").hidden = noPicker;
        refreshPicked();
    }
    function refreshPicked() {
        const el = $("pickedInfo");
        if (state.picked) { el.className = "picked ok"; el.innerHTML = `<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Pasta pronta e com escrita testada<small>${esc(state.drive || "?")} › … › ${esc(state.picked.handle.name || "pasta escolhida")} › ${esc(state.picked.folderName)}</small>`; }
        else if (!env.hasPicker) { el.className = "picked"; el.textContent = state.useDownloads ? "Os ficheiros irão para a pasta de Transferências." : "Este navegador não permite escolher pastas."; }
        else { el.className = "picked"; el.textContent = "Nenhuma pasta escolhida."; }
    }
    async function pickFolder() {
        $("pickError").textContent = "";
        if (!state.drive) { $("driveError").textContent = "Escolha primeiro o disco."; $("driveChips").querySelector("input")?.focus(); return; }
        const nameErr = pwa.validateFolderName($("folderName").value);
        if (nameErr) { setFieldError("folderField", "folderError", nameErr); $("folderName").focus(); return; }
        if (!env.hasPicker) return;
        const folderName = $("folderName").value;
        const btn = $("pickFolder"); btn.disabled = true;
        try {
            const handle = await window.showDirectoryPicker({ id: "wellstate-install", mode: "readwrite", startIn: "documents" });
            if (!handle || handle.kind !== "directory") throw Object.assign(new Error("tipo"), { name: "TypeMismatchError" });
            let perm = await handle.queryPermission({ mode: "readwrite" });
            if (perm !== "granted") perm = await handle.requestPermission({ mode: "readwrite" });
            if (perm !== "granted") throw Object.assign(new Error("negado"), { name: "NotAllowedError" });
            const sub = await handle.getDirectoryHandle(folderName, { create: true });
            const probe = await sub.getFileHandle(".wellstate-teste", { create: true });
            const w = await probe.createWritable(); await w.write("wellstate-ok"); await w.close();
            const back = await (await probe.getFile()).text();
            await sub.removeEntry(".wellstate-teste");
            if (back !== "wellstate-ok") throw Object.assign(new Error("leitura"), { name: "DataError" });
            state.picked = { handle, folderName };
            await pwa.store.set("dataDir", { handle, folderName, drive: state.drive, at: new Date().toISOString() });
            state.folderLabel = `${state.drive} › … › ${handle.name || "pasta escolhida"} › ${folderName}`; saveState();
        } catch (e) {
            state.picked = null;
            const n = e && e.name;
            $("pickError").textContent = n === "AbortError" ? "Seleção cancelada. Carregue em “Escolher pasta” para tentar de novo."
                : n === "NotAllowedError" ? "Sem permissão de escrita nessa pasta. Escolha outra ou autorize o acesso quando o navegador perguntar."
                : n === "SecurityError" ? "O navegador bloqueou esta pasta por segurança (raiz do disco ou pasta do sistema). Crie uma pasta nova no disco pretendido e escolha-a."
                : n === "TypeError" ? "O nome da pasta não é aceite pelo sistema. Altere-o e tente de novo."
                : n === "NoModificationAllowedError" ? "A pasta é só de leitura ou está a ser usada por outro programa."
                : n === "DataError" ? "A escrita de teste não foi confirmada. Escolha outra pasta."
                : "Não foi possível usar essa pasta: " + (e && e.message || "erro desconhecido") + ".";
        } finally { btn.disabled = false; refreshPicked(); }
    }

    /* ---------- passo 5: tarefas ---------- */
    const TASKS = [
        ["perm", "Autorizar escrita na pasta", () => !!state.picked],
        ["notify", "Ativar notificações", () => state.opts.notify],
        ["persist", "Proteger os dados guardados", () => state.opts.persist],
        ["offline", "Preparar modo offline", () => state.opts.offline],
        ["files", "Guardar ficheiros de instalação", () => true]
    ];
    function renderStep5() {
        state.phase = "prepare"; $("manual").hidden = true; $("runError").textContent = ""; $("ackError").textContent = "";
        const active = TASKS.filter(t => t[2]());
        $("taskList").innerHTML = TASKS.map(([id, label, on]) => `<li class="${on() ? "wait" : "skip"}" data-id="${id}"><span class="ico"><i class="fa-solid ${on() ? ICON.wait : "fa-minus"}"></i></span><span>${esc(label)}</span><small>${on() ? "Em espera" : "Desativado"}</small></li>`).join("");
        setProgress(0, active.length);
        updateConfirm();
        if (pwa.isStandalone()) { $("confirmText").textContent = "A aplicação já está instalada e a correr como app."; }
    }
    function setTask(id, status, detail) {
        const el = document.querySelector(`#taskList [data-id="${id}"]`); if (!el) return;
        el.className = status; el.querySelector(".ico i").className = "fa-solid " + ICON[status]; el.querySelector("small").textContent = detail || "";
    }
    function setProgress(done, total) {
        const pct = total ? Math.round((done / total) * 100) : 0; const p = $("progress");
        p.setAttribute("aria-valuenow", String(pct)); $("progressBar").style.width = pct + "%"; p.classList.toggle("done", pct === 100);
    }
    function updateConfirm() {
        const btn = $("runInstall").querySelector("span"), txt = $("confirmText");
        if (state.phase === "prepare") { btn.textContent = "Preparar e instalar"; txt.innerHTML = "Primeiro preparamos tudo aqui. Depois, ao carregar em <b>Instalar agora</b>, o navegador mostra uma pequena janela de confirmação: escolha <b>Instalar</b> nessa janela."; }
        else { btn.textContent = pwa.canPrompt() ? "Instalar agora" : "Ver como instalar"; txt.innerHTML = pwa.canPrompt() ? "Preparação concluída. Carregue em <b>Instalar agora</b> e confirme na janela do navegador." : "Preparação concluída. Este navegador não abre o pedido automático. Siga as instruções abaixo."; }
    }
    async function runTasks() {
        const active = TASKS.filter(t => t[2]()); let done = 0; const out = state.results;
        const finish = (id, status, detail) => { setTask(id, status, detail); done++; setProgress(done, active.length); };
        const run = async (id, fn) => {
            if (!active.find(t => t[0] === id)) return;
            setTask(id, "run", "A executar…");
            try { const r = await fn(); finish(id, r.s, r.d); out[id] = r; } catch (e) { finish(id, "fail", e && e.message || "Erro"); out[id] = { s: "fail", d: String(e && e.message || e) }; }
        };
        await run("perm", async () => {
            let p = await state.picked.handle.queryPermission({ mode: "readwrite" });
            if (p !== "granted") p = await state.picked.handle.requestPermission({ mode: "readwrite" });
            if (p !== "granted") throw new Error("Permissão recusada. Volte ao passo 3 e escolha a pasta de novo.");
            return { s: "ok", d: "Concedida" };
        });
        if (out.perm && out.perm.s === "fail") return false;
        await run("notify", async () => {
            if (!("Notification" in window)) return { s: "warn", d: "Não suportado" };
            if (Notification.permission === "granted") return { s: "ok", d: "Já ativas" };
            if (Notification.permission === "denied") return { s: "warn", d: "Bloqueadas no navegador" };
            const r = await Notification.requestPermission(); return r === "granted" ? { s: "ok", d: "Ativas" } : { s: "warn", d: "Não autorizadas" };
        });
        await run("persist", async () => {
            if (!navigator.storage || !navigator.storage.persist) return { s: "warn", d: "Não suportado" };
            if (await navigator.storage.persisted()) return { s: "ok", d: "Já protegido" };
            return (await navigator.storage.persist()) ? { s: "ok", d: "Protegido" } : { s: "warn", d: "O navegador não concedeu" };
        });
        await run("offline", async () => {
            if (!env.secure || !("serviceWorker" in navigator)) return { s: "warn", d: "Indisponível sem HTTPS" };
            const r = await pwa.precache((d, t) => setTask("offline", "run", `${d}/${t}`));
            return r.failed ? { s: "warn", d: `${r.total - r.failed}/${r.total} ficheiros` } : { s: "ok", d: `${r.total} ficheiros` };
        });
        await run("files", async () => {
            const info = { app: "Wellstate", versao: VERSION, computador: state.pcName, disco: state.drive, pasta: state.folderName, instaladoEm: new Date().toISOString(), origem: location.origin, sistema: env.os, navegador: env.browser };
            const json = JSON.stringify(info, null, 2);
            const readme = `Wellstate ${VERSION}\r\nComputador: ${state.pcName}\r\nEsta pasta guarda cópias de segurança e o registo de instalação do Wellstate.\r\nPode apagar a pasta a qualquer momento sem afetar o servidor.\r\n`;
            if (state.picked) {
                const sub = await state.picked.handle.getDirectoryHandle(state.picked.folderName, { create: true });
                for (const [name, text] of [["wellstate-instalacao.json", json], ["LEIA-ME.txt", readme]]) {
                    const fh = await sub.getFileHandle(name, { create: true });
                    const w = await fh.createWritable(); await w.write(text); await w.close();
                    if ((await (await fh.getFile()).text()).length !== text.length) throw new Error(`Verificação falhou em ${name}`);
                }
                return { s: "ok", d: "2 ficheiros" };
            }
            const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
            const a = document.createElement("a"); a.href = url; a.download = "wellstate-instalacao.json"; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
            return { s: "ok", d: "Transferido" };
        });
        try { localStorage.setItem("wellstate-pc", JSON.stringify({ name: state.pcName, drive: state.drive, folder: state.folderName, at: new Date().toISOString() })); } catch { /* ignora */ }
        return true;
    }
    function manualSteps() {
        const b = env.browser, os = env.os; let title = "Instalação manual", steps = [];
        if (b === "Edge") steps = ["Clique nos três pontos <b>(…)</b> no canto superior direito.", "Escolha <b>Aplicações</b>.", "Clique em <b>Instalar este site como uma aplicação</b> e confirme."];
        else if (b === "Chrome" && os === "iOS") steps = ["Toque em <b>Partilhar</b>.", "Escolha <b>Adicionar ao ecrã principal</b>."];
        else if (b === "Chrome") steps = ["Clique no ícone de instalação <b>⊕</b> no fim da barra de endereços, ou nos três pontos <b>⋮</b>.", "Escolha <b>Guardar e partilhar › Instalar página como app</b>.", "Confirme em <b>Instalar</b>."];
        else if (b === "Safari" && os === "iOS") steps = ["Toque em <b>Partilhar</b> (quadrado com seta).", "Escolha <b>Adicionar ao ecrã principal</b>.", "Toque em <b>Adicionar</b>."];
        else if (b === "Safari") steps = ["No menu <b>Ficheiro</b>, escolha <b>Adicionar ao Dock…</b>.", "Confirme o nome e clique em <b>Adicionar</b>."];
        else if (b === "Firefox") { title = "Firefox não instala aplicações"; steps = ["O Firefox para computador não suporta instalação de apps web.", "Abra este endereço no <b>Microsoft Edge</b> ou no <b>Google Chrome</b> e repita o assistente."]; }
        else steps = ["Procure no menu do navegador a opção <b>Instalar aplicação</b> ou <b>Adicionar ao ecrã principal</b>."];
        const m = $("manual"); m.hidden = false;
        m.innerHTML = `<h3>${esc(title)}</h3><ol>${steps.map(s => `<li>${s}</li>`).join("")}</ol>`;
        $("alreadyInstalled").hidden = b === "Firefox" && env.desktop;
    }
    async function onInstallClick() {
        $("runError").textContent = ""; $("ackError").textContent = ""; clearAlert();
        const btn = $("runInstall");
        if (state.phase === "prepare") {
            if (!$("ack").checked) { $("ackError").textContent = "Marque a caixa para confirmar que leu o aviso."; $("ack").focus(); return; }
            if (!state.picked && !state.useDownloads) { showAlert("Falta escolher a pasta no passo 3.", ""); return; }
            if (!state.pcName) { showAlert("Falta o nome do computador no passo 4.", ""); return; }
            btn.disabled = true; $("ack").disabled = true;
            const ok = await runTasks();
            btn.disabled = false; $("ack").disabled = false;
            if (!ok) { $("runError").textContent = "A preparação foi interrompida. Corrija o problema indicado e tente de novo."; return; }
            state.phase = "install";
            if (pwa.isInstalled() && pwa.isStandalone()) { go(6); return; }
            updateConfirm(); btn.focus();
            return;
        }
        if (pwa.canPrompt()) {
            btn.disabled = true;
            const r = await pwa.prompt();
            btn.disabled = false;
            if (r.outcome === "accepted") { state.results.installed = true; await sleep(400); go(6); }
            else if (r.outcome === "dismissed") { showAlert("A instalação foi cancelada. Quando quiser, carregue outra vez em “Instalar agora”.", "info"); updateConfirm(); }
            else { $("runError").textContent = "O navegador não conseguiu abrir o pedido (" + (r.message || r.outcome) + ")."; manualSteps(); }
            return;
        }
        manualSteps();
    }

    /* ---------- passo 6 ---------- */
    function renderSummary() {
        const r = state.results, installed = pwa.isInstalled() || r.installed === true || r.manual === true;
        const label = x => !x ? "Não executado" : x.s === "ok" ? (x.d || "Sim") : x.d || "Aviso";
        const rows = [["Computador", state.pcName || "—"], ["Sistema", `${env.os} · ${env.browser}`], ["Disco", state.drive || "—"], ["Pasta", state.picked ? `…/${state.picked.handle.name || "pasta escolhida"}/${state.picked.folderName}` : state.useDownloads ? "Transferências" : "—"],
            ["Modo offline", state.opts.offline ? label(r.offline) : "Desativado"], ["Dados protegidos", state.opts.persist ? label(r.persist) : "Desativado"], ["Notificações", state.opts.notify ? label(r.notify) : "Desativadas"],
            ["Aplicação", installed ? "Instalada" : "Aberta no navegador"]];
        $("summary").innerHTML = rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join("");
        $("doneLead").textContent = installed ? "O Wellstate está instalado. Procure “Wellstate” no menu Iniciar, no Launchpad ou no ambiente de trabalho." : "A configuração está feita. Pode instalar a qualquer momento pelo botão “Instalar app” do painel.";
        try { sessionStorage.removeItem(SS_KEY); } catch { /* ignora */ }
    }

    /* ---------- eventos ---------- */
    $("btnNext").addEventListener("click", () => { const err = validateStep(state.step); if (err) { showAlert(err); return; } go(state.step + 1); });
    $("btnBack").addEventListener("click", () => go(state.step - 1));
    $("recheck").addEventListener("click", () => runChecks());
    $("runInstall").addEventListener("click", onInstallClick);
    $("alreadyInstalled").addEventListener("click", () => {
        if (!pwa.isInstalled() && !confirm_("Não conseguimos confirmar a instalação automaticamente. Já instalou mesmo a aplicação?")) return;
        state.results.manual = true; go(6);
    });
    function confirm_(msg) { return window.confirm(msg); }
    ["optOffline", "optPersist", "optNotify"].forEach(id => $(id).addEventListener("change", e => { state.opts[{ optOffline: "offline", optPersist: "persist", optNotify: "notify" }[id]] = e.target.checked; saveState(); }));
    $("pcName").addEventListener("input", () => { setFieldError("pcNameField", "pcNameError", ""); });
    document.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.tagName === "INPUT" && e.target.type === "text") { e.preventDefault(); if (!$("btnNext").hidden && !$("btnNext").disabled) $("btnNext").click(); } });
    pwa.on(type => { if (type === "installable" && state.step === 5) updateConfirm(); if (type === "installed" && state.step === 5 && state.phase === "install") { state.results.installed = true; go(6); } });
    window.addEventListener("online", () => { if (state.step === 2) runChecks(); });

    /* ---------- arranque ---------- */
    loadState();
    $("pcName").value = state.pcName;
    $("optOffline").checked = state.opts.offline; $("optPersist").checked = state.opts.persist; $("optNotify").checked = state.opts.notify;
    (async () => {
        const saved = await pwa.store.get("dataDir");
        if (saved && saved.handle && saved.folderName === state.folderName && state.drive) { try { if ((await saved.handle.queryPermission({ mode: "readwrite" })) === "granted") state.picked = { handle: saved.handle, folderName: saved.folderName }; } catch { /* ignora */ } }
        if (state.step >= 4 && !state.picked && !(state.useDownloads && !env.hasPicker)) state.step = 3;
        if (state.step === 6) state.step = 1;
        if (pwa.isStandalone() && state.step === 1) { state.step = 6; }
        go(state.step, { focus: false });
    })();
})();

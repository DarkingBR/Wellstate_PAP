/* Página offline: tenta voltar sozinha quando a rede regressa. */
(function () {
    const status = document.getElementById("status");
    const retry = document.getElementById("retry");
    const say = text => { if (status) status.textContent = text; };
    const back = () => { location.replace(new URL("dashboard.html", location.href).href); };
    window.addEventListener("online", () => { say("Ligação restabelecida. A reabrir…"); setTimeout(back, 600); });
    if (retry) retry.addEventListener("click", async () => {
        if (!navigator.onLine) { say("O dispositivo continua sem rede. Verifique o Wi-Fi ou o cabo."); return; }
        retry.disabled = true; say("A testar a ligação…");
        try {
            const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
            const r = await fetch("login.html", { cache: "no-store", signal: ctl.signal }); clearTimeout(t);
            if (r.ok) { say("Servidor encontrado. A reabrir…"); back(); return; }
            say("O servidor respondeu com erro (" + r.status + "). Tente dentro de instantes.");
        } catch { say("Servidor inacessível. Confirme que o PHP está a correr."); }
        retry.disabled = false;
    });
})();

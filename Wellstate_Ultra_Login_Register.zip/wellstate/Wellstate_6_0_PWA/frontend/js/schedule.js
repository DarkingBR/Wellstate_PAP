/* Horários escolares — grelha semanal e leitura de documento por foto. */
(function () {
    const body = document.getElementById("scheduleBody");
    let STORE = window.WELLSTATE_STORE;
    const days = [1, 2, 3, 4, 5];
    const dialog = document.getElementById("lessonDialog");
    const form = document.getElementById("lessonForm");
    const addBtn = document.getElementById("addLessonBtn");
    addBtn.hidden = false;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
    const roomName = id => STORE.rooms.find(room => room.id === id)?.name || id || "Sala por definir";

    function render() {
        body.replaceChildren();
        const timeSlots = window.TIME_SLOTS || [];
        timeSlots.forEach(slot => {
            const [start, end] = slot.split(" - ");
            const row = document.createElement("tr");
            const timeCell = document.createElement("td");
            timeCell.className = "cell-slot";
            timeCell.textContent = slot;
            row.appendChild(timeCell);
            days.forEach(day => {
                const cell = document.createElement("td");
                const lesson = (STORE.schedule[day] || []).find(item => item.start < end && item.end > start);
                if (!lesson) {
                    cell.textContent = "—";
                    cell.className = "empty-slot";
                } else {
                    const index = (STORE.schedule[day] || []).indexOf(lesson);
                    cell.className = "has-class";
                    cell.innerHTML = `<div class="lesson-cell"><strong>${esc(lesson.subject)}</strong><span class="lesson-group">${esc(lesson.group || "Turma por definir")}</span><span class="lesson-room"><i class="fa-solid fa-location-dot"></i> ${esc(roomName(lesson.room))}</span><span class="lesson-time">${esc(lesson.start)}–${esc(lesson.end)}</span><button class="lesson-edit" type="button" data-edit-day="${day}" data-edit-index="${index}" aria-label="Editar aula"><i class="fa-solid fa-pen"></i><span>Editar</span></button></div>`;
                }
                row.appendChild(cell);
            });
            body.appendChild(row);
        });
        fillRooms();
        fillScanRooms();
    }

    function fillRooms(selected) {
        const select = document.getElementById("lessonRoom");
        if (!select) return;
        select.innerHTML = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        if (selected) select.value = selected;
    }

    function fillScanRooms() {
        const select = document.getElementById("scanRoom");
        if (!select) return;
        select.innerHTML = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
    }

    function openEditor(day, index) {
        const editing = day != null && index != null ? STORE.schedule[day]?.[Number(index)] : null;
        document.getElementById("lessonDialogTitle").textContent = editing ? "Editar aula" : "Adicionar aula";
        document.getElementById("deleteLessonBtn").hidden = !editing;
        document.getElementById("lessonIndex").value = editing ? String(index) : "";
        document.getElementById("lessonDay").value = String(editing?.day || day || 1);
        document.getElementById("lessonDay").dataset.originalDay = editing ? String(editing.day || day) : "";
        fillRooms(editing?.room);
        document.getElementById("lessonSubject").value = editing?.subject || "";
        document.getElementById("lessonGroup").value = editing?.group || "";
        document.getElementById("lessonTeacher").value = editing?.teacher || "";
        if (editing) {
            document.getElementById("lessonStart").value = editing.start;
            document.getElementById("lessonEnd").value = editing.end;
        } else {
            document.getElementById("lessonStart").value = "08:15";
            document.getElementById("lessonEnd").value = "09:05";
        }
        document.getElementById("lessonFormError").textContent = "";
        dialog.showModal();
    }

    function closeEditor() { dialog.close(); }
    addBtn.addEventListener("click", () => openEditor());
    body.addEventListener("click", event => {
        const button = event.target.closest("[data-edit-day]");
        if (button) openEditor(button.dataset.editDay, button.dataset.editIndex);
    });
    document.getElementById("closeLessonDialog").addEventListener("click", closeEditor);
    document.getElementById("cancelLessonBtn").addEventListener("click", closeEditor);

    const submitBtn = form.querySelector('button[type="submit"]');
    function validateLesson(next) {
        if (!next.subject) return "A disciplina é obrigatória.";
        if (next.subject.length > 40) return "A disciplina não pode ter mais de 40 caracteres.";
        if (next.group.length > 40) return "A turma não pode ter mais de 40 caracteres.";
        if (next.teacher.length > 60) return "O nome do professor não pode ter mais de 60 caracteres.";
        if (!next.room) return "Escolha uma sala.";
        if (!/^\d{2}:\d{2}$/.test(next.start) || !/^\d{2}:\d{2}$/.test(next.end)) return "Indique as horas no formato HH:MM.";
        if (next.start >= next.end) return "A hora de fim tem de ser posterior à hora de início.";
        if (next.start < "07:00" || next.end > "23:00") return "As aulas têm de decorrer entre as 07:00 e as 23:00.";
        return null;
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        const day = Number(document.getElementById("lessonDay").value);
        const indexValue = document.getElementById("lessonIndex").value;
        const editing = indexValue === "" ? null : STORE.schedule[document.getElementById("lessonDay").dataset.originalDay || day]?.[Number(indexValue)];
        const next = {
            day,
            subject: document.getElementById("lessonSubject").value.trim(),
            group: document.getElementById("lessonGroup").value.trim(),
            teacher: document.getElementById("lessonTeacher").value.trim(),
            room: document.getElementById("lessonRoom").value,
            start: document.getElementById("lessonStart").value,
            end: document.getElementById("lessonEnd").value
        };
        const error = document.getElementById("lessonFormError");
        const problem = validateLesson(next);
        if (problem) { error.textContent = problem; return; }
        const conflict = (STORE.schedule[day] || []).find(lesson => lesson !== editing
            && next.start < lesson.end && next.end > lesson.start && lesson.room === next.room);
        if (conflict) { error.textContent = `Conflito: a sala já tem ${conflict.subject} entre ${conflict.start} e ${conflict.end}.`; return; }

        submitBtn.disabled = true;
        error.textContent = "";
        try {
            if (editing?.id) await window.WellstateStore.updateLesson(editing.id, next);
            else await window.WellstateStore.createLesson(next);
            closeEditor();
            toast(editing ? "Aula atualizada." : "Aula adicionada ao horário.");
        } catch (failure) {
            error.textContent = failure.message;
        } finally { submitBtn.disabled = false; }
    });

    document.getElementById("deleteLessonBtn").addEventListener("click", async () => {
        const day = document.getElementById("lessonDay").dataset.originalDay || document.getElementById("lessonDay").value;
        const lesson = STORE.schedule[day]?.[Number(document.getElementById("lessonIndex").value)];
        if (!lesson?.id) return;
        if (!await window.WellstateUI.confirm({ title: "Remover aula", message: `Remover ${lesson.subject} (${lesson.start}–${lesson.end}) do horário?`, confirmLabel: "Remover", danger: true })) return;
        try {
            await window.WellstateStore.deleteLesson(lesson.id);
            closeEditor();
            toast("Aula removida.");
        } catch (failure) {
            document.getElementById("lessonFormError").textContent = failure.message;
        }
    });

    /* ---------- Leitura de horário por foto / ficheiro ---------- */
    const scanDialog = document.getElementById("scanDialog");
    const scanFileInput = document.getElementById("scanFileInput");
    const scanPreview = document.getElementById("scanPreview");
    const scanPlaceholder = document.getElementById("scanPlaceholder");
    const scanStatus = document.getElementById("scanStatus");
    const scanResultFields = document.getElementById("scanResultFields");
    const applyScanBtn = document.getElementById("applyScanBtn");
    let currentScanObjectUrl = null;

    function setScanStatus(message, type) {
        scanStatus.textContent = message;
        scanStatus.classList.remove("is-error", "is-ok");
        if (type === "error") scanStatus.classList.add("is-error");
        if (type === "ok") scanStatus.classList.add("is-ok");
    }

    function resetScanUi() {
        if (currentScanObjectUrl) {
            URL.revokeObjectURL(currentScanObjectUrl);
            currentScanObjectUrl = null;
        }
        scanPreview.hidden = true;
        scanPreview.removeAttribute("src");
        scanPlaceholder.hidden = false;
        scanResultFields.hidden = true;
        applyScanBtn.disabled = true;
        document.getElementById("scanClearBtn").hidden = true;
        setScanStatus("A imagem será analisada para preencher horas e disciplina. Confirme sempre os dados antes de guardar.");
        scanFileInput.value = "";
    }

    function openScanDialog() {
        resetScanUi();
        fillScanRooms();
        const today = new Date().getDay(); // 0=domingo
        document.getElementById("scanDay").value = String(today >= 1 && today <= 5 ? today : 1);
        scanDialog.showModal();
    }

    function closeScanDialog() {
        resetScanUi();
        scanDialog.close();
    }

    document.getElementById("scanDocBtn")?.addEventListener("click", openScanDialog);
    document.getElementById("closeScanDialog")?.addEventListener("click", closeScanDialog);
    document.getElementById("cancelScanBtn")?.addEventListener("click", closeScanDialog);

    document.getElementById("scanCameraBtn")?.addEventListener("click", () => {
        scanFileInput.setAttribute("capture", "environment");
        scanFileInput.click();
    });
    document.getElementById("scanFileBtn")?.addEventListener("click", () => {
        scanFileInput.removeAttribute("capture");
        scanFileInput.click();
    });
    document.getElementById("scanClearBtn")?.addEventListener("click", resetScanUi);

    scanFileInput?.addEventListener("change", async () => {
        const file = scanFileInput.files?.[0];
        if (!file) return;
        if (!file.type.startsWith("image/")) {
            setScanStatus("Escolha uma imagem (foto do horário).", "error");
            return;
        }
        if (currentScanObjectUrl) URL.revokeObjectURL(currentScanObjectUrl);
        currentScanObjectUrl = URL.createObjectURL(file);
        scanPreview.src = currentScanObjectUrl;
        scanPreview.hidden = false;
        scanPlaceholder.hidden = true;
        document.getElementById("scanClearBtn").hidden = false;
        applyScanBtn.disabled = true;
        scanResultFields.hidden = true;
        setScanStatus("A ler o documento… isto pode demorar alguns segundos.");

        try {
            const text = await readTextFromImage(file);
            const parsed = parseScheduleText(text);
            if (parsed.start) document.getElementById("scanStart").value = parsed.start;
            if (parsed.end) document.getElementById("scanEnd").value = parsed.end;
            if (parsed.subject) document.getElementById("scanSubject").value = parsed.subject;
            if (parsed.group) document.getElementById("scanGroup").value = parsed.group;
            if (parsed.teacher) document.getElementById("scanTeacher").value = parsed.teacher;
            if (parsed.day) document.getElementById("scanDay").value = String(parsed.day);
            scanResultFields.hidden = false;
            applyScanBtn.disabled = false;
            if (parsed.start || parsed.subject) {
                setScanStatus("Texto detetado. Confirme ou corrija os campos e clique em Aplicar.", "ok");
            } else {
                setScanStatus("Não foi possível ler horas com clareza. Preencha os campos à mão e aplique.", "error");
            }
        } catch (err) {
            console.warn(err);
            scanResultFields.hidden = false;
            applyScanBtn.disabled = false;
            setScanStatus("A leitura automática falhou. Preencha os campos com base na imagem e aplique.", "error");
        }
    });

    /** Extrai texto de uma imagem com Tesseract.js (se disponível) ou devolve string vazia. */
    async function readTextFromImage(file) {
        if (typeof Tesseract === "undefined") {
            throw new Error("OCR indisponível offline");
        }
        const result = await Tesseract.recognize(file, "por+eng", {
            logger: m => {
                if (m.status === "recognizing text" && m.progress != null) {
                    setScanStatus(`A ler o documento… ${Math.round(m.progress * 100)}%`);
                }
            }
        });
        return result?.data?.text || "";
    }

    /** Interpreta horas e alguns campos a partir do texto OCR. */
    function parseScheduleText(raw) {
        const text = String(raw || "").replace(/\s+/g, " ").trim();
        const out = { start: "", end: "", subject: "", group: "", teacher: "", day: null };

        // Horas no formato 8:15, 08:15, 8h15, 08h15-09h05, etc.
        const timeMatches = [...text.matchAll(/\b([01]?\d|2[0-3])[:hH]([0-5]\d)\b/g)];
        if (timeMatches.length >= 2) {
            const fmt = m => `${String(m[1]).padStart(2, "0")}:${m[2]}`;
            out.start = fmt(timeMatches[0]);
            out.end = fmt(timeMatches[1]);
        } else if (timeMatches.length === 1) {
            out.start = `${String(timeMatches[0][1]).padStart(2, "0")}:${timeMatches[0][2]}`;
        }

        const dayMap = {
            segunda: 1, "2ª": 1, "2a": 1,
            terca: 2, terça: 2, "3ª": 2, "3a": 2,
            quarta: 3, "4ª": 3, "4a": 3,
            quinta: 4, "5ª": 4, "5a": 4,
            sexta: 5, "6ª": 5, "6a": 5
        };
        const lower = text.toLowerCase();
        for (const [key, val] of Object.entries(dayMap)) {
            if (lower.includes(key)) { out.day = val; break; }
        }

        // Disciplinas comuns (códigos curtos em maiúsculas)
        const subjectMatch = text.match(/\b(MAT|POR|ING|FIS|QUI|BIO|HIS|GEO|EF|EDF|AI|TIC|PSI|FIL|ECO|DIR|DES|ELT|MEC|INF)\b/i);
        if (subjectMatch) out.subject = subjectMatch[1].toUpperCase();

        const groupMatch = text.match(/\b(\d{1,2}\.?\s*º?\s*[A-Z]?)\b/);
        if (groupMatch) out.group = groupMatch[1].replace(/\s+/g, " ").trim();

        return out;
    }

    applyScanBtn?.addEventListener("click", async () => {
        const next = {
            day: Number(document.getElementById("scanDay").value),
            subject: document.getElementById("scanSubject").value.trim(),
            group: document.getElementById("scanGroup").value.trim(),
            teacher: document.getElementById("scanTeacher").value.trim(),
            room: document.getElementById("scanRoom").value,
            start: document.getElementById("scanStart").value,
            end: document.getElementById("scanEnd").value
        };
        const problem = validateLesson(next);
        if (problem) {
            setScanStatus(problem, "error");
            return;
        }
        const conflict = (STORE.schedule[next.day] || []).find(lesson =>
            next.start < lesson.end && next.end > lesson.start && lesson.room === next.room);
        if (conflict) {
            setScanStatus(`Conflito: a sala já tem ${conflict.subject} entre ${conflict.start} e ${conflict.end}.`, "error");
            return;
        }
        applyScanBtn.disabled = true;
        try {
            await window.WellstateStore.createLesson(next);
            closeScanDialog();
            toast("Aula adicionada a partir do documento.");
        } catch (failure) {
            setScanStatus(failure.message, "error");
            applyScanBtn.disabled = false;
        }
    });

    window.addEventListener("wellstate:store-updated", event => { STORE = event.detail; render(); });
    function toast(message, type = "success") { window.WellstateUI.toast(message, type); }
    render();
})();

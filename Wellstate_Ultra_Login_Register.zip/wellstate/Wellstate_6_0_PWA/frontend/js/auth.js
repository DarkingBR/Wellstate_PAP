/* Login e registo: validação no cliente, PHP para e-mail/password,
   Firebase Auth para Google e GitHub. */
import firebase from "./firebase.js";

const form = document.getElementById("authForm");
const mode = form?.dataset.mode || "login";
const alertBox = document.getElementById("formAlert");
const button = form?.querySelector(".btn-submit");
const labelText = button?.querySelector("span")?.textContent || "Entrar";

const SOCIAL_KEY = "wellstate-social-user";

function setError(id, message) {
    const box = form?.querySelector(`[data-field="${id}"]`);
    if (!box) return;
    const input = box.querySelector("input");
    box.classList.toggle("invalid", Boolean(message));
    if (input) input.classList.toggle("invalid", Boolean(message));
    const err = box.querySelector(".field-error");
    if (err) err.textContent = message || "";
}

function clearErrors() {
    if (alertBox) {
        alertBox.classList.remove("show");
        alertBox.textContent = "";
    }
    form?.querySelectorAll("[data-field]").forEach(f => setError(f.dataset.field, ""));
}

function showAlert(msg) {
    if (!alertBox) return;
    alertBox.textContent = msg;
    alertBox.classList.add("show");
}

/* Mostrar / esconder palavra-passe */
document.querySelectorAll(".toggle-pass").forEach(btn => {
    btn.addEventListener("click", () => {
        const input = document.getElementById(btn.dataset.toggle);
        if (!input) return;
        const show = input.type === "password";
        input.type = show ? "text" : "password";
        const icon = btn.querySelector("i");
        if (icon) icon.className = show ? "fa-solid fa-eye-slash" : "fa-solid fa-eye";
        btn.setAttribute("aria-label", show ? "Esconder palavra-passe" : "Mostrar palavra-passe");
    });
});

/* Indicador de força da password (registo) */
const strength = document.getElementById("strength");
if (strength) {
    const names = ["", "Fraca — adicione maiúsculas e números", "Razoável", "Boa", "Forte"];
    document.getElementById("password")?.addEventListener("input", e => {
        const v = e.target.value;
        let level = 0;
        if (v.length >= 8) level++;
        if (/[A-Z]/.test(v) && /[a-z]/.test(v)) level++;
        if (/\d/.test(v)) level++;
        if (/[^A-Za-z0-9]/.test(v) || v.length >= 12) level++;
        strength.dataset.level = level;
        const label = document.getElementById("strengthLabel");
        if (label) label.textContent = names[level] || "";
    });
}

/* Caps Lock */
const capsHint = document.getElementById("capsHint");
if (capsHint) {
    const pwd = document.getElementById("password");
    const checkCaps = e => {
        if (typeof e.getModifierState === "function") {
            capsHint.hidden = !e.getModifierState("CapsLock");
        }
    };
    pwd?.addEventListener("keydown", checkCaps);
    pwd?.addEventListener("keyup", checkCaps);
}

/* Restaurar e-mail lembrado */
try {
    const saved = localStorage.getItem("ws-email");
    if (saved && mode === "login") {
        const emailInput = document.getElementById("email");
        if (emailInput && !emailInput.value) emailInput.value = saved;
        const remember = document.getElementById("remember");
        if (remember) remember.checked = true;
    }
} catch { /* private mode */ }

function validate(data) {
    let ok = true;
    const fail = (id, msg) => { setError(id, msg); ok = false; };

    /* Honeypot: bots preenchem campos invisíveis */
    if ((data.website || "").trim().length > 0) {
        showAlert("Pedido rejeitado por segurança.");
        return false;
    }

    if (mode === "register") {
        const name = (data.name || "").trim();
        if (name.length < 2) fail("name", "Escreva o seu nome completo.");
        else if (name.length > 80) fail("name", "O nome é demasiado longo.");
        else if (!/^[\p{L}\p{N} .'-]+$/u.test(name)) fail("name", "Use apenas letras, espaços e hífens.");
        else if (/(script|javascript|<|>|{|}|\[|\]|\\)/i.test(name)) fail("name", "Caracteres inválidos no nome.");
    }

    const email = (data.email || "").trim().toLowerCase();
    if (!email) fail("email", "Introduza o e-mail.");
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 190) {
        fail("email", "Introduza um e-mail válido.");
    } else if (email.includes("..") || email.startsWith(".") || email.endsWith(".")) {
        fail("email", "Formato de e-mail inválido.");
    }

    if (mode === "login") {
        if (!(data.password || "").length) fail("password", "Escreva a palavra-passe.");
        else if ((data.password || "").length > 200) fail("password", "Palavra-passe demasiado longa.");
    } else {
        const pwd = data.password || "";
        if (pwd.length < 8) fail("password", "Use pelo menos 8 caracteres.");
        else if (pwd.length > 200) fail("password", "Palavra-passe demasiado longa.");
        else if (!/[A-Za-z]/.test(pwd) || !/\d/.test(pwd)) {
            fail("password", "Inclua letras e números.");
        } else if (pwd.toLowerCase() === email) {
            fail("password", "A palavra-passe não pode ser igual ao e-mail.");
        } else if (/^(password|12345678|qwerty|abc123|wellstate)/i.test(pwd)) {
            fail("password", "Essa palavra-passe é demasiado comum.");
        }
        if (pwd !== (data.confirm || "")) fail("confirm", "As palavras-passe não coincidem.");
    }
    return ok;
}

async function finishSocialLogin(user) {
    const profile = {
        uid: user.uid,
        email: user.email || "",
        name: user.displayName || user.email?.split("@")[0] || "Utilizador",
        photoURL: user.photoURL || "",
        provider: user.providerData?.[0]?.providerId || "firebase",
        at: Date.now()
    };
    try {
        sessionStorage.setItem(SOCIAL_KEY, JSON.stringify(profile));
        localStorage.setItem(SOCIAL_KEY, JSON.stringify(profile));
    } catch { /* ok */ }
    window.location.replace("dashboard.html");
}

function socialErrorMessage(err) {
    const code = err?.code || "";
    if (code === "auth/popup-closed-by-user" || code === "auth/cancelled-popup-request") {
        return "Janela de autenticação fechada. Tente de novo quando quiser.";
    }
    if (code === "auth/account-exists-with-different-credential") {
        return "Já existe uma conta com este e-mail noutro método de entrada.";
    }
    if (code === "auth/popup-blocked") {
        return "O browser bloqueou a janela. Permita pop-ups para este site.";
    }
    if (code === "auth/network-request-failed") {
        return "Sem ligação à rede. Verifique a internet e tente outra vez.";
    }
    if (code === "auth/operation-not-allowed") {
        return "Este método de entrada ainda não está ativo na consola Firebase (Authentication → Sign-in method).";
    }
    return "Não foi possível autenticar. Tente novamente ou use e-mail e palavra-passe.";
}

async function handleSocial(provider) {
    const btnG = document.getElementById("btnGoogle");
    const btnH = document.getElementById("btnGithub");
    const active = provider === "google" ? btnG : btnH;
    if (!active || active.disabled) return;
    clearErrors();
    [btnG, btnH].forEach(b => { if (b) b.disabled = true; });
    active.classList.add("is-loading");
    try {
        const user = provider === "google"
            ? await firebase.signInWithGoogle()
            : await firebase.signInWithGithub();
        if (user) await finishSocialLogin(user);
    } catch (err) {
        showAlert(socialErrorMessage(err));
    } finally {
        [btnG, btnH].forEach(b => { if (b) b.disabled = false; });
        active.classList.remove("is-loading");
    }
}

document.getElementById("btnGoogle")?.addEventListener("click", () => handleSocial("google"));
document.getElementById("btnGithub")?.addEventListener("click", () => handleSocial("github"));

/* Submit e-mail / password */
form?.addEventListener("submit", async event => {
    event.preventDefault();
    clearErrors();
    const data = Object.fromEntries(new FormData(form).entries());
    data.email = String(data.email || "").trim().toLowerCase();
    data.name = String(data.name || "").trim();
    if (!validate(data)) return;

    if (button.disabled) return;
    button.disabled = true;
    button.querySelector("span").textContent = mode === "login" ? "A entrar…" : "A criar conta…";

    try {
        const csrfRes = await fetch("php/csrf.php", { credentials: "same-origin", cache: "no-store" });
        if (!csrfRes.ok) throw new Error("csrf");
        const { csrf } = await csrfRes.json();

        const response = await fetch(`php/${mode}.php`, {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "X-CSRF-Token": csrf
            },
            body: JSON.stringify(data)
        });

        const raw = await response.text();
        let body = {};
        try { body = JSON.parse(raw); } catch { /* resposta sem JSON */ }

        if (!response.ok || !body.user) {
            Object.entries(body.errors || {}).forEach(([id, msg]) => setError(id, msg));
            const isFile = location.protocol === "file:" || !raw.trim().startsWith("{");
            showAlert(body.message || (isFile
                ? "O PHP não está a responder. Abra esta página por http://localhost/wellstate/ (Apache do XAMPP ligado)."
                : "Não foi possível concluir. Verifique os dados e tente novamente."));
            return;
        }

        try {
            if (mode === "login") {
                const r = document.getElementById("remember");
                if (r?.checked) localStorage.setItem("ws-email", data.email);
                else localStorage.removeItem("ws-email");
            }
            localStorage.removeItem(SOCIAL_KEY);
            sessionStorage.removeItem(SOCIAL_KEY);
        } catch { /* ok */ }

        window.location.replace("dashboard.html");
    } catch {
        showAlert("Servidor PHP indisponível. Abra o painel por http://localhost/wellstate/ com o Apache do XAMPP ligado.");
    } finally {
        button.disabled = false;
        button.querySelector("span").textContent = labelText;
    }
});

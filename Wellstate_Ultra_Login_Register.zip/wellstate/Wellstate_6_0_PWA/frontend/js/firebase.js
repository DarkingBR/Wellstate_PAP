/* Wellstate · Firebase (Auth + Firestore)
   Configuração pública do projeto. A segurança real está nas regras (firestore.rules)
   e nos providers ativados na consola Firebase. */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
    getFirestore, doc, setDoc, getDoc, collection, getDocs,
    writeBatch, enableIndexedDbPersistence
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {
    getAuth, signInAnonymously, signInWithPopup, GoogleAuthProvider,
    GithubAuthProvider, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getAnalytics, isSupported } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-analytics.js";

const firebaseConfig = {
    apiKey: "AIzaSyBCkOKVdEZlkIWhKg_feyde2dvM7YGzbns",
    authDomain: "wellstate-pap.firebaseapp.com",
    projectId: "wellstate-pap",
    storageBucket: "wellstate-pap.firebasestorage.app",
    messagingSenderId: "600103840665",
    appId: "1:600103840665:web:4a653f023fafa2c02c0108",
    measurementId: "G-LGE14T04DP"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

isSupported().then(ok => { if (ok) getAnalytics(app); }).catch(() => {});

/* Persistência offline — dados em cache local e sincronizam quando a rede voltar. */
try {
    enableIndexedDbPersistence(db).catch(() => {});
} catch { /* Safari privado, etc. */ }

const say = state => window.dispatchEvent(new CustomEvent("wellstate:cloud", { detail: state }));
let signedIn = signInAnonymously(auth).catch(() => null);
const lastSave = {};
const SAVE_EVERY_MS = 18000;
const MAX_RETRIES = 2;

function fail(error) {
    const code = error && error.code;
    if (code === "permission-denied") say("denied");
    else if (code === "unavailable" || code === "deadline-exceeded") say("offline");
    else say("error");
}

async function withRetry(fn, retries = MAX_RETRIES) {
    let lastErr;
    for (let i = 0; i <= retries; i++) {
        try {
            return await fn();
        } catch (err) {
            lastErr = err;
            if (i < retries) await new Promise(r => setTimeout(r, 400 * (i + 1)));
        }
    }
    throw lastErr;
}

async function save(path, data) {
    const now = Date.now();
    if (now - (lastSave[path] || 0) < SAVE_EVERY_MS) return;
    lastSave[path] = now;
    try {
        await signedIn;
        await withRetry(async () => {
            if (path === "/rooms") {
                const batch = writeBatch(db);
                (data || []).forEach(r => {
                    const id = String(r.roomId || r.id || "").trim();
                    if (!id) return;
                    batch.set(doc(db, "rooms", id), {
                        ...r,
                        roomId: id,
                        savedAt: new Date().toISOString()
                    }, { merge: true });
                });
                await batch.commit();
            } else {
                const devices = (data.devices || []).slice(0, 250).map(d => ({
                    ip: d.ip,
                    mac: d.mac || "",
                    hostname: d.hostname || "",
                    vendor: d.vendor || "",
                    kind: d.kind || "",
                    kindLabel: d.kindLabel || "",
                    responseMs: d.responseMs ?? null,
                    isGateway: !!d.isGateway,
                    isSelf: !!d.isSelf,
                    key: d.key || d.ip
                }));
                await setDoc(doc(db, "network", "latest"), {
                    scanCidr: data.scanCidr || "",
                    scannedAt: data.scannedAt || null,
                    savedAt: new Date().toISOString(),
                    count: devices.length,
                    devices
                }, { merge: true });
            }
        });
        say("ok");
    } catch (error) {
        fail(error);
    }
}

async function load(path) {
    try {
        await signedIn;
        let result = null;
        await withRetry(async () => {
            if (path === "/rooms") {
                const snap = await getDocs(collection(db, "rooms"));
                result = snap.docs.map(d => d.data());
                if (!result.length) result = null;
            } else {
                const snap = await getDoc(doc(db, "network", "latest"));
                if (snap.exists()) {
                    const d = snap.data();
                    const list = Array.isArray(d.devices) ? d.devices : [];
                    result = {
                        ...d,
                        online: true,
                        fromBackup: true,
                        scanning: false,
                        automaticallyDetected: true,
                        devices: list.map(x => ({
                            ...x,
                            online: true,
                            confidence: "medium",
                            reasons: ["Última leitura guardada no Firestore"],
                            openPorts: []
                        })),
                        summary: list.reduce((acc, x) => {
                            const k = x.kind || "other";
                            acc[k] = (acc[k] || 0) + 1;
                            return acc;
                        }, {})
                    };
                }
            }
        });
        if (result) {
            window.WS_FROM_BACKUP = Date.now();
            say("ok");
        }
        return result;
    } catch (error) {
        fail(error);
        return null;
    }
}

/* ---------- Auth social (Google / GitHub) ---------- */
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });
const githubProvider = new GithubAuthProvider();

async function signInWithGoogle() {
    const cred = await signInWithPopup(auth, googleProvider);
    return cred.user;
}

async function signInWithGithub() {
    const cred = await signInWithPopup(auth, githubProvider);
    return cred.user;
}

function watchAuth(callback) {
    return onAuthStateChanged(auth, callback);
}

async function signOutFirebase() {
    try { await signOut(auth); } catch { /* ok */ }
}

export default {
    save,
    load,
    auth,
    signInWithGoogle,
    signInWithGithub,
    watchAuth,
    signOutFirebase,
    db
};

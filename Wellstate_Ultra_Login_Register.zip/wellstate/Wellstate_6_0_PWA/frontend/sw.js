/* Wellstate · Service Worker
   - Pré-carrega o "esqueleto" da aplicação para abrir mesmo sem rede.
   - API e sessão (api/, php/) NUNCA são guardadas: vão sempre à rede.
   - Navegação: rede primeiro, depois cache, depois página offline.
   - Ficheiros estáticos: cache primeiro com atualização em segundo plano. */
"use strict";

const VERSION = "wellstate-v5.3.0";
const STATIC_CACHE = `${VERSION}-static`;
const RUNTIME_CACHE = `${VERSION}-runtime`;
const SCOPE = self.registration.scope;                       // funciona em / e em /wellstate/
const url = path => new URL(path, SCOPE).href;
const EXTERNAL_HOSTS = new Set(["fonts.googleapis.com", "fonts.gstatic.com", "cdnjs.cloudflare.com", "cdn.jsdelivr.net"]);
const MAX_RUNTIME_ENTRIES = 80;

const CORE = [
    "offline.html", "login.html", "register.html", "install.html", "dashboard.html", "rooms.html", "pcs.html", "schedule.html", "history.html", "admin.html",
    "css/base.css", "css/polish.css", "css/install.css", "css/login.css", "css/pcs.css",
    "js/pwa.js", "js/install.js", "js/polish.js", "js/ui.js", "js/config.js", "js/theme.js", "js/clock.js", "js/data-store.js", "js/app-shell.js", "js/auth-guard.js",
    "js/auth.js", "js/auth-fx.js", "js/api-client.js", "js/dashboard.js", "js/rooms.js", "js/pcs.js", "js/schedule.js", "js/schedule-data.js", "js/history.js", "js/admin.js", "js/strip.js", "js/notifications.js",
    "img/icons/icon-192.png", "img/icons/icon-512.png", "img/icons/apple-touch-icon.png", "favicon.ico", "manifest.webmanifest"
].map(url);

const isApi = u => /\/(api|php)(\/|$)/.test(u.pathname);
const cacheable = res => res && res.status === 200 && (res.type === "basic" || res.type === "cors" || res.type === "opaque");

async function trim(cacheName, max) {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map(k => cache.delete(k)));
}

/** Guarda cada ficheiro à parte: um falhar não impede os outros. Devolve {done, failed}. */
async function precache(onProgress) {
    const cache = await caches.open(STATIC_CACHE);
    let done = 0, failed = 0;
    await Promise.all(CORE.map(async href => {
        try {
            const res = await fetch(new Request(href, { cache: "reload", credentials: "same-origin" }));
            if (!res.ok) throw new Error(String(res.status));
            await cache.put(href, res);
        } catch { failed++; }
        done++;
        if (onProgress) onProgress(done, CORE.length, failed);
    }));
    return { done, failed, total: CORE.length };
}

self.addEventListener("install", event => { event.waitUntil(precache().catch(() => {})); });

self.addEventListener("activate", event => {
    event.waitUntil((async () => {
        const keep = new Set([STATIC_CACHE, RUNTIME_CACHE]);
        const names = await caches.keys();
        await Promise.all(names.filter(n => n.startsWith("wellstate-") && !keep.has(n)).map(n => caches.delete(n)));
        if (self.registration.navigationPreload) await self.registration.navigationPreload.enable().catch(() => {});
        await self.clients.claim();
    })());
});

self.addEventListener("message", event => {
    const data = event.data;
    if (!data || typeof data !== "object" || typeof data.type !== "string") return;    // validação do formato
    if (event.source && event.source.url && new URL(event.source.url).origin !== self.location.origin) return;   // só a própria origem
    if (data.type === "SKIP_WAITING") { self.skipWaiting(); return; }
    if (data.type === "GET_VERSION") { event.source && event.source.postMessage({ type: "VERSION", version: VERSION }); return; }
    if (data.type === "PRECACHE_ALL") {
        event.waitUntil((async () => {
            const send = msg => self.clients.matchAll({ type: "window" }).then(list => list.forEach(c => c.postMessage(msg)));
            try {
                const result = await precache((done, total, failed) => send({ type: "PRECACHE_PROGRESS", done, total, failed }));
                await send({ type: "PRECACHE_DONE", ...result });
            } catch (error) { await send({ type: "PRECACHE_ERROR", message: String(error && error.message || error) }); }
        })());
    }
});

self.addEventListener("fetch", event => {
    const req = event.request;
    if (req.method !== "GET") return;                                   // POST/PUT/DELETE: nunca interceta
    let u;
    try { u = new URL(req.url); } catch { return; }
    if (u.protocol !== "http:" && u.protocol !== "https:") return;     // ignora chrome-extension:, data:, etc.
    if (req.headers.has("range")) return;                              // vídeo/áudio parcial: deixa passar
    const sameOrigin = u.origin === self.location.origin;

    if (sameOrigin && isApi(u)) return;                                // API e sessão: sempre rede
    if (sameOrigin && /\/(sw\.js|diagnostico\.html)$/.test(u.pathname)) return;
    if (!sameOrigin && !EXTERNAL_HOSTS.has(u.hostname)) return;        // só fontes/ícones/bibliotecas conhecidas

    if (req.mode === "navigate") { event.respondWith(navigation(event)); return; }
    event.respondWith(staleWhileRevalidate(req, sameOrigin));
});

async function navigation(event) {
    const req = event.request;
    try {
        const preload = await event.preloadResponse;
        const res = preload || await fetch(req);
        if (res && res.ok && res.type === "basic") {
            const copy = res.clone();
            caches.open(RUNTIME_CACHE).then(c => c.put(req, copy)).catch(() => {});
        }
        return res;
    } catch {
        const cached = await caches.match(req, { ignoreSearch: true });
        if (cached) return cached;
        const offline = await caches.match(url("offline.html"));
        return offline || new Response("Sem ligação.", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } });
    }
}

async function staleWhileRevalidate(req, sameOrigin) {
    const cache = await caches.open(sameOrigin ? STATIC_CACHE : RUNTIME_CACHE);
    const cached = await cache.match(req, { ignoreSearch: sameOrigin });
    const network = fetch(req).then(res => {
        if (cacheable(res)) { cache.put(req, res.clone()).then(() => trim(RUNTIME_CACHE, MAX_RUNTIME_ENTRIES)).catch(() => {}); }
        return res;
    }).catch(() => null);
    if (cached) { network.catch(() => {}); return cached; }
    const res = await network;
    return res || new Response("", { status: 504, statusText: "Offline" });
}

/**
 * Wellstate · Sensor de sala (ESP8266)
 * ------------------------------------
 * Hardware típico:
 *   - NodeMCU / Wemos D1 mini (ESP8266)
 *   - PIR HC-SR501  → pino D5 (GPIO14)
 *   - HC-SR04 TRIG  → pino D6 (GPIO12)
 *   - HC-SR04 ECHO  → pino D7 (GPIO13)
 *   - LED opcional  → pino D4 (GPIO2, LED interno em muitos módulos)
 *
 * Envia POST JSON para a API Wellstate:
 *   POST /api/rooms/{ROOM_ID}/telemetry
 *   Header: X-Device-Key: <chave>
 *   Body: { "motion": true/false, "occupied": true/false, "distance": cm }
 *
 * Bibliotecas (Gestor de Bibliotecas do Arduino IDE):
 *   - ESP8266WiFi (já vem com o core ESP8266)
 *   - ESP8266HTTPClient
 *   - ArduinoJson (por Benoit Blanchon) — versão 6.x ou 7.x
 *
 * Configuração: preenche as constantes em CONFIG abaixo.
 */

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <ArduinoJson.h>

// ===================== CONFIG (altera estes valores) =====================
const char* WIFI_SSID     = "NOME_DA_REDE_WIFI";
const char* WIFI_PASSWORD = "PASSWORD_WIFI";

// Endereço base da API (sem barra no fim). Exemplos:
//   "http://192.168.1.10:5080/api"
//   "http://192.168.1.10/wellstate/api"
const char* API_BASE      = "http://192.168.1.10:5080/api";

// Deve ser igual a Wellstate:DeviceApiKey / WELLSTATE_DEVICE_API_KEY no servidor
const char* DEVICE_API_KEY = "COPIA_A_CHAVE_DO_SERVIDOR";

// Identificador da sala no Wellstate (ex.: "C1.01", "Lab-Info")
const char* ROOM_ID        = "C1.01";

// Intervalo entre envios (ms). 10–15 s é um bom compromisso.
const unsigned long SEND_EVERY_MS = 12000;

// Distância máxima (cm) para considerar a sala ocupada (além do PIR)
const float OCCUPY_MAX_CM = 150.0;

// Pinos (NodeMCU / D1 mini)
const int PIN_PIR   = 14; // D5
const int PIN_TRIG  = 12; // D6
const int PIN_ECHO  = 13; // D7
const int PIN_LED   = 2;  // D4 (LED interno, ativo em LOW em muitos módulos)
// =========================================================================

unsigned long lastSend = 0;

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println(F("Wellstate · sensor de sala (ESP8266)"));

  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_TRIG, LOW);
  digitalWrite(PIN_LED, HIGH); // LED off (ativo LOW)

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print(F("A ligar ao Wi-Fi"));
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 30000) {
    delay(400);
    Serial.print('.');
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(F("IP: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("Wi-Fi falhou. Reinicia ou verifica SSID/password."));
  }
}

/** Lê distância em cm com HC-SR04. Devolve -1 se inválido. */
float readDistanceCm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000UL); // timeout ~30 ms
  if (us == 0) return -1.0f;
  float cm = (us * 0.0343f) / 2.0f;
  if (cm < 2.0f || cm > 400.0f) return -1.0f;
  return cm;
}

bool sendTelemetry(bool motion, bool occupied, float distanceCm) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println(F("Sem Wi-Fi — a tentar reconectar…"));
    WiFi.reconnect();
    delay(2000);
    if (WiFi.status() != WL_CONNECTED) return false;
  }

  // Preferir path com roomId; se o roomId tiver ponto (C1.01), a API PHP
  // também aceita /rooms/telemetry?roomId=...
  String url = String(API_BASE) + "/rooms/telemetry?roomId=" + ROOM_ID;

  WiFiClient client;
  HTTPClient http;
  http.setTimeout(8000);
  if (!http.begin(client, url)) {
    Serial.println(F("HTTP begin falhou"));
    return false;
  }
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_API_KEY);

  StaticJsonDocument<256> doc;
  doc["motion"] = motion;
  doc["occupied"] = occupied;
  if (distanceCm > 0) {
    doc["distance"] = distanceCm;
  }

  String body;
  serializeJson(doc, body);

  int code = http.POST(body);
  String resp = http.getString();
  http.end();

  Serial.print(F("POST "));
  Serial.print(code);
  Serial.print(F(" "));
  Serial.println(resp);

  // 200 / 201 = ok
  return code == 200 || code == 201;
}

void loop() {
  bool motion = digitalRead(PIN_PIR) == HIGH;
  float dist = readDistanceCm();

  // Ocupada só se há movimento E (opcionalmente) alguém perto do sensor
  bool near = (dist > 0 && dist <= OCCUPY_MAX_CM);
  bool occupied = motion && (near || dist < 0); // se ultrassónico falhar, confia no PIR

  // LED: aceso quando há movimento
  digitalWrite(PIN_LED, motion ? LOW : HIGH);

  unsigned long now = millis();
  if (now - lastSend >= SEND_EVERY_MS) {
    lastSend = now;
    Serial.print(F("motion="));
    Serial.print(motion ? "1" : "0");
    Serial.print(F(" dist="));
    Serial.print(dist);
    Serial.print(F(" occ="));
    Serial.println(occupied ? "1" : "0");

    bool ok = sendTelemetry(motion, occupied, dist);
    if (!ok) Serial.println(F("Envio falhou — verifica API_BASE, chave e firewall do PC."));
  }

  delay(50);
}

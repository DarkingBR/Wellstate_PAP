# Firebase no Wellstate

## O que é usado

- **Firestore** — cópia de segurança das leituras das salas e do último scan de rede.
- **Authentication** — login anónimo (para o Firestore) e, opcionalmente, Google / GitHub no ecrã de entrada.

## Ativar Google e GitHub

1. Abra a [consola Firebase](https://console.firebase.google.com/) → projeto **wellstate-pap**.
2. **Authentication** → **Sign-in method**.
3. Ative **Google** e **GitHub**.
4. Em GitHub, crie uma OAuth App em github.com/settings/developers e cole o Client ID / Secret na consola Firebase.
5. Em **Authorized domains**, confirme que o domínio onde a app corre (ex.: `localhost`) está listado.

Sem estes passos, os botões "Continuar com Google / GitHub" mostram um aviso claro no ecrã de login.

## Regras

O ficheiro `firestore.rules` na raiz do projeto deve ser publicado na consola (Firestore → Rules).
Só utilizadores autenticados (incluindo anónimos) podem ler/escrever `rooms` e `network`.

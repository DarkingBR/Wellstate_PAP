# Wellstate · Arduino (ESP8266) e Firewall

Este documento faz parte da PAP 2026–2027 e explica como ligar os sensores de sala e o que configurar no firewall da rede.

## 1. Sensor de sala (Arduino / ESP8266)

### Pasta do código
```
arduino/Wellstate_RoomSensor/Wellstate_RoomSensor.ino
```

### Material
| Componente | Função |
|------------|--------|
| NodeMCU ou Wemos D1 mini (ESP8266) | Wi‑Fi + microcontrolador |
| PIR HC-SR501 | Deteta movimento |
| HC-SR04 | Distância (ocupação) |
| Fonte 5 V estável | Alimentação |

### Ligações (NodeMCU)
| Sensor | Pino ESP |
|--------|----------|
| PIR OUT | D5 (GPIO14) |
| HC-SR04 TRIG | D6 (GPIO12) |
| HC-SR04 ECHO | D7 (GPIO13) |
| LED (opcional) | D4 (GPIO2) |

### Configuração no `.ino`
1. `WIFI_SSID` e `WIFI_PASSWORD` — rede da escola ou hotspot de testes.
2. `API_BASE` — URL da API, por exemplo `http://192.168.1.10:5080/api`.
3. `DEVICE_API_KEY` — igual à chave do servidor (`WELLSTATE_DEVICE_API_KEY` ou `Wellstate:DeviceApiKey`).
4. `ROOM_ID` — ID da sala no Wellstate (ex.: `C1.01`).

### API usada
```
POST {API_BASE}/rooms/{ROOM_ID}/telemetry
Header: X-Device-Key: <chave>
Content-Type: application/json

{
  "motion": true,
  "occupied": true,
  "distance": 120.5
}
```

Respostas esperadas: **201** (criado) ou **200**.  
Erro **401**: chave errada. **503**: chave ainda não configurada no servidor.

### Arduino IDE
1. Instalar o core **ESP8266** (Board Manager).
2. Biblioteca **ArduinoJson** (Library Manager).
3. Placa: *NodeMCU 1.0* ou *LOLIN(WEMOS) D1 mini*.
4. Abrir o `.ino`, preencher CONFIG, carregar.

---

## 2. Firewall (rede e PC do servidor)

O scan de dispositivos e os sensores precisam de comunicação na LAN. Se o firewall bloquear, o painel fica vazio ou o ESP não envia dados.

### No PC onde corre a API (Windows)
1. Abrir **Firewall do Windows Defender** → *Regras de entrada*.
2. Criar regra para o porto da API (ex.: **5080** TCP) ou para o Apache (**80**).
3. Permitir **ICMP** (ping) se quiseres que o scan por ping veja mais equipamentos — muitos telemóveis e PCs bloqueiam ping; o Wellstate também usa TCP/ARP.

PowerShell (como administrador), exemplo para a API em .NET na porta 5080:
```powershell
New-NetFirewallRule -DisplayName "Wellstate API 5080" -Direction Inbound -Protocol TCP -LocalPort 5080 -Action Allow
```

### No router da escola
- Os ESP8266 e o PC da API devem estar na **mesma rede** (ou com encaminhamento conhecido).
- Evitar *isolamento de clientes* (AP isolation / guest Wi‑Fi) na rede dos sensores, senão o ESP não alcança o servidor.
- Se usares VLAN de IoT, cria regra: **IoT → servidor Wellstate, TCP porto da API** (e só isso).

### Regras recomendadas (resumo)
| Origem | Destino | Porto | Ação | Motivo |
|--------|---------|-------|------|--------|
| Sensores ESP | PC API | 5080 ou 80 TCP | Permitir | Telemetria de salas |
| PCs lab | PC API | 5080 ou 80 TCP | Permitir | Painel web |
| Internet pública | PC API | * | Bloquear | Não expor a API à Internet sem HTTPS e autenticação forte |
| Guest Wi‑Fi | Rede interna | * | Bloquear / isolar | Segurança |

### No código PHP de rede
O ficheiro `frontend/api/network.php` já tem em conta firewalls que bloqueiam ICMP: faz scan por **TCP** e lê a tabela **ARP**, para continuar a ver equipamentos mesmo quando o ping falha.

---

## 3. Teste rápido
1. Servidor Wellstate a correr na LAN.
2. Chave de dispositivo configurada.
3. Carregar o sketch no ESP com o IP certo.
4. Abrir o Monitor Série (115200) e confirmar `POST 201`.
5. No painel → **Salas**: a sala deve atualizar presença.

## 4. Segurança (PAP)
- Não commits a password Wi‑Fi nem a chave real no Git público.
- Usa chave longa e só no servidor + nos ESP.
- Em demonstração, podes usar hotspot do telemóvel + portátil na mesma rede.

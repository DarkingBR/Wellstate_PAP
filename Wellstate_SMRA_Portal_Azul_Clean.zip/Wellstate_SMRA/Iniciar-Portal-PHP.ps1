$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
if (-not (Get-Command php -ErrorAction SilentlyContinue)) {
    throw 'Instale PHP 8.1+ com as extensões PDO e PDO_SQLite.'
}
php -S 0.0.0.0:8080 -t . server/router.php

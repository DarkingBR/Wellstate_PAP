$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Instale o .NET SDK 8.' }
if (-not (Get-Command php -ErrorAction SilentlyContinue)) { throw 'Instale PHP 8.1+ com PDO_SQLite.' }
if (-not ((php -m) -match '(?im)^pdo_sqlite$')) { throw 'Ative a extensão PDO_SQLite no PHP.' }

$api = Start-Process -FilePath 'dotnet' -ArgumentList @('run', '--project', (Join-Path $root 'backend-csharp/Wellstate.API.csproj'), '--urls', 'http://0.0.0.0:5080') -WorkingDirectory $root -PassThru -NoNewWindow
try {
    Set-Location $root
    php -S 0.0.0.0:8080 -t . server/router.php
}
finally {
    if ($api -and -not $api.HasExited) { Stop-Process -Id $api.Id -Force }
}

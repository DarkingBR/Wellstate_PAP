#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"

command -v dotnet >/dev/null 2>&1 || { echo 'Instale o .NET SDK 8.' >&2; exit 1; }
command -v php >/dev/null 2>&1 || { echo 'Instale PHP 8.1+ com PDO_SQLite.' >&2; exit 1; }
php -m | grep -qi '^pdo_sqlite$' || { echo 'A extensão PDO_SQLite do PHP não está ativa.' >&2; exit 1; }

dotnet run --project "$ROOT/backend-csharp/Wellstate.API.csproj" --urls 'http://0.0.0.0:5080' &
API_PID=$!
cleanup() { kill "$API_PID" 2>/dev/null || true; wait "$API_PID" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
cd "$ROOT"
php -S 0.0.0.0:8080 -t . server/router.php

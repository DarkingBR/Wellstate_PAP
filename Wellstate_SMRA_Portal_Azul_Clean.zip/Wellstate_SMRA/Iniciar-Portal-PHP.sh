#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v php >/dev/null 2>&1; then
  echo "Erro: instale PHP 8.1+ com as extensões PDO e PDO_SQLite." >&2
  exit 1
fi
if ! php -m | grep -qi '^pdo_sqlite$'; then
  echo "Erro: a extensão PDO_SQLite do PHP não está ativa." >&2
  exit 1
fi
exec php -S 0.0.0.0:8080 -t . server/router.php

# Wellstate SMRA · Portal Azul

Portal de monitorização de salas, rede e sensores, reorganizado por responsabilidade. A interface existente foi preservada; o acesso ao portal passa a usar autenticação PHP.

## Tecnologias e responsabilidades

| Pasta | Tecnologia | Responsabilidade |
|---|---|---|
| `frontend/` | HTML, CSS, JavaScript | Páginas, estilos, componentes e interação do dashboard |
| `server/` | PHP 8.1+ | Login, registo, sessões, CSRF e armazenamento local de contas |
| `backend-csharp/` | C# / .NET 8 | API REST, telemetria SQLite, sinais e descoberta de computadores |
| `firmware/Wellstate_Firmware/` | C++ / Arduino ESP8266 | Leitura de sensores, Wi-Fi e envio de telemetria |
| `firebase/` e `docs/FIREBASE.md` | Firebase / Firestore | Regras e esquema de destino; integração cloud ainda não configurada |

> **Nota sobre a base de dados:** Firestore é uma base de dados **NoSQL**, não SQL. O sistema mantém SQLite (SQL) para contas e dados operacionais locais. O projeto não contém `Project ID` ou credenciais de serviço Firebase; por isso o Firestore não é apresentado como conectado.

## Início rápido

### Requisitos

- PHP 8.1 ou superior, com `PDO` e `PDO_SQLite`.
- .NET SDK 8 para a API C#.
- Arduino IDE 2.x e core ESP8266 apenas se for compilar/gravar o firmware.

### 1. Configurar chaves locais

No backend, substitui as chaves de exemplo por valores aleatórios através de variáveis de ambiente, por exemplo:

```bash
export Wellstate__DeviceApiKey="uma-chave-aleatoria-longa-para-o-sensor"
export Wellstate__AgentApiKey="outra-chave-aleatoria-longa-para-o-agente"
```

No Windows PowerShell, usa `$env:Wellstate__DeviceApiKey = '...'` e `$env:Wellstate__AgentApiKey = '...'` antes de iniciar a API. Não publiques chaves nem `firmware/Wellstate_Firmware/secrets.h`.

### 2. Iniciar o portal e a API

Na raiz do projeto:

```bash
./start-wellstate.sh
```

O portal PHP abre em `http://localhost:8080`; a API C# ouve em `http://localhost:5080`. Em Windows, executa `start-wellstate.ps1` ou `Iniciar-Servidor.bat`. Também podes iniciar os componentes separadamente:

```bash
# Terminal 1 — API C# (a partir da raiz)
dotnet run --project backend-csharp/Wellstate.API.csproj --urls http://0.0.0.0:5080

# Terminal 2 — portal PHP, na raiz do projeto
php -S 0.0.0.0:8080 -t . server/router.php
```

A primeira conta pode ser criada em `/register`; depois inicia sessão em `/login`. As contas são guardadas em `server/data/users.sqlite`, criada automaticamente.

### 3. Configurar o sensor ESP8266 (opcional)

1. Copia `firmware/Wellstate_Firmware/secrets.example.h` para `secrets.h`.
2. Preenche Wi-Fi, `WELLSTATE_API_BASE_URL` (porta 5080), `WELLSTATE_PORTAL_URL` (porta 8080/login), sala e chave do dispositivo.
3. Instala as bibliotecas indicadas em [docs/HARDWARE.md](docs/HARDWARE.md), compila e grava na placa.

## Persistência

- Utilizadores PHP: SQLite em `server/data/users.sqlite`, palavras-passe com `password_hash`.
- Medições e sinais: SQLite em `backend-csharp/Data/wellstate.db`.
- Salas, computadores configurados, horários e preferências: armazenamento local do navegador (`localStorage`).
- Firestore: não ligado nesta versão. Esquema e regras de referência em [docs/FIREBASE.md](docs/FIREBASE.md).

## Segurança e limites

- O router PHP protege páginas HTML do frontend, mantém a sessão em cookie HttpOnly e valida CSRF nas ações de conta.
- O servidor PHP integrado destina-se a desenvolvimento ou LAN de confiança; para publicação use PHP-FPM/Apache/Nginx com HTTPS.
- A API C# tem endpoints de leitura sem sessão PHP e comunica diretamente com os dispositivos. **Mantenha a porta 5080 limitada à LAN/VPN; não a exponha à Internet.** Sensores e agentes continuam a usar chaves de dispositivo próprias.
- As alterações de salas e horários continuam locais ao browser, não são sincronizadas entre utilizadores.
- Este pacote inclui exemplos de configuração, não credenciais reais. Firestore requer um projeto Firebase, configuração e credenciais privadas próprias.

## Documentação

- [Configuração e resolução de problemas](docs/SETUP.md)
- [Arquitetura da base de dados](docs/DATABASE.md)
- [Esquema Firestore de referência](docs/FIREBASE.md)
- [Montagem de hardware](docs/ASSEMBLY.md)
- [Referência da API REST](docs/REST_API.md)

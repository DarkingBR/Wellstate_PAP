using System.ComponentModel.DataAnnotations;

namespace Wellstate.API.Models;

public sealed class RoomTelemetryRequest
{
    [Range(-40, 85)]
    public double? Temperature { get; set; }

    [Range(0, 100)]
    public double? Humidity { get; set; }

    [Range(2, 400)]
    public double? Distance { get; set; }

    public bool Motion { get; set; }
    public bool Occupied { get; set; }

    [StringLength(20)]
    public string? Event { get; set; }
}

public sealed record RoomTelemetry(
    long Id,
    string RoomId,
    double? Temperature,
    double? Humidity,
    double? Distance,
    bool Motion,
    bool Occupied,
    string Event,
    DateTimeOffset UpdatedAt);

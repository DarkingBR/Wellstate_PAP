namespace Wellstate.API.Models;

public class Pc
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Ip { get; set; } = string.Empty;
    public string RoomId { get; set; } = string.Empty;

    // Online é verdadeiro quando há resposta de ping ou heartbeat recente do agente.
    public bool Online { get; set; }
    public bool NetworkOnline { get; set; }
    public bool AgentOnline { get; set; }
    public long? ResponseMs { get; set; }
    public DateTimeOffset? LastSeenAt { get; set; }
}

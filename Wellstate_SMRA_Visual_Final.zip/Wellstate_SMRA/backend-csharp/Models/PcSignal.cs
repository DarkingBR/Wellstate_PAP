using System.ComponentModel.DataAnnotations;

namespace Wellstate.API.Models;

public sealed class PcSignal
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string PcId { get; set; } = string.Empty;
    public string Type { get; set; } = "notification";
    public string Message { get; set; } = string.Empty;
    public string Status { get; set; } = "pending";
    public string? ResultMessage { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public DateTimeOffset? ClaimedAt { get; set; }
    public DateTimeOffset? ReceivedAt { get; set; }
    public DateTimeOffset? ReturnedAt { get; set; }
}

public sealed class SendSignalRequest
{
    [Required]
    [RegularExpression("notification", ErrorMessage = "O tipo de sinal suportado é notification.")]
    public string Type { get; set; } = "notification";

    [Required]
    [StringLength(500, MinimumLength = 1)]
    public string Message { get; set; } = string.Empty;

    [Range(5, 600)]
    public int? ExpiresInSeconds { get; set; }
}

public sealed class AgentHeartbeatRequest
{
    [StringLength(100)]
    public string? ComputerName { get; set; }

    [StringLength(40)]
    public string? AgentVersion { get; set; }
}

public sealed class SignalAcknowledgementRequest
{
    public bool Success { get; set; }

    [StringLength(500)]
    public string? Details { get; set; }
}

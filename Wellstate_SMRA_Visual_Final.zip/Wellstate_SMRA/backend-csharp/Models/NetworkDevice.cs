namespace Wellstate.API.Models;

public sealed class NetworkDevice
{
    public string Ip { get; init; } = string.Empty;
    public string Hostname { get; init; } = string.Empty;
    public bool Online { get; init; }
    public long? ResponseMs { get; init; }
}

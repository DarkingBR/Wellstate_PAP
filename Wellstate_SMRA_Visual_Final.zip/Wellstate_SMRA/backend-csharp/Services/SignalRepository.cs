using System.Globalization;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using Wellstate.API.Models;

namespace Wellstate.API.Services;

/// <summary>Persistência transacional dos sinais, partilhando a base SQLite do sistema.</summary>
public sealed class SignalRepository
{
    private readonly string _connectionString;
    private readonly string _legacyJsonPath;
    private readonly Task _initialized;

    public SignalRepository(IConfiguration configuration, IHostEnvironment environment)
    {
        var configuredPath = configuration["Wellstate:Database:Path"] ?? "Data/wellstate.db";
        var databasePath = Path.IsPathRooted(configuredPath)
            ? configuredPath
            : Path.Combine(environment.ContentRootPath, configuredPath);
        var legacyPath = configuration["Wellstate:Signal:LegacyLogFile"] ?? "Data/signals.json";
        _legacyJsonPath = Path.IsPathRooted(legacyPath)
            ? legacyPath
            : Path.Combine(environment.ContentRootPath, legacyPath);
        Directory.CreateDirectory(Path.GetDirectoryName(databasePath)!);
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = databasePath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Cache = SqliteCacheMode.Shared,
            Pooling = true,
            ForeignKeys = true,
            DefaultTimeout = 15
        }.ToString();
        _initialized = InitializeAsync();
    }

    private async Task InitializeAsync()
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            PRAGMA journal_mode = WAL;
            PRAGMA synchronous = NORMAL;
            PRAGMA busy_timeout = 15000;
            CREATE TABLE IF NOT EXISTS pc_signals (
                id TEXT PRIMARY KEY,
                pc_id TEXT NOT NULL COLLATE NOCASE,
                type TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT NOT NULL,
                result_message TEXT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                claimed_at TEXT NULL,
                received_at TEXT NULL,
                returned_at TEXT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_pc_signals_pc_created
                ON pc_signals(pc_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_pc_signals_pending
                ON pc_signals(pc_id, status, created_at);
            """;
        await command.ExecuteNonQueryAsync();
        await ImportLegacyJsonIfNeededAsync();
    }

    private async Task ImportLegacyJsonIfNeededAsync()
    {
        if (!File.Exists(_legacyJsonPath)) return;
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        await using var count = connection.CreateCommand();
        count.CommandText = "SELECT COUNT(*) FROM pc_signals;";
        if (Convert.ToInt64(await count.ExecuteScalarAsync(), CultureInfo.InvariantCulture) > 0) return;

        List<PcSignal> legacy;
        try
        {
            legacy = JsonSerializer.Deserialize<List<PcSignal>>(await File.ReadAllTextAsync(_legacyJsonPath),
                new JsonSerializerOptions(JsonSerializerDefaults.Web)) ?? [];
        }
        catch (JsonException)
        {
            return;
        }
        if (legacy.Count == 0) return;

        await using var transaction = await connection.BeginTransactionAsync();
        foreach (var signal in legacy.TakeLast(500))
        {
            await using var insert = connection.CreateCommand();
            insert.Transaction = (SqliteTransaction)transaction;
            insert.CommandText = """
                INSERT OR IGNORE INTO pc_signals
                    (id, pc_id, type, message, status, result_message, created_at, expires_at,
                     claimed_at, received_at, returned_at)
                VALUES
                    ($id, $pcId, $type, $message, $status, $resultMessage, $createdAt, $expiresAt,
                     $claimedAt, $receivedAt, $returnedAt);
                """;
            insert.Parameters.AddWithValue("$id", signal.Id);
            insert.Parameters.AddWithValue("$pcId", signal.PcId);
            insert.Parameters.AddWithValue("$type", signal.Type);
            insert.Parameters.AddWithValue("$message", signal.Message);
            insert.Parameters.AddWithValue("$status", signal.Status);
            insert.Parameters.AddWithValue("$resultMessage", (object?)signal.ResultMessage ?? DBNull.Value);
            insert.Parameters.AddWithValue("$createdAt", Format(signal.CreatedAt));
            insert.Parameters.AddWithValue("$expiresAt", Format(signal.ExpiresAt));
            insert.Parameters.AddWithValue("$claimedAt", DbDate(signal.ClaimedAt));
            insert.Parameters.AddWithValue("$receivedAt", DbDate(signal.ReceivedAt));
            insert.Parameters.AddWithValue("$returnedAt", DbDate(signal.ReturnedAt));
            await insert.ExecuteNonQueryAsync();
        }
        await transaction.CommitAsync();
        File.Copy(_legacyJsonPath, _legacyJsonPath + ".migrated.bak", overwrite: true);
    }

    public async Task<List<PcSignal>> LoadAsync(CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, pc_id, type, message, status, result_message, created_at, expires_at,
                   claimed_at, received_at, returned_at
            FROM pc_signals ORDER BY created_at ASC;
            """;
        var results = new List<PcSignal>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            results.Add(new PcSignal
            {
                Id = reader.GetString(0),
                PcId = reader.GetString(1),
                Type = reader.GetString(2),
                Message = reader.GetString(3),
                Status = reader.GetString(4),
                ResultMessage = reader.IsDBNull(5) ? null : reader.GetString(5),
                CreatedAt = Parse(reader.GetString(6)),
                ExpiresAt = Parse(reader.GetString(7)),
                ClaimedAt = reader.IsDBNull(8) ? null : Parse(reader.GetString(8)),
                ReceivedAt = reader.IsDBNull(9) ? null : Parse(reader.GetString(9)),
                ReturnedAt = reader.IsDBNull(10) ? null : Parse(reader.GetString(10))
            });
        }
        return results;
    }

    public async Task ReplaceAllAsync(IReadOnlyCollection<PcSignal> signals, CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);
        await using (var delete = connection.CreateCommand())
        {
            delete.Transaction = (SqliteTransaction)transaction;
            delete.CommandText = "DELETE FROM pc_signals;";
            await delete.ExecuteNonQueryAsync(cancellationToken);
        }

        foreach (var signal in signals)
        {
            await using var insert = connection.CreateCommand();
            insert.Transaction = (SqliteTransaction)transaction;
            insert.CommandText = """
                INSERT INTO pc_signals
                    (id, pc_id, type, message, status, result_message, created_at, expires_at,
                     claimed_at, received_at, returned_at)
                VALUES
                    ($id, $pcId, $type, $message, $status, $resultMessage, $createdAt, $expiresAt,
                     $claimedAt, $receivedAt, $returnedAt);
                """;
            insert.Parameters.AddWithValue("$id", signal.Id);
            insert.Parameters.AddWithValue("$pcId", signal.PcId);
            insert.Parameters.AddWithValue("$type", signal.Type);
            insert.Parameters.AddWithValue("$message", signal.Message);
            insert.Parameters.AddWithValue("$status", signal.Status);
            insert.Parameters.AddWithValue("$resultMessage", (object?)signal.ResultMessage ?? DBNull.Value);
            insert.Parameters.AddWithValue("$createdAt", Format(signal.CreatedAt));
            insert.Parameters.AddWithValue("$expiresAt", Format(signal.ExpiresAt));
            insert.Parameters.AddWithValue("$claimedAt", DbDate(signal.ClaimedAt));
            insert.Parameters.AddWithValue("$receivedAt", DbDate(signal.ReceivedAt));
            insert.Parameters.AddWithValue("$returnedAt", DbDate(signal.ReturnedAt));
            await insert.ExecuteNonQueryAsync(cancellationToken);
        }
        await transaction.CommitAsync(cancellationToken);
    }

    public async Task CheckAsync(CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM pc_signals;";
        await command.ExecuteScalarAsync(cancellationToken);
    }

    private static string Format(DateTimeOffset value) => value.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture);
    private static object DbDate(DateTimeOffset? value) => value.HasValue ? Format(value.Value) : DBNull.Value;
    private static DateTimeOffset Parse(string value) => DateTimeOffset.Parse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
}

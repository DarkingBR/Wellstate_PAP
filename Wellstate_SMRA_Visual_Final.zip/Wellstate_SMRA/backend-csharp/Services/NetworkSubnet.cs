using System.Buffers.Binary;
using System.Net;

namespace Wellstate.API.Services;

/// <summary>Sub-rede IPv4 que pode ser varrida sem sair de um intervalo privado.</summary>
public sealed record NetworkSubnet(
    string Cidr,
    uint NetworkAddressValue,
    int PrefixLength,
    string InterfaceName,
    string LocalAddress,
    string? Gateway,
    bool AutomaticallyDetected)
{
    public long AddressCount => 1L << (32 - PrefixLength);
    public long HostCount => PrefixLength >= 31 ? AddressCount : AddressCount - 2;

    public static NetworkSubnet ParseCidr(string cidr)
    {
        var parts = cidr.Split('/', 2, StringSplitOptions.TrimEntries);
        if (parts.Length != 2 || !IPAddress.TryParse(parts[0], out var address) ||
            !int.TryParse(parts[1], out var prefix) || address.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork || prefix is < 0 or > 32)
        {
            throw new ArgumentException($"Sub-rede IPv4 inválida: '{cidr}'. Usa, por exemplo, 192.168.1.0/24.", nameof(cidr));
        }

        return Create(address, prefix, "Configuração manual", address.ToString(), null, automaticallyDetected: false);
    }

    public static NetworkSubnet FromInterface(IPAddress address, IPAddress mask, string interfaceName, string? gateway)
    {
        if (address.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork ||
            mask.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork)
        {
            throw new ArgumentException("A descoberta automática só suporta endereços IPv4.");
        }

        var maskValue = ToUInt32(mask);
        var prefix = 0;
        var zeroSeen = false;
        for (var bit = 31; bit >= 0; bit--)
        {
            var set = (maskValue & (1u << bit)) != 0;
            if (set && zeroSeen) throw new ArgumentException("A máscara IPv4 da interface não é contígua.");
            if (set) prefix++;
            else zeroSeen = true;
        }

        return Create(address, prefix, interfaceName, address.ToString(), gateway, automaticallyDetected: true);
    }

    public IEnumerable<IPAddress> EnumerateHosts(int limit)
    {
        if (limit <= 0) yield break;

        var count = Math.Min(HostCount, limit);
        var first = PrefixLength >= 31 ? (ulong)NetworkAddressValue : (ulong)NetworkAddressValue + 1;
        for (long index = 0; index < count; index++)
        {
            yield return FromUInt32((uint)(first + (ulong)index));
        }
    }

    public static bool IsPrivateAddress(IPAddress address)
    {
        if (address.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork) return false;
        var value = ToUInt32(address);
        return (value & 0xFF000000u) == 0x0A000000u ||
               (value & 0xFFF00000u) == 0xAC100000u ||
               (value & 0xFFFF0000u) == 0xC0A80000u;
    }

    private static NetworkSubnet Create(IPAddress address, int prefix, string interfaceName, string localAddress, string? gateway, bool automaticallyDetected)
    {
        var value = ToUInt32(address);
        var mask = prefix == 0 ? 0u : uint.MaxValue << (32 - prefix);
        var network = value & mask;
        var addressCount = 1L << (32 - prefix);
        var last = (uint)((ulong)network + (ulong)addressCount - 1);
        if (!IsPrivateAddress(FromUInt32(network)) || !IsPrivateAddress(FromUInt32(last)))
        {
            throw new ArgumentException("Por segurança, a descoberta só aceita sub-redes IPv4 privadas (10/8, 172.16/12 ou 192.168/16).");
        }

        var normalizedCidr = $"{FromUInt32(network)}/{prefix}";
        return new NetworkSubnet(normalizedCidr, network, prefix, interfaceName, localAddress, gateway, automaticallyDetected);
    }

    private static uint ToUInt32(IPAddress address) => BinaryPrimitives.ReadUInt32BigEndian(address.GetAddressBytes());

    private static IPAddress FromUInt32(uint value)
    {
        var bytes = new byte[4];
        BinaryPrimitives.WriteUInt32BigEndian(bytes, value);
        return new IPAddress(bytes);
    }
}

using Wellstate.API.Models;

namespace Wellstate.API.Services;

public sealed class PcRepository
{
    public IReadOnlyList<Pc> Pcs { get; }

    public PcRepository(IConfiguration configuration)
    {
        Pcs = configuration.GetSection("Wellstate:Pcs").Get<List<Pc>>() ?? [];
    }

    public Pc? Find(string id) => Pcs.FirstOrDefault(pc => pc.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
}

using System.Net.NetworkInformation;

namespace Wellstate.API.Services;

/// <summary>
/// Verifica se um determinado PC está ligado na rede via ICMP ping.
/// </summary>
public class PingService
{
    private readonly int _timeoutMs;

    public PingService(IConfiguration config)
    {
        _timeoutMs = config.GetValue<int?>("Wellstate:PingTimeoutMs") ?? 800;
    }

    public async Task<(bool online, long? rttMs)> PingAsync(string ipOrHost)
    {
        try
        {
            using var ping = new Ping();
            var reply = await ping.SendPingAsync(ipOrHost, _timeoutMs);
            if (reply.Status == IPStatus.Success)
                return (true, reply.RoundtripTime);
            return (false, null);
        }
        catch
        {
            return (false, null);
        }
    }
}

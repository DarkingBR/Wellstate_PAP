using Wellstate.API.Models;

namespace Wellstate.API.Services;

/// <summary>
/// Mantém uma fila curta e persistente de sinais. Um sinal só entra na fila quando
/// o agente está ligado; caso contrário é registado como devolvido sem entrega tardia.
/// </summary>
public sealed class SignalService
{
    private const int MaxHistoryEntries = 500;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly List<PcSignal> _signals = [];
    private readonly SignalRepository _repository;
    private readonly Task _initialized;
    private readonly TimeSpan _defaultLifetime;
    private readonly TimeSpan _claimLifetime = TimeSpan.FromSeconds(20);

    public SignalService(IConfiguration configuration, SignalRepository repository)
    {
        _repository = repository;
        var lifetimeSeconds = configuration.GetValue<int?>("Wellstate:Signal:DefaultExpirySeconds") ?? 30;
        _defaultLifetime = TimeSpan.FromSeconds(Math.Clamp(lifetimeSeconds, 5, 600));
        _initialized = LoadAsync();
    }

    private async Task LoadAsync()
    {
        var stored = await _repository.LoadAsync();
        _signals.AddRange(stored.TakeLast(MaxHistoryEntries));
    }

    public async Task<PcSignal> CreateAsync(string pcId, string type, string message, bool receiverOnline, int? expiresInSeconds, CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var changed = ExpireAndReleaseClaims();
            var lifetime = expiresInSeconds.HasValue
                ? TimeSpan.FromSeconds(Math.Clamp(expiresInSeconds.Value, 5, 600))
                : _defaultLifetime;
            var now = DateTimeOffset.UtcNow;
            var signal = new PcSignal
            {
                PcId = pcId,
                Type = type,
                Message = message.Trim(),
                Status = receiverOnline ? "pending" : "returned",
                ResultMessage = receiverOnline
                    ? "Sinal enviado; a aguardar confirmação do PC."
                    : "Erro: PC desligado ou sem ligação. O sinal foi devolvido e não ficará em fila.",
                CreatedAt = now,
                ExpiresAt = now.Add(lifetime),
                ReturnedAt = receiverOnline ? null : now
            };
            _signals.Add(signal);
            TrimHistory();
            await PersistAsync(cancellationToken);
            return Copy(signal);
        }
        finally { _gate.Release(); }
    }

    public async Task<PcSignal?> ClaimNextAsync(string pcId, CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var changed = ExpireAndReleaseClaims();
            var signal = _signals
                .Where(item => item.PcId.Equals(pcId, StringComparison.OrdinalIgnoreCase) && item.Status == "pending")
                .OrderBy(item => item.CreatedAt)
                .FirstOrDefault();
            if (signal is null)
            {
                if (changed) await PersistAsync(cancellationToken);
                return null;
            }

            signal.Status = "claimed";
            signal.ClaimedAt = DateTimeOffset.UtcNow;
            signal.ResultMessage = "Entregue ao agente; aguarda confirmação de apresentação.";
            await PersistAsync(cancellationToken);
            return Copy(signal);
        }
        finally { _gate.Release(); }
    }

    public async Task<PcSignal?> AcknowledgeAsync(string pcId, string signalId, bool success, string? details, CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await _gate.WaitAsync(cancellationToken);
        try
        {
            ExpireAndReleaseClaims();
            var item = _signals.FirstOrDefault(candidate =>
                candidate.Id.Equals(signalId, StringComparison.OrdinalIgnoreCase) &&
                candidate.PcId.Equals(pcId, StringComparison.OrdinalIgnoreCase));
            if (item is null || item.Status != "claimed") return null;

            item.Status = success ? "received" : "failed";
            item.ReceivedAt = DateTimeOffset.UtcNow;
            item.ResultMessage = string.IsNullOrWhiteSpace(details)
                ? (success ? "Sinal recebido e apresentado no PC." : "Erro: o PC não conseguiu apresentar o sinal.")
                : details.Trim();
            await PersistAsync(cancellationToken);
            return Copy(item);
        }
        finally { _gate.Release(); }
    }

    public async Task<IReadOnlyList<PcSignal>> GetHistoryAsync(string pcId, int limit = 30, CancellationToken cancellationToken = default)
    {
        await _initialized.WaitAsync(cancellationToken);
        await _gate.WaitAsync(cancellationToken);
        try
        {
            if (ExpireAndReleaseClaims()) await PersistAsync(cancellationToken);
            return _signals
                .Where(item => item.PcId.Equals(pcId, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(item => item.CreatedAt)
                .Take(Math.Clamp(limit, 1, 100))
                .Select(Copy)
                .ToList();
        }
        finally { _gate.Release(); }
    }

    private bool ExpireAndReleaseClaims()
    {
        var now = DateTimeOffset.UtcNow;
        var changed = false;
        foreach (var signal in _signals)
        {
            if (signal.Status == "claimed" && signal.ClaimedAt.HasValue && now - signal.ClaimedAt.Value > _claimLifetime)
            {
                signal.Status = "pending";
                signal.ClaimedAt = null;
                signal.ResultMessage = "O agente não confirmou; o sinal pode ser entregue novamente antes de expirar.";
                changed = true;
            }

            if ((signal.Status == "pending" || signal.Status == "claimed") && now >= signal.ExpiresAt)
            {
                signal.Status = "returned";
                signal.ReturnedAt = now;
                signal.ResultMessage = "Erro: o PC não confirmou dentro do prazo; o sinal foi devolvido.";
                changed = true;
            }
        }
        return changed;
    }

    private Task PersistAsync(CancellationToken cancellationToken) =>
        _repository.ReplaceAllAsync(_signals.Select(Copy).ToList(), cancellationToken);

    private void TrimHistory()
    {
        if (_signals.Count > MaxHistoryEntries)
            _signals.RemoveRange(0, _signals.Count - MaxHistoryEntries);
    }

    private static PcSignal Copy(PcSignal signal) => new()
    {
        Id = signal.Id,
        PcId = signal.PcId,
        Type = signal.Type,
        Message = signal.Message,
        Status = signal.Status,
        ResultMessage = signal.ResultMessage,
        CreatedAt = signal.CreatedAt,
        ExpiresAt = signal.ExpiresAt,
        ClaimedAt = signal.ClaimedAt,
        ReceivedAt = signal.ReceivedAt,
        ReturnedAt = signal.ReturnedAt
    };
}

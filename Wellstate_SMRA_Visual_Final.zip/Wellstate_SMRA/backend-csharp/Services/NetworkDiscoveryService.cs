using System.Collections.Concurrent;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using Wellstate.API.Models;

namespace Wellstate.API.Services;

public sealed record NetworkScanResult(
    string ScanCidr,
    DateTimeOffset ScannedAt,
    IReadOnlyList<NetworkDevice> Devices,
    bool AutomaticallyDetected,
    string InterfaceName,
    string ServerAddress,
    string? Gateway,
    int HostsScanned,
    long HostsAvailable,
    bool ScanLimited);

/// <summary>Descobre apenas hosts de uma sub-rede privada ligada ao servidor; nunca varre a Internet pública.</summary>
public sealed class NetworkDiscoveryService
{
    private readonly NetworkSubnetResolver _subnetResolver;
    private readonly int _timeoutMs;
    private readonly int _maxHosts;
    private readonly int _parallelism;
    private readonly TimeSpan _cacheDuration;
    private readonly SemaphoreSlim _scanLock = new(1, 1);
    private NetworkScanResult? _cached;

    public NetworkDiscoveryService(IConfiguration configuration, NetworkSubnetResolver subnetResolver)
    {
        _subnetResolver = subnetResolver;
        _timeoutMs = Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:PingTimeoutMs") ?? 350, 100, 2000);
        _maxHosts = Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:MaxHosts") ?? 4096, 1, 65534);
        _parallelism = Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:Parallelism") ?? 128, 1, 256);
        _cacheDuration = TimeSpan.FromSeconds(Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:CacheSeconds") ?? 8, 0, 60));
    }

    public async Task<NetworkScanResult> ScanAsync(bool force, CancellationToken cancellationToken)
    {
        if (!force && IsCacheFresh()) return _cached!;

        await _scanLock.WaitAsync(cancellationToken);
        try
        {
            if (!force && IsCacheFresh()) return _cached!;

            var subnet = _subnetResolver.Resolve();
            var addresses = subnet.EnumerateHosts(_maxHosts).ToArray();
            var devices = new ConcurrentBag<NetworkDevice>();
            using var limiter = new SemaphoreSlim(_parallelism, _parallelism);
            var jobs = addresses.Select(async ip =>
            {
                await limiter.WaitAsync(cancellationToken);
                try
                {
                    using var ping = new Ping();
                    var reply = await ping.SendPingAsync(ip, _timeoutMs);
                    if (reply.Status != IPStatus.Success) return;

                    devices.Add(new NetworkDevice
                    {
                        Ip = ip.ToString(),
                        Hostname = await ResolveHostnameAsync(ip, cancellationToken),
                        Online = true,
                        ResponseMs = reply.RoundtripTime
                    });
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch (SocketException)
                {
                    // Um DNS inverso sem resposta não invalida a descoberta por ping.
                }
                catch (PingException)
                {
                    // Alguns sistemas recusam ICMP; os restantes endereços continuam a ser verificados.
                }
                catch (InvalidOperationException)
                {
                    // Um host isolado com erro de rede não interrompe o scan.
                }
                finally
                {
                    limiter.Release();
                }
            });

            await Task.WhenAll(jobs);
            _cached = new NetworkScanResult(
                subnet.Cidr,
                DateTimeOffset.UtcNow,
                devices.OrderBy(device => IpSortKey(device.Ip)).ToArray(),
                subnet.AutomaticallyDetected,
                subnet.InterfaceName,
                subnet.LocalAddress,
                subnet.Gateway,
                addresses.Length,
                subnet.HostCount,
                subnet.HostCount > addresses.Length);
            return _cached;
        }
        finally
        {
            _scanLock.Release();
        }
    }

    private bool IsCacheFresh() => _cached is not null && DateTimeOffset.UtcNow - _cached.ScannedAt < _cacheDuration;

    private static async Task<string> ResolveHostnameAsync(IPAddress ip, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            var lookup = Dns.GetHostEntryAsync(ip);
            var completed = await Task.WhenAny(lookup, Task.Delay(120, cancellationToken));
            cancellationToken.ThrowIfCancellationRequested();
            return completed == lookup ? (await lookup).HostName : string.Empty;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch
        {
            return string.Empty;
        }
    }

    private static long IpSortKey(string value) => IPAddress.TryParse(value, out var ip)
        ? System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(ip.GetAddressBytes())
        : long.MaxValue;
}

using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace Wellstate.API.Services;

public sealed class NetworkUnavailableException(string message) : Exception(message);

/// <summary>Escolhe a sub-rede da rota IPv4 principal ou, como alternativa, uma interface LAN ativa.</summary>
public sealed class NetworkSubnetResolver
{
    private readonly string? _configuredCidr;

    public NetworkSubnetResolver(IConfiguration configuration)
    {
        _configuredCidr = configuration["Wellstate:Network:Cidr"];
    }

    public NetworkSubnet Resolve()
    {
        if (!string.IsNullOrWhiteSpace(_configuredCidr) &&
            !string.Equals(_configuredCidr.Trim(), "auto", StringComparison.OrdinalIgnoreCase))
        {
            return NetworkSubnet.ParseCidr(_configuredCidr.Trim());
        }

        var candidates = GetPrivateNetworks();
        if (candidates.Count == 0)
        {
            throw new NetworkUnavailableException(
                "Não foi encontrada uma interface com gateway e endereço IPv4 privado. Liga o servidor à rede ou define Wellstate:Network:Cidr manualmente.");
        }

        var routedAddress = GetDefaultRouteAddress();
        NetworkSubnet? selected = null;
        if (routedAddress is not null)
        {
            foreach (var candidate in candidates)
            {
                if (IPAddress.TryParse(candidate.Subnet.LocalAddress, out var local) && local.Equals(routedAddress))
                {
                    selected = candidate.Subnet;
                    break;
                }
            }
        }

        selected ??= candidates
            .OrderBy(candidate => candidate.InterfaceType == NetworkInterfaceType.Wireless80211 ? 0 :
                                  candidate.InterfaceType == NetworkInterfaceType.Ethernet ? 1 : 2)
            .ThenByDescending(candidate => candidate.Subnet.PrefixLength)
            .First()
            .Subnet;

        return selected;
    }

    private static List<(NetworkSubnet Subnet, NetworkInterfaceType InterfaceType)> GetPrivateNetworks()
    {
        var candidates = new List<(NetworkSubnet Subnet, NetworkInterfaceType InterfaceType)>();
        foreach (var network in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (network.OperationalStatus != OperationalStatus.Up || network.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                continue;

            try
            {
                var properties = network.GetIPProperties();
                var gateway = properties.GatewayAddresses
                    .Select(entry => entry.Address)
                    .FirstOrDefault(address => address.AddressFamily == AddressFamily.InterNetwork && !address.Equals(IPAddress.Any));
                if (gateway is null) continue;

                foreach (var unicast in properties.UnicastAddresses)
                {
                    if (unicast.Address.AddressFamily != AddressFamily.InterNetwork ||
                        IPAddress.IsLoopback(unicast.Address) || unicast.IPv4Mask is null ||
                        !NetworkSubnet.IsPrivateAddress(unicast.Address))
                    {
                        continue;
                    }

                    try
                    {
                        var subnet = NetworkSubnet.FromInterface(unicast.Address, unicast.IPv4Mask, network.Name, gateway.ToString());
                        candidates.Add((subnet, network.NetworkInterfaceType));
                    }
                    catch (ArgumentException)
                    {
                        // Ignora adaptadores com máscaras inválidas ou intervalos não privados.
                    }
                }
            }
            catch (NetworkInformationException)
            {
                // Uma interface que desaparece durante a consulta não impede as restantes.
            }
        }

        return candidates
            .GroupBy(candidate => candidate.Subnet.Cidr, StringComparer.OrdinalIgnoreCase)
            .Select(group => group.First())
            .ToList();
    }

    private static IPAddress? GetDefaultRouteAddress()
    {
        try
        {
            // Connect UDP escolhe a rota local do sistema operativo; não envia dados nem faz scan ao destino TEST-NET.
            using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.Connect(new IPEndPoint(IPAddress.Parse("192.0.2.1"), 9));
            return (socket.LocalEndPoint as IPEndPoint)?.Address;
        }
        catch (SocketException)
        {
            return null;
        }
    }
}

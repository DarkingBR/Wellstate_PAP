using System.Collections.Concurrent;

namespace Wellstate.API.Services;

public sealed record AgentPresence(DateTimeOffset LastSeenAt, string? ComputerName, string? AgentVersion);

/// <summary>Presença dos agentes Windows publicada pelo stream SSE.</summary>
public sealed class PcPresenceService
{
    private readonly ConcurrentDictionary<string, AgentPresence> _agents = new(StringComparer.OrdinalIgnoreCase);
    private readonly TimeSpan _onlineWindow;

    public PcPresenceService(IConfiguration configuration)
    {
        var seconds = configuration.GetValue<int?>("Wellstate:Signal:AgentOnlineSeconds") ?? 8;
        _onlineWindow = TimeSpan.FromSeconds(Math.Clamp(seconds, 3, 60));
    }

    public Task MarkSeenAsync(string pcId, string? computerName, string? agentVersion)
    {
        _agents[pcId] = new(DateTimeOffset.UtcNow, computerName, agentVersion);
        return Task.CompletedTask;
    }

    public bool IsOnline(string pcId)
    {
        var presence = Get(pcId);
        return presence is not null && DateTimeOffset.UtcNow - presence.LastSeenAt <= _onlineWindow;
    }

    public AgentPresence? Get(string pcId) => _agents.TryGetValue(pcId, out var presence) ? presence : null;
    public TimeSpan OnlineWindow => _onlineWindow;
}

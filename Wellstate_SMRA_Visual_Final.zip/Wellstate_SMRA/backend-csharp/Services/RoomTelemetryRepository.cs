using System.Globalization;
using Microsoft.Data.Sqlite;
using Wellstate.API.Models;

namespace Wellstate.API.Services;

public sealed class RoomTelemetryRepository
{
    private const int RetentionDays = 90;
    private readonly string _connectionString;
    private readonly Task _initialized;
    private int _writeCount;

    public RoomTelemetryRepository(IConfiguration configuration, IHostEnvironment environment)
    {
        var configuredPath = configuration["Wellstate:Database:Path"] ?? "Data/wellstate.db";
        var databasePath = Path.IsPathRooted(configuredPath)
            ? configuredPath
            : Path.Combine(environment.ContentRootPath, configuredPath);
        Directory.CreateDirectory(Path.GetDirectoryName(databasePath)!);
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = databasePath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Cache = SqliteCacheMode.Shared,
            Pooling = true,
            ForeignKeys = true,
            DefaultTimeout = 10
        }.ToString();
        _initialized = InitializeAsync();
    }

    private async Task InitializeAsync()
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            PRAGMA journal_mode = WAL;
            PRAGMA synchronous = NORMAL;
            PRAGMA foreign_keys = ON;
            PRAGMA busy_timeout = 10000;
            CREATE TABLE IF NOT EXISTS rooms (
                room_id TEXT PRIMARY KEY COLLATE NOCASE,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS room_telemetry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id TEXT NOT NULL COLLATE NOCASE,
                temperature REAL NULL,
                humidity REAL NULL,
                distance REAL NULL,
                motion INTEGER NOT NULL CHECK (motion IN (0, 1)),
                occupied INTEGER NOT NULL CHECK (occupied IN (0, 1)),
                event TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON UPDATE CASCADE ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_room_telemetry_room_time
                ON room_telemetry(room_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_room_telemetry_time
                ON room_telemetry(created_at DESC);
            """;
        await command.ExecuteNonQueryAsync();
    }

    public async Task<RoomTelemetry> AddAsync(string roomId, RoomTelemetryRequest request, CancellationToken cancellationToken)
    {
        await _initialized.WaitAsync(cancellationToken);
        var createdAt = DateTimeOffset.UtcNow;
        var eventName = request.Occupied ? "occupied" : request.Motion ? "motion" : "reading";

        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);

        await using (var room = connection.CreateCommand())
        {
            room.Transaction = (SqliteTransaction)transaction;
            room.CommandText = "INSERT INTO rooms(room_id, created_at) VALUES ($roomId, $createdAt) ON CONFLICT(room_id) DO NOTHING;";
            room.Parameters.AddWithValue("$roomId", roomId);
            room.Parameters.AddWithValue("$createdAt", createdAt.ToString("O", CultureInfo.InvariantCulture));
            await room.ExecuteNonQueryAsync(cancellationToken);
        }

        long id;
        await using (var insert = connection.CreateCommand())
        {
            insert.Transaction = (SqliteTransaction)transaction;
            insert.CommandText = """
                INSERT INTO room_telemetry(room_id, temperature, humidity, distance, motion, occupied, event, created_at)
                VALUES ($roomId, $temperature, $humidity, $distance, $motion, $occupied, $event, $createdAt);
                SELECT last_insert_rowid();
                """;
            insert.Parameters.AddWithValue("$roomId", roomId);
            insert.Parameters.AddWithValue("$temperature", (object?)request.Temperature ?? DBNull.Value);
            insert.Parameters.AddWithValue("$humidity", (object?)request.Humidity ?? DBNull.Value);
            insert.Parameters.AddWithValue("$distance", (object?)request.Distance ?? DBNull.Value);
            insert.Parameters.AddWithValue("$motion", request.Motion ? 1 : 0);
            insert.Parameters.AddWithValue("$occupied", request.Occupied ? 1 : 0);
            insert.Parameters.AddWithValue("$event", eventName);
            insert.Parameters.AddWithValue("$createdAt", createdAt.ToString("O", CultureInfo.InvariantCulture));
            id = (long)(await insert.ExecuteScalarAsync(cancellationToken) ?? 0L);
        }

        await transaction.CommitAsync(cancellationToken);
        if (Interlocked.Increment(ref _writeCount) % 100 == 0)
            await PruneAsync(cancellationToken);

        return new RoomTelemetry(id, roomId, request.Temperature, request.Humidity, request.Distance,
            request.Motion, request.Occupied, eventName, createdAt);
    }

    public async Task<IReadOnlyList<RoomTelemetry>> GetLatestAsync(CancellationToken cancellationToken)
    {
        await _initialized.WaitAsync(cancellationToken);
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT t.id, t.room_id, t.temperature, t.humidity, t.distance, t.motion, t.occupied, t.event, t.created_at
            FROM room_telemetry t
            INNER JOIN (SELECT room_id, MAX(id) AS latest_id FROM room_telemetry GROUP BY room_id) latest
                ON latest.latest_id = t.id
            ORDER BY t.room_id COLLATE NOCASE;
            """;
        var rows = new List<RoomTelemetry>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken)) rows.Add(Read(reader));
        return rows;
    }

    public async Task<IReadOnlyList<RoomTelemetry>> GetHistoryAsync(
        string? roomId, int limit, DateTimeOffset? from, DateTimeOffset? to, CancellationToken cancellationToken)
    {
        await _initialized.WaitAsync(cancellationToken);
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        var filters = new List<string>();
        if (!string.IsNullOrWhiteSpace(roomId))
        {
            filters.Add("room_id = $roomId COLLATE NOCASE");
            command.Parameters.AddWithValue("$roomId", roomId);
        }
        if (from.HasValue)
        {
            filters.Add("created_at >= $from");
            command.Parameters.AddWithValue("$from", from.Value.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture));
        }
        if (to.HasValue)
        {
            filters.Add("created_at <= $to");
            command.Parameters.AddWithValue("$to", to.Value.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture));
        }
        command.CommandText = $"SELECT id, room_id, temperature, humidity, distance, motion, occupied, event, created_at FROM room_telemetry {(filters.Count > 0 ? "WHERE " + string.Join(" AND ", filters) : string.Empty)} ORDER BY id DESC LIMIT $limit;";
        command.Parameters.AddWithValue("$limit", Math.Clamp(limit, 1, 2000));
        var rows = new List<RoomTelemetry>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken)) rows.Add(Read(reader));
        return rows;
    }

    private async Task PruneAsync(CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM room_telemetry WHERE created_at < $cutoff;";
        command.Parameters.AddWithValue("$cutoff", DateTimeOffset.UtcNow.AddDays(-RetentionDays).ToString("O", CultureInfo.InvariantCulture));
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static RoomTelemetry Read(SqliteDataReader reader) => new(
        reader.GetInt64(0),
        reader.GetString(1),
        reader.IsDBNull(2) ? null : reader.GetDouble(2),
        reader.IsDBNull(3) ? null : reader.GetDouble(3),
        reader.IsDBNull(4) ? null : reader.GetDouble(4),
        reader.GetInt64(5) != 0,
        reader.GetInt64(6) != 0,
        reader.GetString(7),
        DateTimeOffset.Parse(reader.GetString(8), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind));
}

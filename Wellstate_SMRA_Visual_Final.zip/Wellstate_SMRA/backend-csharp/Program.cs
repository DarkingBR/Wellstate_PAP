using Microsoft.Extensions.FileProviders;
using Wellstate.API.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<PingService>();
builder.Services.AddSingleton<PcRepository>();
builder.Services.AddSingleton<PcPresenceService>();
builder.Services.AddSingleton<SignalRepository>();
builder.Services.AddSingleton<SignalService>();
builder.Services.AddSingleton<RoomTelemetryRepository>();
builder.Services.AddSingleton<NetworkSubnetResolver>();
builder.Services.AddSingleton<NetworkDiscoveryService>();

builder.Services.AddCors(options => options.AddPolicy("wellstate", policy =>
    policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("wellstate");
var frontendPath = Path.GetFullPath(Path.Combine(builder.Environment.ContentRootPath, "..", "frontend"));
if (Directory.Exists(frontendPath))
{
    var frontendProvider = new PhysicalFileProvider(frontendPath);
    app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = frontendProvider });
    app.UseStaticFiles(new StaticFileOptions { FileProvider = frontendProvider });
}

// O dashboard/API de leitura ficam acessíveis sem conta. Hardware e agentes continuam a usar as suas chaves próprias.
app.MapControllers();
app.Run("http://0.0.0.0:5080");

using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Models;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[Route("api/pcs")]
public sealed class PcsController : ControllerBase
{
    private readonly PingService _ping;
    private readonly PcRepository _repository;
    private readonly PcPresenceService _presence;

    public PcsController(PingService ping, PcRepository repository, PcPresenceService presence)
    {
        _ping = ping;
        _repository = repository;
        _presence = presence;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Pc>>> GetAll()
    {
        var result = await Task.WhenAll(_repository.Pcs.Select(BuildStatusAsync));
        return Ok(result);
    }

    [HttpGet("stream")]
    public async Task Stream(CancellationToken cancellationToken)
    {
        Response.StatusCode = StatusCodes.Status200OK;
        Response.ContentType = "text/event-stream; charset=utf-8";
        Response.Headers.CacheControl = "no-cache, no-store";
        Response.Headers.Connection = "keep-alive";
        Response.Headers["X-Accel-Buffering"] = "no";

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                var state = _repository.Pcs.Select(pc =>
                {
                    var presence = _presence.Get(pc.Id);
                    var agentOnline = presence is not null && DateTimeOffset.UtcNow - presence.LastSeenAt <= _presence.OnlineWindow;
                    return new
                    {
                        id = pc.Id,
                        online = agentOnline,
                        agentOnline,
                        lastSeenAt = presence?.LastSeenAt.ToUnixTimeMilliseconds(),
                        agentVersion = presence?.AgentVersion
                    };
                });
                await Response.WriteAsync($"data: {JsonSerializer.Serialize(state)}\n\n", cancellationToken);
                await Response.Body.FlushAsync(cancellationToken);
                await Task.Delay(TimeSpan.FromSeconds(1), cancellationToken);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // Fecho normal do stream quando o navegador se desliga.
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Pc>> GetOne(string id)
    {
        var pc = _repository.Find(id);
        if (pc is null) return NotFound(new { message = "PC não encontrado." });
        return Ok(await BuildStatusAsync(pc));
    }

    private async Task<Pc> BuildStatusAsync(Pc source)
    {
        var (networkOnline, rtt) = await _ping.PingAsync(source.Ip);
        var presence = _presence.Get(source.Id);
        var agentOnline = presence is not null && DateTimeOffset.UtcNow - presence.LastSeenAt <= _presence.OnlineWindow;
        return new Pc
        {
            Id = source.Id,
            Name = source.Name,
            Ip = source.Ip,
            RoomId = source.RoomId,
            Online = agentOnline || networkOnline,
            AgentOnline = agentOnline,
            NetworkOnline = networkOnline,
            ResponseMs = rtt,
            LastSeenAt = presence?.LastSeenAt
        };
    }
}

using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Models;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[Route("api/pcs/{pcId}/signals")]
public sealed class PcSignalsController : ControllerBase
{
    private readonly PcRepository _repository;
    private readonly PcPresenceService _presence;
    private readonly SignalService _signals;

    public PcSignalsController(PcRepository repository, PcPresenceService presence, SignalService signals)
    {
        _repository = repository;
        _presence = presence;
        _signals = signals;
    }

    /// <summary>Regista e enfileira apenas se o agente do recetor estiver ligado.</summary>
    [HttpPost]
    public async Task<ActionResult> Send(string pcId, SendSignalRequest request, CancellationToken cancellationToken)
    {
        if (_repository.Find(pcId) is null) return NotFound(new { message = "PC não encontrado." });

        var receiverOnline = _presence.IsOnline(pcId);
        var signal = await _signals.CreateAsync(pcId, request.Type.Trim().ToLowerInvariant(), request.Message,
            receiverOnline, request.ExpiresInSeconds, cancellationToken);
        var result = new { accepted = receiverOnline, status = signal.Status, message = signal.ResultMessage, signal };
        return receiverOnline ? Ok(result) : Conflict(result);
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<PcSignal>>> History(string pcId, [FromQuery] int limit = 30, CancellationToken cancellationToken = default)
    {
        if (_repository.Find(pcId) is null) return NotFound(new { message = "PC não encontrado." });
        return Ok(await _signals.GetHistoryAsync(pcId, limit, cancellationToken));
    }
}

using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Models;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[AllowAnonymous]
[Route("api/pcs/{pcId}/agent")]
public sealed class PcAgentController : ControllerBase
{
    private readonly PcRepository _repository;
    private readonly PcPresenceService _presence;
    private readonly SignalService _signals;
    private readonly IConfiguration _configuration;

    public PcAgentController(PcRepository repository, PcPresenceService presence, SignalService signals, IConfiguration configuration)
    {
        _repository = repository;
        _presence = presence;
        _signals = signals;
        _configuration = configuration;
    }

    [HttpPost("heartbeat")]
    public async Task<ActionResult> Heartbeat(string pcId, AgentHeartbeatRequest request)
    {
        if (!IsAgentAuthorized()) return Unauthorized(new { message = "X-Agent-Key inválida ou não configurada." });
        if (_repository.Find(pcId) is null) return NotFound(new { message = "PC não registado." });
        await _presence.MarkSeenAsync(pcId, request.ComputerName, request.AgentVersion);
        return Ok(new { status = "online", timestamp = DateTimeOffset.UtcNow });
    }

    [HttpGet("signals/next")]
    public async Task<ActionResult<PcSignal>> NextSignal(string pcId, CancellationToken cancellationToken)
    {
        if (!IsAgentAuthorized()) return Unauthorized(new { message = "X-Agent-Key inválida ou não configurada." });
        if (_repository.Find(pcId) is null) return NotFound();
        var signal = await _signals.ClaimNextAsync(pcId, cancellationToken);
        return signal is null ? NoContent() : Ok(signal);
    }

    [HttpPost("signals/{signalId}/ack")]
    public async Task<ActionResult<PcSignal>> Acknowledge(string pcId, string signalId,
        SignalAcknowledgementRequest request, CancellationToken cancellationToken)
    {
        if (!IsAgentAuthorized()) return Unauthorized(new { message = "X-Agent-Key inválida ou não configurada." });
        var signal = await _signals.AcknowledgeAsync(pcId, signalId, request.Success, request.Details, cancellationToken);
        return signal is null ? NotFound() : Ok(signal);
    }

    private bool IsAgentAuthorized()
    {
        var expected = _configuration["Wellstate:AgentApiKey"];
        var provided = Request.Headers["X-Agent-Key"].ToString();
        if (string.IsNullOrWhiteSpace(expected) || expected.Contains("CHANGE_ME", StringComparison.OrdinalIgnoreCase) || expected.StartsWith("DEFINA_", StringComparison.OrdinalIgnoreCase)) return false;
        var expectedBytes = Encoding.UTF8.GetBytes(expected);
        var providedBytes = Encoding.UTF8.GetBytes(provided);
        return providedBytes.Length == expectedBytes.Length && CryptographicOperations.FixedTimeEquals(providedBytes, expectedBytes);
    }
}

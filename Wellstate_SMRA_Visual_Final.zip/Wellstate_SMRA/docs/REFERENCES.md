# Referências técnicas

- [Arduino IDE — documentação](https://docs.arduino.cc/software/ide/)
- [ESP8266 Arduino Core — instalação de boards](https://arduino-esp8266.readthedocs.io/en/latest/installing.html)
- [ESP8266 Arduino Core — HTTPClient](https://arduino-esp8266.readthedocs.io/en/latest/esp8266wifi/client-examples.html)
- [Adafruit DHT sensor library](https://github.com/adafruit/DHT-sensor-library)
- [Adafruit Unified Sensor](https://github.com/adafruit/Adafruit_Sensor)
- [ASP.NET Core Web API](https://learn.microsoft.com/aspnet/core/web-api/)
- [Microsoft.Data.Sqlite](https://learn.microsoft.com/dotnet/standard/data/sqlite/)
- [HC-SR04 com ESP8266 NodeMCU](https://randomnerdtutorials.com/esp8266-nodemcu-hc-sr04-ultrasonic-arduino/) — protege ECHO com divisor de tensão ou level shifter.

O firmware usa o ESP8266 Arduino Core, `ESP8266HTTPClient` e a biblioteca DHT da Adafruit para publicar medições na API REST local. Não usa PlatformIO nem Firebase no fluxo atual.

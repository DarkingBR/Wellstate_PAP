# Firebase Firestore — esquema detalhado do Wellstate SMRA

> **Importante:** esta versão do app ainda não lê nem grava no Firebase. A telemetria e os sinais ficam no SQLite do backend; salas, dispositivos cadastrados e horários ficam no `localStorage` do navegador. Portanto, criar estas coleções no Console **não conecta automaticamente o app ao Firestore**. Esta especificação define o destino recomendado para uma integração/migração futura, incluindo os campos, tipos e exemplos de documentos.

## 1. O que criar no Firebase

Para uma integração completa, o modelo recomendado usa estas coleções raiz:

| Coleção | Necessidade | Conteúdo |
|---|---|---|
| `rooms` | Obrigatória | Cadastro estável das salas |
| `telemetry` | Obrigatória | Uma leitura de sensor por documento, com histórico |
| `devices` | Obrigatória se usar PCs/agentes | Cadastro e último estado conhecido dos PCs geridos |
| `schedules` | Obrigatória se transferir horários para a nuvem | Uma aula por documento |
| `signals` | Obrigatória se transferir notificações para PCs | Fila e histórico de sinais enviados a agentes |
| `appConfig` | Opcional | Fuso horário e parâmetros globais editáveis |
| `users` | Opcional, somente se adicionar Firebase Authentication | Perfil mínimo e papel de acesso por UID autenticado |

**Não crie uma coleção para cada sala.** Use uma única coleção `rooms`, com o identificador da sala como ID do documento. Da mesma forma, não guarde o histórico todo num array do documento da sala: cada medição deve ser um documento independente em `telemetry`.

### Estado atual versus destino

| Dado atualmente utilizado pelo app | Onde está hoje | Coleção recomendada |
|---|---|---|
| Nome/ID das salas | `localStorage` e cadastro SQLite criado pelos sensores | `rooms` |
| Temperatura, humidade, distância, movimento e ocupação | SQLite `room_telemetry` | `telemetry` |
| PCs cadastrados (ID, nome, IP, sala) | `Wellstate:Pcs` em `backend-csharp/appsettings.json` | `devices` |
| Estado online e resposta do ping/heartbeat | Calculado pela API; presença do agente é temporária em memória | `devices` (último estado, atualizado pelo servidor) |
| Horários | `localStorage` (`wellstate-store`) | `schedules` |
| Sinais de notificação para PC | SQLite `pc_signals` | `signals` |
| Preferência de tema/avisos do navegador | `localStorage` local | **Não migrar** por padrão |
| Utilizadores | Não existe login nesta versão | `users` apenas se houver autenticação real |

## 2. Regras gerais de modelação

1. IDs de documento são estáveis, sem `/`, sem espaços desnecessários e preservam a mesma grafia em todas as referências. IDs de salas atuais: `C1.01`, `C0.13`, `B1.02`, `D1.4` e `EF_EB`.
2. Use os IDs em maiúsculas exatamente como configurados no app. Firestore diferencia maiúsculas e minúsculas.
3. Datas devem ser **Firestore Timestamp**, sempre em UTC. Na interface, apresentar horários em `Europe/Lisbon`.
4. Valores numéricos de sensor são números, não strings com unidades. Guarde `23.7`, não `"23,7 °C"`.
5. Para um sensor sem leitura, use `null` nos campos numéricos opcionais; não use `"—"`, `"null"` ou `0` como substituto.
6. Booleanos são `true`/`false`. Nunca grave `"true"`/`"false"` como texto.
7. O `roomId`/`deviceId` referenciado precisa corresponder a um documento existente. Firestore não impõe chaves estrangeiras; a API deve validar essa relação.
8. Campos marcados como **gerados pelo servidor** não devem ser aceites diretamente de um navegador público.

## 3. Dicionário de dados completo

### 3.1 `rooms/{roomId}` — cadastro da sala

O ID do documento é o próprio identificador estável da sala, por exemplo `rooms/C1.01`.

| Campo | Tipo Firestore | Obrigatório | Exemplo | Descrição / validação |
|---|---|---:|---|---|
| `roomId` | string | Sim | `C1.01` | Repetição do ID do documento para facilitar respostas da API e exportações. Tem de ser igual ao ID do caminho. |
| `name` | string | Sim | `Bloco C · Sala 1.01` | Nome visível no painel. 1–120 caracteres. |
| `block` | string | Não | `C` | Bloco/edifício; pode ser omitido para espaços como ginásio. |
| `floor` | integer (number) | Não | `1` | Piso, quando aplicável. Aceita valores negativos se houver cave. |
| `active` | boolean | Sim | `true` | `false` desativa a sala sem apagar o histórico. |
| `sensorId` | string | Não | `ESP-C101` | Identificador do sensor principal, se houver inventário de hardware. |
| `createdAt` | timestamp | Sim | Timestamp UTC | Data de criação do cadastro; definir uma vez. |
| `updatedAt` | timestamp | Sim | Timestamp UTC | Última alteração do cadastro. |

**Documento de exemplo `rooms/C1.01`:**

```json
{
  "roomId": "C1.01",
  "name": "Bloco C · Sala 1.01",
  "block": "C",
  "floor": 1,
  "active": true,
  "sensorId": "ESP-C101",
  "createdAt": "TIMESTAMP_FIRESTORE_UTC",
  "updatedAt": "TIMESTAMP_FIRESTORE_UTC"
}
```

`TIMESTAMP_FIRESTORE_UTC` é uma indicação de tipo, não texto para gravar. No Console, crie `createdAt` e `updatedAt` escolhendo **timestamp** e indicando a data/hora UTC. Se não existir um sensor com ID real, omita `sensorId` em vez de usar o exemplo.

Salas locais iniciais do app (só cadastrar as que realmente serão usadas):

| ID de documento | `name` sugerido | `block` | `floor` |
|---|---|---|---:|
| `C1.01` | `Bloco C · Sala 1.01` | `C` | `1` |
| `C0.13` | `Bloco C · Sala 0.13` | `C` | `0` |
| `B1.02` | `Bloco B · Sala 1.02` | `B` | `1` |
| `D1.4` | `Bloco D · Sala 1.4` | `D` | `1` |
| `EF_EB` | `Ginásio` | (omitir) | (omitir) |

### 3.2 `telemetry/{telemetryId}` — uma medição de sensor

Cada `POST /api/rooms/{roomId}/telemetry` futuro cria **um documento novo**. Use um Auto-ID do Firestore (ou UUID do backend); não use o `roomId` como ID, pois cada sala terá muitas medições.

| Campo | Tipo Firestore | Obrigatório | Exemplo | Origem / validação |
|---|---|---:|---|---|
| `roomId` | string | Sim | `C1.01` | ID de `rooms/{roomId}`. O backend atual aceita 1–80 caracteres. |
| `temperature` | number (double) ou null | Não | `23.7` | Celsius; intervalo aceite pela API: -40 a 85. Não inclua `°C` na string. |
| `humidity` | number (double) ou null | Não | `58.2` | Humidade relativa em percentagem; intervalo 0–100. |
| `distance` | number (double) ou null | Não | `142.0` | Centímetros; intervalo aceite: 2–400. |
| `motion` | boolean | Sim | `true` | Estado bruto do sensor PIR. |
| `occupied` | boolean | Sim | `true` | Estado de ocupação calculado/confirmado pelo firmware. Se `true`, `motion` também tem de ser `true`. |
| `event` | string (enum) | Sim | `occupied` | Valor atual derivado pelo backend: `occupied`, `motion` ou `reading`. `occupied` se ocupada; caso contrário `motion` se houve movimento; senão `reading`. |
| `recordedAt` | timestamp | Sim | Timestamp UTC | Instante em que o backend recebeu e gravou a leitura. No JSON REST atual o nome é `updatedAt` e na tabela SQLite é `created_at`; mapear ambos para este campo Firestore. Usar `serverTimestamp()` no servidor na nova implementação. |
| `sensorId` | string | Não | `ESP-C101` | Identificador do hardware, se o firmware o fornecer. |
| `firmwareVersion` | string | Não | `1.0.0` | Versão reportada pelo hardware, se disponível. |

**Documento de exemplo `telemetry/{autoId}`:**

```json
{
  "roomId": "C1.01",
  "temperature": 23.7,
  "humidity": 58.2,
  "distance": 142,
  "motion": true,
  "occupied": true,
  "event": "occupied",
  "recordedAt": "TIMESTAMP_FIRESTORE_UTC",
  "sensorId": "ESP-C101",
  "firmwareVersion": "1.0.0"
}
```

Se a medição não tiver temperatura ou humidade, mantenha o campo com valor Firestore **null** ou omita-o de forma consistente; nunca invente uma leitura. A retenção atual do SQLite é de 90 dias. Para replicá-la no Firestore, inclua um campo adicional `expireAt` (timestamp de expiração = `recordedAt + 90 dias`) e ative a política TTL do Firestore nesse campo, ou implemente a limpeza no servidor. A TTL é assíncrona, não apaga necessariamente exatamente no instante da expiração.

### 3.3 `devices/{deviceId}` — cadastro e último estado do PC

Use o ID estável da configuração, por exemplo `devices/PC-01`. Não confunda PCs configurados com os hosts encontrados numa verificação pontual da rede: hosts descobertos podem ser transitórios e não precisam virar documentos permanentes.

| Campo | Tipo Firestore | Obrigatório | Exemplo | Origem / validação |
|---|---|---:|---|---|
| `deviceId` | string | Sim | `PC-01` | Igual ao ID do documento. |
| `name` | string | Sim | `PC-01 · Sala 1.01` | Nome do equipamento apresentado no painel. |
| `ip` | string | Sim | `192.168.1.101` | IPv4 reservado/fixo do dispositivo; troque o IP de exemplo pelo IP real da LAN. |
| `roomId` | string ou null | Sim | `C1.01` | Sala correspondente em `rooms`; null se o PC não estiver numa sala. |
| `active` | boolean | Sim | `true` | Cadastro habilitado. Não apague para indicar que está offline. |
| `online` | boolean | Sim | `true` | Derivado pelo servidor: agente online **ou** ping de rede respondeu. |
| `networkOnline` | boolean | Sim | `true` | Resultado mais recente de ICMP/ping. |
| `agentOnline` | boolean | Sim | `false` | Heartbeat recente do agente Wellstate. |
| `responseMs` | integer ou null | Sim | `18` | Latência do ping em milissegundos; null se indisponível. |
| `lastSeenAt` | timestamp ou null | Sim | Timestamp UTC | Último heartbeat conhecido do agente. A resposta ICMP é calculada em cada consulta e não tem um timestamp persistido na API atual; usar null se não houver heartbeat. |
| `agentVersion` | string ou null | Sim | `1.2.0` | Última versão do agente; null se desconhecida. |
| `statusUpdatedAt` | timestamp | Sim | Timestamp UTC | Instante em que o servidor calculou estes campos de estado. |
| `createdAt` | timestamp | Sim | Timestamp UTC | Criação do cadastro. |
| `updatedAt` | timestamp | Sim | Timestamp UTC | Alteração do cadastro/configuração. |

**Documento de exemplo `devices/PC-01`:**

```json
{
  "deviceId": "PC-01",
  "name": "PC-01 · Sala 1.01",
  "ip": "192.168.1.101",
  "roomId": "C1.01",
  "active": true,
  "online": true,
  "networkOnline": true,
  "agentOnline": false,
  "responseMs": 18,
  "lastSeenAt": "TIMESTAMP_FIRESTORE_UTC",
  "agentVersion": null,
  "statusUpdatedAt": "TIMESTAMP_FIRESTORE_UTC",
  "createdAt": "TIMESTAMP_FIRESTORE_UTC",
  "updatedAt": "TIMESTAMP_FIRESTORE_UTC"
}
```

O endereço `192.168.1.101` é **apenas ilustrativo**. Use IP reservado da própria rede. Quando desconhecido, grave `responseMs: null`, `lastSeenAt: null` e `online: false`; não mantenha um estado online antigo como se fosse atual.

Hosts avulsos encontrados por `GET /api/network/devices` têm hoje apenas `ip`, `hostname`, `online` e `responseMs`, e o resultado da verificação é transitório. Se for necessário auditar scans, crie separadamente `networkScans/{scanId}` com `startedAt` (timestamp), `finishedAt` (timestamp), `cidr` (string), `hostsFound` (integer) e `requestedBy` (string opcional), e guarde hosts em `networkScans/{scanId}/hosts/{hostId}`. Não misture esses resultados passageiros com os PCs geridos.

### 3.4 `schedules/{lessonId}` — uma aula semanal

Hoje o horário é um objeto local agrupado por dia da semana. Na nuvem, guardar **um documento por aula** simplifica consultas, edição e ordenação. Use UUID/Auto-ID estável por aula; editar a aula deve atualizar o mesmo documento, não criar cópias.

| Campo | Tipo Firestore | Obrigatório | Exemplo | Descrição / validação |
|---|---|---:|---|---|
| `dayOfWeek` | integer (number) | Sim | `1` | ISO: segunda=1, terça=2, quarta=3, quinta=4, sexta=5, sábado=6, domingo=7. O horário atual usa 1–5. |
| `subject` | string | Sim | `MAT` | Nome ou abreviatura da disciplina. 1–50 caracteres. |
| `group` | string | Sim | `12.º P` | Turma/grupo. |
| `teacher` | string | Sim | `Professor/a` | Docente. Substituir o texto de demonstração pelo nome real. |
| `roomId` | string | Sim | `C1.01` | Referência a `rooms/{roomId}`. |
| `startTime` | string | Sim | `08:15` | Hora local `HH:mm`; validar 00:00–23:59. |
| `endTime` | string | Sim | `09:05` | Hora local `HH:mm`; tem de ser posterior a `startTime`. |
| `timeZone` | string | Sim | `Europe/Lisbon` | Fuso IANA. Horário recorrente guarda hora local, não timestamp UTC. |
| `active` | boolean | Sim | `true` | Permite desativar sem apagar. |
| `academicYear` | string ou null | Não | `2026/2027` | Ano letivo a que se aplica; não está atualmente definido no app. |
| `createdAt` | timestamp | Sim | Timestamp UTC | Criação do documento. |
| `updatedAt` | timestamp | Sim | Timestamp UTC | Última edição. |

**Documento de exemplo `schedules/{lessonId}`:**

```json
{
  "dayOfWeek": 1,
  "subject": "MAT",
  "group": "12.º P",
  "teacher": "Professor/a",
  "roomId": "C1.01",
  "startTime": "08:15",
  "endTime": "09:05",
  "timeZone": "Europe/Lisbon",
  "active": true,
  "academicYear": null,
  "createdAt": "TIMESTAMP_FIRESTORE_UTC",
  "updatedAt": "TIMESTAMP_FIRESTORE_UTC"
}
```

`Professor/a` e `12.º P` refletem valores atuais de demonstração/configuração, não identificam necessariamente a escola. Corrija-os antes de usar o horário como fonte oficial.

### 3.5 `signals/{signalId}` — notificação/sinal para um PC

Mapeia a tabela SQLite `pc_signals`. Use o `Id` atual (GUID sem hífens ou UUID) como ID do documento para evitar duplicados durante migração.

| Campo | Tipo Firestore | Obrigatório | Exemplo | Descrição / validação |
|---|---|---:|---|---|
| `signalId` | string | Sim | `e62a...` | Igual ao ID do documento. |
| `deviceId` | string | Sim | `PC-01` | PC destinatário, correspondente a `devices/{deviceId}`. No SQLite atual chama-se `PcId`. |
| `type` | string (enum) | Sim | `notification` | Atualmente o único tipo aceite é `notification`. |
| `message` | string | Sim | `Por favor, verificar a sala.` | Texto de 1–500 caracteres. |
| `status` | string (enum) | Sim | `pending` | Apenas `pending`, `claimed`, `received`, `failed` ou `returned`. |
| `resultMessage` | string ou null | Sim | `A aguardar confirmação do PC.` | Explicação/resultados; pode ser null antes de qualquer processamento. Máximo 500 caracteres se fornecido. |
| `createdAt` | timestamp | Sim | Timestamp UTC | Momento de criação. |
| `expiresAt` | timestamp | Sim | Timestamp UTC | Expiração; predefinição atual 30 s, configurável de 5 a 600 s. |
| `claimedAt` | timestamp ou null | Sim | Timestamp UTC/null | Quando o agente tomou posse do sinal. Claim sem confirmação é libertado após cerca de 20 s. |
| `receivedAt` | timestamp ou null | Sim | Timestamp UTC/null | Momento do ACK do agente. No código atual também marca a resposta do agente para falha. |
| `returnedAt` | timestamp ou null | Sim | Timestamp UTC/null | Quando foi devolvido/expirou ou o PC estava offline. |

**Documento de exemplo `signals/{signalId}`:**

```json
{
  "signalId": "8d781aa7b5204d1b9d198c55cced10a4",
  "deviceId": "PC-01",
  "type": "notification",
  "message": "Por favor, verificar o equipamento da sala.",
  "status": "pending",
  "resultMessage": "Sinal enviado; a aguardar confirmação do PC.",
  "createdAt": "TIMESTAMP_FIRESTORE_UTC",
  "expiresAt": "TIMESTAMP_FIRESTORE_UTC",
  "claimedAt": null,
  "receivedAt": null,
  "returnedAt": null
}
```

`expiresAt` deve ser posterior a `createdAt`. O servidor deve fazer as transições de estado de forma transacional. Não permita que o frontend altere `status`, os timestamps de entrega, nem que reenvie um sinal expirado silenciosamente. A versão atual conserva no máximo 500 sinais; a migração precisa manter deliberadamente essa política ou escolher outra.

### 3.6 `appConfig/main` — configurações globais opcionais

Só crie se as definições precisarem ser partilhadas e editáveis pela aplicação. Valores técnicos/secretos **não** devem ser armazenados aqui.

| Campo | Tipo Firestore | Obrigatório | Exemplo |
|---|---|---:|---|
| `timeZone` | string | Sim | `Europe/Lisbon` |
| `telemetryRetentionDays` | integer | Sim | `90` |
| `updatedAt` | timestamp | Sim | Timestamp UTC |
| `updatedBy` | string | Não | UID do utilizador autenticado |

O `main` é o ID de documento; caminho `appConfig/main`. Não guardar API keys, chaves dos sensores/agentes, palavras-passe, service-account JSON nem tokens nesse documento.

### 3.7 `users/{uid}` — só com Authentication

A versão atual abre sem login e não possui coleção `users`. Se no futuro ativar Firebase Authentication, use o UID emitido pelo Firebase Authentication como ID do documento; nunca use e-mail como ID.

| Campo | Tipo Firestore | Obrigatório | Exemplo | Observação |
|---|---|---:|---|---|
| `uid` | string | Sim | UID do Authentication | Igual ao ID do documento. |
| `displayName` | string | Sim | `Operador da escola` | Nome de apresentação. |
| `email` | string | Não | `operador@escola.pt` | Dados de perfil, se necessário. Não usar como prova de autorização. |
| `role` | string (enum) | Sim | `operator` | `admin`, `operator` ou `viewer`; validar no servidor/regras. |
| `active` | boolean | Sim | `true` | Revogação lógica adicional. |
| `createdAt` | timestamp | Sim | Timestamp UTC | Criação do perfil. |
| `updatedAt` | timestamp | Sim | Timestamp UTC | Última alteração. |

Não crie usuários fictícios para preencher o Console. Primeiro configure Authentication e crie a pessoa por um fluxo autenticado; depois crie o perfil com UID e papel aprovados.

## 4. Como criar documentos no Console Firebase

1. Abra **Firebase Console → projeto correto → Firestore Database → Criar base de dados**. Escolha a região adequada à escola e ao requisito de residência dos dados. Não escolha modo de teste para uma aplicação publicada.
2. Abra **Dados → Iniciar coleção** e crie o nome da coleção raiz (por exemplo `rooms`).
3. Para salas, defina o ID do documento como o ID real (`C1.01`, `B1.02`, etc.). Para `telemetry`, use **ID automático** para cada leitura.
4. Adicione cada campo com o tipo nativo: `string`, `number`/`integer`, `boolean`, `null`, `timestamp`. Para mapa/arrays, só use se um esquema futuro os exigir; este modelo não precisa deles.
5. Crie primeiro os documentos de `rooms`. Depois cadastre `devices` e `schedules` que referenciam salas existentes.
6. `telemetry` e `signals` devem normalmente ser criadas pela API com Firebase Admin SDK, não digitadas manualmente no Console. Os exemplos acima servem para conferir estrutura ou testar com dados claramente identificados como teste.
7. Publique as regras restritivas antes de abrir acesso a qualquer cliente.

### Tipos no Console versus JSON

Os exemplos JSON neste guia ilustram valores e nomes; `TIMESTAMP_FIRESTORE_UTC` é um marcador. **Não grave esse marcador como string.** No Console selecione o tipo `timestamp`; através do SDK use `Timestamp`/`serverTimestamp()`. `integer` e `double` aparecem no SDK/REST sob o tipo geral number, mas ambos precisam ser numéricos. Firestore não aceita `undefined`; omita o campo ou use `null` nos campos explicitamente anuláveis.

## 5. Índices recomendados

O Firestore cria automaticamente índices de campo único. Para as consultas previstas, preparar índices compostos para:

| Coleção | Campos (ordem) | Consulta apoiada |
|---|---|---|
| `telemetry` | `roomId` ASC, `recordedAt` DESC | Últimas medições de uma sala (`where roomId == ...`, `orderBy recordedAt desc`) |
| `signals` | `deviceId` ASC, `createdAt` DESC | Histórico recente de sinais de um PC |
| `signals` | `deviceId` ASC, `status` ASC, `createdAt` ASC | Próximo sinal pendente por PC |
| `schedules` | `dayOfWeek` ASC, `startTime` ASC | Aulas ativas do dia ordenadas por hora |
| `devices` | `active` ASC, `online` ASC | Listas filtradas por estado, se essa consulta for usada |

Um índice só é necessário quando a consulta concreta o exige; o Console também oferece um link de criação ao devolver `FAILED_PRECONDITION`. O ficheiro `firebase/firestore.indexes.json` deve corresponder às consultas que a implementação realmente executar antes de publicar.

## 6. Segurança obrigatória

- O navegador não pode receber credenciais de Firebase Admin nem chave de service account.
- A integração preferida deste projeto é **frontend → API ASP.NET → Firestore via Admin SDK**. O backend valida as chaves de hardware/agente já usadas pelo projeto, valida limites/IDs e aplica as transições de sinais.
- O Admin SDK do servidor ignora Firestore Security Rules; proteja o serviço, mantenha credenciais no gestor de segredos/variáveis seguras e não as inclua no ZIP, Git ou `appsettings.json` versionado.
- Para o SDK cliente, sem Authentication, mantenha tudo negado. Se adicionar Authentication, autorize apenas dados de perfil próprios e leituras estritamente necessárias; mantenha escritas sensíveis e todas as escritas de sensores/sinais no servidor.
- Nunca publique `allow read, write: if true`.
- `firebase/firestore.rules` do ZIP permanece deliberadamente com negação total: isso é seguro, mas impede clientes Firebase de ler/escrever. Ainda não significa que a API já esteja ligada ao Firestore.

Modelo inicial de regras **negadas** (o atual no projeto):

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

Não substitua por regras permissivas só para fazer os dados aparecerem no painel. A ligação Firebase e a autorização precisam ser implementadas e testadas juntas.

## 7. Migração e operação

1. Fazer backup verificável do `backend-csharp/Data/wellstate.db` e exportar `localStorage` (`wellstate-store`) de cada navegador que contenha configuração relevante.
2. Normalizar IDs de salas/PCs e resolver referências antes de copiar dados. Não migrar preferências de tema, sons ou avisos por padrão.
3. Criar/corrigir `rooms`, `devices` e `schedules` e validar contagens/nomes no Firestore.
4. Migrar medições como documentos com `recordedAt` Timestamp (UTC), sem converter medições ausentes em zero. Preservar `roomId` e a ordem temporal; respeitar a retenção de 90 dias atual ou aprovar explicitamente outra retenção.
5. Migrar sinais preservando `signalId`, estado e timestamps. Impedir que sinais expirados voltem à fila como `pending`.
6. Implementar o Firestore Admin SDK no backend, autenticação da API, tratamento de falhas/retries/idempotência e política de retenção; só depois apontar a UI para os endpoints já migrados.
7. Validar leituras, gravações, regras, índices e restauração de backup num projeto de teste antes de mudar para produção.

Firestore não tem transações ilimitadas nem elimina a necessidade de política para crescimento/custos. Para cada leitura de sensor, grava-se um documento; ajuste frequência, retenção, consultas e monitorização de custos antes de ligar todos os sensores.

## 8. Fontes oficiais

- [Firestore: modelo de dados](https://firebase.google.com/docs/firestore/data-model)
- [Firestore: tipos de dados](https://firebase.google.com/docs/firestore/manage-data/data-types)
- [Firestore: adicionar dados](https://firebase.google.com/docs/firestore/manage-data/add-data)
- [Firestore: índices](https://firebase.google.com/docs/firestore/query-data/indexing)
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/get-started)
- [Firebase Admin SDK](https://firebase.google.com/docs/admin/setup)

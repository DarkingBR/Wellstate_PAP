# Arranque · Wellstate SMRA

## 1. Preparar a rede e os computadores

1. Instale o .NET SDK 8 no computador que ficará ligado à LAN.
2. Garanta que o servidor e a NodeMCU estão na mesma rede privada Wi-Fi/LAN; o ESP8266 necessita de Wi-Fi 2,4 GHz.
3. Reserve IPs no router para servidor, ESP e PCs. Edite `backend-csharp/appsettings.json` → `Wellstate:Pcs` com IDs, nomes e endereços reais.

Exemplo de PCs nomeados:

```json
"Pcs": [
  { "id": "PC-01", "name": "PC-01 · Estação de trabalho 1", "ip": "192.168.1.10", "roomId": "C1.01" },
  { "id": "PC-02", "name": "PC-02 · Estação de trabalho 2", "ip": "192.168.1.11", "roomId": "C1.01" },
  { "id": "PC-03", "name": "PC-03 · Estação de trabalho 3", "ip": "192.168.1.12", "roomId": "C1.01" }
]
```

A API atribui nomes determinísticos `PC-<último octeto>` aos hosts descobertos sem nome DNS. Um equipamento desligado só pode ser mostrado pelo nome se tiver cadastro/IP reservado.

## 2. Iniciar backend

Abra PowerShell na pasta `backend-csharp`. Configure as chaves **de dispositivo** (não são login de utilizador) no ambiente:

```powershell
$env:Wellstate__DeviceApiKey = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
$env:Wellstate__AgentApiKey = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
$env:ASPNETCORE_ENVIRONMENT = "Production"
dotnet restore
dotnet run
```

Guarde os dois valores fora do Git. Copie `DeviceApiKey` para `secrets.h` da NodeMCU e defina `WELLSTATE_AGENT_API_KEY` apenas se usar o agente Windows. Configure `Wellstate:Network:Cidr` como `auto` ou como a sua sub-rede, por exemplo `192.168.1.0/24`.

Confirme `http://IP-DO-SERVIDOR:5080/api/health` e abra `http://IP-DO-SERVIDOR:5080/`. **Não há tela de login ou registo**: o endereço abre diretamente o dashboard. Mantenha a API apenas numa LAN/VPN de confiança e não exponha a porta 5080 publicamente.

## 3. Compilar e ligar a NodeMCU

1. Siga [`ASSEMBLY.md`](ASSEMBLY.md) para montar os sensores com o divisor de tensão correto e observar a advertência GPIO0/D3.
2. Instale o core ESP8266 e as bibliotecas DHT conforme [`HARDWARE.md`](HARDWARE.md).
3. Copie `firmware/Wellstate_Firmware/secrets.example.h` como `secrets.h` na mesma pasta. Preencha SSID, senha Wi-Fi, URL do servidor, o mesmo `DeviceApiKey` e ID da sala.
4. Se o servidor está em `http://192.168.1.2:5080`, use essa URL em `WELLSTATE_API_BASE_URL`, sem `/api` final.
5. Compile/envie para NodeMCU v2 e abra o Monitor Série a 115200 baud.
6. A placa serve HTTP na porta 80. `/` redireciona diretamente ao dashboard; `/api/status` e `/api/network` são endpoints locais auxiliares. Não necessitam conta de utilizador.

## 4. Estados, rede e aplicação

- O painel mostra temperatura, humidade, distância e estado PIR, além dos PCs online/offline.
- A API faz a descoberta ICMP na LAN do servidor. A rota opcional do ESP `/api/network` testa TCP/445 nos IPs `.10`–`.20`; portas filtradas podem ocultar um PC ligado.
- A instalação PWA requer HTTPS (exceto localhost). Por IP HTTP local o painel continua acessível pelo navegador; a instalação como app não é garantida.
- Firebase não é necessário nesta versão. O esquema Firestore opcional está documentado em [`FIREBASE.md`](FIREBASE.md).

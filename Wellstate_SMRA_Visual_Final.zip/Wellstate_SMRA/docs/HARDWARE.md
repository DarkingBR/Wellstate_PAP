# Firmware e hardware · Wellstate SMRA

## Equipamento e ligações

Projeto para NodeMCU v2 / ESP8266, sensor DHT11, PIR HC-SR501, ultrassónico HC-SR04, LED, resistência de 220–330 Ω e divisor de tensão de 1 kΩ/2 kΩ. Usa alimentação USB da placa e GND comum. O guia ilustrado, com passos de protoboard, está em [ASSEMBLY.md](ASSEMBLY.md).

| NodeMCU | Ligação | Observações |
|---|---|---|
| D1 / GPIO5 | PIR OUT | PIR VCC conforme o módulo; garante que OUT não excede 3,3 V. |
| D2 / GPIO4 | HC-SR04 TRIG | Recebe o sinal de 3,3 V da placa. |
| D3 / GPIO0 | Junção do divisor ligado a ECHO | **Nunca ligues ECHO de 5 V diretamente ao ESP8266. GPIO0 é pino de arranque; ver aviso abaixo.** |
| D4 / GPIO2 | DHT11 DATA | DHT a 3,3 V; GND comum; no sensor nu, pull-up de 4,7–10 kΩ entre DATA e 3,3 V. |
| D5 / GPIO14 | Resistência 220–330 Ω → LED → GND | Pisca lentamente quando a placa está ativa; fica aceso com presença confirmada. |
| VIN / 5 V | HC-SR04 VCC | GND comum. |
| GND | GND de todos os módulos | Referência elétrica comum. |

Liga ECHO do HC-SR04 a uma resistência de 1 kΩ e depois à junção que segue para D3; da junção usa 2 kΩ para GND (cerca de 3,3 V). Um level shifter adequado também serve. O ESP8266 usa lógica de 3,3 V; uma ligação direta de 5 V pode danificar a placa.

> **Atenção: conflito do pino pedido.** D3/GPIO0 é um pino strap de arranque: tem de permanecer em nível alto durante o reset para iniciar a aplicação. A saída ECHO do HC-SR04 pode estar baixa quando a placa arranca, causando bootloader/arranque intermitente. O esquema/código mantém o D3 solicitado, mas para montagem fiável recomendamos ligar ECHO ao D7/GPIO13 e alterar `#define ECHO_PIN D3` para `#define ECHO_PIN D7` no `.ino`. Não existe uma correção puramente de software para um nível elétrico incompatível no arranque.

## Arduino IDE

1. Instala Arduino IDE 2.x.
2. Abre **File → Preferences** e adiciona o URL de placas ESP8266 da documentação oficial `https://arduino.esp8266.com/stable/package_esp8266com_index.json` em *Additional boards manager URLs*.
3. Em **Boards Manager**, instala **ESP8266 by ESP8266 Community** e seleciona **NodeMCU 1.0 (ESP-12E Module)**.
4. Em **Library Manager**, instala **DHT sensor library** por Adafruit e **Adafruit Unified Sensor**. `ESP8266WebServer`, `ESP8266WiFi` e `ESP8266HTTPClient` acompanham o core ESP8266; não precisas importar uma biblioteca de ping no firmware (a API faz ping pela LAN do servidor).
5. Abre `firmware/Wellstate_Firmware/Wellstate_Firmware.ino`.
6. Edita `secrets.h` na mesma pasta e substitui os valores; esse ficheiro local é ignorado pelo Git. Há um template limpo em `secrets.example.h`.
7. Seleciona a porta USB, compila e carrega. Abre o monitor série a 115200 baud.

### Configuração de `secrets.h`

```cpp
#define WIFI_SSID                 "NOME_WIFI_2_4_GHZ"
#define WIFI_PASSWORD             "PALAVRA_PASSE_WIFI"
#define WELLSTATE_API_BASE_URL    "http://IP-RESERVADO-DO-SERVIDOR:5080"
#define WELLSTATE_DEVICE_API_KEY "MESMO_TOKEN_CONFIGURADO_NO_BACKEND"
#define WELLSTATE_ROOM_ID         "C1.01"
#define DHT_PIN                   D4
```

Reserva um IP para o servidor no router ou usa um nome DNS interno estável; atualiza o endereço quando necessário. Garante que o backend está em execução antes de testar. Define `Wellstate__DeviceApiKey` no ambiente do processo .NET e copia exatamente o mesmo token para o firmware. O firmware publica a cada 10 segundos em `POST /api/rooms/{roomId}/telemetry`, com o cabeçalho `X-Device-Key`, e tenta novamente depois de falhas de rede.

A comunicação HTTP está limitada à LAN privada. Não exponhas a API à Internet: o token de dispositivo é enviado como cabeçalho sem encriptação. Para redes não confiáveis, implementa HTTPS e autenticação apropriada antes de usar.

## Medições e limites

A cada 10 segundos são enviados temperatura, humidade, distância, movimento e estado estimado. O servidor SQLite acrescenta timestamp UTC e mantém até 90 dias de histórico. `occupied` significa somente movimento PIR e objeto detetado a menos de 2 m; não reconhece nem identifica alunos. A medição e os sensores devem ser testados fisicamente no local.


## Servidor HTTP e verificação local de rede

O firmware inicia `ESP8266WebServer` na porta 80. `/` encaminha o navegador para o painel central configurado na URL da API; `/api/status` entrega o último JSON dos sensores; `/api/network` lista nomes `PC-01`–`PC-11` para os octetos `.10`–`.20` e testa TCP/445 sem instalar agentes nos PCs. Ajuste `networkHosts[]` e a sub-rede `/24` no firmware se a LAN/IP reservada for diferente.

Este teste TCP é apenas indicativo: uma firewall pode fechar a porta 445 num PC ligado. O estado oficial do painel usa o scan ICMP controlado pela API .NET e PCs cadastrados, também na LAN do servidor. O ESP e a API expõem leitura LAN; não encaminhe a porta 80 publicamente.

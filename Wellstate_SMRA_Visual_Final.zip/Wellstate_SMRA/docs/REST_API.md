# API REST · Wellstate

O backend .NET liga o firmware ESP8266, o dashboard e as ferramentas de gestão. Os exemplos usam `http://IP-DO-SERVIDOR:5080`; todos os clientes precisam alcançar a mesma instalação central.

## Endpoints

| Método | Rota | Acesso | Resultado |
|---|---|---|---|
| `GET` | `/api/health` | LAN | Estado da API e do SQLite |
| `GET` | `/api/network/devices` | LAN/VPN | Hosts que respondem na sub-rede privada do servidor |
| `GET` | `/api/network/devices?refresh=true` | LAN/VPN | Força uma nova verificação, ignorando o cache |
| `GET` | `/api/rooms` | LAN | Última leitura de cada sala com sensor |
| `GET` | `/api/rooms/history?roomId=C1.01&limit=500` | LAN | Leituras recentes; `roomId` é opcional, limite de 1–2000 |
| `GET` | `/api/rooms/history?from=2026-09-28T00:00:00Z&to=2026-09-29T00:00:00Z` | LAN | Filtrar por intervalo UTC |
| `POST` | `/api/rooms/{roomId}/telemetry` | LAN + chave | Guardar uma leitura ambiental |
| `GET` | `/api/pcs` e `/api/pcs/{id}` | LAN | Inventário configurado e status agregado dos PCs |
| `GET` | `/api/pcs/stream` | LAN | Presença dos agentes via Server-Sent Events |
| `POST` | `/api/pcs/{pcId}/agent/heartbeat` | LAN | Heartbeat do agente Windows |

As respostas usam JSON em *camelCase*. Datas são devolvidas em ISO-8601 UTC.

## Descoberta da rede

`Wellstate:Network:Cidr` é `auto` por padrão. A API escolhe a sub-rede IPv4 privada da rota ativa no servidor; se não encontrar uma LAN/VPN privada, responde `503` com orientação. Para fixar uma sub-rede, defina um CIDR privado como `192.168.1.0/24` em `backend-csharp/appsettings.json`. Por segurança, intervalos IPv4 públicos não são aceitos.

A resposta inclui `scanCidr`, `scannedAt`, `automaticallyDetected`, `interfaceName`, `serverAddress`, `gateway`, `hostsScanned`, `hostsAvailable`, `scanLimited` e a lista `devices`. O scan tem concorrência limitada e cache de 8 segundos por padrão. Se `scanLimited` for `true`, aumente `Wellstate:Network:MaxHosts` conforme a dimensão da LAN.

O scan lista apenas dispositivos que respondem. Para mostrar PCs desligados, configure seus IDs, nomes e IPs reservados/fixos em `Wellstate:Pcs`; um host desconhecido desligado não pode ser inferido só pela rede. `online` é `true` quando ping ou heartbeat recente confirma o PC, e `networkOnline`/`agentOnline` distinguem os dois sinais. O agente é necessário para confirmação quando ICMP é bloqueado.

## Registrar telemetria

Pedido:

```http
POST /api/rooms/C1.01/telemetry HTTP/1.1
Content-Type: application/json
X-Device-Key: <MESMA_CHAVE_CONFIGURADA_NO_BACKEND_E_NO_SENSOR>
```

```json
{
  "temperature": 22.6,
  "humidity": 48.0,
  "distance": 134.2,
  "motion": true,
  "occupied": true
}
```

`distance` pode ser `null` quando o sensor ultrassónico não obteve leitura válida. Temperatura aceite: −40 a 85 °C; humidade: 0 a 100%; distância: 2 a 400 cm ou `null`. `occupied` só pode ser verdadeiro quando `motion` também é verdadeiro. O servidor determina o evento e carimba a data/hora.

Resposta: `201 Created` com o registo guardado. Chave ausente/incorreta recebe `401`; se a chave não estiver configurada, a API responde `503`. O painel não recebe o segredo do sensor.

## Configurar a chave do dispositivo

Gere um segredo aleatório com pelo menos 32 bytes e configure-o **fora do repositório**. Exemplo no PowerShell:

```powershell
$token = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
$env:Wellstate__DeviceApiKey = $token
$env:ASPNETCORE_ENVIRONMENT = "Development"
dotnet run
```

Copie o mesmo valor para `WELLSTATE_DEVICE_API_KEY` em `firmware/Wellstate_Firmware/secrets.h`. Não envie esse token no frontend nem publique o ficheiro local. `appsettings.json` contém deliberadamente um placeholder.

## Rede e segurança

O dashboard e as rotas de leitura/descoberta não pedem conta ou token de utilizador nesta versão. O POST de telemetria continua a exigir `X-Device-Key` e as rotas do agente Windows continuam a exigir `X-Agent-Key`. O CORS permite pedidos do frontend configurado. Mantenha API, dashboard e placas numa rede privada/VPN, limite a porta 5080 na firewall e não faça encaminhamento público. HTTP não cifra as chaves de dispositivos; para redes não confiáveis, publique por HTTPS.

# Tema visual de referência

`css/reference-ui.css` aplica a nova composição visual ao Wellstate. O dashboard tem conteúdo claro com sidebar escura, cartões de métricas, painéis escuros de presença/ocupação, eventos, atalhos e uma ilustração de campus. Salas, Horários, Dispositivos, Relatórios e Configurações usam listas/cartões escuros, busca, filtros e navegação de perfil.

O layout preserva os identificadores dos scripts existentes, usa o tema guardado no navegador, mantém contraste para estados online/offline, ocupação e movimento e passa a barra de navegação horizontal em ecrãs estreitos. Leituras ausentes aparecem como “Sem leitura”; não há dados de demonstração inventados para preencher cartões.

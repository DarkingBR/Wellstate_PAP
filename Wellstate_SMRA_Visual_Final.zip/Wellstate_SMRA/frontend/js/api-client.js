/* Cliente REST partilhado pelo painel, histórico e inventário da rede. */
const CFG = window.WELLSTATE_CONFIG;
const API_ROOT = String(CFG.API_BASE_URL || "").replace(/\/+$/, "");

async function request(path, options = {}) {
    const method = String(options.method || "GET").toUpperCase();
    const retries = method === "GET" ? (CFG.API_RETRIES ?? 1) : 0;
    let lastError;

    for (let attempt = 0; attempt <= retries; attempt++) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), CFG.API_TIMEOUT_MS ?? 30000);
        try {
            const response = await fetch(`${API_ROOT}${path}`, {
                ...options,
                method,
                cache: "no-store",
                credentials: CFG.API_CREDENTIALS || "same-origin",
                headers: { Accept: "application/json", ...(options.headers || {}) },
                signal: controller.signal
            });

            if (!response.ok) {
                let message = `A API respondeu HTTP ${response.status}.`;
                try {
                    const body = await response.json();
                    message = body.message || body.title || body.detail || message;
                } catch { /* resposta sem JSON */ }
                const error = new Error(message);
                error.status = response.status;
                if (response.status < 500 || attempt === retries) throw error;
                lastError = error;
            } else {
                if (response.status === 204) return null;
                return await response.json();
            }
        } catch (error) {
            lastError = error.name === "AbortError"
                ? new Error("A API demorou demasiado para responder. Verifique a rede ou tente novamente.")
                : error.name === "TypeError"
                    ? new Error("Não foi possível alcançar a API. Confirme que o backend está ligado e que o endereço do painel aponta para ele.")
                    : error;
            if (error.status && error.status < 500) throw error;
            if (attempt === retries) throw lastError;
        } finally {
            clearTimeout(timeout);
        }

        await new Promise(resolve => setTimeout(resolve, 350 * (attempt + 1)));
    }

    throw lastError || new Error("Não foi possível ligar à API.");
}

export const apiClient = Object.freeze({
    get: path => request(path),
    getLatestRooms: () => request("/rooms"),
    getPcs: () => request("/pcs"),
    getNetworkDevices: ({ refresh = false } = {}) => request(`/network/devices${refresh ? "?refresh=true" : ""}`),
    getHistory: ({ roomId, limit = 2000, from, to } = {}) => {
        const params = new URLSearchParams({ limit: String(limit) });
        if (roomId) params.set("roomId", roomId);
        if (from) params.set("from", new Date(from).toISOString());
        if (to) params.set("to", new Date(to).toISOString());
        return request(`/rooms/history?${params.toString()}`);
    },
    getHealth: () => request("/health")
});

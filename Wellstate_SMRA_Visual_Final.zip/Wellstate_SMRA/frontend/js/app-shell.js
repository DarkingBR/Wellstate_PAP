/* Shell partilhado: identidade local, pesquisa e atalhos de navegação. */
(function () {
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };
    setText("userName", "Administrador");
    setText("userEmail", "Acesso local");

    const actions = document.querySelector(".topbar-actions");
    if (!actions) return;
    const page = location.pathname.split("/").pop() || "dashboard.html";

    if (page !== "dashboard.html") {
        const placeholders = { "rooms.html": "Pesquisar sala...", "schedule.html": "Pesquisar aula...", "pcs.html": "Pesquisar dispositivo...", "history.html": "Pesquisar evento...", "admin.html": "Pesquisar configuração..." };
        const search = document.createElement("label");
        search.className = "global-search";
        search.innerHTML = `<i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input type="search" placeholder="${placeholders[page] || "Pesquisar..."}" aria-label="Pesquisar nesta página" />`;
        actions.prepend(search);
        const input = search.querySelector("input");
        const searchable = ".room-card, .room-item, .device-card, .pc-card, .history-item, .lesson-card";
        const applySearch = () => {
            const term = input.value.trim().toLocaleLowerCase("pt-PT");
            document.querySelectorAll(searchable).forEach(item => {
                item.classList.toggle("search-hidden", Boolean(term) && !item.textContent.toLocaleLowerCase("pt-PT").includes(term));
            });
        };
        window.WellstateApplySearch = applySearch;
        input.addEventListener("input", () => {
            window.WELLSTATE_SEARCH = input.value.trim();
            applySearch();
            window.dispatchEvent(new CustomEvent("wellstate:search", { detail: window.WELLSTATE_SEARCH }));
        });
        new MutationObserver(applySearch).observe(document.querySelector("main") || document.body, { childList: true, subtree: true });
    }

    const utilities = document.createElement("div");
    utilities.className = "header-utilities";
    utilities.innerHTML = '<a class="utility-icon notification-action" href="dashboard.html#recentEvents" aria-label="Ver notificações recentes" title="Notificações"><i class="fa-regular fa-bell"></i><span class="notification-count" hidden>0</span></a><a class="header-avatar-link" href="admin.html" aria-label="Abrir configurações da conta" title="Administrador"><i class="fa-solid fa-user"></i></a>';
    actions.appendChild(utilities);
})();

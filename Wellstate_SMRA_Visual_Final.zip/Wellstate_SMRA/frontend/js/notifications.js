/* Wellstate · alertas de ocupação fora do horário letivo, sempre em hora de Lisboa. */
(function () {
    const NOTIFIED_KEY = "wellstate-notified";
    const COOLDOWN_MS = 15 * 60 * 1000;

    function getNotified() {
        try { return JSON.parse(localStorage.getItem(NOTIFIED_KEY) || "{}"); }
        catch { return {}; }
    }
    function setNotified(value) { localStorage.setItem(NOTIFIED_KEY, JSON.stringify(value)); }

    function askPermission() {
        if (!("Notification" in window) || Notification.permission !== "default") return;
        Notification.requestPermission().catch(() => {});
    }

    function inClassNow(roomId) {
        const SCHEDULE = window.SCHEDULE || {};
        const now = window.WellstateClock.parts();
        return (SCHEDULE[now.day] || []).some(lesson => {
            if (lesson.room !== roomId) return false;
            const [startHour, startMinute] = lesson.start.split(":").map(Number);
            const [endHour, endMinute] = lesson.end.split(":").map(Number);
            return now.minuteOfDay >= startHour * 60 + startMinute && now.minuteOfDay < endHour * 60 + endMinute;
        });
    }

    function pushAlert(roomId, room) {
        const notified = getNotified();
        const last = notified[roomId] || 0;
        if (Date.now() - last < COOLDOWN_MS) return;
        notified[roomId] = Date.now();
        setNotified(notified);
        const title = "Wellstate · Sala ocupada fora de horário";
        const body = `Sala ${roomId} — movimento/presença detetada sem aula ativa. Temp. ${room.temperature ?? "—"}°C, hum. ${room.humidity ?? "—"}%.`;
        if ("Notification" in window && Notification.permission === "granted") {
            try { new Notification(title, { body, tag: `wellstate-${roomId}`, renotify: true }); }
            catch { /* o browser pode bloquear notificações fora de um contexto seguro */ }
        }
        showToast(title, body);
    }

    function showToast(title, body) {
        let host = document.getElementById("wellstate-toast-host");
        if (!host) {
            host = document.createElement("div");
            host.id = "wellstate-toast-host";
            host.className = "toast-host";
            document.body.appendChild(host);
        }
        const element = document.createElement("div");
        element.className = "toast danger";
        element.setAttribute("role", "status");
        element.setAttribute("data-testid", "off-hours-toast");
        const titleElement = document.createElement("strong");
        titleElement.className = "toast-title";
        titleElement.textContent = title;
        const bodyElement = document.createElement("div");
        bodyElement.className = "toast-body";
        bodyElement.textContent = body;
        element.append(titleElement, bodyElement);
        host.appendChild(element);
        setTimeout(() => element.classList.add("show"), 10);
        setTimeout(() => { element.classList.remove("show"); setTimeout(() => element.remove(), 350); }, 8000);
    }

    window.WellstateNotify = {
        checkRoom(roomId, room) {
            if (!room) return;
            const isMoving = !!room.motion || (typeof room.distance === "number" && room.distance > 0 && room.distance < 200);
            if (!(!!room.occupied || isMoving)) return;
            if (inClassNow(roomId)) return;
            pushAlert(roomId, room);
        },
        askPermission
    };
})();

/* Relógio escolar: timestamps UTC são apresentados e comparados no fuso horário IANA Europe/Lisbon. */
(function () {
    const zone = window.WELLSTATE_CONFIG?.TIME_ZONE || "Europe/Lisbon";
    const weekdayNumbers = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
    const formatter = new Intl.DateTimeFormat("en-US", {
        timeZone: zone,
        weekday: "long",
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23"
    });

    function parts(date = new Date()) {
        const values = Object.fromEntries(formatter.formatToParts(date).map(part => [part.type, part.value]));
        return {
            day: weekdayNumbers[(values.weekday || "").toLowerCase()],
            hour: Number(values.hour),
            minute: Number(values.minute),
            minuteOfDay: Number(values.hour) * 60 + Number(values.minute)
        };
    }
    function formatTime(date = new Date(), includeSeconds = false) {
        return new Intl.DateTimeFormat("pt-PT", {
            timeZone: zone,
            hour: "2-digit", minute: "2-digit", ...(includeSeconds ? { second: "2-digit" } : {}),
            hourCycle: "h23"
        }).format(date);
    }
    function formatDate(date = new Date()) {
        return new Intl.DateTimeFormat("pt-PT", { timeZone: zone, weekday: "long", year: "numeric", month: "long", day: "numeric" }).format(date);
    }
    function formatDateTime(date = new Date(), includeSeconds = false) {
        return new Intl.DateTimeFormat("pt-PT", {
            timeZone: zone, dateStyle: "short", timeStyle: includeSeconds ? "medium" : "short", hourCycle: "h23"
        }).format(date);
    }
    window.WellstateClock = Object.freeze({ zone, parts, formatTime, formatDate, formatDateTime });
})();

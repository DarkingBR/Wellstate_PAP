import { apiClient } from "./api-client.js";

let SCHEDULE = window.SCHEDULE || {};
let STORE = window.WELLSTATE_STORE;
const grid = document.getElementById("roomsGrid");
let activeRoomFilter = "all";
document.querySelectorAll("[data-room-filter]").forEach(button => button.addEventListener("click", () => {
    activeRoomFilter = button.dataset.roomFilter;
    applyRoomFilter();
}));
const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const roomLabel = id => STORE.rooms.find(room => room.id === id)?.name || `Sala ${id}`;
let lastData = {};
let apiOnline = false;

function classNow(roomId) {
    const current = window.WellstateClock.parts();
    return (SCHEDULE[current.day] || []).find(lesson => {
        if (lesson.room !== roomId) return false;
        const [startHour, startMinute] = lesson.start.split(":").map(Number);
        const [endHour, endMinute] = lesson.end.split(":").map(Number);
        return current.minuteOfDay >= startHour * 60 + startMinute && current.minuteOfDay < endHour * 60 + endMinute;
    });
}

function setApiBadge(online) {
    apiOnline = online;
    const badge = document.getElementById("apiStatus");
    if (!badge) return;
    badge.classList.toggle("is-offline", !online);
    badge.innerHTML = `<span class="pulse-dot"></span> ${online ? "API REST ligada" : "API REST indisponível"}`;
}

function render(data = lastData) {
    lastData = data;
    const configuredRooms = STORE.rooms || [];
    const ids = [...new Set([...configuredRooms.map(room => room.id), ...Object.keys(data)])];
    if (!ids.length) {
        grid.innerHTML = '<div class="panel"><div class="chip">Ainda não há salas configuradas.</div></div>';
        applyRoomFilter();
        return;
    }
    grid.replaceChildren();
    if (!apiOnline) {
        const note = document.createElement("div");
        note.className = "signal-status-note";
        note.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i><span>Sem ligação à API; a atualização será retomada automaticamente.</span>';
        grid.appendChild(note);
    }
    ids.forEach(id => renderCard(id, data[id] || {}));
    applyRoomFilter();
}

function renderCard(id, sensor) {
    const lesson = classNow(id);
    const occupied = Boolean(sensor.occupied) && Boolean(lesson);
    const hasReading = Boolean(sensor.updatedAt);
    const badge = !hasReading
        ? '<span class="status-badge offline"><i class="fa-solid fa-circle"></i> Sem leitura</span>'
        : occupied
            ? '<span class="status-badge occupied"><i class="fa-solid fa-circle"></i> Ocupada</span>'
            : sensor.motion
                ? '<span class="status-badge motion"><i class="fa-solid fa-person-walking"></i> Movimento detetado</span>'
                : '<span class="status-badge free"><i class="fa-solid fa-check"></i> Sem movimento</span>';
    const updated = hasReading ? `${window.WellstateClock.formatTime(new Date(sensor.updatedAt))} · Lisboa` : "A aguardar sensor";
    const card = document.createElement("article");
    card.className = "room-card";
    card.dataset.state = hasReading ? (occupied ? "occupied" : "free") : "offline";
    card.innerHTML = `<div class="head"><div class="room-card-heading"><span class="room-card-icon"><i class="fa-solid fa-door-open"></i></span><div><h3>${esc(roomLabel(id))}</h3><div class="subject">${lesson ? `${esc(lesson.subject)} · ${esc(lesson.group || "Turma por definir")} · ${esc(lesson.start)}–${esc(lesson.end)}` : "Sem aula prevista agora"}</div>${lesson?.teacher ? `<div class="subject">Docente: ${esc(lesson.teacher)}</div>` : ""}<div class="subject">${esc(updated)}</div></div></div>${badge}</div><div class="room-metrics"><div class="metric-tile temp"><div class="label"><i class="fa-solid fa-temperature-half"></i> Temperatura</div><div class="value">${esc(sensor.temperature ?? "—")}<span style="font-size:14px">°C</span></div></div><div class="metric-tile hum"><div class="label"><i class="fa-solid fa-droplet"></i> Humidade</div><div class="value">${esc(sensor.humidity ?? "—")}<span style="font-size:14px">%</span></div></div><div class="metric-tile dist"><div class="label"><i class="fa-solid fa-ruler"></i> Distância</div><div class="value">${esc(sensor.distance ?? "—")}<span style="font-size:14px">cm</span></div></div><div class="metric-tile motion"><div class="label"><i class="fa-solid fa-person-walking"></i> Movimento PIR</div><div class="value">${sensor.motion ? "Sim" : "Não"}</div></div></div>`;
    grid.appendChild(card);
}

function applyRoomFilter() {
    const cards = [...grid.querySelectorAll(".room-card")];
    const counts = {
        all: cards.length,
        occupied: cards.filter(card => card.dataset.state === "occupied").length,
        free: cards.filter(card => card.dataset.state === "free").length
    };
    const ids = { all: "roomsTotal", occupied: "roomsOccupied", free: "roomsFree" };
    Object.entries(ids).forEach(([key, id]) => { const target = document.getElementById(id); if (target) target.textContent = counts[key]; });
    document.querySelectorAll("[data-room-filter]").forEach(button => button.classList.toggle("active", button.dataset.roomFilter === activeRoomFilter));
    cards.forEach(card => { card.hidden = activeRoomFilter !== "all" && card.dataset.state !== activeRoomFilter; });
    if (window.WellstateApplySearch) window.WellstateApplySearch();
}

async function poll() {
    try {
        const readings = await apiClient.getLatestRooms();
        lastData = Object.fromEntries(readings.map(reading => [reading.roomId, reading]));
        setApiBadge(true);
    } catch {
        setApiBadge(false);
    }
    render(lastData);
    window.setTimeout(poll, document.hidden ? 30000 : (window.WELLSTATE_CONFIG.POLL_INTERVAL_MS || 10000));
}

window.addEventListener("wellstate:store-updated", event => {
    STORE = event.detail;
    SCHEDULE = STORE.schedule;
    render();
});

render();
poll();

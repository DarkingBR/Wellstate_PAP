/* Wellstate · configuração local de salas, PCs e horário. */
(function () {
    const CFG = window.WELLSTATE_CONFIG;
    const DEFAULT_STORE = {
        rooms: [
            { id: "C1.01", name: "Bloco C · Sala 1.01" },
            { id: "C0.13", name: "Bloco C · Sala 0.13" },
            { id: "B1.02", name: "Bloco B · Sala 1.02" },
            { id: "D1.4", name: "Bloco D · Sala 1.4" },
            { id: "EF_EB", name: "Ginásio" }
        ],
        pcs: [],
        // Períodos transcritos da imagem HOrаrio.png incluída no projeto.
        schedule: {
            1: [
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "09:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "09:15", end: "10:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:25", end: "11:15" },
                { subject: "EDF", group: "12.º P", teacher: "Professor/a", room: "EF_EB", start: "11:25", end: "12:15" }
            ],
            2: [
                { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "09:05" },
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "09:15", end: "10:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:25", end: "11:15" },
                { subject: "PSI T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:25", end: "12:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "12:25", end: "13:15" },
                { subject: "RDC T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "15:10" },
                { subject: "RDC T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "15:30", end: "16:20" }
            ],
            3: [
                { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "08:15", end: "09:05" },
                { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "09:15", end: "10:05" },
                { subject: "PSI T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "10:25", end: "11:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:25", end: "12:15" }
            ],
            4: [
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "09:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "09:15", end: "10:05" },
                { subject: "PSI T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "10:25", end: "11:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:25", end: "12:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "12:25", end: "13:15" },
                { subject: "RDC T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "15:10" },
                { subject: "RDC T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "15:30", end: "16:20" }
            ],
            5: [
                { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "08:15", end: "09:05" },
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "09:15", end: "10:05" },
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "10:25", end: "11:15" },
                { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "11:25", end: "12:15" }
            ]
        }
    };

    // Versão exata do horário de demonstração anterior. Só substituímos quando
    // não há edições do utilizador, para corrigir também os navegadores existentes.
    const LEGACY_DEFAULT_SCHEDULE = {
        1: [
            { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "10:35" },
            { subject: "EDF", group: "12.º P", teacher: "Professor/a", room: "EF_EB", start: "11:15", end: "12:15" }
        ],
        2: [
            { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "10:35" },
            { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:35", end: "12:15" },
            { subject: "PSI", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "12:15", end: "14:15" },
            { subject: "RDC", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "16:20" }
        ],
        3: [
            { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "09:15", end: "10:15" },
            { subject: "PSI", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:15", end: "13:15" }
        ],
        4: [
            { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "10:35" },
            { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:35", end: "11:15" },
            { subject: "PSI", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:15", end: "13:15" },
            { subject: "RDC", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "16:20" }
        ],
        5: [
            { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "08:15", end: "10:35" },
            { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "10:35", end: "12:15" },
            { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "12:15", end: "13:15" }
        ]
    };

    function purgeDrafts(value) {
        if (Array.isArray(value)) return value
            .filter(item => !(item && typeof item === "object" && (item.isDraft || item.draft === true || ["draft", "rascunho"].includes(String(item.status || "").toLowerCase()))))
            .map(purgeDrafts);
        if (!value || typeof value !== "object") return value;
        for (const key of Object.keys(value)) {
            if (/^(drafts?|rascunhos?)$/i.test(key)) delete value[key];
            else value[key] = purgeDrafts(value[key]);
        }
        return value;
    }

    function clearLegacyDraftKeys() {
        for (let index = localStorage.length - 1; index >= 0; index--) {
            const key = localStorage.key(index);
            if (key && /(^|[-_:])(drafts?|rascunhos?)([-_:]|$)/i.test(key)) localStorage.removeItem(key);
        }
    }

    function normalize(store) {
        const cleaned = purgeDrafts(store);
        cleaned.rooms ||= structuredClone(DEFAULT_STORE.rooms);
        cleaned.pcs ||= structuredClone(DEFAULT_STORE.pcs);
        cleaned.schedule ||= structuredClone(DEFAULT_STORE.schedule);
        Object.values(cleaned.schedule).forEach(day => Array.isArray(day) && day.forEach(lesson => {
            lesson.group ||= "Turma por definir";
            lesson.teacher ||= "Professor/a";
        }));
        return cleaned;
    }

    function load() {
        try {
            const raw = localStorage.getItem(CFG.STORE_KEY);
            if (!raw) return structuredClone(DEFAULT_STORE);
            const parsed = JSON.parse(raw);
            const cleaned = normalize(parsed);
            if (JSON.stringify(cleaned.schedule) === JSON.stringify(LEGACY_DEFAULT_SCHEDULE))
                cleaned.schedule = structuredClone(DEFAULT_STORE.schedule);
            return cleaned;
        } catch {
            return structuredClone(DEFAULT_STORE);
        }
    }

    function save(store) {
        const cleaned = normalize(store);
        localStorage.setItem(CFG.STORE_KEY, JSON.stringify(cleaned));
        window.WELLSTATE_STORE = cleaned;
        window.SCHEDULE = cleaned.schedule;
        window.ROOM_MAP = Object.fromEntries(cleaned.rooms.map(room => [room.id, room.name]));
        window.dispatchEvent(new CustomEvent("wellstate:store-updated", { detail: cleaned }));
    }

    clearLegacyDraftKeys();
    const store = load();
    localStorage.setItem(CFG.STORE_KEY, JSON.stringify(store));
    window.WELLSTATE_STORE = store;
    window.SCHEDULE = store.schedule;
    window.ROOM_MAP = Object.fromEntries(store.rooms.map(room => [room.id, room.name]));
    window.TIME_SLOTS = [
        "08:15 - 09:05", "09:15 - 10:05", "10:25 - 11:15", "11:25 - 12:15",
        "12:25 - 13:15", "13:20 - 14:10", "14:20 - 15:10", "15:30 - 16:20",
        "16:30 - 17:20", "17:30 - 18:20"
    ];
    window.WellstateStore = {
        get: load,
        save,
        reset: () => {
            localStorage.removeItem(CFG.STORE_KEY);
            const fresh = structuredClone(DEFAULT_STORE);
            save(fresh);
            return fresh;
        }
    };
    window.addEventListener("storage", event => {
        if (event.key !== CFG.STORE_KEY || !event.newValue) return;
        try { save(JSON.parse(event.newValue)); } catch { /* ignora dados inválidos de outra aba */ }
    });
})();

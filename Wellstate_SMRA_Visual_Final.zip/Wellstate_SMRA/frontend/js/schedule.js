/* Horários escolares alinhados com os períodos de referência. */
(function () {
    const body = document.getElementById("scheduleList");
    const dayTabs = document.getElementById("dayTabs");
    let STORE = window.WELLSTATE_STORE;
    const days = [1, 2, 3, 4, 5];
    const currentDay = window.WellstateClock.parts().day;
    let selectedDay = days.includes(currentDay) ? currentDay : 1;
    const dialog = document.getElementById("lessonDialog");
    const form = document.getElementById("lessonForm");
    const addBtn = document.getElementById("addLessonBtn");
    addBtn.hidden = false;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
    const roomName = id => STORE.rooms.find(room => room.id === id)?.name || id || "Sala por definir";

    function dateForDay(day) {
        const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: window.WellstateClock.zone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date()).map(part => [part.type, part.value]));
        const today = new Date(Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day)));
        const weekday = currentDay === 0 ? 7 : currentDay;
        today.setUTCDate(today.getUTCDate() + (1 - weekday) + day - 1);
        return today;
    }

    function lessonState(lesson, day) {
        if (day !== window.WellstateClock.parts().day) return "Programada";
        const now = window.WellstateClock.parts().minuteOfDay;
        const [sh, sm] = lesson.start.split(":").map(Number);
        const [eh, em] = lesson.end.split(":").map(Number);
        if (now >= sh * 60 + sm && now < eh * 60 + em) return "Em andamento";
        return now < sh * 60 + sm ? "Aguardando" : "Concluída";
    }

    function render() {
        dayTabs.replaceChildren();
        const dayNames = { 1: "Seg", 2: "Ter", 3: "Qua", 4: "Qui", 5: "Sex" };
        days.forEach(day => {
            const date = dateForDay(day);
            const button = document.createElement("button");
            button.type = "button";
            button.className = `day-tab${day === selectedDay ? " active" : ""}`;
            button.setAttribute("role", "tab");
            button.setAttribute("aria-selected", String(day === selectedDay));
            button.innerHTML = `<span>${dayNames[day]}</span><strong>${date.getUTCDate()}</strong>`;
            button.addEventListener("click", () => { selectedDay = day; render(); });
            dayTabs.appendChild(button);
        });

        const localizedDate = new Intl.DateTimeFormat("pt-PT", { timeZone: "UTC", weekday: "long", day: "numeric", month: "long" }).format(dateForDay(selectedDay));
        document.getElementById("selectedDayDate").textContent = localizedDate;
        document.getElementById("selectedDayTitle").textContent = `${{ 1: "Segunda-feira", 2: "Terça-feira", 3: "Quarta-feira", 4: "Quinta-feira", 5: "Sexta-feira" }[selectedDay]}`;
        const lessons = (STORE.schedule[selectedDay] || []).slice().sort((first, second) => first.start.localeCompare(second.start));
        document.getElementById("dayLessonCount").textContent = `${lessons.length} ${lessons.length === 1 ? "aula" : "aulas"}`;
        body.replaceChildren();
        if (!lessons.length) {
            body.innerHTML = '<div class="lesson-empty"><i class="fa-regular fa-calendar"></i><strong>Nenhuma aula neste dia</strong><span>Use “Adicionar aula” para criar um horário.</span></div>';
            fillRooms();
            return;
        }
        lessons.forEach((lesson, index) => {
            const state = lessonState(lesson, selectedDay);
            const card = document.createElement("article");
            card.className = `lesson-card${state === "Em andamento" ? " is-now" : ""}`;
            card.innerHTML = `<div class="lesson-time-block"><strong>${esc(lesson.start)}</strong><span>${esc(lesson.end)}</span></div><div class="lesson-card-main"><h3>${esc(lesson.subject)}</h3><p>${esc(lesson.group || "Turma por definir")}</p><span class="lesson-room"><i class="fa-solid fa-location-dot"></i>${esc(roomName(lesson.room))}</span></div><div class="lesson-card-end"><span class="lesson-state ${state === "Em andamento" ? "state-now" : ""}"><i class="fa-solid fa-circle"></i>${esc(state)}</span><button class="lesson-edit" type="button" data-edit-day="${selectedDay}" data-edit-index="${STORE.schedule[selectedDay].indexOf(lesson)}" aria-label="Editar aula"><i class="fa-solid fa-pen"></i><span>Editar</span></button></div>`;
            body.appendChild(card);
        });
        fillRooms();
        if (window.WellstateApplySearch) window.WellstateApplySearch();
    }

    function fillRooms(selected) {
        const select = document.getElementById("lessonRoom");
        select.innerHTML = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        if (selected) select.value = selected;
    }

    function openEditor(day = String(selectedDay), index = "") {
        form.reset();
        document.getElementById("lessonFormError").textContent = "";
        document.getElementById("lessonIndex").value = index;
        const isEdit = index !== "";
        document.getElementById("lessonDialogTitle").textContent = isEdit ? "Editar aula / sala" : "Adicionar aula";
        document.getElementById("lessonDay").value = day;
        document.getElementById("deleteLessonBtn").hidden = !isEdit;
        fillRooms();
        if (isEdit) {
            const lesson = STORE.schedule[day][Number(index)];
            document.getElementById("lessonSubject").value = lesson.subject || "";
            document.getElementById("lessonGroup").value = lesson.group || "";
            document.getElementById("lessonTeacher").value = lesson.teacher || "";
            document.getElementById("lessonRoom").value = lesson.room || "";
            document.getElementById("lessonStart").value = lesson.start || "";
            document.getElementById("lessonEnd").value = lesson.end || "";
        } else {
            document.getElementById("lessonStart").value = "08:15";
            document.getElementById("lessonEnd").value = "09:05";
        }
        dialog.showModal();
    }

    function closeEditor() { dialog.close(); }
    addBtn.addEventListener("click", () => openEditor());
    body.addEventListener("click", event => {
        const button = event.target.closest("[data-edit-day]");
        if (button) openEditor(button.dataset.editDay, button.dataset.editIndex);
    });
    document.getElementById("closeLessonDialog").addEventListener("click", closeEditor);
    document.getElementById("cancelLessonBtn").addEventListener("click", closeEditor);

    form.addEventListener("submit", event => {
        event.preventDefault();
        const day = document.getElementById("lessonDay").value;
        const indexValue = document.getElementById("lessonIndex").value;
        const index = indexValue === "" ? -1 : Number(indexValue);
        const next = {
            subject: document.getElementById("lessonSubject").value.trim(),
            group: document.getElementById("lessonGroup").value.trim(),
            teacher: document.getElementById("lessonTeacher").value.trim(),
            room: document.getElementById("lessonRoom").value,
            start: document.getElementById("lessonStart").value,
            end: document.getElementById("lessonEnd").value
        };
        const error = document.getElementById("lessonFormError");
        if (!next.start || !next.end || next.start >= next.end) {
            error.textContent = "A hora de fim tem de ser posterior à hora de início.";
            return;
        }
        const others = (STORE.schedule[day] || []).filter((_, position) => position !== index);
        const overlap = others.some(lesson => next.start < lesson.end && next.end > lesson.start && next.room === lesson.room);
        if (overlap) {
            error.textContent = "Já existe uma aula nessa sala durante parte deste horário.";
            return;
        }
        if (!STORE.schedule[day]) STORE.schedule[day] = [];
        const timestamp = new Date().toISOString();
        if (index >= 0) {
            const previous = STORE.schedule[day][index];
            const roomHistory = Array.isArray(previous.roomHistory) ? previous.roomHistory : [];
            if (previous.room !== next.room) roomHistory.push({ from: previous.room, to: next.room, changedAt: timestamp, changedBy: "Wellstate" });
            STORE.schedule[day][index] = { ...previous, ...next, roomHistory, updatedAt: timestamp, updatedBy: "Wellstate" };
        } else {
            STORE.schedule[day].push({ ...next, roomHistory: [], createdAt: timestamp, createdBy: "Wellstate" });
        }
        STORE.schedule[day].sort((first, second) => first.start.localeCompare(second.start));
        window.WellstateStore.save(STORE);
        STORE = window.WELLSTATE_STORE;
        render();
        closeEditor();
        toast(index >= 0 ? "Aula atualizada." : "Aula adicionada ao horário.");
    });

    document.getElementById("deleteLessonBtn").addEventListener("click", () => {
        const day = document.getElementById("lessonDay").value;
        const index = Number(document.getElementById("lessonIndex").value);
        if (!Number.isInteger(index) || index < 0 || !STORE.schedule[day]?.[index]) return;
        if (!confirm("Remover esta aula do horário?")) return;
        STORE.schedule[day].splice(index, 1);
        window.WellstateStore.save(STORE);
        STORE = window.WELLSTATE_STORE;
        render();
        closeEditor();
        toast("Aula removida.");
    });

    window.addEventListener("wellstate:store-updated", event => { STORE = event.detail; render(); });
    function toast(message) {
        let host = document.getElementById("wellstate-toast-host");
        if (!host) { host = document.createElement("div"); host.id = "wellstate-toast-host"; host.className = "toast-host"; document.body.appendChild(host); }
        const element = document.createElement("div");
        element.className = "toast success";
        element.textContent = message;
        host.appendChild(element);
        setTimeout(() => element.classList.add("show"), 10);
        setTimeout(() => { element.classList.remove("show"); setTimeout(() => element.remove(), 400); }, 2400);
    }
    render();
})();

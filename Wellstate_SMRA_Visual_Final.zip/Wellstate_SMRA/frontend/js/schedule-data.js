/* Wellstate · Compat wrapper
   Mantido apenas para retro-compatibilidade — os dados vêm agora do
   ficheiro `data-store.js`. Este script só garante que os globais
   window.SCHEDULE / window.TIME_SLOTS / window.ROOM_MAP existem.
*/
(function () {
    if (!window.WELLSTATE_STORE) {
        console.warn("data-store.js deve ser carregado antes de schedule-data.js");
    }
})();

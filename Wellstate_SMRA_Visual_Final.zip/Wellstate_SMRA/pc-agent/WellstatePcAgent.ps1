<#
Wellstate PC Agent
Recebe notificações do servidor Wellstate e apresenta-as ao utilizador do Windows.
Não executa comandos, scripts, URLs nem ficheiros recebidos pela rede.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$PcId,

    [string]$ServerUrl = "",

    [string]$AgentKey = $env:WELLSTATE_AGENT_API_KEY,

    [ValidateRange(1, 30)]
    [int]$PollSeconds = 1
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($ServerUrl)) {
    $ServerUrl = $env:WELLSTATE_API_BASE_URL
}
if ([string]::IsNullOrWhiteSpace($ServerUrl)) {
    throw "Defina WELLSTATE_API_BASE_URL ou informe -ServerUrl com a URL alcançável da API (ex.: http://192.168.1.10:5080/api)."
}

try {
    $serverUri = [Uri]::new($ServerUrl)
    if ($serverUri.Scheme -notin @("http", "https") -or -not $serverUri.IsAbsoluteUri) {
        throw "A URL deve começar com http:// ou https:// e incluir o host do servidor."
    }
}
catch {
    throw "ServerUrl inválida ('$ServerUrl'): $($_.Exception.Message)"
}

$baseUrl = $serverUri.GetLeftPart([UriPartial]::Path).TrimEnd("/")
if (-not $serverUri.AbsolutePath.TrimEnd("/").EndsWith("/api", [StringComparison]::OrdinalIgnoreCase)) {
    $baseUrl = "$baseUrl/api"
}
$agentVersion = "1.3.0"
if ([string]::IsNullOrWhiteSpace($AgentKey)) { throw "Defina WELLSTATE_AGENT_API_KEY com o mesmo segredo Wellstate__AgentApiKey configurado no servidor." }

function Invoke-WellstateRequest {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Path,
        [object]$Body
    )

    $parameters = @{
        Method = $Method
        Uri = "$baseUrl$Path"
        TimeoutSec = 8
        ErrorAction = "Stop"
        Headers = @{ "X-Agent-Key" = $AgentKey }
    }
    if ($null -ne $Body) {
        $parameters.ContentType = "application/json"
        $parameters.Body = ($Body | ConvertTo-Json -Compress)
    }
    Invoke-RestMethod @parameters
}

function Show-NotificationSignal {
    param([Parameter(Mandatory = $true)][string]$Message)

    # Som local antes da notificação. Não depende de executar conteúdo remoto.
    try { [System.Media.SystemSounds]::Asterisk.Play() } catch { [Console]::Beep(880, 150) }

    # msg.exe mostra apenas o texto recebido na sessão Windows ativa.
    $msgExe = Join-Path $env:SystemRoot "System32\msg.exe"
    if (-not (Test-Path $msgExe)) { throw "msg.exe não foi encontrado neste Windows." }
    & $msgExe "*" $Message
    if ($LASTEXITCODE -ne 0) { throw "O Windows não conseguiu mostrar a notificação (código $LASTEXITCODE)." }
}

Write-Host "Wellstate PC Agent $agentVersion ligado para $PcId -> $baseUrl (verificação a cada ${PollSeconds}s)" -ForegroundColor Cyan
while ($true) {
    try {
        Invoke-WellstateRequest -Method "POST" -Path "/pcs/$PcId/agent/heartbeat" -Body @{
            computerName = $env:COMPUTERNAME
            agentVersion = $agentVersion
        } | Out-Null

        $signal = Invoke-WellstateRequest -Method "GET" -Path "/pcs/$PcId/agent/signals/next"
        if ($null -ne $signal -and $signal.id) {
            $success = $false
            $details = ""
            try {
                if ($signal.type -ne "notification") { throw "Tipo de sinal não permitido: $($signal.type)" }
                Show-NotificationSignal -Message ([string]$signal.message)
                $success = $true
                $details = "Notificação apresentada em $env:COMPUTERNAME."
            }
            catch {
                $details = $_.Exception.Message
            }

            Invoke-WellstateRequest -Method "POST" -Path "/pcs/$PcId/agent/signals/$($signal.id)/ack" -Body @{
                success = $success
                details = $details
            } | Out-Null
        }

        Start-Sleep -Seconds $PollSeconds
    }
    catch {
        Write-Warning "Ligação ao servidor falhou: $($_.Exception.Message)"
        Start-Sleep -Seconds ([Math]::Max(3, $PollSeconds))
    }
}

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/backend-csharp"
if ! command -v dotnet >/dev/null 2>&1; then
  echo "Erro: instale o .NET 8 SDK antes de iniciar o Wellstate." >&2
  exit 1
fi
exec dotnet run --urls "http://0.0.0.0:5080"

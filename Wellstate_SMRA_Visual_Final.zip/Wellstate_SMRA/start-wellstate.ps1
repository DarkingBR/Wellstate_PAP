$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location (Join-Path $root 'backend-csharp')
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'Instale o .NET 8 SDK antes de iniciar o Wellstate.'
}
dotnet run --urls 'http://0.0.0.0:5080'

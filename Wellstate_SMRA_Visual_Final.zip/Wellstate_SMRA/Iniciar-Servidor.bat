@echo off
echo A iniciar o backend e servidor Wellstate...
powershell -ExecutionPolicy Bypass -File "%~dp0start-wellstate.ps1"
pause
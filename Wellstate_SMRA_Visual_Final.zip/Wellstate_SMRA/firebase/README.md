# Firebase (opcional)

A versão atual do Wellstate SMRA ainda não usa Firebase Authentication nem Firestore. A aplicação grava telemetria e sinais em SQLite; salas, dispositivos cadastrados e horários ficam no navegador. Criar as coleções não liga automaticamente a aplicação ao Firestore.

- O esquema detalhado (coleções, campos, tipos nativos, validações, exemplos de documentos, índices, segurança e migração) está em [docs/FIREBASE.md](../docs/FIREBASE.md).
- `firestore.rules` nega todo o acesso cliente por omissão. Não publique regras permissivas para contornar uma integração ainda não implementada.
- `firestore.indexes.json` contém índices compostos sugeridos para as consultas descritas na documentação; publique-os apenas quando as consultas correspondentes forem implementadas.
- Nunca coloque credenciais Admin/service-account no frontend, ZIP, Git ou neste diretório.

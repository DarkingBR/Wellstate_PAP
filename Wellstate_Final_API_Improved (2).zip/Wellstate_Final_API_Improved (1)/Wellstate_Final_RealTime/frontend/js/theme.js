/* Theme toggle - dark ↔ light */
(function () {
    const KEY = "wellstate-theme";
    const applyTheme = (t) => {
        document.documentElement.setAttribute("data-theme", t);
        try { localStorage.setItem(KEY, t); } catch (e) {}
        const btns = document.querySelectorAll("#themeToggle i, .theme-toggle i");
        btns.forEach((i) => { i.className = t === "light" ? "fa-solid fa-sun" : "fa-solid fa-moon"; });
    };

    const saved = (() => { try { return localStorage.getItem(KEY); } catch (e) { return null; } })();
    applyTheme(saved || "dark");

    document.addEventListener("click", (e) => {
        const btn = e.target.closest("#themeToggle, .theme-toggle");
        if (!btn) return;
        const cur = document.documentElement.getAttribute("data-theme") || "dark";
        applyTheme(cur === "dark" ? "light" : "dark");
    });
})();

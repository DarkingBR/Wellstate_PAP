/* Wellstate · identidade operacional da plataforma. */
(function () {
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };
    setText("userName", "Wellstate Operator");
    setText("userEmail", "Sistema Ativo");
})();

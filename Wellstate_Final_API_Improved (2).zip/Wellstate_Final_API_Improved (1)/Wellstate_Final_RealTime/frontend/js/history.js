/* Wellstate · Histórico
   - Lista de eventos (últimos)
   - Gráfico de 24h (temp + humidade) com Chart.js
   - Exportação PDF semanal com jsPDF
*/
import { apiClient } from "./api-client.js";

const list = document.getElementById("historyList");
const filter = document.getElementById("roomFilter");
const rangeSel = document.getElementById("rangeSel");
const pdfBtn = document.getElementById("exportPdfBtn");
const chartCanvas = document.getElementById("chartCanvas");
let chart = null;
let STORE = window.WELLSTATE_STORE;
let apiOnline = false;
const TIME_ZONE = window.WELLSTATE_CONFIG?.TIME_ZONE || "Europe/Lisbon";

function roomLabel(id) {
    const cfg = (STORE.rooms || []).find(r => r.id === id);
    return cfg?.name || `Sala ${id}`;
}

async function loadRooms() {
    let ids = (STORE.rooms || []).map(room => room.id);
    try {
        const readings = await apiClient.getLatestRooms();
        apiOnline = true;
        ids = [...new Set([...ids, ...readings.map(reading => reading.roomId)])];
    } catch { apiOnline = false; }
    filter.innerHTML = `<option value="">Todas as salas</option>` +
        ids.map((id) => `<option value="${id}">${roomLabel(id)}</option>`).join("");
}

async function fetchHistoryEntries(roomId, from, to) {
    try {
        const rows = await apiClient.getHistory({ roomId, limit: 2000, from, to });
        apiOnline = true;
        return rows.map(row => ({ ...row, ts: row.updatedAt }));
    } catch {
        apiOnline = false;
        return [];
    }
}

function parseTs(ts) {
    if (typeof ts === "number") return new Date(ts);
    if (Number.isFinite(+ts)) return new Date(+ts);
    return new Date(ts);
}

async function loadHistory() {
    list.innerHTML = `<div class="skeleton wide"></div>`;
    const roomId = filter.value;
    const rangeH = Number(rangeSel?.value || 24);

    const now = Date.now();
    const from = now - rangeH * 3600 * 1000;
    const entries = await fetchHistoryEntries(roomId, from, now);

    const filtered = entries
        .map(e => ({ ...e, _t: parseTs(e.ts).getTime() }))
        .filter(e => e._t >= from)
        .sort((a, b) => b._t - a._t);

    renderList(filtered);
    renderChart(filtered, roomId);
}

function renderList(entries) {
    if (!entries.length) {
        list.innerHTML = `<div class="chip">${apiOnline ? "Sem histórico registado no intervalo selecionado." : "API REST indisponível; confirma a ligação ao servidor."}</div>`;
        return;
    }
    list.innerHTML = "";
    entries.slice(0, 200).forEach((ev) => {
        const el = document.createElement("div");
        el.className = "history-item fade-in";
        el.innerHTML = `
            <div class="time">${new Intl.DateTimeFormat("pt-PT", { timeZone: TIME_ZONE, dateStyle: "short", timeStyle: "medium", hourCycle: "h23" }).format(new Date(ev._t))}</div>
            <div class="desc"><strong>${roomLabel(ev.roomId)}</strong> · ${ev.event || "leitura"} · ${ev.temperature ?? "—"}°C · ${ev.humidity ?? "—"}%</div>
            <span class="status-badge ${ev.occupied ? "occupied" : "free"}">${ev.occupied ? "Ocupada" : "Livre"}</span>`;
        list.appendChild(el);
    });
}

function renderChart(entries, roomFilter) {
    if (!chartCanvas || !window.Chart) return;

    // Agrupar por sala; se filtro definido, apenas uma sala
    const grouped = {};
    entries.forEach(e => {
        (grouped[e.roomId] = grouped[e.roomId] || []).push(e);
    });
    const palette = ["#1e88ff", "#22e39c", "#ffb547", "#ff5678", "#6c7cff", "#00e0ff"];
    const datasets = [];
    let colorIdx = 0;
    Object.entries(grouped).forEach(([rid, evs]) => {
        const sorted = evs.slice().sort((a, b) => a._t - b._t);
        const color = palette[colorIdx % palette.length]; colorIdx++;
        datasets.push({
            label: `${roomLabel(rid)} · Temp (°C)`,
            data: sorted.filter(e => typeof e.temperature === "number").map(e => ({ x: e._t, y: e.temperature })),
            borderColor: color, backgroundColor: color + "30", tension: 0.35, pointRadius: 2
        });
        datasets.push({
            label: `${roomLabel(rid)} · Hum (%)`,
            data: sorted.filter(e => typeof e.humidity === "number").map(e => ({ x: e._t, y: e.humidity })),
            borderColor: color, borderDash: [6, 4], backgroundColor: "transparent", tension: 0.35, pointRadius: 2,
            yAxisID: "y1"
        });
    });

    if (chart) chart.destroy();
    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    const gridCol = isLight ? "rgba(30,60,120,0.08)" : "rgba(180,200,255,0.08)";
    const textCol = isLight ? "#0a1a3a" : "#e6efff";

    chart = new Chart(chartCanvas, {
        type: "line",
        data: { datasets },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: textCol, font: { family: "Space Grotesk" } } },
                tooltip: { mode: "index", intersect: false }
            },
            scales: {
                x: {
                    type: "time",
                    adapters: { date: { zone: TIME_ZONE } },
                    time: { unit: "hour", displayFormats: { hour: "HH:mm" } },
                    grid: { color: gridCol }, ticks: { color: textCol }
                },
                y: { title: { display: true, text: "°C", color: textCol }, grid: { color: gridCol }, ticks: { color: textCol } },
                y1: { position: "right", title: { display: true, text: "%", color: textCol }, grid: { drawOnChartArea: false }, ticks: { color: textCol } }
            },
            interaction: { mode: "nearest", axis: "x", intersect: false }
        }
    });
}

// ===== PDF export (semana atual) =====
async function exportPdf() {
    if (!window.jspdf) return alert("jsPDF não carregou.");
    const { jsPDF } = window.jspdf;
    const roomId = filter.value;
    const now = new Date();
    const start = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    const entries = await fetchHistoryEntries(roomId, start, now);
    const week = entries
        .map(e => ({ ...e, _t: parseTs(e.ts).getTime() }))
        .filter(e => e._t >= start.getTime())
        .sort((a, b) => a._t - b._t);

    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const marginX = 40;
    let y = 50;

    doc.setFont("helvetica", "bold"); doc.setFontSize(20);
    doc.setTextColor(30, 136, 255); doc.text("Wellstate · Relatório Semanal", marginX, y);
    y += 22;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(80);
    doc.text(`Intervalo: ${window.WellstateClock.formatDateTime(start)}  →  ${window.WellstateClock.formatDateTime(now)} (${TIME_ZONE})`, marginX, y);
    y += 14;
    doc.text(`Sala: ${roomId ? roomLabel(roomId) : "Todas"}`, marginX, y);
    y += 14;
    doc.text(`Total de registos: ${week.length}`, marginX, y);
    y += 22;

    // Estatísticas por sala
    const stats = {};
    week.forEach(e => {
        const s = stats[e.roomId] = stats[e.roomId] || { n: 0, tSum: 0, tN: 0, hSum: 0, hN: 0, occ: 0 };
        s.n++;
        if (typeof e.temperature === "number") { s.tSum += e.temperature; s.tN++; }
        if (typeof e.humidity === "number") { s.hSum += e.humidity; s.hN++; }
        if (e.occupied) s.occ++;
    });

    doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(20);
    doc.text("Resumo por sala", marginX, y); y += 16;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10);
    Object.entries(stats).forEach(([rid, s]) => {
        const tAvg = s.tN ? (s.tSum / s.tN).toFixed(1) : "—";
        const hAvg = s.hN ? (s.hSum / s.hN).toFixed(0) : "—";
        doc.text(`• ${roomLabel(rid)}: ${s.n} registos · Temp média ${tAvg}°C · Hum média ${hAvg}% · Ocupações ${s.occ}`, marginX, y);
        y += 14;
        if (y > 780) { doc.addPage(); y = 50; }
    });

    y += 8;
    doc.setFont("helvetica", "bold"); doc.setFontSize(13);
    doc.text("Registos (cronológico)", marginX, y); y += 14;

    doc.setFont("helvetica", "bold"); doc.setFontSize(9);
    doc.text("Data/Hora", marginX, y);
    doc.text("Sala", marginX + 130, y);
    doc.text("Evento", marginX + 220, y);
    doc.text("T (°C)", marginX + 320, y);
    doc.text("H (%)", marginX + 370, y);
    doc.text("Ocupada", marginX + 420, y);
    y += 4;
    doc.setDrawColor(200); doc.line(marginX, y, marginX + 500, y);
    y += 10;
    doc.setFont("helvetica", "normal");

    week.forEach(e => {
        if (y > 800) { doc.addPage(); y = 50; }
        doc.text(window.WellstateClock.formatDateTime(new Date(e._t)), marginX, y);
        doc.text(String(roomLabel(e.roomId)).slice(0, 18), marginX + 130, y);
        doc.text(String(e.event || "leitura").slice(0, 18), marginX + 220, y);
        doc.text(String(e.temperature ?? "—"), marginX + 320, y);
        doc.text(String(e.humidity ?? "—"), marginX + 370, y);
        doc.text(e.occupied ? "Sim" : "Não", marginX + 420, y);
        y += 12;
    });

    // Rodapé
    const pageCount = doc.internal.pages.length - 1;
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8); doc.setTextColor(120);
        doc.text(`Wellstate · PAP · Página ${i}/${pageCount}`, marginX, 820);
    }

    const stamp = now.toISOString().slice(0, 10);
    doc.save(`wellstate-semana-${stamp}.pdf`);
}

filter.addEventListener("change", loadHistory);
if (rangeSel) rangeSel.addEventListener("change", loadHistory);
if (pdfBtn) pdfBtn.addEventListener("click", exportPdf);

window.addEventListener("wellstate:store-updated", (e) => { STORE = e.detail; loadRooms().then(loadHistory); });

loadRooms().then(loadHistory);

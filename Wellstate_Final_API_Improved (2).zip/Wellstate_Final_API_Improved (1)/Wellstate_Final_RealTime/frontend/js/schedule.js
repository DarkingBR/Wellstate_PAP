/* Horários escolares alinhados com os períodos de referência. */
(function () {
    const body = document.getElementById("scheduleBody");
    let STORE = window.WELLSTATE_STORE;
    const days = [1, 2, 3, 4, 5];
    const dialog = document.getElementById("lessonDialog");
    const form = document.getElementById("lessonForm");
    const addBtn = document.getElementById("addLessonBtn");
    addBtn.hidden = false;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
    const roomName = id => STORE.rooms.find(room => room.id === id)?.name || id || "Sala por definir";

    function render() {
        body.replaceChildren();
        const timeSlots = window.TIME_SLOTS || [];
        timeSlots.forEach(slot => {
            const [start, end] = slot.split(" - ");
            const row = document.createElement("tr");
            const timeCell = document.createElement("td");
            timeCell.className = "cell-slot";
            timeCell.textContent = slot;
            row.appendChild(timeCell);
            days.forEach(day => {
                const cell = document.createElement("td");
                const lesson = (STORE.schedule[day] || []).find(item => item.start < end && item.end > start);
                if (!lesson) {
                    cell.textContent = "—";
                    cell.className = "empty-slot";
                } else {
                    const index = (STORE.schedule[day] || []).indexOf(lesson);
                    cell.className = "has-class";
                    cell.innerHTML = `<div class="lesson-cell"><strong>${esc(lesson.subject)}</strong><span class="lesson-group">${esc(lesson.group || "Turma por definir")}</span><span class="lesson-room"><i class="fa-solid fa-location-dot"></i> ${esc(roomName(lesson.room))}</span><span class="lesson-time">${esc(lesson.start)}–${esc(lesson.end)}</span><button class="lesson-edit" type="button" data-edit-day="${day}" data-edit-index="${index}" aria-label="Editar aula"><i class="fa-solid fa-pen"></i><span>Editar</span></button></div>`;
                }
                row.appendChild(cell);
            });
            body.appendChild(row);
        });
        fillRooms();
    }

    function fillRooms(selected) {
        const select = document.getElementById("lessonRoom");
        select.innerHTML = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        if (selected) select.value = selected;
    }

    function openEditor(day = "1", index = "") {
        form.reset();
        document.getElementById("lessonFormError").textContent = "";
        document.getElementById("lessonIndex").value = index;
        const isEdit = index !== "";
        document.getElementById("lessonDialogTitle").textContent = isEdit ? "Editar aula / sala" : "Adicionar aula";
        document.getElementById("lessonDay").value = day;
        document.getElementById("deleteLessonBtn").hidden = !isEdit;
        fillRooms();
        if (isEdit) {
            const lesson = STORE.schedule[day][Number(index)];
            document.getElementById("lessonSubject").value = lesson.subject || "";
            document.getElementById("lessonGroup").value = lesson.group || "";
            document.getElementById("lessonTeacher").value = lesson.teacher || "";
            document.getElementById("lessonRoom").value = lesson.room || "";
            document.getElementById("lessonStart").value = lesson.start || "";
            document.getElementById("lessonEnd").value = lesson.end || "";
        } else {
            document.getElementById("lessonStart").value = "08:15";
            document.getElementById("lessonEnd").value = "09:05";
        }
        dialog.showModal();
    }

    function closeEditor() { dialog.close(); }
    addBtn.addEventListener("click", () => openEditor());
    body.addEventListener("click", event => {
        const button = event.target.closest("[data-edit-day]");
        if (button) openEditor(button.dataset.editDay, button.dataset.editIndex);
    });
    document.getElementById("closeLessonDialog").addEventListener("click", closeEditor);
    document.getElementById("cancelLessonBtn").addEventListener("click", closeEditor);

    form.addEventListener("submit", event => {
        event.preventDefault();
        const day = document.getElementById("lessonDay").value;
        const indexValue = document.getElementById("lessonIndex").value;
        const index = indexValue === "" ? -1 : Number(indexValue);
        const next = {
            subject: document.getElementById("lessonSubject").value.trim(),
            group: document.getElementById("lessonGroup").value.trim(),
            teacher: document.getElementById("lessonTeacher").value.trim(),
            room: document.getElementById("lessonRoom").value,
            start: document.getElementById("lessonStart").value,
            end: document.getElementById("lessonEnd").value
        };
        const error = document.getElementById("lessonFormError");
        if (!next.start || !next.end || next.start >= next.end) {
            error.textContent = "A hora de fim tem de ser posterior à hora de início.";
            return;
        }
        const others = (STORE.schedule[day] || []).filter((_, position) => position !== index);
        const overlap = others.some(lesson => next.start < lesson.end && next.end > lesson.start && next.room === lesson.room);
        if (overlap) {
            error.textContent = "Já existe uma aula nessa sala durante parte deste horário.";
            return;
        }
        if (!STORE.schedule[day]) STORE.schedule[day] = [];
        const timestamp = new Date().toISOString();
        if (index >= 0) {
            const previous = STORE.schedule[day][index];
            const roomHistory = Array.isArray(previous.roomHistory) ? previous.roomHistory : [];
            if (previous.room !== next.room) roomHistory.push({ from: previous.room, to: next.room, changedAt: timestamp, changedBy: "Wellstate" });
            STORE.schedule[day][index] = { ...previous, ...next, roomHistory, updatedAt: timestamp, updatedBy: "Wellstate" };
        } else {
            STORE.schedule[day].push({ ...next, roomHistory: [], createdAt: timestamp, createdBy: "Wellstate" });
        }
        STORE.schedule[day].sort((first, second) => first.start.localeCompare(second.start));
        window.WellstateStore.save(STORE);
        STORE = window.WELLSTATE_STORE;
        render();
        closeEditor();
        toast(index >= 0 ? "Aula atualizada." : "Aula adicionada ao horário.");
    });

    document.getElementById("deleteLessonBtn").addEventListener("click", () => {
        const day = document.getElementById("lessonDay").value;
        const index = Number(document.getElementById("lessonIndex").value);
        if (!Number.isInteger(index) || index < 0 || !STORE.schedule[day]?.[index]) return;
        if (!confirm("Remover esta aula do horário?")) return;
        STORE.schedule[day].splice(index, 1);
        window.WellstateStore.save(STORE);
        STORE = window.WELLSTATE_STORE;
        render();
        closeEditor();
        toast("Aula removida.");
    });

    window.addEventListener("wellstate:store-updated", event => { STORE = event.detail; render(); });
    function toast(message) {
        let host = document.getElementById("wellstate-toast-host");
        if (!host) { host = document.createElement("div"); host.id = "wellstate-toast-host"; host.className = "toast-host"; document.body.appendChild(host); }
        const element = document.createElement("div");
        element.className = "toast success";
        element.textContent = message;
        host.appendChild(element);
        setTimeout(() => element.classList.add("show"), 10);
        setTimeout(() => { element.classList.remove("show"); setTimeout(() => element.remove(), 400); }, 2400);
    }
    render();
})();

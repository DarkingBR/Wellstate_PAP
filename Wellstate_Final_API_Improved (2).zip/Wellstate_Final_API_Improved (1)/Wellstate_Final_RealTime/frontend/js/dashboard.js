import { apiClient } from "./api-client.js";

const CFG = window.WELLSTATE_CONFIG;
let SCHEDULE = window.SCHEDULE || {};
let STORE = window.WELLSTATE_STORE;
let roomsCache = {};
let apiOnline = false;
const setText = (id, value) => { const element = document.getElementById(id); if (element) element.textContent = value; };
const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const fmtHM = date => window.WellstateClock.formatTime(date);
const roomIdFromKey = key => (STORE.rooms || []).find(room => room.id === key)?.id || key;

document.getElementById("dateNow").textContent = `${window.WellstateClock.formatDate()} · ${window.WellstateClock.zone}`;

function setApiBadge(online, label) {
    apiOnline = online;
    const badge = document.getElementById("apiStatus");
    if (!badge) return;
    badge.classList.toggle("is-offline", !online);
    badge.innerHTML = `<span class="pulse-dot"></span> ${esc(label)}`;
}

function isClassNow(lesson) {
    if (!lesson?.start || !lesson?.end) return false;
    const [startHour, startMinute] = lesson.start.split(":").map(Number);
    const [endHour, endMinute] = lesson.end.split(":").map(Number);
    const current = window.WellstateClock.parts();
    return current.minuteOfDay >= startHour * 60 + startMinute && current.minuteOfDay < endHour * 60 + endMinute;
}

function classForRoomNow(roomId) {
    return (SCHEDULE[window.WellstateClock.parts().day] || []).find(lesson => lesson.room === roomId && isClassNow(lesson));
}
function roomLabel(id) { return STORE.rooms.find(room => room.id === id)?.name || `Sala ${id}`; }

const roomList = document.getElementById("roomList");
const pcList = document.getElementById("pcList");

function renderRoomsMini() {
    const configured = STORE.rooms || [];
    const ids = [...new Set([...configured.map(room => room.id), ...Object.keys(roomsCache)])];
    if (!ids.length) {
        roomList.innerHTML = '<div class="chip">Ainda não existem salas configuradas.</div>';
        return;
    }
    roomList.replaceChildren();
    ids.forEach(roomId => {
        const sensor = roomsCache[roomId] || {};
        const lesson = classForRoomNow(roomId);
        const occupied = Boolean(sensor.occupied) && Boolean(lesson);
        const hasReading = Boolean(sensor.updatedAt);
        const badge = !hasReading
            ? '<span class="status-badge offline"><i class="fa-solid fa-circle"></i> Sem leitura</span>'
            : occupied
                ? '<span class="status-badge occupied"><i class="fa-solid fa-circle"></i> Ocupada</span>'
                : sensor.motion
                    ? '<span class="status-badge motion"><i class="fa-solid fa-person-walking"></i> Movimento</span>'
                    : '<span class="status-badge free"><i class="fa-solid fa-check"></i> Sem movimento</span>';
        const row = document.createElement("div");
        row.className = "room-item";
        row.innerHTML = `<div class="left"><div class="icon"><i class="fa-solid fa-door-open"></i></div><div><div class="name">${esc(roomLabel(roomId))}</div><div class="sub">${lesson ? `${esc(lesson.subject)} · ${esc(lesson.group || "Turma por definir")}` : "Sem aula prevista"}</div></div></div><div class="metrics"><span class="metric"><strong>${esc(sensor.temperature ?? "—")}</strong>°C</span><span class="metric"><strong>${esc(sensor.humidity ?? "—")}</strong>%</span>${badge}</div>`;
        roomList.appendChild(row);
    });
}

async function loadPcs() {
    try {
        const result = await apiClient.get("/network/devices");
        const devices = Array.isArray(result?.devices) ? result.devices : [];
        renderPcsMini(devices);
        setText("kpiPcsOn", devices.filter(device => device.online).length);
        setApiBadge(true, "API REST ligada");
    } catch {
        renderPcsMini([], true);
        setText("kpiPcsOn", "—");
    }
    setText("pcsUpdated", `Atualizado ${fmtHM(new Date())}`);
}

function renderPcsMini(devices, localMode = false) {
    if (!devices.length) {
        pcList.innerHTML = `<div class="chip">${localMode ? "API indisponível." : "Nenhum dispositivo encontrado."}</div>`;
        return;
    }
    pcList.replaceChildren();
    devices.slice(0, 8).forEach(device => {
        const row = document.createElement("div");
        row.className = "pc-item";
        row.innerHTML = `<div class="left"><div class="icon">●</div><div><div class="name">${esc(device.hostname || "Dispositivo sem nome")}</div><div class="sub">${esc(device.ip)} · ${esc(device.responseMs ?? "—")} ms</div></div></div><span class="status-badge online">Online</span>`;
        pcList.appendChild(row);
    });
}

function computeKpis() {
    const entries = Object.entries(roomsCache);
    setText("kpiRooms", new Set([...(STORE.rooms || []).map(room => room.id), ...entries.map(([id]) => id)]).size);
    let occupied = 0;
    let temperatureTotal = 0;
    let temperatureCount = 0;
    entries.forEach(([roomId, sensor]) => {
        if (sensor.occupied && classForRoomNow(roomId)) occupied++;
        if (typeof sensor.temperature === "number") { temperatureTotal += sensor.temperature; temperatureCount++; }
    });
    setText("kpiOccupied", occupied);
    setText("kpiTemp", temperatureCount ? `${(temperatureTotal / temperatureCount).toFixed(1)}°C` : "—");
}

function renderScheduleStrip() {
    const lessons = (SCHEDULE[window.WellstateClock.parts().day] || []).slice().sort((first, second) => first.start.localeCompare(second.start));
    const strip = document.getElementById("scheduleStrip");
    if (!lessons.length) {
        strip.innerHTML = '<div class="chip">Sem aulas hoje.</div>';
        setText("scheduleToday", "0 aulas");
        return;
    }
    setText("scheduleToday", `${lessons.length} aulas`);
    strip.replaceChildren();
    lessons.forEach(lesson => {
        const active = isClassNow(lesson);
        const item = document.createElement("div");
        item.className = `class-card ${active ? "now" : ""}`;
        item.innerHTML = `<span class="time">${esc(lesson.start)} — ${esc(lesson.end)}</span><span class="subject">${esc(lesson.subject)}${active ? ' <span class="now-badge">AGORA</span>' : ""}</span><span class="room"><i class="fa-solid fa-door-open"></i> ${esc(roomLabel(lesson.room))}</span><span class="room">${esc(lesson.group || "Turma por definir")} · ${esc(lesson.teacher || "Docente por definir")}</span>`;
        strip.appendChild(item);
    });
}

async function refreshRooms() {
    try {
        const readings = await apiClient.getLatestRooms();
        roomsCache = Object.fromEntries(readings.map(reading => [reading.roomId, reading]));
        setApiBadge(true, "API REST ligada");
        renderRoomsMini();
        computeKpis();
        const newest = readings.reduce((latest, row) => Math.max(latest, Date.parse(row.updatedAt) || 0), 0);
        setText("roomsUpdated", newest ? `Última medição ${fmtHM(new Date(newest))}` : "A aguardar medições");
        if (window.WellstateNotify) readings.forEach(room => window.WellstateNotify.checkRoom(room.roomId, room));
    } catch (error) {
        setApiBadge(false, "API REST indisponível");
        setText("roomsUpdated", "A tentar reconectar");
        renderRoomsMini();
    }
}

async function pollRooms() {
    await refreshRooms();
    window.setTimeout(pollRooms, document.hidden ? Math.max(CFG.POLL_INTERVAL_MS, 30000) : CFG.POLL_INTERVAL_MS);
}

window.addEventListener("wellstate:store-updated", event => {
    STORE = event.detail;
    SCHEDULE = STORE.schedule;
    renderRoomsMini();
    renderScheduleStrip();
    computeKpis();
});

renderScheduleStrip();
renderRoomsMini();
computeKpis();
loadPcs();
window.setInterval(() => { if (!document.hidden) loadPcs(); }, Math.max(CFG.POLL_INTERVAL_MS || 15000, 10000));
pollRooms();

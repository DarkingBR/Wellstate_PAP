# Agente Wellstate de sinais para PCs Windows

O agente PowerShell `WellstatePcAgent.ps1` envia presença para a API a cada segundo, recebe notificações de texto, toca um som local e confirma o resultado. **Não executa comandos remotos.**

## Configuração da conexão

O agente não presume um IP fixo. Passe a URL que o PC consegue alcançar (`http://IP-RESERVADO-DO-SERVIDOR:5080/api` ou a URL HTTPS/VPN configurada). Para mudar de Wi-Fi ou rede, use um nome/IP estável, como uma reserva DHCP ou DNS interno; a API não consegue adivinhar o endereço do servidor a partir de outro PC.

Também pode definir a variável de ambiente `WELLSTATE_API_BASE_URL`. Se o parâmetro terminar sem `/api`, o agente acrescenta essa rota.

## Instalação

1. Em `backend-csharp/appsettings.json`, cadastre o computador com ID único, nome e IP reservado/fixo.
2. Copie a pasta `pc-agent/` para o PC Windows, por exemplo `C:\Wellstate\`.
3. Abra PowerShell como o utilizador que permanece com sessão no PC:

   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   C:\Wellstate\WellstatePcAgent.ps1 -PcId "PC-C101-01" -ServerUrl "http://192.168.1.10:5080/api"
   ```

4. Para usar a URL via variável de ambiente:

   ```powershell
   $env:WELLSTATE_API_BASE_URL = "http://192.168.1.10:5080/api"
   C:\Wellstate\WellstatePcAgent.ps1 -PcId "PC-C101-01"
   ```

5. Para arrancar quando o utilizador inicia sessão, cria uma tarefa no Agendador de Tarefas. Usa o mesmo `-PcId` e `-ServerUrl` do comando acima (ou configure a variável de ambiente para o utilizador da tarefa):

   ```text
   Programa: powershell.exe
   Argumentos: -NoProfile -ExecutionPolicy Bypass -File "C:\Wellstate\WellstatePcAgent.ps1" -PcId "PC-C101-01" -ServerUrl "http://192.168.1.10:5080/api"
   Iniciar em: C:\Wellstate
   ```

## Estados

| Estado | Significado |
|---|---|
| **Online por agente** | Heartbeat recebido nos últimos 8 segundos. |
| **Online por rede** | O servidor recebeu resposta de ping para o IP cadastrado. |
| **Offline** | Não houve resposta de ping nem heartbeat recente; confirme firewall, IP e energia. |
| **Recebido** | A notificação foi apresentada no Windows e confirmada à API. |

Sinais e histórico ficam no SQLite `backend-csharp/Data/wellstate.db`; sinais que aguardam confirmação expiram após 30 segundos por padrão. O agente apresenta apenas mensagens de texto recebidas da API.

## Segurança e alcance da ligação

Para acesso por dados móveis, estabeleça uma VPN com rota ao servidor ou utilize uma publicação HTTPS protegida por autenticação no gateway reverso. A API não autentica utilizadores do painel e não deve ser exposta à Internet sem essa camada de segurança. API, painel e cada agente têm de alcançar a mesma instalação central.

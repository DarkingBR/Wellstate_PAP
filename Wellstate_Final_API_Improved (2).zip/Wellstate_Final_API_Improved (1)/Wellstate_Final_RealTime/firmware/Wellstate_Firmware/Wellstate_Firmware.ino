/*
 * Wellstate · ESP8266 / NodeMCU v2
 * Sensores: DHT11 + PIR HC-SR501 + ultrassónico HC-SR04.
 * Publica medições na API REST Wellstate, que as guarda em SQLite.
 * Não identifica pessoas; a presença é apenas uma estimativa dos sensores.
 */
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <DHT.h>
#include "secrets.h"

#ifndef DHT_PIN
#define DHT_PIN D4
#endif
#ifndef WELLSTATE_ROOM_ID
#define WELLSTATE_ROOM_ID "C1.01"
#endif
#define DHT_TYPE DHT11
#define PIR_PIN D5
#define TRIG_PIN D6
#define ECHO_PIN D7
#define LED_PIN D1

namespace {
constexpr unsigned long WIFI_RETRY_MS = 15000;
constexpr unsigned long SENSOR_READ_MS = 1000;
constexpr unsigned long DHT_READ_MS = 2500;
constexpr unsigned long TELEMETRY_MS = 10000;
constexpr float PRESENCE_DISTANCE_CM = 200.0f;

DHT dht(DHT_PIN, DHT_TYPE);
float temperatureC = NAN;
float humidityPct = NAN;
float distanceCm = NAN;
bool motionDetected = false;
bool presenceConfirmed = false;
bool ledOn = false;
bool configurationReady = false;
unsigned long lastWifiAttempt = 0;
unsigned long lastSensorRead = 0;
unsigned long lastDhtRead = 0;
unsigned long lastTelemetryAttempt = 0;
unsigned long lastLedToggle = 0;

float readDistance() {
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(3);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    const unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
    if (duration == 0) return NAN;
    const float cm = (static_cast<float>(duration) * 0.0343f) / 2.0f;
    if (cm < 2.0f || cm > 400.0f) return NAN;
    return cm;
}

void maintainWiFi() {
    if (WiFi.status() == WL_CONNECTED) return;
    const unsigned long now = millis();
    if (lastWifiAttempt != 0 && now - lastWifiAttempt < WIFI_RETRY_MS) return;
    lastWifiAttempt = now;
    Serial.printf("[Wi-Fi] A ligar a %s\n", WIFI_SSID);
    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

String encodePathSegment(const String &value) {
    String encoded;
    const char hex[] = "0123456789ABCDEF";
    for (size_t i = 0; i < value.length(); ++i) {
        const uint8_t c = static_cast<uint8_t>(value[i]);
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.') {
            encoded += static_cast<char>(c);
        } else {
            encoded += '%';
            encoded += hex[c >> 4];
            encoded += hex[c & 0x0F];
        }
    }
    return encoded;
}

String telemetryJson() {
    String json = "{";
    bool hasField = false;
    if (!isnan(temperatureC)) {
        json += "\"temperature\":" + String(temperatureC, 1);
        hasField = true;
    }
    if (!isnan(humidityPct)) {
        if (hasField) json += ',';
        json += "\"humidity\":" + String(humidityPct, 1);
        hasField = true;
    }
    if (hasField) json += ',';
    json += "\"distance\":";
    json += isnan(distanceCm) ? "null" : String(distanceCm, 1);
    json += ",\"motion\":";
    json += motionDetected ? "true" : "false";
    json += ",\"occupied\":";
    json += presenceConfirmed ? "true" : "false";
    json += "}";
    return json;
}

void postTelemetry() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[API] Sem Wi-Fi; a leitura será tentada novamente no próximo intervalo.");
        return;
    }

    WiFiClient client;
    HTTPClient http;
    http.setTimeout(6000);
    const String url = String(WELLSTATE_API_BASE_URL) + "/api/rooms/" +
        encodePathSegment(String(WELLSTATE_ROOM_ID)) + "/telemetry";
    if (!http.begin(client, url)) {
        Serial.println("[API] Não foi possível iniciar a ligação HTTP.");
        return;
    }
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Device-Key", WELLSTATE_DEVICE_API_KEY);
    const String payload = telemetryJson();
    const int status = http.POST(payload);
    if (status >= 200 && status < 300) {
        Serial.printf("[API] Medição guardada · sala %s · T=%s°C · H=%s%% · movimento=%s · presença=%s\n",
            WELLSTATE_ROOM_ID,
            isnan(temperatureC) ? "—" : String(temperatureC, 1).c_str(),
            isnan(humidityPct) ? "—" : String(humidityPct, 1).c_str(),
            motionDetected ? "sim" : "não", presenceConfirmed ? "sim" : "não");
    } else if (status > 0) {
        Serial.printf("[API ERRO] HTTP %d · %s\n", status, http.getString().c_str());
    } else {
        Serial.printf("[API ERRO] %s\n", http.errorToString(status).c_str());
    }
    http.end();
}

void readSensors() {
    const unsigned long now = millis();
    motionDetected = digitalRead(PIR_PIN) == HIGH;
    if (now - lastSensorRead >= SENSOR_READ_MS || lastSensorRead == 0) {
        lastSensorRead = now;
        distanceCm = readDistance();
        presenceConfirmed = motionDetected && !isnan(distanceCm) && distanceCm < PRESENCE_DISTANCE_CM;
    }
    if (now - lastDhtRead >= DHT_READ_MS || lastDhtRead == 0) {
        lastDhtRead = now;
        const float newTemperature = dht.readTemperature();
        const float newHumidity = dht.readHumidity();
        if (!isnan(newTemperature)) temperatureC = newTemperature;
        if (!isnan(newHumidity)) humidityPct = newHumidity;
        if (isnan(newTemperature) || isnan(newHumidity))
            Serial.println("[Sensor] Leitura DHT11 inválida; será mantida a última leitura válida.");
    }

    if (presenceConfirmed) {
        digitalWrite(LED_PIN, HIGH);
        ledOn = true;
    } else if (motionDetected) {
        if (now - lastLedToggle >= 180) {
            ledOn = !ledOn;
            digitalWrite(LED_PIN, ledOn ? HIGH : LOW);
            lastLedToggle = now;
        }
    } else {
        digitalWrite(LED_PIN, LOW);
        ledOn = false;
    }
}
} // namespace

void setup() {
    Serial.begin(115200);
    delay(250);
    Serial.println();
    Serial.println("Wellstate · Monitor ambiental de sala · Arduino IDE / REST");
    Serial.printf("Sala configurada: %s\n", WELLSTATE_ROOM_ID);

    pinMode(PIR_PIN, INPUT);
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
    pinMode(LED_PIN, OUTPUT);
    digitalWrite(TRIG_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    dht.begin();

    configurationReady = strlen(WIFI_SSID) > 0 && strlen(WIFI_PASSWORD) > 0 &&
        strlen(WELLSTATE_DEVICE_API_KEY) >= 24 && strlen(WELLSTATE_ROOM_ID) > 0 &&
        strlen(WELLSTATE_API_BASE_URL) > 0 && strstr(WELLSTATE_DEVICE_API_KEY, "CHANGE_ME") == nullptr &&
        strstr(WELLSTATE_API_BASE_URL, "CHANGE_ME") == nullptr &&
        strstr(WIFI_SSID, "CHANGE_ME") == nullptr && strstr(WIFI_PASSWORD, "CHANGE_ME") == nullptr;
    if (!configurationReady) {
        Serial.println("[CONFIG] Copia secrets.example.h para secrets.h e preenche Wi-Fi, endereço da API e chave do dispositivo.");
        return;
    }

    WiFi.mode(WIFI_STA);
    WiFi.persistent(false);
    WiFi.setAutoReconnect(true);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.println("[Wi-Fi] Ligação iniciada; o dispositivo continuará a tentar reconectar.");
}

void loop() {
    readSensors();
    if (!configurationReady) {
        delay(20);
        return;
    }
    maintainWiFi();
    const unsigned long now = millis();
    if (now - lastTelemetryAttempt >= TELEMETRY_MS || lastTelemetryAttempt == 0) {
        lastTelemetryAttempt = now;
        postTelemetry();
    }
    delay(20);
}

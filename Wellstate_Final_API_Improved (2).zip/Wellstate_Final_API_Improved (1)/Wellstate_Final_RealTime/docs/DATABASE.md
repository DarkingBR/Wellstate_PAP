# Dados e persistência · Wellstate

| Dados | Localização | Persistência |
|---|---|---|
| Medições e histórico ambiental | SQLite `backend-csharp/Data/wellstate.db` | Tabelas indexadas, WAL e retenção de 90 dias |
| Sinais de PCs | A mesma base SQLite, tabela `pc_signals` | Estado e histórico persistentes, atualizados transacionalmente |
| Antigo histórico de sinais JSON | `backend-csharp/Data/signals.json` | Importado uma vez para SQLite; mantém cópia `.migrated.bak` |
| Estado dos agentes e presença | Memória da API | Heartbeat a cada segundo; reiniciar a API reinicia a presença e não a história de sinais |
| Salas, PCs e horários | `localStorage` (`wellstate-store`) | Sobrevivem no navegador atual; as abas do mesmo navegador sincronizam alterações |
| Tema, avisos e preferências sonoras | `localStorage` | Preferências locais por navegador |

## SQLite

O backend cria as tabelas e índices na primeira execução sem depender de um serviço externo nem de credenciais da base. A localização predefinida é `backend-csharp/Data/wellstate.db`; altera-a através de `Wellstate:Database:Path` no `appsettings.json`.

- As medições e alterações ao histórico de sinais usam transações e um journal SQLite em modo WAL, com timeout de espera para reduzir erros durante acessos simultâneos.
- As leituras usam índices por sala e instante; os sinais usam índices por computador, estado e hora.
- Os timestamps são armazenados em UTC e são formatados na interface como hora de Lisboa (`Europe/Lisbon`), respeitando automaticamente a mudança de hora.
- As medições com mais de 90 dias são limpas a cada 100 novos registos.
- Sinais têm no máximo 500 entradas; pedidos não entregues expiram ao fim de 30 segundos por predefinição.
- `/api/health` valida tanto a tabela de telemetria como o armazenamento de sinais.

Uma única base SQLite elimina a separação anterior entre telemetria SQLite e sinais em ficheiros JSON. O JSON histórico é importado apenas quando a nova tabela ainda está vazia. A cópia de segurança antiga é mantida e nunca removida durante a migração.

## Salas, horários e sincronização entre dispositivos

Os dados de configuração continuam no navegador porque a API original não tinha autenticação nem endpoints CRUD de configuração. Alterações são partilhadas entre separadores do mesmo navegador, não entre telemóveis ou outros computadores. Para tornar a configuração escolar comum a todos os utilizadores seria necessário acrescentar autenticação/autorização e uma API específica para essa configuração; não se deve expor o `localStorage` como se fosse uma base de dados partilhada.

## Segurança e cópias de segurança

O POST dos sensores exige `X-Device-Key`. Os endpoints dos PCs e a respetiva interface ainda não têm autenticação de utilizador. **Não encaminhes a porta 5080 para a Internet pública.** Para usar dados móveis ou uma rede de outro local, usa uma VPN entre o telefone/computador e a rede do servidor ou coloca a aplicação atrás de um gateway HTTPS com autenticação para os utilizadores e dispositivos. A API, o browser e cada agente têm de conseguir alcançar o mesmo servidor; apenas mudar de Wi-Fi para dados móveis não estabelece essa ligação.

Protege a máquina e os ficheiros `wellstate.db`, `wellstate.db-wal`, `wellstate.db-shm` e `signals.json.migrated.bak`. Para uma cópia coerente, usa o backup SQLite ou para o backend antes de copiar os dados.

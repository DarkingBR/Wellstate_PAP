# Firmware e hardware · Wellstate

## Equipamento e ligações

Projeto para NodeMCU v2 / ESP8266, sensor DHT11, PIR HC-SR501, ultrassónico HC-SR04, LED, resistência de 220 Ω e divisor de tensão de 1 kΩ/2 kΩ. Usa alimentação USB da placa e GND comum.

| NodeMCU | Ligação | Observações |
|---|---|---|
| D4 / GPIO2 | DHT11 DATA | Alimenta o DHT11 a 3,3 V; GND comum. |
| D5 / GPIO14 | PIR OUT | O sensor pode ser alimentado a VIN/5 V; garante que OUT não excede 3,3 V. |
| D6 / GPIO12 | HC-SR04 TRIG | O TRIG recebe 3,3 V da placa. |
| D7 / GPIO13 | Junção do divisor ligado a ECHO | **Não ligues ECHO de 5 V diretamente ao ESP8266.** |
| VIN / 5 V | HC-SR04 VCC | GND comum. |
| D1 / GPIO5 | Resistência 220 Ω → LED → GND | Acende com presença estimada; pisca com movimento sem confirmação de distância. |
| GND | GND de todos os módulos | Referência elétrica comum. |

Liga ECHO do HC-SR04 a uma resistência de 1 kΩ e depois à junção que segue para D7; da junção usa 2 kΩ para GND (cerca de 3,3 V). Um level shifter adequado também serve. O ESP8266 usa lógica de 3,3 V; uma ligação direta de 5 V pode danificar a placa.

## Arduino IDE

1. Instala Arduino IDE 2.x.
2. Abre **File → Preferences** e adiciona o URL de placas ESP8266 da documentação oficial `https://arduino.esp8266.com/stable/package_esp8266com_index.json` em *Additional boards manager URLs*.
3. Em **Boards Manager**, instala **ESP8266 by ESP8266 Community** e seleciona **NodeMCU 1.0 (ESP-12E Module)**.
4. Em **Library Manager**, instala **DHT sensor library** por Adafruit e **Adafruit Unified Sensor**.
5. Abre `firmware/Wellstate_Firmware/Wellstate_Firmware.ino`.
6. Edita `secrets.h` na mesma pasta e substitui os valores; esse ficheiro local é ignorado pelo Git. Há um template limpo em `secrets.example.h`.
7. Seleciona a porta USB, compila e carrega. Abre o monitor série a 115200 baud.

### Configuração de `secrets.h`

```cpp
#define WIFI_SSID                 "NOME_WIFI_2_4_GHZ"
#define WIFI_PASSWORD             "PALAVRA_PASSE_WIFI"
#define WELLSTATE_API_BASE_URL    "http://IP-RESERVADO-DO-SERVIDOR:5080"
#define WELLSTATE_DEVICE_API_KEY "MESMO_TOKEN_CONFIGURADO_NO_BACKEND"
#define WELLSTATE_ROOM_ID         "C1.01"
#define DHT_PIN                   D4
```

Reserva um IP para o servidor no router ou usa um nome DNS interno estável; atualiza o endereço quando necessário. Garante que o backend está em execução antes de testar. Define `Wellstate__DeviceApiKey` no ambiente do processo .NET e copia exatamente o mesmo token para o firmware. O firmware publica a cada 10 segundos em `POST /api/rooms/{roomId}/telemetry`, com o cabeçalho `X-Device-Key`, e tenta novamente depois de falhas de rede.

A comunicação HTTP está limitada à LAN privada. Não exponhas a API à Internet: o token de dispositivo é enviado como cabeçalho sem encriptação. Para redes não confiáveis, implementa HTTPS e autenticação apropriada antes de usar.

## Medições e limites

A cada 10 segundos são enviados temperatura, humidade, distância, movimento e estado estimado. O servidor SQLite acrescenta timestamp UTC e mantém até 90 dias de histórico. `occupied` significa somente movimento PIR e objeto detetado a menos de 2 m; não reconhece nem identifica alunos. A medição e os sensores devem ser testados fisicamente no local.

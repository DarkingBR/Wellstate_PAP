# Sinais do servidor para PCs

## Funcionamento

```text
Painel Web ── SSE/REST ── Servidor Wellstate + SQLite ── REST ── Agente Windows ── Mensagem + som
```

1. Cada PC executa `pc-agent/WellstatePcAgent.ps1`. O agente envia heartbeat e procura um sinal a cada segundo.
2. O agente é considerado online se comunicou nos últimos 8 segundos.
3. `/api/pcs/stream` transmite presença dos agentes por Server-Sent Events.
4. `GET /api/pcs` mostra o status agregado: online se o PC respondeu ao ping ou se enviou heartbeat recente. Os campos `networkOnline` e `agentOnline` detalham a origem.
5. Ao enviar sinal, a API verifica a presença no momento do pedido. Se o agente estiver offline, responde HTTP 409, registra o resultado e não deixa a notificação pendente para entrega tardia.
6. Se estiver ligado, o sinal é guardado na tabela `pc_signals` antes de ser enviado ao agente. A API expõe estados `pending`, `claimed`, `received`, `failed` ou `returned`.
7. O agente toca um som no Windows, apresenta a notificação e confirma se conseguiu apresentá-la. Se não chegar confirmação, o pedido expira após 30 segundos por predefinição.

O agente é limitado a texto de notificação: não executa comandos, scripts, URLs ou ficheiros recebidos pela rede.

## Endereço da API e redes diferentes

O agente não tem um IP de servidor fixo no código. Informe `-ServerUrl` ou defina `WELLSTATE_API_BASE_URL` no Windows:

```powershell
C:\Wellstate\WellstatePcAgent.ps1 -PcId "PC-C101-01" -ServerUrl "http://192.168.1.10:5080/api"
```

Use um endereço alcançável na mesma LAN/VPN. Para não mudar o URL quando o servidor reiniciar, reserve um IP para ele no router ou crie um nome DNS interno. A API detecta automaticamente a sub-rede conectada ao próprio servidor; isso não muda a URL que os agentes precisam usar para encontrá-la.

Por dados móveis ou noutro local, ligue o utilizador a uma VPN com rota para o servidor, ou publique uma URL HTTPS através de um gateway que exija autenticação para utilizadores e dispositivos. Não encaminhe diretamente a porta 5080 para a Internet: endpoints de sinais, presença e histórico não têm autenticação de utilizador.

## Preparar o servidor

1. Instale o [.NET SDK 8](https://dotnet.microsoft.com/download/dotnet/8.0).
2. Em `backend-csharp/appsettings.json`, configure IDs, nomes, IPs fixos/reservados e salas dos PCs em `Wellstate:Pcs`.
3. No PowerShell, a partir de `backend-csharp`, inicie a API:

   ```powershell
   $token = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
   $env:Wellstate__DeviceApiKey = $token
   $env:ASPNETCORE_ENVIRONMENT = "Production"
   dotnet restore
   dotnet run
   ```

4. Teste `http://localhost:5080/api/health`; deve responder `status: ok`, `database: ok` e `signalStorage: sqlite`.
5. Se a firewall do Windows bloquear a LAN, permita TCP 5080 apenas na rede privada:

   ```powershell
   New-NetFirewallRule -DisplayName "Wellstate API local" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 5080 -Profile Private
   ```

A variável `Wellstate__DeviceApiKey` é para a telemetria NodeMCU. Copie o token correspondente para `WELLSTATE_DEVICE_API_KEY` no firmware e mantenha-o privado.

## Endpoints principais

| Endpoint | Função |
|---|---|
| `GET /api/health` | Estado da API e persistência SQLite |
| `GET /api/network/devices` | Dispositivos que respondem na LAN privada do servidor |
| `GET /api/pcs` | Status de rede e agente para os PCs cadastrados |
| `GET /api/pcs/stream` | Atualizações SSE de presença do agente |
| `POST /api/pcs/{pcId}/signals` | Regista o sinal; devolve 409 se o agente estiver offline |
| `GET /api/pcs/{pcId}/signals` | Histórico persistente de sinais |
| `POST /api/pcs/{pcId}/agent/heartbeat` | Presença do agente Windows |
| `GET /api/pcs/{pcId}/agent/signals/next` | O agente pede um sinal pendente |
| `POST /api/pcs/{pcId}/agent/signals/{id}/ack` | Confirma a apresentação da mensagem |

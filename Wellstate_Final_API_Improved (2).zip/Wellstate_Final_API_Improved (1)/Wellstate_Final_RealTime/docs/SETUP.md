# Configuração rápida · Wellstate

## 1. Iniciar a API

1. Instale o **.NET SDK 8** e abra a pasta do projeto no VS Code.
   Em Linux, instale também o utilitário ICMP: `sudo apt-get install iputils-ping` (em distribuições Debian/Ubuntu).
2. No terminal, entre em `backend-csharp` e defina uma chave aleatória para os sensores. No PowerShell:

   ```powershell
   $token = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
   $env:Wellstate__DeviceApiKey = $token
   $env:ASPNETCORE_ENVIRONMENT = "Production"
   dotnet restore
   dotnet run
   ```

   A API escuta em `http://0.0.0.0:5080`. A base SQLite, com tabelas indexadas para medições e sinais de PCs, é criada automaticamente em `Data/wellstate.db`.

3. Confirme `http://localhost:5080/api/health`; deve indicar `status: ok`, `database: ok` e `signalStorage: sqlite`.
4. O painel usa o host da API automaticamente quando é servido por ela ou por um servidor estático na mesma máquina. Para outro host, defina `window.WELLSTATE_API_BASE_URL` antes de `js/config.js`.

## 2. Escolher a rede e acompanhar PCs

Por padrão, `Wellstate:Network:Cidr` está em `auto`: a API encontra a interface IPv4 privada da rota principal do servidor e verifica essa sub-rede. O scan fica limitado a 4096 endereços por consulta, usa até 128 verificações simultâneas e guarda o resultado em cache por 8 segundos. O endpoint é apenas para rede local/VPN privada. Sem `iputils-ping` em Linux, a API devolve um erro `503` explicando a dependência.

Para escolher uma sub-rede fixa, edite `backend-csharp/appsettings.json`, por exemplo:

```json
"Network": {
  "Cidr": "192.168.1.0/24",
  "PingTimeoutMs": 350,
  "Parallelism": 128,
  "MaxHosts": 4096,
  "CacheSeconds": 8
}
```

O painel lista automaticamente os equipamentos que respondem ao scan. Para também apresentar um PC desligado, registre-o em `Wellstate:Pcs` com IP reservado/fixo:

```json
"Pcs": [
  { "id": "PC-LAB-01", "name": "Computador do laboratório 1", "ip": "192.168.1.25", "roomId": "C1.01" },
  { "id": "PC-LAB-02", "name": "Computador do laboratório 2", "ip": "192.168.1.26", "roomId": "C1.01" }
]
```

O status do inventário é **online** se o PC responder ao ping ou se o agente Wellstate enviar um heartbeat recente; os dois sinais aparecem separadamente no cartão. Instale o agente Windows para uma confirmação mais confiável quando o firewall bloquear ICMP. Sem um inventário prévio, nenhum scanner consegue saber que endereço corresponde a um PC que está desligado.

## 3. Abrir o painel

Abre `http://IP-DO-SERVIDOR:5080/` ou `http://IP-DO-SERVIDOR:5080/pcs.html`. Não abras os HTML diretamente com `file://`. O painel consulta a API com timeout e nova tentativa automática; uma verificação manual força o scan mesmo quando existe cache.

O stream SSE de `/api/pcs/stream` apresenta a presença do agente. A página de inventário atualiza a cada 15 segundos enquanto está visível.

## 4. Instalar os agentes dos PCs

Consulta [pc-agent/README.md](../pc-agent/README.md). Em cada PC, inicie o agente com o ID cadastrado no backend. O agente envia heartbeats, recebe apenas notificações de texto e confirma a apresentação da mensagem; não executa comandos remotos.

## 5. Arduino IDE e NodeMCU

1. Instale Arduino IDE 2.x e o pacote de placas ESP8266.
2. Instale **DHT sensor library** (Adafruit) e **Adafruit Unified Sensor**.
3. Abra `firmware/Wellstate_Firmware/Wellstate_Firmware.ino` e configure `secrets.h` com SSID/senha de Wi-Fi 2,4 GHz, token, URL da API e ID da sala.
4. Compile e grave com a placa NodeMCU 1.0 selecionada.

## Fora da LAN, dados móveis e segurança

A detecção automática verifica a rede conectada ao **servidor da API**, não a rede do navegador/celular. Em outra rede, use VPN com rota para a instalação central. A API não consegue enumerar PCs arbitrários pela Internet; firewalls, ICMP bloqueado, VLANs e redes convidadas também podem ocultar equipamentos. Não encaminhe diretamente a porta 5080 para a Internet. Se usar HTTPS, publique painel e API por um gateway HTTPS protegido e configure a URL da API para evitar conteúdo misto.

## Resolução de problemas

- `/api/health` com 503: confirme acesso de escrita ao diretório `Data` e verifique os logs do backend.
- Painel sem ligação: confirme endereço/porta, firewall TCP 5080, VPN e que o navegador alcança o host da API.
- Descoberta com 503: o servidor não encontrou uma interface IPv4 privada ativa; conecte-o à LAN ou configure `Wellstate:Network:Cidr`.
- Sub-rede errada: defina o CIDR manualmente, por exemplo `10.10.0.0/24`, e confirme que a API está rodando dentro dessa LAN/VPN.
- PC marcado offline: confirme IP reservado/fixo, firewall ICMP e heartbeat do agente; o agente precisa usar o mesmo `PcId` do inventário.
- Erro 409 ao enviar: o agente não comunicou nos últimos 8 segundos; ligue-o antes de voltar a enviar.
- Erro 401 no sensor: compare `Wellstate__DeviceApiKey` e `WELLSTATE_DEVICE_API_KEY`.
- Sem telemetria: verifique a NodeMCU, sensores, Wi-Fi e ligações elétricas.

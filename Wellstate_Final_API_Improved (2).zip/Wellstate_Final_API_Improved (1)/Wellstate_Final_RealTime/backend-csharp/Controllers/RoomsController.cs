using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Models;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[Route("api/rooms")]
public sealed class RoomsController : ControllerBase
{
    private readonly RoomTelemetryRepository _repository;
    private readonly IConfiguration _configuration;

    public RoomsController(RoomTelemetryRepository repository, IConfiguration configuration)
    {
        _repository = repository;
        _configuration = configuration;
    }

    /// <summary>Retorna a leitura mais recente de cada sala com sensor.</summary>
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<RoomTelemetry>>> GetLatest(CancellationToken cancellationToken)
        => Ok(await _repository.GetLatestAsync(cancellationToken));

    /// <summary>Retorna leituras históricas, da mais recente para a mais antiga.</summary>
    [HttpGet("history")]
    public async Task<ActionResult<IReadOnlyList<RoomTelemetry>>> GetHistory(
        [FromQuery] string? roomId,
        [FromQuery] int limit = 500,
        [FromQuery] DateTimeOffset? from = null,
        [FromQuery] DateTimeOffset? to = null,
        CancellationToken cancellationToken = default)
    {
        if (from.HasValue && to.HasValue && from.Value > to.Value)
            return BadRequest(new { message = "O parâmetro 'from' tem de ser anterior a 'to'." });
        return Ok(await _repository.GetHistoryAsync(roomId, limit, from, to, cancellationToken));
    }

    /// <summary>Recebe uma medição de um dispositivo ESP8266 autenticado.</summary>
    [HttpPost("{roomId}/telemetry")]
    [Consumes("application/json")]
    public async Task<ActionResult<RoomTelemetry>> PostTelemetry(
        string roomId,
        [FromBody] RoomTelemetryRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(roomId) || roomId.Length > 80)
            return BadRequest(new { message = "O identificador da sala deve ter entre 1 e 80 caracteres." });

        var expected = _configuration["Wellstate:DeviceApiKey"];
        if (string.IsNullOrWhiteSpace(expected) || expected.Contains("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
            return Problem(statusCode: StatusCodes.Status503ServiceUnavailable,
                title: "A API ainda não tem uma chave de dispositivo configurada.");

        var provided = Request.Headers["X-Device-Key"].ToString();
        var expectedBytes = Encoding.UTF8.GetBytes(expected);
        var providedBytes = Encoding.UTF8.GetBytes(provided);
        if (providedBytes.Length != expectedBytes.Length || !CryptographicOperations.FixedTimeEquals(providedBytes, expectedBytes))
            return Unauthorized(new { message = "Chave do dispositivo inválida." });

        if (request.Occupied && !request.Motion)
            return BadRequest(new { message = "Uma sala só pode ser marcada como ocupada quando há movimento detetado." });

        var reading = await _repository.AddAsync(roomId.Trim(), request, cancellationToken);
        return Created($"/api/rooms/history?roomId={Uri.EscapeDataString(roomId.Trim())}", reading);
    }
}

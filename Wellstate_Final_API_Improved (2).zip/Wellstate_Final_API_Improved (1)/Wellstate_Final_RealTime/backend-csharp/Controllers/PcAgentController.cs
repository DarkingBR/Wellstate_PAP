using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Models;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[Route("api/pcs/{pcId}/agent")]
public sealed class PcAgentController : ControllerBase
{
    private readonly PcRepository _repository;
    private readonly PcPresenceService _presence;
    private readonly SignalService _signals;

    public PcAgentController(PcRepository repository, PcPresenceService presence, SignalService signals)
    {
        _repository = repository;
        _presence = presence;
        _signals = signals;
    }

    [HttpPost("heartbeat")]
    public async Task<ActionResult> Heartbeat(string pcId, AgentHeartbeatRequest request)
    {
        if (_repository.Find(pcId) is null) return NotFound(new { message = "PC não registado." });
        await _presence.MarkSeenAsync(pcId, request.ComputerName, request.AgentVersion);
        return Ok(new { status = "online", timestamp = DateTimeOffset.UtcNow });
    }

    [HttpGet("signals/next")]
    public async Task<ActionResult<PcSignal>> NextSignal(string pcId, CancellationToken cancellationToken)
    {
        if (_repository.Find(pcId) is null) return NotFound();
        var signal = await _signals.ClaimNextAsync(pcId, cancellationToken);
        return signal is null ? NoContent() : Ok(signal);
    }

    [HttpPost("signals/{signalId}/ack")]
    public async Task<ActionResult<PcSignal>> Acknowledge(string pcId, string signalId,
        SignalAcknowledgementRequest request, CancellationToken cancellationToken)
    {
        var signal = await _signals.AcknowledgeAsync(pcId, signalId, request.Success, request.Details, cancellationToken);
        return signal is null ? NotFound() : Ok(signal);
    }
}

using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[Route("api/health")]
public sealed class HealthController : ControllerBase
{
    private readonly RoomTelemetryRepository _telemetry;
    private readonly SignalRepository _signals;

    public HealthController(RoomTelemetryRepository telemetry, SignalRepository signals)
    {
        _telemetry = telemetry;
        _signals = signals;
    }

    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken cancellationToken)
    {
        try
        {
            await _telemetry.GetLatestAsync(cancellationToken);
            await _signals.CheckAsync(cancellationToken);
            return Ok(new
            {
                service = "Wellstate.API",
                status = "ok",
                database = "ok",
                signalStorage = "sqlite",
                now = DateTimeOffset.UtcNow
            });
        }
        catch (Exception)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                service = "Wellstate.API",
                status = "degraded",
                database = "unavailable",
                now = DateTimeOffset.UtcNow
            });
        }
    }
}

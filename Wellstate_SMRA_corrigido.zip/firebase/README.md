# Firebase · Wellstate SMRA

Projeto: `wellstate-pap`. O app e a placa ESP8266 usam **início de sessão anónimo** e o Firestore.

## Ativar (uma vez, no Console do Firebase)

1. **Authentication → Método de início de sessão → Anónimo → Ativar.**
2. **Firestore → Regras:** cole o conteúdo de `firestore.rules` e carregue em **Publicar**.
3. **Firestore → Dados:** apague os documentos de exemplo vazios das 5 coleções (os que têm texto `""` e números `0`). O app ignora-os, mas ocupam espaço e confundem.
4. Opcional: em **Firestore → TTL**, crie uma política em `telemetry` sobre o campo `recordedAt` para apagar leituras antigas automaticamente.

## O que cada coleção faz

| Coleção | Quem escreve | Quem lê |
|---|---|---|
| `telemetry` | Placa ESP8266 (1 leitura/min por sala) | Salas, Dashboard, Relatórios |
| `schedules` | Página Horários (cada aula é um documento) | Todas as páginas, em tempo real |
| `rooms` | App, no primeiro arranque | — |
| `devices`, `signals` | Ainda API C# | Só leitura |

## Limites e segurança

- Qualquer pessoa com a chave web consegue iniciar sessão anónima. As regras validam o formato e os limites dos dados, mas não identificam utilizadores. Para uso real, passe a Firebase Authentication com conta e/ou ative **App Check**.
- A placa não valida o certificado HTTPS (`setInsecure`). Use em rede de confiança.
- Quota gratuita: 20 000 gravações/dia. Com 1 leitura/min, cada sala usa 1 440/dia.
- Nunca coloque credenciais Admin/service-account no frontend nem neste repositório.

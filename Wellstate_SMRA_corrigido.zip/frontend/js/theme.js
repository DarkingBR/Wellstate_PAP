/* Tema único Wellstate: escuro. Sem alternância nem preferência gravada. */
document.documentElement.setAttribute("data-theme", "dark");
try { localStorage.removeItem("wellstate-theme"); } catch (_) {}

/* Grade semanal: junta tempos seguidos da mesma disciplina/sala num só bloco. */
(function () {
    const anchor = document.querySelector(".schedule-day-panel");
    if (!anchor || !window.WELLSTATE_STORE) return;
    const slots = window.TIME_SLOTS.map(s => s.split(" - "));
    const days = [["Segunda", 1], ["Terça", 2], ["Quarta", 3], ["Quinta", 4], ["Sexta", 5]];
    const base = s => String(s).replace(/\s*T\d$/, "");
    const hue = s => { let h = 0; for (const c of base(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
    const host = document.createElement("section");
    host.className = "panel wk";
    anchor.before(host);

    function blocks(day) {
        const out = [];
        (window.WELLSTATE_STORE.schedule[day] || [])
            .map(l => ({ ...l, a: slots.findIndex(s => s[0] === l.start), b: slots.findIndex(s => s[1] === l.end) }))
            .filter(l => l.a >= 0 && l.b >= l.a).sort((x, y) => x.a - y.a)
            .forEach(l => {
                const p = out[out.length - 1];
                if (p && p.b + 1 === l.a && p.room === l.room && base(p.subject) === base(l.subject)) {
                    p.b = l.b; if (!p.labels.includes(l.subject)) p.labels.push(l.subject);
                } else out.push({ ...l, labels: [l.subject] });
            });
        return out;
    }

    function render() {
        const now = window.WellstateClock.parts();
        const cur = slots.findIndex(s => s[0].replace(":", "") * 1 <= (Math.floor(now.minuteOfDay / 60) * 100 + now.minuteOfDay % 60) && (Math.floor(now.minuteOfDay / 60) * 100 + now.minuteOfDay % 60) < s[1].replace(":", "") * 1);
        let h = '<div class="wk-grid" role="table" aria-label="Horário semanal"><div class="wk-h wk-corner">Tempo</div>';
        days.forEach(([n, d]) => h += `<div class="wk-h${d === now.day ? " is-today" : ""}" style="grid-column:${d + 1}">${n}</div>`);
        slots.forEach((s, i) => {
            h += `<div class="wk-t${i === cur ? " is-now" : ""}" style="grid-row:${i + 2}"><b>${s[0]}</b><span>${s[1]}</span></div>`;
            days.forEach(([, d]) => h += `<div class="wk-e${d === now.day ? " is-today" : ""}" style="grid-row:${i + 2};grid-column:${d + 1}"></div>`);
        });
        days.forEach(([, d]) => blocks(d).forEach(b => {
            const live = d === now.day && cur >= b.a && cur <= b.b;
            h += `<button type="button" class="wk-b${live ? " is-live" : ""}" data-day="${d}" data-room="${b.room}" style="--h:${hue(b.subject)};grid-column:${d + 1};grid-row:${b.a + 2}/${b.b + 3}"><span class="wk-s">${b.labels.join("<br>")}</span><em>${b.room}</em></button>`;
        }));
        host.innerHTML = h + "</div>";
    }

    host.addEventListener("click", e => {
        const b = e.target.closest(".wk-b");
        if (!b) return;
        document.querySelectorAll("#dayTabs .day-tab")[Number(b.dataset.day) - 1]?.click();
        const first = document.querySelector(".lesson-edit");
        anchor.scrollIntoView({ behavior: "smooth", block: "start" });
        first?.focus({ preventScroll: true });
    });
    window.addEventListener("wellstate:store-updated", render);
    setInterval(() => { if (!document.hidden) render(); }, 30000);
    render();
})();

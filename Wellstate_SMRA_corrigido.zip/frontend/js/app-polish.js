/* Instalador em etapas (janela própria) + feedback de clique. */
(function () {
    const KEY = "wellstate-install-state";
    const standalone = matchMedia("(display-mode: standalone)").matches || navigator.standalone;
    const read = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
    const write = v => { try { localStorage.setItem(KEY, v); } catch { /* sem armazenamento */ } };
    let deferred = null, win = null, step = 0, cached = false, prefs = { notify: true, offline: true };
    addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferred = e; });
    addEventListener("appinstalled", () => write("done"));

    /* Efeito de toque nos botões */
    document.addEventListener("pointerdown", e => {
        const t = e.target.closest("button, .btn-primary, .btn-ghost, .nav-link, .day-tab");
        if (!t || t.disabled) return;
        const r = t.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2, s = document.createElement("span");
        s.className = "rip"; s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
        if (getComputedStyle(t).position === "static") t.style.position = "relative";
        t.classList.add("has-rip"); t.appendChild(s); setTimeout(() => s.remove(), 600);
    }, { passive: true });

    const ua = navigator.userAgent, ios = /iPad|iPhone|iPod/.test(ua), safari = /^((?!chrome|android).)*safari/i.test(ua);
    const checks = () => [
        ["Ligação segura", location.protocol === "https:" || ["localhost", "127.0.0.1"].includes(location.hostname)],
        ["Service worker", "serviceWorker" in navigator],
        ["Armazenamento local", (() => { try { localStorage.setItem("_t", 1); localStorage.removeItem("_t"); return true; } catch { return false; } })()],
        ["Navegador compatível", Boolean(deferred) || ios || safari || "BeforeInstallPromptEvent" in window]
    ];
    const FILES = ["dashboard.html", "rooms.html", "schedule.html", "pcs.html", "history.html", "admin.html", "manifest.webmanifest", "css/style.css", "css/dashboard.css", "css/professional.css", "css/reference-ui.css", "css/portal-blue.css", "css/wellstate-overhaul.css", "css/schedule.css", "css/app-polish.css", "js/config.js", "js/data-store.js", "js/app-shell.js", "js/schedule.js", "js/schedule-grid.js", "js/app-polish.js", "assets/wellstate-smra-logo.png", "assets/icon-192.png"];

    const titles = ["Bem-vindo", "Verificação", "Preferências", "Transferência", "Concluído"];
    const body = [
        () => `<img class="ins-logo" src="assets/icon-192.png" alt=""><h2>Instalar o Wellstate SMRA</h2><p>Abre em janela própria, sem barra do navegador, com ícone no ambiente de trabalho e arranque rápido. A instalação demora menos de um minuto.</p><ul class="ins-list"><li>Janela dedicada e atalhos para Salas e Dispositivos</li><li>Páginas e estilos guardados para abrir mais depressa</li><li>Sem mexer em ficheiros nem em definições do sistema</li></ul>`,
        () => `<h2>A verificar o seu dispositivo</h2><p>Estes requisitos garantem que a instalação corre sem surpresas.</p><ul class="ins-checks">${checks().map(([n, ok]) => `<li class="${ok ? "ok" : "no"}"><i class="fa-solid ${ok ? "fa-circle-check" : "fa-triangle-exclamation"}"></i>${n}</li>`).join("")}</ul>${checks().some(c => !c[1]) ? '<p class="ins-warn">Algum requisito falhou. Abra o endereço em localhost ou HTTPS e tente de novo.</p>' : ""}`,
        () => `<h2>Preferências</h2><p>Pode alterar tudo depois em Definições.</p><label class="ins-opt"><input type="checkbox" data-pref="offline" ${prefs.offline ? "checked" : ""}><span><b>Guardar ficheiros no dispositivo</b><small>O app abre mais depressa e mostra o ecrã de erro quando não houver rede.</small></span></label><label class="ins-opt"><input type="checkbox" data-pref="notify" ${prefs.notify ? "checked" : ""}><span><b>Avisos de alertas e aulas</b><small>Mostra notificações quando uma sala precisa de atenção.</small></span></label>`,
        () => `<h2>A transferir</h2><p id="insMsg">A preparar ficheiros…</p><div class="ins-bar"><i id="insFill"></i></div><div class="ins-pct" id="insPct">0%</div>`,
        () => `<div class="ins-done"><i class="fa-solid fa-check"></i></div><h2>Tudo pronto</h2><p id="insEnd">${deferred ? "Confirme a janela de instalação do navegador para criar o ícone." : ios ? "No Safari, toque em Partilhar e escolha “Adicionar ao ecrã principal”." : "Use o ícone de instalar na barra de endereço ou o menu do navegador, em “Instalar app”."}</p>`
    ];

    async function download() {
        const msg = document.getElementById("insMsg"), fill = document.getElementById("insFill"), pct = document.getElementById("insPct");
        const list = prefs.offline && "caches" in window ? FILES : [];
        const cache = list.length ? await caches.open("wellstate-offline-v1") : null;
        let n = 0;
        for (const f of (list.length ? list : ["·"])) {
            msg.textContent = list.length ? `A guardar ${f}` : "A concluir…";
            if (cache) { try { await cache.add(f); } catch { /* ficheiro opcional */ } }
            n++; const p = Math.round(n / (list.length || 1) * 100);
            fill.style.width = p + "%"; pct.textContent = p + "%";
            await new Promise(r => setTimeout(r, 45));
        }
        if (prefs.notify && "Notification" in window && Notification.permission === "default") { try { await Notification.requestPermission(); } catch { /* ignorado */ } }
        cached = true; paint();
        setTimeout(() => step === 3 && go(1), 450);
    }

    function paint() {
        if (!win) return;
        win.querySelector(".ins-body").innerHTML = body[step]();
        win.querySelector(".ins-title").textContent = `Instalador · ${titles[step]}`;
        win.querySelectorAll(".ins-dots i").forEach((d, i) => d.className = i < step ? "past" : i === step ? "now" : "");
        const back = win.querySelector("[data-back]"), next = win.querySelector("[data-next]");
        back.hidden = step === 0 || step >= 3;
        next.hidden = false; next.disabled = false;
        next.textContent = ["Começar", "Continuar", "Iniciar instalação", "A transferir…", deferred ? "Instalar agora" : "Fechar"][step];
        if (step === 1 && checks().some(c => !c[1])) next.disabled = true;
        if (step === 3) next.disabled = true;
        next.focus();
    }
    async function go(d) {
        if (step === 4 && d > 0) { if (deferred) { deferred.prompt(); const r = await deferred.userChoice; deferred = null; if (r.outcome === "accepted") write("done"); } return close(); }
        step = Math.max(0, Math.min(4, step + d));
        paint();
        if (step === 3) download();
    }
    function close() {
        if (!win) return;
        if (read() !== "done") write("seen");
        win.classList.add("out"); const w = win; win = null;
        setTimeout(() => w.remove(), 260);
        document.body.classList.remove("ins-open");
    }
    function open() {
        if (win || standalone) return;
        step = 0;
        win = document.createElement("div");
        win.className = "ins-scrim";
        win.innerHTML = `<div class="ins-win" role="dialog" aria-modal="true" aria-label="Instalador"><div class="ins-bar-top"><span class="ins-title"></span><button type="button" class="ins-x" data-close aria-label="Fechar"><i class="fa-solid fa-xmark"></i></button></div><div class="ins-body"></div><div class="ins-foot"><div class="ins-dots"><i></i><i></i><i></i><i></i><i></i></div><button type="button" class="btn-ghost" data-back>Voltar</button><button type="button" class="btn-primary" data-next></button></div></div>`;
        win.addEventListener("click", e => {
            if (e.target.closest("[data-close]") || e.target === win) close();
            else if (e.target.closest("[data-back]")) go(-1);
            else if (e.target.closest("[data-next]")) go(1);
        });
        win.addEventListener("change", e => { if (e.target.dataset.pref) prefs[e.target.dataset.pref] = e.target.checked; });
        win.addEventListener("keydown", e => { if (e.key === "Escape") close(); });
        document.body.append(win); document.body.classList.add("ins-open"); paint();
    }
    window.WellstateInstaller = { open };

    addEventListener("DOMContentLoaded", () => {
        if (standalone) return;
        const foot = document.querySelector(".side-foot");
        if (foot) {
            const b = document.createElement("button");
            b.type = "button"; b.className = "side-install"; b.innerHTML = '<i class="fa-solid fa-download"></i><span>Instalar app</span>';
            b.addEventListener("click", open); foot.prepend(b);
        }
        if (!read() && /dashboard\.html$|\/$/.test(location.pathname)) setTimeout(open, 1400);
    });
})();

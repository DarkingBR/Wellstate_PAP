/* Cliente REST único: retries exponenciais apenas em leituras seguras (GET). */
import { fb } from "./firebase-client.js";

const CFG = window.WELLSTATE_CONFIG;
const API_ROOT = String(CFG.API_BASE_URL || "").replace(/\/+$/, "");

function emitApiStatus(online, path, error) {
    window.dispatchEvent(new CustomEvent("wellstate:api-status", {
        detail: { online, path, error: error || null, at: Date.now() }
    }));
}

async function request(path, options = {}) {
    const method = String(options.method || "GET").toUpperCase();
    const retries = method === "GET" ? Math.max(0, CFG.API_RETRIES ?? 2) : 0;
    const timeoutMs = path.startsWith("/network/devices") ? (CFG.NETWORK_TIMEOUT_MS ?? 45000) : (CFG.API_TIMEOUT_MS ?? 15000);
    let lastError;

    for (let attempt = 0; attempt <= retries; attempt++) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        try {
            const response = await fetch(`${API_ROOT}${path}`, {
                ...options,
                method,
                cache: "no-store",
                credentials: CFG.API_CREDENTIALS || "same-origin",
                headers: { Accept: "application/json", ...(options.headers || {}) },
                signal: controller.signal
            });
            if (!response.ok) {
                let message = `A API respondeu HTTP ${response.status}.`;
                try {
                    const body = await response.json();
                    message = body.message || body.title || body.detail || message;
                } catch { /* resposta sem JSON */ }
                const error = new Error(message);
                error.status = response.status;
                error.proxyUnavailable = response.headers.get("X-Wellstate-Proxy-Error") === "unavailable";
                if (response.status < 500 || attempt === retries) {
                    emitApiStatus(!error.proxyUnavailable, path, error.proxyUnavailable ? message : null);
                    throw error;
                }
                lastError = error;
            } else {
                emitApiStatus(true, path);
                if (response.status === 204) return null;
                if (!(response.headers.get("content-type") || "").includes("json")) throw new Error("A API respondeu, mas o conteúdo não está em formato JSON.");
                return await response.json();
            }
        } catch (error) {
            lastError = error.name === "AbortError"
                ? new Error(`A API excedeu o tempo limite de ${Math.round(timeoutMs / 1000)} s. Verifica se o backend está ligado e se o servidor e o telemóvel estão na mesma rede.`)
                : error.name === "TypeError"
                    ? new Error(`Não foi possível alcançar ${API_ROOT}. Confirma o backend C# na porta 5080, o proxy /api e a rede/firewall.`)
                    : error;
            if (error.status && error.status < 500) throw error;
            if (attempt === retries) {
                emitApiStatus(false, path, lastError?.message || "Sem resposta da API.");
                throw lastError;
            }
        } finally {
            clearTimeout(timeout);
        }

        await new Promise(resolve => setTimeout(resolve, Math.min(4000, 350 * (2 ** attempt)) + Math.floor(Math.random() * 160)));
    }

    throw lastError || new Error("Não foi possível ligar à API.");
}

const within = (promise, ms) => Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error("tempo esgotado")), ms))]);

/* Firebase é a fonte principal; a API C# complementa e serve de reserva. */
async function latestRooms() {
    const [cloud, rest] = await Promise.allSettled([within(fb.latestRooms(), 9000), within(request("/rooms"), 2500)]);
    if (cloud.status === "rejected" && rest.status === "rejected") throw rest.reason;
    const merged = new Map();
    [...(rest.value || []), ...(cloud.value || [])].forEach(reading => {
        const previous = merged.get(reading.roomId);
        if (!previous || new Date(reading.updatedAt) > new Date(previous.updatedAt)) merged.set(reading.roomId, reading);
    });
    return [...merged.values()];
}

async function history(options) {
    try {
        const rows = await within(fb.history(options), 12000);
        if (rows.length) return rows;
    } catch { /* usa a API C# */ }
    return request(`/rooms/history?${historyParams(options)}`);
}

function historyParams({ roomId, limit = 2000, from, to } = {}) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (roomId) params.set("roomId", roomId);
    if (from) params.set("from", new Date(from).toISOString());
    if (to) params.set("to", new Date(to).toISOString());
    return params.toString();
}

export const apiClient = Object.freeze({
    get: path => request(path),
    getLatestRooms: latestRooms,
    getPcs: () => request("/pcs"),
    getNetworkDevices: ({ refresh = false, cidr = "" } = {}) => {
        const params = new URLSearchParams();
        if (refresh) params.set("refresh", "true");
        if (cidr.trim()) params.set("cidr", cidr.trim());
        const query = params.toString();
        return request(`/network/devices${query ? `?${query}` : ""}`);
    },
    getHistory: history,
    getHealth: () => request("/health")
});

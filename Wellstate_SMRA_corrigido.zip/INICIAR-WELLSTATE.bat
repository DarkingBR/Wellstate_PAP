@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul || (echo ERRO: Instale o .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0 & pause & exit /b 1)
where php >nul 2>nul || (echo ERRO: Instale PHP 8.1+ com PDO_SQLite e adicione-o ao PATH. & pause & exit /b 1)
if not exist "server\data" mkdir "server\data"
start "Wellstate API" /D "%~dp0backend-csharp" cmd /k dotnet run --urls http://0.0.0.0:5080
timeout /t 4 /nobreak >nul
start "Wellstate Portal" /D "%~dp0" cmd /k php -S 0.0.0.0:8080 -t . server/router.php
timeout /t 2 /nobreak >nul
start "" http://localhost:8080/register
echo Wellstate iniciado. Registe a primeira conta; depois use http://localhost:8080/login.
echo Deixe as duas janelas do servidor abertas enquanto usar o sistema.

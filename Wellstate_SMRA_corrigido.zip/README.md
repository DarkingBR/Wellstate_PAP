# Wellstate SMRA

Portal PWA de monitorização ambiental e de equipamentos, com frontend web, API REST em .NET 8, persistência SQLite, autenticação PHP e firmware ESP8266.

## Começar

- **Arranque de um clique:** execute `INICIAR-WELLSTATE.bat` no Windows ou `./iniciar-wellstate.sh` no Linux/macOS.
- **Guia completo:** [EXECUTAR.md](EXECUTAR.md) — requisitos, arranque automático, VS Code, Arduino IDE, Firebase e solução de problemas.
- **Persistência:** [docs/DATABASE.md](docs/DATABASE.md).
- **Firestore:** [firebase/README.md](firebase/README.md) e [docs/FIREBASE.md](docs/FIREBASE.md).

Requisitos: .NET 8 SDK e PHP 8.1+ com PDO_SQLite. O portal abre em `http://localhost:8080`; a saúde da API em `http://localhost:5080/api/health`. Não abra os HTML com duplo clique ou Live Server: estes não iniciam autenticação e API.

## Bases de dados

SQLite é a base **SQL** local usada por defeito (`server/data/users.sqlite` e `backend-csharp/Data/wellstate.db`). Firebase Firestore é **NoSQL**, não SQL. O firmware envia telemetria à API C#, que grava em SQLite. O frontend pode usar Firestore quando Authentication e as regras do projeto estiverem configuradas; não existe sincronização SQL↔Firestore automática.

## Estrutura organizada

- `frontend/` — PWA, páginas, scripts e stylesheet consolidado `css/wellstate.css`.
- `backend-csharp/` — API REST, telemetria e descoberta de rede.
- `server/` — portal PHP, autenticação e proxy same-origin.
- `firmware/Wellstate_Firmware/` — firmware ESP8266; copie `secrets.example.h` para `secrets.h` antes de compilar.
- `firebase/` — regras e índices Firestore.
- `.vscode/tasks.json` — tarefas para iniciar portal e API no VS Code.

Não partilhe `secrets.h`, bases locais, palavras-passe ou chaves reais. Para produção, use hosting e HTTPS com os controlos de segurança apropriados.

# Executar o Wellstate SMRA

## Arranque automático (sem Live Server)

O portal não deve ser aberto com duplo clique no HTML nem com Live Server: usa módulos JavaScript, autenticação PHP, SQLite, a API C# e o service worker. O Live Server só serve ficheiros estáticos e não inicia estes serviços.

1. Instale **.NET 8 SDK**, **PHP 8.1+ com PDO_SQLite** e um navegador moderno. Confirme que `dotnet` e `php` estão no `PATH`.
2. Descompacte a pasta toda num caminho local. No Windows, execute `INICIAR-WELLSTATE.bat`; no Linux/macOS, execute `./iniciar-wellstate.sh`.
3. O iniciador arranca a API C# (porta 5080) e o portal PHP (porta 8080), abre o registo inicial e mantém os serviços em execução. Registe a primeira conta e entre.
4. Para terminar, feche as janelas de terminal iniciadas (Windows) ou prima `Ctrl+C` (Linux/macOS).

**Endereços locais:** portal `http://localhost:8080`; registo inicial `http://localhost:8080/register`; saúde da API `http://localhost:5080/api/health`.

Se preferir executar manualmente, abra dois terminais na pasta do projeto:

```bash
cd backend-csharp
dotnet run --urls http://0.0.0.0:5080
```

```bash
php -S 0.0.0.0:8080 -t . server/router.php
```

O PHP e o .NET têm de permanecer ativos durante a utilização. Para iniciar automaticamente ao iniciar o computador, configure o iniciador no **Agendador de Tarefas do Windows** ou em **Aplicações de início de sessão** do Linux/macOS. Não se deve expor as portas 5080/8080 à Internet.

## VS Code: executar e depurar

Abra a pasta descompactada inteira no VS Code. O projeto contém tarefas em `.vscode/tasks.json` para arrancar o portal e a API; execute **Terminal → Run Task → Wellstate: iniciar tudo**. Instale a extensão C# Dev Kit para depurar a API, se necessário. Não abra apenas `frontend/` como workspace: as rotas, dados e scripts esperam a raiz do projeto.

A API REST é a integração entre frontend, sensores e backend. O navegador chama `/api` através do portal; a configuração em `frontend/js/config.js` resolve a API local automaticamente. O endpoint de teste é `GET /api/health`.

## Arduino IDE: ligar o ESP8266

1. Instale Arduino IDE 2.x e o suporte de placas **ESP8266** (Boards Manager). Instale a biblioteca **DHT sensor library by Adafruit** e a dependência **Adafruit Unified Sensor**.
2. Copie `firmware/Wellstate_Firmware/secrets.example.h` para `firmware/Wellstate_Firmware/secrets.h`.
3. Edite apenas a cópia local: Wi-Fi 2,4 GHz, IP reservado do computador servidor, sala e uma chave aleatória. Configure a mesma chave no servidor como `Wellstate__DeviceApiKey`.
4. Abra `firmware/Wellstate_Firmware/Wellstate_Firmware.ino`, escolha a placa ESP8266/NodeMCU e a porta USB e carregue o firmware.
5. O ESP8266 envia telemetria à API C# em `http://IP-DO-SERVIDOR:5080/api/rooms/{sala}/telemetry`. Permita essa porta na firewall apenas para a rede local. O navegador/IDE não precisa de credenciais de serviço Firebase.

Não partilhe `secrets.h`; este contém credenciais Wi-Fi e a chave do dispositivo. O arquivo de exemplo tem valores fictícios e não conecta até ser configurado.

## Firebase e bases de dados: não são a mesma coisa

- **SQLite é SQL** e é a persistência instalada por defeito: o portal usa `server/data/users.sqlite`; a API usa `backend-csharp/Data/wellstate.db`.
- **Firebase Firestore é NoSQL**, não é SQL. A configuração web no projeto é pública por desenho; as regras e a autenticação definem acesso. O frontend tenta Firestore para telemetria/horários e mantém a API/armazenamento local como caminho alternativo. O firmware envia à API C#; o backend persiste em SQLite.
- Não existe uma ligação SQL automática a Firebase. Para replicar SQL e Firestore em simultâneo é necessário implementar e operar sincronização/migração no servidor; este pacote não promete isso.
- A ligação Firestore requer rede e as opções de Authentication/Firestore configuradas em Firebase. Consulte `firebase/README.md` e `docs/FIREBASE.md`. Nenhuma chave de conta de serviço Firebase é necessária no browser ou firmware.

## Rede local e resolução de problemas

- A API responde em `http://localhost:5080/api/health`. Se não responder, verifique se o .NET 8 está instalado e se a porta 5080 está livre.
- O portal deve responder em `http://localhost:8080/login`. Se falhar, confirme PHP e a extensão PDO_SQLite.
- Para outro dispositivo na mesma rede, substitua `localhost` pelo IP local do servidor e autorize as portas 8080 (portal) e 5080 (API/sensor) na firewall privada.
- Configure `Wellstate__DeviceApiKey` e `Wellstate__AgentApiKey` como variáveis de ambiente antes de usar sensores/agentes reais. Não use o valor de exemplo `CHANGE_ME`.
- O `php -S` é servidor local de desenvolvimento, não servidor de produção. Para acesso público use hosting Apache/Nginx + PHP-FPM e HTTPS, com autenticação e controles de acesso apropriados.

# Dados e persistência · Wellstate

| Dados | Localização | Persistência |
|---|---|---|
| Utilizadores e palavras-passe protegidas | `server/data/users.sqlite` | SQLite criado pelo PHP; palavra-passe armazenada apenas como hash |
| Medições ambientais | `backend-csharp/Data/wellstate.db` | SQLite, tabelas/indexes, WAL e retenção de 90 dias |
| Sinais de PCs | `backend-csharp/Data/wellstate.db` | Tabela SQLite `pc_signals` |
| Estado temporário de agentes | Memória do backend C# | Reiniciar a API reinicia a presença, não o histórico persistido |
| Salas, computadores configurados, horário e preferências | `localStorage` (`wellstate-store`) | Local ao browser atual; não sincroniza entre utilizadores/dispositivos |
| Firestore | Ativo quando projeto/regras/Auth estão habilitados | Frontend lê telemetria e mantém horários/salas; firmware ESP8266 também grava telemetria diretamente |

## SQLite

O módulo PHP cria `server/data/users.sqlite` ao registar a primeira conta. A API C# cria `backend-csharp/Data/wellstate.db` ao iniciar e gerir telemetria/sinais. Ambas as bases são locais e separadas por responsabilidade.

- O registo usa consultas PDO parametrizadas, índice/constraint de unicidade para e-mail e `password_hash`/`password_verify`.
- Telemetria e sinais usam transações, modo WAL, índices e timestamps UTC.
- As medições com mais de 90 dias são limpas pelo backend; consulte os serviços em `backend-csharp/Services/`.
- Faça cópias de segurança com a aplicação parada ou usando o mecanismo de backup SQLite. Inclua os ficheiros `-wal`/`-shm` apenas segundo procedimento consistente.

## Firestore versus SQL

Firestore é NoSQL, com coleções/documentos; não é uma base SQL. A aplicação mantém **dois destinos separados**: a API C# grava telemetria/sinais no SQLite; o frontend pode consultar Firestore e o ESP8266 publica telemetria no Firestore usando autenticação anónima. Firestore exige que o projeto `wellstate-pap` exista, Authentication Anónimo esteja habilitado e as regras em `firebase/firestore.rules` estejam publicadas. O frontend não sincroniza automaticamente todo o SQLite com Firestore, nem a API C# usa Firebase Admin SDK. Não coloque credenciais de service account no browser ou firmware.

## Segurança

O login protege as páginas servidas pelo portal PHP. A API C# e os endpoints de leitura continuam independentes da sessão de utilizador para permitir a integração de sensores e agentes. Restrinja a porta 5080 à LAN/VPN e use as chaves de serviço previstas em `appsettings.json`/variáveis de ambiente. Não exponha a API diretamente à Internet.

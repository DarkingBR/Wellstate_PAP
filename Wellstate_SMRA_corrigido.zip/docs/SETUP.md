# Configuração rápida

O guia completo de instalação, execução automática, VS Code, Arduino IDE, rede e diagnóstico está em [`../EXECUTAR.md`](../EXECUTAR.md).

## Dependências

- .NET 8 SDK.
- PHP 8.1 ou superior com extensões `PDO` e `PDO_SQLite`.
- Para o firmware: Arduino IDE 2.x, suporte ESP8266, DHT sensor library by Adafruit e Adafruit Unified Sensor.

## Arranque local

No Windows execute `INICIAR-WELLSTATE.bat`; no Linux/macOS execute `./iniciar-wellstate.sh`. O portal fica em `http://localhost:8080`, API em `http://localhost:5080/api/health`. Não use `file://` ou Live Server como servidor da aplicação.

## Persistência e Firebase

SQLite é SQL e guarda utilizadores/telemetria localmente. Firestore é NoSQL: o browser e o firmware podem usá-lo quando Authentication Anónimo, Firestore e as regras publicadas estiverem configurados. Não há sincronização geral automática entre SQLite e Firestore. Detalhes em [`DATABASE.md`](DATABASE.md), [`FIREBASE.md`](FIREBASE.md) e [`../firebase/README.md`](../firebase/README.md).

## Firmware

Copie `firmware/Wellstate_Firmware/secrets.example.h` para `secrets.h`, configure Wi-Fi, IP do servidor e a chave de dispositivo correspondente a `Wellstate__DeviceApiKey`. Mantenha o ficheiro com segredos privado; consulte [`../EXECUTAR.md`](../EXECUTAR.md).

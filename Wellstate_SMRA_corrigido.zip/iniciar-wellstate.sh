#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
command -v dotnet >/dev/null || { echo 'Instale o .NET 8 SDK.'; exit 1; }
command -v php >/dev/null || { echo 'Instale PHP 8.1+ com PDO_SQLite.'; exit 1; }
mkdir -p "$ROOT/server/data"
(cd "$ROOT/backend-csharp" && dotnet run --urls http://0.0.0.0:5080) & API_PID=$!
(cd "$ROOT" && php -S 0.0.0.0:8080 -t . server/router.php) & PHP_PID=$!
cleanup(){ kill "$API_PID" "$PHP_PID" 2>/dev/null || true; }
trap cleanup INT TERM EXIT
sleep 4
URL='http://localhost:8080/register'
if command -v xdg-open >/dev/null; then xdg-open "$URL" >/dev/null 2>&1 || true; elif command -v open >/dev/null; then open "$URL"; fi
echo "Wellstate ativo: $URL (Ctrl+C encerra os serviços)."
wait

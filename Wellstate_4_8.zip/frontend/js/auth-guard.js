/* Protege as páginas do painel: sem sessão PHP, vai para o login. */
(function () {
    document.documentElement.style.visibility = "hidden";
    fetch("php/me.php", { credentials: "same-origin", cache: "no-store" })
        .then(r => (r.ok ? r.json() : Promise.reject()))
        .then(({ user }) => {
            document.documentElement.style.visibility = "";
            window.addEventListener("load", () => {
                const name = document.getElementById("userName");
                if (name) name.textContent = user.name;
                const avatar = document.getElementById("userAvatar");
                if (avatar) avatar.textContent = String(user.name || "W").trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase();
                const footer = document.querySelector(".sidebar-footer");
                if (!footer) return;
                const out = document.createElement("button");
                out.className = "footer-btn logout";
                out.innerHTML = '<i class="fa-solid fa-right-from-bracket"></i><span>Terminar sessão</span>';
                out.addEventListener("click", async () => {
                    await fetch("php/logout.php", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: "{}" }).catch(() => {});
                    window.location.replace("login.html");
                });
                (footer.querySelector(".footer-actions") || footer).appendChild(out);
                setTimeout(() => { if (name) name.textContent = user.name; }, 0);
            });
        })
        .catch(() => window.location.replace("login.html"));
})();

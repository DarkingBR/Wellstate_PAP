/* Wellstate · efeitos do login/registo: relógio, constelação das salas, parallax e aviso de Caps Lock. */
(function () {
    "use strict";
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var ZONE = "Europe/Lisbon";

    /* ---------- Relógio e saudação ---------- */
    var clock = document.getElementById("authClock");
    var greet = document.getElementById("authGreet");
    var dateEl = document.getElementById("authDate");
    function tick() {
        var now = new Date();
        var hm = new Intl.DateTimeFormat("pt-PT", { timeZone: ZONE, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(now);
        var hour = parseInt(new Intl.DateTimeFormat("en-GB", { timeZone: ZONE, hour: "2-digit", hourCycle: "h23" }).format(now), 10);
        var date = new Intl.DateTimeFormat("pt-PT", { timeZone: ZONE, weekday: "long", day: "numeric", month: "long" }).format(now);
        if (clock) clock.textContent = hm;
        if (greet) greet.textContent = hour < 6 ? "Boa madrugada" : hour < 12 ? "Bom dia" : hour < 20 ? "Boa tarde" : "Boa noite";
        if (dateEl) dateEl.textContent = date.charAt(0).toUpperCase() + date.slice(1);
    }
    tick();
    setInterval(tick, 15000);

    /* ---------- Constelação: cada sala é uma estrela ---------- */
    var svg = document.getElementById("constellation");
    if (svg) {
        var nodes = Array.prototype.slice.call(svg.querySelectorAll(".node"));
        var text = document.getElementById("constText");
        var count = document.getElementById("constCount");
        var initial = { "C1.01": true, "B1.02": true };
        nodes.forEach(function (n) { if (initial[n.dataset.room]) n.classList.add("occ"); });

        function refreshCount() {
            var occ = svg.querySelectorAll(".node.occ").length;
            if (count) count.textContent = occ + " de " + nodes.length + " ocupadas";
        }
        function say(node, occupied) {
            if (!text) return;
            text.classList.remove("swap"); void text.offsetWidth;
            text.textContent = node.dataset.name + (occupied ? " ficou ocupada" : " ficou livre");
            text.classList.add("swap");
        }
        refreshCount();
        if (text) text.textContent = "Salas a mudar de estado em tempo real";

        if (!reduce) {
            setInterval(function () {
                var n = nodes[Math.floor(Math.random() * nodes.length)];
                var occ = svg.querySelectorAll(".node.occ").length;
                var willBeOcc = !n.classList.contains("occ");
                if (willBeOcc && occ >= 3) return;          // mantém o céu equilibrado
                if (!willBeOcc && occ <= 1) return;
                n.classList.toggle("occ", willBeOcc);
                say(n, willBeOcc); refreshCount();
            }, 2600);
        }
        nodes.forEach(function (n) {
            n.addEventListener("mouseenter", function () {
                if (!text) return;
                text.classList.remove("swap"); void text.offsetWidth;
                text.textContent = n.dataset.name + (n.classList.contains("occ") ? " · ocupada" : " · livre");
                text.classList.add("swap");
            });
        });
    }

    /* ---------- Parallax suave do campo de estrelas ---------- */
    var stars = document.querySelector(".auth-stars");
    var panel = document.querySelector(".auth-brand");
    if (stars && panel && !reduce && window.matchMedia("(hover: hover)").matches) {
        var tx = 0, ty = 0, cx = 0, cy = 0, raf = 0;
        function loop() {
            cx += (tx - cx) * 0.06; cy += (ty - cy) * 0.06;
            stars.style.transform = "translate3d(" + cx.toFixed(2) + "px," + cy.toFixed(2) + "px,0) scale(1.06)";
            raf = (Math.abs(tx - cx) > .05 || Math.abs(ty - cy) > .05) ? requestAnimationFrame(loop) : 0;
        }
        document.addEventListener("mousemove", function (e) {
            tx = (e.clientX / window.innerWidth - .5) * -26;
            ty = (e.clientY / window.innerHeight - .5) * -26;
            if (!raf) raf = requestAnimationFrame(loop);
        });
    }

    /* ---------- Aviso de Caps Lock ---------- */
    var pass = document.getElementById("password");
    var caps = document.getElementById("capsHint");
    if (pass && caps) {
        var check = function (e) { if (e.getModifierState) caps.hidden = !e.getModifierState("CapsLock"); };
        pass.addEventListener("keydown", check);
        pass.addEventListener("keyup", check);
        pass.addEventListener("blur", function () { caps.hidden = true; });
    }
})();

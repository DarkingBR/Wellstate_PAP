<?php
declare(strict_types=1);
/* Wellstate · descoberta de dispositivos na LAN (sem dependências externas).
   1) Varre a sub-rede privada do servidor com ping em paralelo; 2) lê a tabela ARP (MAC);
   3) testa portas TCP típicas; 4) identifica fabricante (OUI) e classifica o tipo de dispositivo.
   Só aparece quem está realmente a responder: quem se desliga desaparece no scan seguinte. */

if (!function_exists('mb_strlen')) { function mb_strlen($s, $e = null) { return (int)preg_match_all('/./us', (string)$s); } }
if (!function_exists('mb_substr')) { function mb_substr($s, $st, $len = null, $e = null) { preg_match_all('/./us', (string)$s, $m); return implode('', array_slice($m[0], $st, $len)); } }

const WS_SCAN_TTL = 8;            // segundos de cache entre scans (a página pede de 20 em 20 s)
const WS_NAME_TTL = 1800;         // validade dos nomes de host em cache
const WS_PORT_TTL = 300;          // validade dos resultados de portas em cache
const WS_PORTS = [135, 139, 445, 3389, 22, 80, 443, 62078, 5555, 9100, 515, 631, 8009, 8008, 548, 5353];

function ws_is_windows(): bool { return stripos(PHP_OS_FAMILY, 'Windows') === 0; }
function ws_can_exec(): bool { return function_exists('proc_open') && !in_array('proc_open', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true); }
function ws_data_dir(): string { $d = dirname(__DIR__, 2) . '/data'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }

/* ---------- Execução paralela de comandos ---------- */
/** @param array<string,array> $cmds chave => argv. Devolve chave => stdout. */
function ws_run_parallel(array $cmds, int $concurrency = 48, float $timeout = 4.0): array
{
    $results = []; $running = []; $queue = array_keys($cmds); $deadline = microtime(true) + $timeout;
    while ($queue || $running) {
        while ($queue && count($running) < $concurrency) {
            $key = array_shift($queue);
            $proc = @proc_open($cmds[$key], [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, null, null, ['bypass_shell' => true]);
            if (!is_resource($proc)) { $results[$key] = ''; continue; }
            stream_set_blocking($pipes[1], false); stream_set_blocking($pipes[2], false);
            $running[$key] = ['p' => $proc, 'pipes' => $pipes, 'out' => '', 'start' => microtime(true)];
        }
        foreach ($running as $key => &$r) {
            $r['out'] .= (string)stream_get_contents($r['pipes'][1]);
            @stream_get_contents($r['pipes'][2]);
            $st = proc_get_status($r['p']);
            $expired = microtime(true) > $deadline || (microtime(true) - $r['start']) > 3.5;
            if (!$st['running'] || $expired) {
                $r['out'] .= (string)stream_get_contents($r['pipes'][1]);
                if ($st['running']) @proc_terminate($r['p']);
                foreach ($r['pipes'] as $pp) @fclose($pp);
                @proc_close($r['p']);
                $results[$key] = $r['out'];
                unset($running[$key]);
            }
        }
        unset($r);
        if ($running) usleep(15000);
        if (microtime(true) > $deadline + 1) break;
    }
    foreach ($running as $key => $r) { @proc_terminate($r['p']); $results[$key] = $r['out']; }
    return $results;
}
function ws_run(array $argv, float $timeout = 4.0): string { $r = ws_run_parallel(['x' => $argv], 1, $timeout); return $r['x'] ?? ''; }

/* ---------- Rede do servidor ---------- */
function ws_ip_in(string $ip, string $net, int $prefix): bool
{
    $mask = $prefix === 0 ? 0 : (~((1 << (32 - $prefix)) - 1)) & 0xFFFFFFFF;
    return (ip2long($ip) & $mask) === (ip2long($net) & $mask);
}
function ws_is_private(string $ip): bool
{
    $l = ip2long($ip); if ($l === false) return false;
    return ws_ip_in($ip, '10.0.0.0', 8) || ws_ip_in($ip, '172.16.0.0', 12) || ws_ip_in($ip, '192.168.0.0', 16) || ws_ip_in($ip, '100.64.0.0', 10);
}
function ws_mask_to_prefix(string $mask): int { return substr_count(decbin(ip2long($mask) & 0xFFFFFFFF), '1'); }

/** Lê a saída do `ipconfig` (PT/EN). Se $wantedIp for null, escolhe o primeiro IPv4 privado. */
function ws_parse_ipconfig(string $txt, ?string $wantedIp): ?array
{
    $blocks = preg_split('/\r?\n(?=\S)/', $txt) ?: [];
    foreach ($blocks as $b) {
        $ip = null; $mask = null; $gw = null;
        $inGw = false;
        foreach (preg_split('/\r?\n/', $b) ?: [] as $line) {
            $hasLabel = (bool)preg_match('/\.\s*:\s|:\s*\S*$/', $line) && preg_match('/[[:alpha:]]/u', $line);
            if (!$hasLabel && $inGw && preg_match('/^\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$/', $line, $m)) { $gw = $m[1]; continue; } // 2.ª linha do gateway (IPv4 após IPv6)
            $inGw = false;
            if (!preg_match('/(\d{1,3}(?:\.\d{1,3}){3})\s*$/', $line, $m)) { if (preg_match('/gateway/i', $line)) $inGw = true; continue; }
            if (preg_match('/gateway/i', $line)) { $gw = $m[1]; $inGw = true; }
            elseif (preg_match('/m[áaÃ¡]scara|mask|m.scara/iu', $line)) $mask = $m[1];
            elseif (preg_match('/ipv4|endere.o ip|ip address/i', $line) && !preg_match('/dhcp|dns|wins/i', $line)) $ip = $m[1];
        }
        if ($ip === null || !ws_is_private($ip)) continue;
        if ($wantedIp !== null && $wantedIp !== $ip) continue;
        return ['ip' => $ip, 'prefix' => $mask ? ws_mask_to_prefix($mask) : 24, 'interface' => trim((string)strtok($b, "\n"), " :\r"), 'gateway' => $gw];
    }
    return null;
}

/** Descobre IP local, prefixo, interface e gateway. Lança RuntimeException se não houver LAN privada. */
function ws_local_network(): array
{
    $ip = null;
    $s = @stream_socket_client('udp://192.0.2.1:9', $en, $es, 1); // UDP "connect": não envia pacotes
    if ($s) { $name = stream_socket_get_name($s, false); fclose($s); if ($name) $ip = explode(':', $name)[0]; }
    $prefix = 24; $iface = ''; $gateway = null;

    if (ws_is_windows()) {
        $txt = ws_run(['ipconfig'], 5);
        $parsed = ws_parse_ipconfig($txt, $ip) ?? ws_parse_ipconfig($txt, null);
        if ($parsed) { $ip = $parsed['ip']; $prefix = $parsed['prefix']; $iface = $parsed['interface']; $gateway = $parsed['gateway']; }
    } else {
        $txt = ws_run(['ip', '-4', '-o', 'addr', 'show'], 4);
        $cands = [];
        foreach (preg_split('/\r?\n/', $txt) ?: [] as $line) {
            if (preg_match('/^\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m) && $m[1] !== 'lo' && ws_is_private($m[2]))
                $cands[] = ['ip' => $m[2], 'prefix' => (int)$m[3], 'iface' => $m[1]];
        }
        $pick = null;
        foreach ($cands as $c) if ($c['ip'] === $ip) { $pick = $c; break; }   // a interface usada para sair para a Internet
        $pick = $pick ?? ($cands[0] ?? null);                                  // senão, a primeira rede privada
        if ($pick) { $ip = $pick['ip']; $prefix = $pick['prefix']; $iface = $pick['iface']; }
        $route = ws_run(['ip', 'route', 'show', 'default'], 3);
        if (preg_match('/default via (\d+\.\d+\.\d+\.\d+)/', $route, $m)) $gateway = $m[1];
    }
    if ($ip === null || !ws_is_private($ip)) throw new RuntimeException('O servidor não está ligado a uma rede privada (Wi-Fi/Ethernet). Ligue-o à rede da escola ou à VPN.');
    return ['ip' => $ip, 'prefix' => $prefix, 'interface' => $iface ?: 'rede', 'gateway' => $gateway];
}

/* ---------- ARP ---------- */
function ws_norm_mac(string $m): string { return strtoupper(str_replace('-', ':', trim($m))); }
function ws_parse_arp_windows(string $txt): array
{
    $out = [];
    foreach (preg_split('/\r?\n/', $txt) ?: [] as $line) {
        if (!preg_match('/^\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-f]{2}(?:-[0-9a-f]{2}){5})\s+(\S+)/i', $line, $m)) continue;
        if (!preg_match('/din|dyn/i', $m[3])) continue; // ignora entradas estáticas (multicast/broadcast)
        $out[$m[1]] = ws_norm_mac($m[2]);
    }
    return $out;
}
function ws_parse_arp_linux(string $txt): array
{
    $out = [];
    foreach (preg_split('/\r?\n/', $txt) ?: [] as $line) {
        if (!preg_match('/^(\d+\.\d+\.\d+\.\d+)\s+.*?lladdr\s+([0-9a-f:]{17})\s+(\S+)/i', $line, $m)) continue;
        if (preg_match('/FAILED|INCOMPLETE/i', $m[3])) continue;
        $out[$m[1]] = ws_norm_mac($m[2]);
    }
    return $out;
}
function ws_parse_ping(string $txt): ?array
{
    if (!preg_match('/ttl[=:]\s*(\d+)/i', $txt, $m)) return null;
    $ms = preg_match('/(?:time|tempo|zeit)\s*[=<]\s*([\d.,]+)\s*ms/i', $txt, $t) ? (int)round((float)str_replace(',', '.', $t[1])) : 1;
    return ['ms' => max($ms, 1), 'ttl' => (int)$m[1]];
}
function ws_arp(string $localIp, int $prefix): array
{
    $out = [];
    $out = ws_is_windows() ? ws_parse_arp_windows(ws_run(['arp', '-a'], 4)) : ws_parse_arp_linux(ws_run(['ip', '-4', 'neigh', 'show'], 4));
    return array_filter($out, fn($mac, $ip) => $mac !== 'FF:FF:FF:FF:FF:FF' && ws_ip_in($ip, $localIp, $prefix), ARRAY_FILTER_USE_BOTH);
}

/* ---------- Portas TCP ---------- */
/** @return array<string,array{open:int[],alive:bool}> */
function ws_probe_ports(array $ips, array $ports, float $timeout = 0.9): array
{
    $res = []; foreach ($ips as $ip) $res[$ip] = ['open' => [], 'alive' => false];
    $pairs = []; foreach ($ips as $ip) foreach ($ports as $p) $pairs[] = [$ip, $p];
    foreach (array_chunk($pairs, 48) as $chunk) {
        $socks = [];
        foreach ($chunk as [$ip, $port]) {
            $s = @stream_socket_client("tcp://$ip:$port", $en, $es, 0, STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT);
            if ($s) { stream_set_blocking($s, false); $socks[(int)$s] = [$s, $ip, $port]; }
        }
        $deadline = microtime(true) + $timeout;
        while ($socks && microtime(true) < $deadline) {
            $w = $e = []; foreach ($socks as [$s]) { $w[] = $s; $e[] = $s; }
            $r = null;
            if (@stream_select($r, $w, $e, 0, 80000) === false) break;
            foreach ($w as $s) {
                [, $ip, $port] = $socks[(int)$s];
                if (@stream_socket_get_name($s, true) !== false) { $res[$ip]['open'][] = $port; $res[$ip]['alive'] = true; }
                elseif (!ws_is_windows()) $res[$ip]['alive'] = true; // ligação recusada (RST) = equipamento vivo
                fclose($s); unset($socks[(int)$s]);
            }
            foreach ($e as $s) {
                if (!isset($socks[(int)$s])) continue;
                [, $ip] = $socks[(int)$s];
                $res[$ip]['alive'] = true; // erro imediato (RST) = equipamento vivo
                fclose($s); unset($socks[(int)$s]);
            }
        }
        foreach ($socks as [$s]) @fclose($s);
    }
    foreach ($res as &$r) { $r['open'] = array_values(array_unique($r['open'])); sort($r['open']); }
    return $res;
}

/* ---------- Fabricante (OUI) ---------- */
function ws_vendors(array $macs): array
{
    $need = []; foreach ($macs as $mac) $need[strtoupper(substr(str_replace(':', '', $mac), 0, 6))] = true;
    $found = []; $file = __DIR__ . '/data/oui.txt';
    if (!$need || !is_file($file)) return $found;
    $fh = fopen($file, 'rb'); if (!$fh) return $found;
    while (($line = fgets($fh)) !== false) {
        if ($line === '' || $line[0] === '#') continue;
        $key = substr($line, 0, 6);
        if (isset($need[$key])) { $found[$key] = trim(substr($line, 7)); if (count($found) === count($need)) break; }
    }
    fclose($fh);
    return $found;
}

/* ---------- Classificação ---------- */
const WS_KINDS = [
    'pc' => 'Computador', 'phone' => 'Telemóvel', 'tablet' => 'Tablet', 'router' => 'Router / Rede', 'printer' => 'Impressora',
    'tv' => 'TV / Media', 'iot' => 'IoT / Sensor', 'server' => 'Servidor', 'console' => 'Consola', 'unknown' => 'Desconhecido',
];
function ws_classify(array $d): array
{
    $sc = []; $why = [];
    $add = function (string $k, int $pts, string $reason) use (&$sc, &$why) { $sc[$k] = ($sc[$k] ?? 0) + $pts; $why[] = $reason; };
    $host = strtolower((string)$d['hostname']); $vendor = strtolower((string)$d['vendor']); $ports = $d['ports']; $ttl = (int)($d['ttl'] ?? 0);

    if (!empty($d['isGateway'])) $add('router', 10, 'É o gateway da rede');
    if ($host !== '') {
        $rules = [
            'phone' => '/iphone|android|galaxy|pixel|redmi|xiaomi|huawei|oppo|oneplus|realme|poco|motorola|moto-|honor|sm-[a-z]\d|phone|telefone|mobile/',
            'tablet' => '/ipad|tablet|tab-|galaxy-tab|kindle|fire-/',
            'pc' => '/desktop|laptop|notebook|macbook|imac|mac-?mini|-pc\b|^pc-|\bpc\d|win(10|11)|windows|ubuntu|workstation|lab-?\d|sala-?\d|thinkpad|surface|latitude|optiplex/',
            'printer' => '/print|epson|canon|brother|laserjet|officejet|deskjet|ricoh|kyocera|lexmark|xerox|\bmfp\b/',
            'tv' => '/\btv\b|roku|chromecast|firetv|fire-tv|appletv|apple-tv|bravia|webos|smarttv|androidtv|shield|echo|alexa|sonos/',
            'iot' => '/esp[-_]?\d|esp8266|esp32|arduino|sensor|wellstate|shelly|tasmota|tuya|camera|cam-|ipcam/',
            'router' => '/router|gateway|modem|^ap-|access-?point|\bswitch\b|mikrotik|ubnt|unifi|fritz|livebox|meo|vodafone|nos-|zyxel/',
            'console' => '/playstation|ps[45]\b|xbox|nintendo|switch-/',
            'server' => '/server|servidor|nas\b|raspberry|raspberrypi|proxmox|synology|qnap/',
        ];
        foreach ($rules as $k => $re) if (preg_match($re, $host)) $add($k, 6, "Nome «{$d['hostname']}»");
    }
    $vendorRules = [
        'phone' => ['samsung' => 3, 'xiaomi' => 5, 'huawei' => 3, 'oppo' => 5, 'oneplus' => 5, 'vivo mobile' => 5, 'realme' => 5, 'motorola' => 4, 'honor' => 4, 'zte' => 2, 'tcl' => 1, 'nothing technology' => 5, 'fairphone' => 6, 'hmd global' => 5, 'google' => 2],
        'pc' => ['intel' => 3, 'realtek' => 2, 'dell' => 4, 'lenovo' => 4, 'asustek' => 3, 'acer' => 4, 'micro-star' => 4, 'gigabyte' => 4, 'microsoft' => 3, 'liteon' => 3, 'azurewave' => 3, 'foxconn' => 3, 'hon hai' => 3, 'toshiba' => 3, 'fujitsu' => 3, 'msi' => 3, 'killer' => 3, 'qualcomm' => 1, 'mediatek' => 1, 'broadcom' => 1, 'hewlett' => 2, 'hp inc' => 2, 'compal' => 3, 'quanta' => 3, 'wistron' => 3, 'pegatron' => 3, 'samsung electronics' => 0],
        'router' => ['tp-link' => 3, 'netgear' => 4, 'd-link' => 4, 'ubiquiti' => 5, 'cisco' => 4, 'zyxel' => 5, 'mikrotik' => 5, 'arris' => 4, 'technicolor' => 5, 'sagemcom' => 5, 'huawei technologies' => 1, 'fritz' => 5, 'avm' => 5, 'linksys' => 5, 'asus' => 0, 'aruba' => 5, 'ruckus' => 5, 'alcatel' => 2, 'altice' => 4, 'meo' => 3, 'vodafone' => 3, 'zte corporation' => 2, 'draytek' => 5, 'tenda' => 5, 'juniper' => 5],
        'iot' => ['espressif' => 6, 'tuya' => 6, 'shelly' => 6, 'allterco' => 6, 'sonoff' => 6, 'itead' => 6, 'ai-thinker' => 6, 'wiznet' => 4, 'hangzhou' => 1, 'gosund' => 5, 'nest' => 5, 'ring' => 4, 'hikvision' => 6, 'dahua' => 6, 'reolink' => 6, 'tapo' => 4, 'philips lighting' => 6, 'signify' => 6, 'ikea' => 4],
        'server' => ['raspberry' => 6, 'supermicro' => 5, 'synology' => 6, 'qnap' => 6, 'vmware' => 5, 'proxmox' => 5, 'xensource' => 5, 'parallels' => 4, 'virtualbox' => 5, 'oracle' => 3],
        'printer' => ['brother' => 6, 'canon' => 4, 'epson' => 6, 'xerox' => 6, 'ricoh' => 6, 'kyocera' => 6, 'lexmark' => 6, 'konica' => 6, 'sharp' => 3, 'oki' => 5, 'zebra' => 5],
        'tv' => ['roku' => 6, 'sony' => 2, 'lg electronics' => 3, 'vizio' => 6, 'hisense' => 5, 'philips' => 2, 'amazon' => 3, 'sonos' => 6, 'bose' => 5, 'harman' => 4, 'panasonic' => 2, 'sharp' => 1],
        'console' => ['nintendo' => 7, 'sony interactive' => 7, 'microsoft xbox' => 7, 'valve' => 5],
    ];
    if ($vendor !== '') foreach ($vendorRules as $k => $list) foreach ($list as $needle => $pts) if ($pts > 0 && str_contains($vendor, $needle)) { $add($k, $pts, "Fabricante {$d['vendor']}"); break; }
    if (str_contains($vendor, 'apple')) { $add('phone', 2, 'Fabricante Apple'); $add('pc', 2, 'Fabricante Apple'); }

    if (!empty($d['randomMac'])) $add('phone', 3, 'Endereço MAC privado (típico de telemóveis)');
    if (array_intersect($ports, [135, 139, 445])) $add('pc', 4, 'Serviços Windows/partilha (SMB)');
    if (in_array(3389, $ports, true)) $add('pc', 3, 'Ambiente de trabalho remoto (RDP)');
    if (in_array(62078, $ports, true)) $add('phone', 8, 'Porta de sincronização iOS (62078)');
    if (in_array(5555, $ports, true)) $add('phone', 2, 'Porta ADB (Android)');
    if (array_intersect($ports, [9100, 515, 631])) $add('printer', 8, 'Porta de impressão (' . implode('/', array_intersect($ports, [9100, 515, 631])) . ')');
    if (array_intersect($ports, [8009, 8008])) $add('tv', 7, 'Porta Cast (8008/8009)');
    if (in_array(548, $ports, true)) $add('pc', 3, 'Partilha Apple (AFP)');
    if (in_array(22, $ports, true) && !array_intersect($ports, [135, 445, 3389])) $add('server', 2, 'SSH aberto');
    if ($ttl >= 100 && $ttl <= 128) $add('pc', 2, "TTL $ttl (Windows)");
    elseif ($ttl > 128) $add('router', 2, "TTL $ttl (equipamento de rede)");
    elseif ($ttl > 32 && $ttl <= 64) { $add('phone', 1, "TTL $ttl (Android/iOS/Linux)"); }

    if (!empty($d['isSelf'])) return ['kind' => 'server', 'label' => 'Este servidor', 'confidence' => 'high', 'reasons' => ['É o computador que executa o Wellstate']];
    arsort($sc);
    $best = array_key_first($sc); $top = $best ? $sc[$best] : 0;
    if (!$best || $top < 3) return ['kind' => 'unknown', 'label' => WS_KINDS['unknown'], 'confidence' => 'low', 'reasons' => []];
    // Empate pc/phone (Apple): desempata por portas/ttl
    $label = WS_KINDS[$best];
    if ($best === 'phone' && $top < 6 && empty($d['hostname'])) $label = 'Telemóvel (provável)';
    return ['kind' => $best, 'label' => $label, 'confidence' => $top >= 8 ? 'high' : ($top >= 5 ? 'medium' : 'low'), 'reasons' => array_values(array_unique($why))];
}

/* ---------- Nomes de host ---------- */
function ws_hostnames(array $ips, bool $windows): array
{
    $cmds = [];
    foreach ($ips as $ip) $cmds[$ip] = $windows ? ['ping', '-a', '-n', '1', '-w', '300', $ip] : ['getent', 'hosts', $ip];
    $names = [];
    foreach (ws_run_parallel($cmds, 24, 4.0) as $ip => $txt) {
        $n = '';
        if ($windows) { if (preg_match('/\s([^\s\[\]]+)\s+\[' . preg_quote($ip, '/') . '\]/u', $txt, $m)) $n = $m[1]; }
        elseif (preg_match('/^\S+\s+(\S+)/', $txt, $m)) $n = $m[1];
        $n = preg_replace('/\.(local|lan|home|localdomain|fritz\.box)$/i', '', $n) ?? $n;
        if ($n !== '' && $n !== $ip) $names[$ip] = mb_substr($n, 0, 60);
    }
    return $names;
}

/* ---------- Scan completo ---------- */
function ws_scan_run(?PDO $pdo, bool $force): array
{
    $cacheFile = ws_data_dir() . '/network-cache.json';
    $cache = is_file($cacheFile) ? (json_decode((string)file_get_contents($cacheFile), true) ?: []) : [];
    if (!ws_can_exec()) throw new RuntimeException('O PHP deste servidor tem proc_open desativado (disable_functions). Ative-o em php.ini para descobrir dispositivos.');

    @set_time_limit(40);
    $t0 = microtime(true);
    $net = ws_local_network();
    $win = ws_is_windows();

    // Sub-rede a varrer (máx. /24 em torno do servidor)
    $scanPrefix = max($net['prefix'], 24); $limited = $net['prefix'] < 24;
    $base = ip2long($net['ip']) & (~((1 << (32 - $scanPrefix)) - 1) & 0xFFFFFFFF);
    $count = (1 << (32 - $scanPrefix)) - 2;
    $hosts = []; for ($i = 1; $i <= $count; $i++) $hosts[] = long2ip($base + $i);
    $cidr = long2ip($base) . '/' . $scanPrefix;

    // 1) Ping em paralelo
    $cmds = [];
    foreach ($hosts as $ip) {
        if ($ip === $net['ip']) continue;
        $cmds[$ip] = $win ? ['ping', '-n', '1', '-w', '450', $ip]
            : (PHP_OS_FAMILY === 'Darwin' ? ['ping', '-c', '1', '-W', '450', $ip] : ['ping', '-c', '1', '-W', '1', $ip]);
    }
    $ping = []; // ip => [ms, ttl]
    foreach (ws_run_parallel($cmds, 64, 9.0) as $ip => $txt) {
        $r = ws_parse_ping($txt);
        if ($r) $ping[$ip] = $r;
    }

    // 2) ARP (apanha equipamentos que bloqueiam ping, p. ex. telemóveis e Windows com firewall)
    $arp = ws_arp($net['ip'], $scanPrefix);
    unset($arp[$net['ip']]);

    // 3) Portas TCP em quem respondeu ao ping ou aparece no ARP
    $candidates = array_values(array_unique(array_merge(array_keys($ping), array_keys($arp))));
    $portCache = $cache['ports'] ?? [];
    $toProbe = array_values(array_filter($candidates, fn($ip) => !isset($portCache[$ip]) || time() - ($portCache[$ip]['at'] ?? 0) > WS_PORT_TTL));
    $aliveNow = []; // só conta como «vivo» quem respondeu a ESTE scan (a cache de portas não prova presença)
    if ($toProbe) foreach (ws_probe_ports($toProbe, WS_PORTS) as $ip => $r) { $portCache[$ip] = ['open' => $r['open'], 'at' => time()]; if ($r['alive']) $aliveNow[$ip] = true; }
    // Quem não respondeu ao ping mas está no ARP é testado de novo a cada scan (barato: poucos hosts)
    $recheck = array_values(array_filter(array_keys($arp), fn($ip) => !isset($ping[$ip]) && !isset($aliveNow[$ip]) && !in_array($ip, $toProbe, true)));
    if ($recheck) foreach (ws_probe_ports($recheck, [80, 443, 445, 62078, 5353, 8009], 0.7) as $ip => $r) if ($r['alive']) $aliveNow[$ip] = true;

    // 4) Quem está online?  ping OK  |  porta respondeu/recusou  |  ARP confirmado em 2 scans seguidos
    $arpSeen = $cache['arpSeen'] ?? []; $newArpSeen = [];
    $firstRun = empty($cache['at']);
    $online = [];
    foreach ($candidates as $ip) {
        $viaPing = isset($ping[$ip]); $viaPort = isset($aliveNow[$ip]);
        $viaArp = isset($arp[$ip]);
        if ($viaArp) $newArpSeen[$ip] = ($arpSeen[$ip] ?? 0) + 1;
        if ($viaPing || $viaPort || ($viaArp && ($newArpSeen[$ip] >= 2 || $firstRun || $force))) $online[$ip] = true;
    }
    // Remove da cache de portas quem desapareceu
    foreach (array_keys($portCache) as $ip) if (!isset($online[$ip])) unset($portCache[$ip]);

    // 5) Nomes e fabricantes
    $names = $cache['names'] ?? [];
    $needName = array_values(array_filter(array_keys($online), fn($ip) => !isset($names[$ip]) || time() - ($names[$ip]['at'] ?? 0) > WS_NAME_TTL));
    if ($needName && microtime(true) - $t0 < 14) {
        $found = ws_hostnames($needName, $win);
        foreach ($needName as $ip) $names[$ip] = ['name' => $found[$ip] ?? '', 'at' => time()];
    }
    $vendors = ws_vendors(array_values($arp));

    // Alias definidos pelo utilizador
    $aliases = [];
    try { if ($pdo) foreach ($pdo->query('SELECT device_key, alias, kind FROM device_aliases')->fetchAll() as $a) $aliases[$a['device_key']] = $a; } catch (Throwable $e) { /* tabela ainda não existe */ }

    $devices = [];
    $selfName = (string)gethostname();
    $list = array_keys($online); $list[] = $net['ip'];
    foreach ($list as $ip) {
        $isSelf = $ip === $net['ip'];
        $mac = $arp[$ip] ?? null;
        $randomMac = $mac !== null && (hexdec(substr($mac, 0, 2)) & 0x02) !== 0;
        $vendor = $mac ? ($vendors[strtoupper(substr(str_replace(':', '', $mac), 0, 6))] ?? '') : '';
        $hostname = $isSelf ? $selfName : ($names[$ip]['name'] ?? '');
        $ports = $isSelf ? [] : ($portCache[$ip]['open'] ?? []);
        $cls = ws_classify(['hostname' => $hostname, 'vendor' => $vendor, 'ports' => $ports, 'ttl' => $ping[$ip]['ttl'] ?? 0,
            'randomMac' => $randomMac, 'isGateway' => $ip === $net['gateway'], 'isSelf' => $isSelf]);
        $key = $mac ?: $ip;
        $alias = $aliases[$key]['alias'] ?? $aliases[$ip]['alias'] ?? '';
        $kindOverride = $aliases[$key]['kind'] ?? $aliases[$ip]['kind'] ?? '';
        if ($kindOverride !== '' && isset(WS_KINDS[$kindOverride])) { $cls['kind'] = $kindOverride; $cls['label'] = WS_KINDS[$kindOverride]; $cls['confidence'] = 'high'; $cls['reasons'] = ['Definido por si']; }
        $display = $alias !== '' ? $alias : ($hostname !== '' ? $hostname : ($vendor !== '' ? $vendor : ''));
        $devices[] = [
            'ip' => $ip, 'mac' => $mac, 'hostname' => $display !== '' ? $display : $cls['label'], 'rawHostname' => $hostname, 'alias' => $alias, 'vendor' => $vendor,
            'kind' => $cls['kind'], 'kindLabel' => $cls['label'], 'confidence' => $cls['confidence'], 'reasons' => $cls['reasons'],
            'online' => true, 'responseMs' => $isSelf ? 0 : ($ping[$ip]['ms'] ?? null), 'ttl' => $ping[$ip]['ttl'] ?? null, 'openPorts' => $ports,
            'randomMac' => $randomMac, 'isGateway' => $ip === $net['gateway'], 'isSelf' => $isSelf,
            'viaPing' => isset($ping[$ip]), 'key' => $key,
        ];
    }
    usort($devices, fn($a, $b) => ip2long($a['ip']) <=> ip2long($b['ip']));

    $result = [
        'scanCidr' => $cidr, 'scannedAt' => gmdate('c'), 'devices' => $devices, 'automaticallyDetected' => true,
        'interfaceName' => $net['interface'], 'serverAddress' => $net['ip'], 'gateway' => $net['gateway'],
        'hostsScanned' => count($hosts), 'hostsAvailable' => $count, 'scanLimited' => $limited,
        'durationMs' => (int)round((microtime(true) - $t0) * 1000), 'nextScanInSeconds' => 20,
        'summary' => array_count_values(array_column($devices, 'kind')),
    ];
    @file_put_contents($cacheFile, json_encode(['at' => time(), 'result' => $result, 'ports' => $portCache, 'names' => $names, 'arpSeen' => $newArpSeen]), LOCK_EX);
    return $result;
}


/* ---------- Scan em segundo plano (não bloqueia o servidor PHP, que atende um pedido de cada vez) ---------- */
function ws_cache_file(): string { return ws_data_dir() . '/network-cache.json'; }
function ws_read_cache(): array { $f = ws_cache_file(); return is_file($f) ? (json_decode((string)@file_get_contents($f), true) ?: []) : []; }
/** Marca a cache como antiga (ex.: após mudar um nome) sem apagar os dados. */
function ws_invalidate(): void { $c = ws_read_cache(); if ($c) { $c['at'] = 0; @file_put_contents(ws_cache_file(), json_encode($c), LOCK_EX); } }
function ws_scan_running(): bool
{
    $fh = @fopen(ws_data_dir() . '/scan.lock', 'c'); if (!$fh) return false;
    $free = flock($fh, LOCK_SH | LOCK_NB);
    if ($free) flock($fh, LOCK_UN);
    fclose($fh);
    return !$free;
}
function ws_php_binary(): ?string
{
    $c = [];
    if (PHP_BINARY && preg_match('/php(\.exe)?$/i', PHP_BINARY)) $c[] = PHP_BINARY;
    $c[] = PHP_BINDIR . DIRECTORY_SEPARATOR . (ws_is_windows() ? 'php.exe' : 'php');
    if (ws_is_windows()) { $c[] = 'C:\\xampp\\php\\php.exe'; $c[] = dirname(PHP_BINARY ?: '') . '\\php.exe'; $c[] = dirname(PHP_BINARY ?: '', 2) . '\\php\\php.exe'; }
    foreach ($c as $path) if ($path && @is_file($path)) return $path;
    return null;
}
/** Lança o worker em background. Devolve false se não for possível (sem popen/PHP CLI). */
function ws_start_worker(bool $force): bool
{
    if (ws_scan_running()) return true;
    $php = ws_php_binary();
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    if (!$php || !function_exists('popen') || in_array('popen', $disabled, true)) return false;
    $worker = __DIR__ . DIRECTORY_SEPARATOR . 'scan-worker.php';
    $arg = $force ? ' force' : '';
    $cmd = ws_is_windows()
        ? 'start /B "" "' . $php . '" "' . $worker . '"' . $arg
        : escapeshellarg($php) . ' ' . escapeshellarg($worker) . $arg . ' >/dev/null 2>&1 &';
    $h = @popen($cmd, 'r');
    if ($h === false) return false;
    @pclose($h);
    return true;
}
/** Resposta imediata: devolve a última leitura e pede um novo scan quando está desatualizada. */
function ws_scan_get(?PDO $pdo, bool $refresh): array
{
    if (!ws_can_exec()) throw new RuntimeException('O PHP deste servidor tem proc_open desativado (disable_functions). Ative-o em php.ini para descobrir dispositivos.');
    $cache = ws_read_cache();
    $age = time() - (int)($cache['at'] ?? 0);
    $stale = empty($cache['result']) || $age >= WS_SCAN_TTL || $refresh;
    $running = ws_scan_running();
    if ($stale && !$running) {
        if (ws_start_worker($refresh)) { usleep(120000); $running = true; }
        else { return ws_scan_run($pdo, $refresh) + ['scanning' => false]; } // sem processo em 2.º plano: scan direto
    }
    $errFile = ws_data_dir() . '/network-error.txt';
    if (!$running && is_file($errFile) && (empty($cache['result']) || filemtime($errFile) >= (int)($cache['at'] ?? 0))) throw new RuntimeException((string)file_get_contents($errFile));
    if (empty($cache['result'])) {
        return ['scanCidr' => '—', 'scannedAt' => null, 'devices' => [], 'automaticallyDetected' => true, 'interfaceName' => '', 'serverAddress' => '', 'gateway' => null,
            'hostsScanned' => 0, 'hostsAvailable' => 0, 'scanLimited' => false, 'durationMs' => 0, 'summary' => [], 'scanning' => true, 'pending' => true];
    }
    return $cache['result'] + ['scanning' => $running, 'ageSeconds' => $age];
}

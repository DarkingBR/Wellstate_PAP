/* Portal usa proxy same-origin; servidor estático local usa a API C# na porta 5080. */
(function () {
    const host = window.location.hostname;
    const isHttp = window.location.protocol === "http:" || window.location.protocol === "https:";
    const port = window.location.port;
    const isPortalOrigin = isHttp && (!port || port === "80" || port === "443" || port === "8080");
    const localBackend = isHttp && host && !isPortalOrigin && port !== "5080"
        ? `${window.location.protocol}//${host}:5080/api`
        : "/api";

    window.WELLSTATE_CONFIG = Object.freeze({
        API_BASE_URL: String(window.WELLSTATE_API_BASE_URL || localBackend).replace(/\/+$/, ""),
        API_TIMEOUT_MS: 18000,
        NETWORK_TIMEOUT_MS: 55000,
        API_RETRIES: 3,
        POLL_INTERVAL_MS: 12000,
        NETWORK_POLL_INTERVAL_MS: 45000,
        HISTORY_POLL_INTERVAL_MS: 45000,
        TIME_ZONE: "Europe/Lisbon",
        STORE_KEY: "wellstate-store"
    });
})();

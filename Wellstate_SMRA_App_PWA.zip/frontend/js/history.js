/* Wellstate · Histórico
   - Lista de eventos (últimos)
   - Gráfico de 24h (temp + humidade) com Chart.js
   - Exportação PDF semanal com jsPDF
*/
import { apiClient } from "./api-client.js";

const list = document.getElementById("historyList");
const filter = document.getElementById("roomFilter");
const rangeSel = document.getElementById("rangeSel");
const pdfBtn = document.getElementById("exportPdfBtn");
const chartCanvas = document.getElementById("chartCanvas");
let chart = null;
let STORE = window.WELLSTATE_STORE;
let apiOnline = false;
let activeMetric = "presence";
let currentEntries = [];
let historyLoading = false;
const TIME_ZONE = window.WELLSTATE_CONFIG?.TIME_ZONE || "Europe/Lisbon";
const setText = (id, value) => { const node = document.getElementById(id); if (node) node.textContent = value; };

function roomLabel(id) {
    const cfg = (STORE.rooms || []).find(r => r.id === id);
    return cfg?.name || `Sala ${id}`;
}

async function loadRooms() {
    let ids = (STORE.rooms || []).map(room => room.id);
    try {
        const readings = await apiClient.getLatestRooms();
        apiOnline = true;
        ids = [...new Set([...ids, ...readings.map(reading => reading.roomId)])];
    } catch { apiOnline = false; }
    filter.innerHTML = `<option value="">Todas as salas</option>` +
        ids.map((id) => `<option value="${id}">${roomLabel(id)}</option>`).join("");
}

async function fetchHistoryEntries(roomId, from, to) {
    try {
        const rows = await apiClient.getHistory({ roomId, limit: 2000, from, to });
        apiOnline = true;
        return rows.map(row => ({ ...row, ts: row.updatedAt }));
    } catch {
        apiOnline = false;
        return [];
    }
}

function parseTs(ts) {
    if (typeof ts === "number") return new Date(ts);
    if (Number.isFinite(+ts)) return new Date(+ts);
    return new Date(ts);
}

async function loadHistory() {
    const silent = arguments[0]?.silent === true;
    if (historyLoading) return;
    historyLoading = true;
    try {
        if (!silent) list.innerHTML = `<div class="skeleton wide"></div>`;
        const roomId = filter.value;
        const rangeH = Number(rangeSel?.value || 24);
        const now = Date.now();
        const from = now - rangeH * 3600 * 1000;
        const entries = await fetchHistoryEntries(roomId, from, now);
        const filtered = entries
            .map(e => ({ ...e, _t: parseTs(e.ts).getTime() }))
            .filter(e => e._t >= from)
            .sort((a, b) => b._t - a._t);

        currentEntries = filtered;
        renderList(filtered);
        renderSummary(filtered);
        renderChart(filtered, roomId);
        const updated = document.getElementById("reportUpdated");
        if (updated) updated.textContent = apiOnline ? `Atualizado ${new Intl.DateTimeFormat("pt-PT", { timeZone: TIME_ZONE, hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date())}` : "API sem resposta";
    } finally {
        historyLoading = false;
    }
}

function renderSummary(entries) {
    const rooms = new Set(entries.map(entry => entry.roomId));
    const temps = entries.map(entry => entry.temperature).filter(value => typeof value === "number");
    const occupied = entries.filter(entry => entry.occupied).length;
    setText("summaryReadings", entries.length);
    setText("summaryRooms", rooms.size);
    setText("summaryTemperature", temps.length ? `${(temps.reduce((sum, value) => sum + value, 0) / temps.length).toFixed(1)}°C` : "—");
    setText("summaryOccupied", `${occupied} · ${entries.length ? Math.round(occupied / entries.length * 100) : 0}%`);
    const range = rangeSel?.selectedOptions?.[0]?.textContent || "Intervalo selecionado";
    setText("reportRangeCaption", range);
}

function renderList(entries) {
    if (!entries.length) {
        list.innerHTML = `<div class="chip">${apiOnline ? "Sem histórico registado no intervalo selecionado." : "API REST indisponível; confirma a ligação ao servidor."}</div>`;
        return;
    }
    list.innerHTML = "";
    entries.slice(0, 200).forEach((ev) => {
        const el = document.createElement("div");
        el.className = "history-item fade-in";
        el.innerHTML = `
            <div class="time">${new Intl.DateTimeFormat("pt-PT", { timeZone: TIME_ZONE, dateStyle: "short", timeStyle: "medium", hourCycle: "h23" }).format(new Date(ev._t))}</div>
            <div class="desc"><strong>${roomLabel(ev.roomId)}</strong> · ${ev.event || "leitura"} · ${ev.temperature ?? "—"}°C · ${ev.humidity ?? "—"}%</div>
            <span class="status-badge ${ev.occupied ? "occupied" : "free"}">${ev.occupied ? "Ocupada" : "Livre"}</span>`;
        list.appendChild(el);
    });
}

function renderChart(entries, roomFilter) {
    if (!chartCanvas || !window.Chart) return;
    const palette = ["#e9ebeb", "#a9afb1", "#858c8e", "#c8cdce", "#6f7779", "#d8dada"];
    const grouped = {};
    entries.forEach(entry => { (grouped[entry.roomId] = grouped[entry.roomId] || []).push(entry); });
    let datasets = [];
    let chartType = "line";
    let axisTitle = activeMetric === "temperature" ? "°C" : "%";

    if (activeMetric === "presence") {
        chartType = "bar";
        axisTitle = "Leituras de presença";
        const hourly = new Map();
        entries.forEach(entry => {
            const bucket = Math.floor(entry._t / 3600000) * 3600000;
            if (!hourly.has(bucket)) hourly.set(bucket, 0);
            if (entry.occupied) hourly.set(bucket, hourly.get(bucket) + 1);
        });
        datasets = [{ label: "Leituras ocupadas", data: [...hourly].sort((a, b) => a[0] - b[0]).map(([x, y]) => ({ x, y })), backgroundColor: "#e8eaea", borderRadius: 5, maxBarThickness: 18 }];
    } else {
        const key = activeMetric === "temperature" ? "temperature" : "humidity";
        const metricLabel = activeMetric === "temperature" ? "Temperatura" : "Humidade";
        let index = 0;
        Object.entries(grouped).forEach(([roomId, rows]) => {
            const points = rows.slice().sort((a, b) => a._t - b._t).filter(row => typeof row[key] === "number").map(row => ({ x: row._t, y: row[key] }));
            if (!points.length) return;
            const color = palette[index++ % palette.length];
            datasets.push({ label: `${roomLabel(roomId)} · ${metricLabel}`, data: points, borderColor: color, backgroundColor: color + "25", tension: .3, pointRadius: 2, pointHoverRadius: 4 });
        });
    }

    if (chart && chart.config.type === chartType) {
        chart.data.datasets = datasets;
        chart.options.scales.y.title.text = axisTitle;
        chart.update();
        return;
    }
    if (chart) chart.destroy();
    const gridCol = "rgba(190,198,200,.12)";
    const textCol = "#c1c6c7";
    const timeFormatter = new Intl.DateTimeFormat("pt-PT", { timeZone: TIME_ZONE, hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
    const title = activeMetric === "presence" ? "Presença nas salas" : activeMetric === "temperature" ? "Temperatura" : "Humidade";
    setText("reportMetricTitle", title);
    setText("reportChartHeading", title);
    chart = new Chart(chartCanvas, {
        type: chartType,
        data: { datasets },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { labels: { color: textCol, font: { family: "Space Grotesk", size: 10 } } }, tooltip: { mode: "index", intersect: false } },
            scales: {
                x: { type: "linear", grid: { color: gridCol }, ticks: { color: textCol, maxTicksLimit: 8, callback: value => timeFormatter.format(new Date(Number(value))) } },
                y: { beginAtZero: activeMetric === "presence", title: { display: true, text: axisTitle, color: textCol }, grid: { color: gridCol }, ticks: { color: textCol } }
            },
            interaction: { mode: "nearest", axis: "x", intersect: false }
        }
    });
}

// ===== PDF export (semana atual) =====
async function exportPdf() {
    if (!window.jspdf) return alert("jsPDF não carregou.");
    const { jsPDF } = window.jspdf;
    const roomId = filter.value;
    const now = new Date();
    const start = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    const entries = await fetchHistoryEntries(roomId, start, now);
    const week = entries
        .map(e => ({ ...e, _t: parseTs(e.ts).getTime() }))
        .filter(e => e._t >= start.getTime())
        .sort((a, b) => a._t - b._t);

    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const marginX = 40;
    let y = 50;

    doc.setFont("helvetica", "bold"); doc.setFontSize(20);
    doc.setTextColor(30, 136, 255); doc.text("Wellstate · Relatório Semanal", marginX, y);
    y += 22;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(80);
    doc.text(`Intervalo: ${window.WellstateClock.formatDateTime(start)}  →  ${window.WellstateClock.formatDateTime(now)} (${TIME_ZONE})`, marginX, y);
    y += 14;
    doc.text(`Sala: ${roomId ? roomLabel(roomId) : "Todas"}`, marginX, y);
    y += 14;
    doc.text(`Total de registos: ${week.length}`, marginX, y);
    y += 22;

    // Estatísticas por sala
    const stats = {};
    week.forEach(e => {
        const s = stats[e.roomId] = stats[e.roomId] || { n: 0, tSum: 0, tN: 0, hSum: 0, hN: 0, occ: 0 };
        s.n++;
        if (typeof e.temperature === "number") { s.tSum += e.temperature; s.tN++; }
        if (typeof e.humidity === "number") { s.hSum += e.humidity; s.hN++; }
        if (e.occupied) s.occ++;
    });

    doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(20);
    doc.text("Resumo por sala", marginX, y); y += 16;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10);
    Object.entries(stats).forEach(([rid, s]) => {
        const tAvg = s.tN ? (s.tSum / s.tN).toFixed(1) : "—";
        const hAvg = s.hN ? (s.hSum / s.hN).toFixed(0) : "—";
        doc.text(`• ${roomLabel(rid)}: ${s.n} registos · Temp média ${tAvg}°C · Hum média ${hAvg}% · Ocupações ${s.occ}`, marginX, y);
        y += 14;
        if (y > 780) { doc.addPage(); y = 50; }
    });

    y += 8;
    doc.setFont("helvetica", "bold"); doc.setFontSize(13);
    doc.text("Registos (cronológico)", marginX, y); y += 14;

    doc.setFont("helvetica", "bold"); doc.setFontSize(9);
    doc.text("Data/Hora", marginX, y);
    doc.text("Sala", marginX + 130, y);
    doc.text("Evento", marginX + 220, y);
    doc.text("T (°C)", marginX + 320, y);
    doc.text("H (%)", marginX + 370, y);
    doc.text("Ocupada", marginX + 420, y);
    y += 4;
    doc.setDrawColor(200); doc.line(marginX, y, marginX + 500, y);
    y += 10;
    doc.setFont("helvetica", "normal");

    week.forEach(e => {
        if (y > 800) { doc.addPage(); y = 50; }
        doc.text(window.WellstateClock.formatDateTime(new Date(e._t)), marginX, y);
        doc.text(String(roomLabel(e.roomId)).slice(0, 18), marginX + 130, y);
        doc.text(String(e.event || "leitura").slice(0, 18), marginX + 220, y);
        doc.text(String(e.temperature ?? "—"), marginX + 320, y);
        doc.text(String(e.humidity ?? "—"), marginX + 370, y);
        doc.text(e.occupied ? "Sim" : "Não", marginX + 420, y);
        y += 12;
    });

    // Rodapé
    const pageCount = doc.internal.pages.length - 1;
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8); doc.setTextColor(120);
        doc.text(`Wellstate · PAP · Página ${i}/${pageCount}`, marginX, 820);
    }

    const stamp = now.toISOString().slice(0, 10);
    doc.save(`wellstate-semana-${stamp}.pdf`);
}

filter.addEventListener("change", loadHistory);
if (rangeSel) rangeSel.addEventListener("change", loadHistory);
if (pdfBtn) pdfBtn.addEventListener("click", exportPdf);
document.querySelectorAll("[data-report-metric]").forEach(button => button.addEventListener("click", () => {
    activeMetric = button.dataset.reportMetric;
    document.querySelectorAll("[data-report-metric]").forEach(tab => {
        const selected = tab === button;
        tab.classList.toggle("active", selected);
        tab.setAttribute("aria-selected", String(selected));
    });
    renderChart(currentEntries, filter.value);
}));

window.addEventListener("wellstate:store-updated", (e) => { STORE = e.detail; loadRooms().then(loadHistory); });
document.addEventListener("visibilitychange", () => {
    if (!document.hidden) loadHistory({ silent: true });
});
window.addEventListener("online", () => { if (!document.hidden) loadRooms().then(() => loadHistory({ silent: true })); });

loadRooms().then(loadHistory);
window.setInterval(() => {
    if (!document.hidden) loadHistory({ silent: true });
}, window.WELLSTATE_CONFIG.HISTORY_POLL_INTERVAL_MS || 30000);

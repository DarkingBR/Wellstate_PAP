/* Interações partilhadas Wellstate: estado de sincronização, feedback e transições acessíveis. */
(function () {
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    const livePage = Boolean(document.querySelector("#apiStatus, #networkBadge, #reportSource"));
    let lastSync = 0;
    let online = null;
    let liveDetail = null;
    let relativeTimer;

    function mountLiveIndicator() {
        if (!livePage || document.getElementById("wellstateLiveIndicator")) return;
        const actions = document.querySelector(".topbar-actions");
        if (!actions) return;
        const indicator = document.createElement("div");
        indicator.id = "wellstateLiveIndicator";
        indicator.className = "ws-live-indicator is-waiting";
        indicator.setAttribute("role", "status");
        indicator.setAttribute("aria-live", "off");
        indicator.innerHTML = '<span class="ws-live-dot" aria-hidden="true"></span><span class="ws-live-copy"><strong>AO VIVO</strong><small>A sincronizar…</small></span>';
        const anchor = actions.querySelector("#themeToggle, #refreshNetwork");
        if (anchor) actions.insertBefore(indicator, anchor);
        else actions.appendChild(indicator);
        renderLiveState();
        relativeTimer = window.setInterval(renderLiveState, 1000);
    }

    function renderLiveState() {
        const indicator = document.getElementById("wellstateLiveIndicator");
        if (!indicator) return;
        indicator.classList.toggle("is-online", online === true);
        indicator.classList.toggle("is-offline", online === false);
        indicator.classList.toggle("is-waiting", online === null);
        const small = indicator.querySelector("small");
        const strong = indicator.querySelector("strong");
        if (strong) strong.textContent = online === false ? "RECONEXÃO" : online === true ? "AO VIVO" : "A SINCRONIZAR";
        if (small) {
            if (online === false) small.textContent = "API sem resposta";
            else if (!lastSync) small.textContent = "A aguardar dados";
            else {
                const age = Math.max(0, Math.floor((Date.now() - lastSync) / 1000));
                small.textContent = age < 2 ? "Atualizado agora" : `Atualizado há ${age} s`;
            }
        }
        indicator.title = liveDetail || (lastSync ? `Última resposta da API: ${new Date(lastSync).toLocaleTimeString("pt-PT")}` : "À espera da primeira resposta da API");
    }

    function pulseContent(nodes) {
        if (reducedMotion) return;
        nodes.filter(Boolean).forEach(node => {
            node.classList.remove("ws-tab-enter");
            void node.offsetWidth;
            node.classList.add("ws-tab-enter");
            window.setTimeout(() => node.classList.remove("ws-tab-enter"), 760);
        });
    }

    window.addEventListener("wellstate:api-status", event => {
        online = Boolean(event.detail?.online);
        if (online) lastSync = Date.now();
        liveDetail = event.detail?.error || (event.detail?.path ? `API respondeu em ${event.detail.path}` : null);
        renderLiveState();
    });

    // Ripple discreto e feedback de pressão em ações/tabs; não intercepta a ação original.
    document.addEventListener("click", event => {
        const control = event.target.closest("button, a.btn-primary, a.btn-ghost, .nav-link");
        if (!control || control.matches(":disabled, [aria-disabled='true']")) return;
        control.classList.add("ws-ripple-host");
        control.classList.remove("ws-pressed");
        void control.offsetWidth;
        control.classList.add("ws-pressed");
        window.setTimeout(() => control.classList.remove("ws-pressed"), 360);

        if (!reducedMotion && event.detail > 0 && control.getBoundingClientRect) {
            const rect = control.getBoundingClientRect();
            const diameter = Math.max(rect.width, rect.height) * 1.35;
            const ripple = document.createElement("span");
            ripple.className = "ws-ripple";
            ripple.style.width = ripple.style.height = `${diameter}px`;
            ripple.style.left = `${event.clientX - rect.left - diameter / 2}px`;
            ripple.style.top = `${event.clientY - rect.top - diameter / 2}px`;
            control.appendChild(ripple);
            window.setTimeout(() => ripple.remove(), 700);
        }

        const tab = control.closest(".tab-btn[data-tab], .day-tab, .report-tab, [data-room-filter]");
        if (!tab) return;
        window.setTimeout(() => {
            if (tab.matches(".tab-btn")) {
                pulseContent([document.querySelector(`.tab-panel.active[data-tab="${CSS.escape(tab.dataset.tab)}"]`)]);
            } else if (tab.matches(".day-tab")) {
                pulseContent([document.getElementById("selectedDayDate"), document.getElementById("selectedDayTitle"), document.getElementById("dayLessonCount"), document.getElementById("scheduleList")]);
            } else if (tab.matches(".report-tab")) {
                pulseContent([document.querySelector(".report-chart-panel .chart-wrap"), document.querySelector(".report-summary")]);
            } else {
                pulseContent([...document.querySelectorAll("#roomsGrid .room-card:not([hidden])")]);
            }
        }, 0);
    });

    document.addEventListener("keydown", event => {
        if (event.key !== "Enter" && event.key !== " ") return;
        const tab = event.target.closest?.(".tab-btn, .day-tab, .report-tab, [data-room-filter]");
        if (!tab) return;
        // O botão nativo emitirá também um click; esta classe dá feedback imediato ao teclado.
        tab.classList.add("ws-keyboard-focus");
        window.setTimeout(() => tab.classList.remove("ws-keyboard-focus"), 420);
    });

    document.addEventListener("keydown", event => {
        if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
        const current = event.target.closest?.('[role="tab"]');
        const group = current?.closest('[role="tablist"]');
        if (!group) return;
        const tabs = [...group.querySelectorAll('[role="tab"]:not(:disabled)')];
        const index = tabs.indexOf(current);
        if (index < 0 || tabs.length < 2) return;
        event.preventDefault();
        const direction = event.key === "ArrowRight" ? 1 : -1;
        const next = tabs[(index + direction + tabs.length) % tabs.length];
        next.focus();
        next.click();
    });

    mountLiveIndicator();
})();

/* Shell partilhado: identidade local, navegação azul, pesquisa e atalhos. */
(function () {
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };
    setText("userName", "Administrador");
    setText("userEmail", "Gestor do Sistema");

    const brand = document.querySelector(".side-head");
    if (brand) {
        const mark = brand.querySelector(".brand-logo");
        if (mark) mark.innerHTML = '<span class="brand-w" aria-hidden="true">W</span>';
        const subtitle = brand.querySelector(".brand-sub");
        if (subtitle) subtitle.textContent = "Monitorização de Rede e Ambiente";
    }

    const page = location.pathname.split("/").pop() || "dashboard.html";
    const nav = document.querySelector(".side-nav");
    const items = [
        { label: "Início", icon: "fa-house", href: "dashboard.html", pages: ["dashboard.html"] },
        { label: "Salas", icon: "fa-door-open", href: "rooms.html", pages: ["rooms.html"], hash: "roomsGrid" },
        { label: "PCs", icon: "fa-desktop", href: "pcs.html", pages: ["pcs.html"], hash: "networkDetails" },
        { label: "Rede", icon: "fa-globe", href: "pcs.html#networkDetails", pages: [], hash: "networkDetails" },
        { label: "Ambiente", icon: "fa-leaf", href: "rooms.html#roomsGrid", pages: [], hash: "roomsGrid" },
        { label: "Relatórios", icon: "fa-chart-column", href: "history.html", pages: ["history.html"] },
        { label: "Alertas", icon: "fa-bell", href: "dashboard.html#recentEvents", pages: [], hash: "recentEvents" },
        { label: "Definições", icon: "fa-gear", href: "admin.html", pages: ["admin.html"] }
    ];
    if (nav) {
        nav.innerHTML = items.map(item => {
            const sectionAlias = (page === "rooms.html" && location.hash === "#roomsGrid")
                || (page === "pcs.html" && location.hash === "#networkDetails")
                || (page === "dashboard.html" && location.hash === "#recentEvents");
            const routeActive = item.pages.includes(page) && !sectionAlias;
            const aliasActive = Boolean(item.hash && location.hash === `#${item.hash}` && ((page === "rooms.html" && item.label === "Ambiente") || (page === "pcs.html" && item.label === "Rede") || (page === "dashboard.html" && item.label === "Alertas")));
            const active = routeActive || aliasActive;
            const isAlerts = item.label === "Alertas";
            return `<a href="${item.href}" class="nav-link${active ? " active" : ""}${isAlerts ? " notification-link" : ""}"${active ? ' aria-current="page"' : ""}><i class="fa-solid ${item.icon}" aria-hidden="true"></i><span>${item.label}</span>${isAlerts ? '<span class="notification-count" hidden>0</span>' : ""}</a>`;
        }).join("");
    }

    const actions = document.querySelector(".topbar-actions");
    if (!actions) return;
    const placeholders = {
        "dashboard.html": "Pesquisar no Wellstate...",
        "rooms.html": "Pesquisar sala...",
        "schedule.html": "Pesquisar aula...",
        "pcs.html": "Pesquisar dispositivo...",
        "history.html": "Pesquisar evento...",
        "admin.html": "Pesquisar configuração..."
    };
    let search = actions.querySelector(".global-search") || document.querySelector(".global-search");
    if (!search) {
        search = document.createElement("label");
        search.className = "global-search";
        search.innerHTML = '<i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input type="search" aria-label="Pesquisar nesta página" />';
        actions.prepend(search);
    }
    const input = search.querySelector("input");
    if (input) {
        input.placeholder = placeholders[page] || "Pesquisar...";
        const searchable = ".portal-access-card, .room-card, .room-item, .device-card, .pc-card, .history-item, .lesson-card, .account-menu-item";
        const applySearch = () => {
            const term = input.value.trim().toLocaleLowerCase("pt-PT");
            document.querySelectorAll(searchable).forEach(item => {
                item.classList.toggle("search-hidden", Boolean(term) && !item.textContent.toLocaleLowerCase("pt-PT").includes(term));
            });
        };
        window.WellstateApplySearch = applySearch;
        input.addEventListener("input", () => {
            window.WELLSTATE_SEARCH = input.value.trim();
            applySearch();
            window.dispatchEvent(new CustomEvent("wellstate:search", { detail: window.WELLSTATE_SEARCH }));
        });
        new MutationObserver(applySearch).observe(document.querySelector("main") || document.body, { childList: true, subtree: true });
    }

    const utilities = document.querySelector(".header-utilities");
    if (!utilities) {
        const headerUtilities = document.createElement("div");
        headerUtilities.className = "header-utilities";
        headerUtilities.innerHTML = '<a class="utility-icon notification-action" href="dashboard.html#recentEvents" aria-label="Ver notificações recentes" title="Alertas"><i class="fa-regular fa-bell"></i><span class="notification-count" hidden>0</span></a><a class="header-avatar-link" href="admin.html" aria-label="Abrir definições da conta" title="Administrador"><i class="fa-solid fa-user"></i></a>';
        actions.appendChild(headerUtilities);
    }

    if ((page === "dashboard.html" && ["#recentEvents", "#operationalPanel"].includes(location.hash)) || (page === "pcs.html" && location.hash === "#networkDetails")) {
        const details = page === "dashboard.html" ? document.querySelector(".dashboard-live-details") : document.getElementById("networkDetails");
        if (details) details.open = true;
    }
    let installPrompt;
    window.addEventListener("beforeinstallprompt", event => {
        event.preventDefault();
        installPrompt = event;
        if (document.querySelector(".install-app-button")) return;
        const button = document.createElement("button");
        button.type = "button";
        button.className = "btn-ghost install-app-button";
        button.innerHTML = '<i class="fa-solid fa-download" aria-hidden="true"></i> Instalar app';
        button.addEventListener("click", async () => {
            if (!installPrompt) return;
            installPrompt.prompt();
            await installPrompt.userChoice;
            installPrompt = null;
            button.remove();
        });
        actions.append(button);
    });
})();

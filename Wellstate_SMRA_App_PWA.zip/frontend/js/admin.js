/* Wellstate · administração local de salas, PCs e horários, sem perfis ou aprovações. */
(function () {
    let STORE = window.WellstateStore.get();
    const DAYS = { 1: "Segunda", 2: "Terça", 3: "Quarta", 4: "Quinta", 5: "Sexta" };
    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);

    function tabActivate(name) {
        document.querySelectorAll(".tab-btn").forEach(button => {
            const selected = button.dataset.tab === name;
            button.classList.toggle("active", selected);
            button.setAttribute("aria-selected", String(selected));
            button.tabIndex = selected ? 0 : -1;
        });
        document.querySelectorAll(".tab-panel").forEach(panel => {
            const selected = panel.dataset.tab === name;
            panel.classList.toggle("active", selected);
            panel.hidden = !selected;
        });
    }
    document.querySelectorAll(".tab-btn").forEach(button => button.addEventListener("click", () => tabActivate(button.dataset.tab)));
    const requestedTab = location.hash.slice(1);
    const initialTab = document.querySelector(`.tab-panel[data-tab="${requestedTab}"]`) ? requestedTab : document.querySelector(".tab-panel.active")?.dataset.tab;
    if (initialTab) tabActivate(initialTab);
    const notificationButton = $("notificationsSetting");
    if (notificationButton) notificationButton.addEventListener("click", async () => {
        const label = $("notificationPermission");
        if (!("Notification" in window)) { label.textContent = "Notificações não suportadas neste navegador"; return; }
        try {
            const permission = await Notification.requestPermission();
            label.textContent = permission === "granted" ? "Alertas do navegador ativados" : permission === "denied" ? "Permissão bloqueada nas definições do navegador" : "Ativar alertas do navegador";
        } catch { label.textContent = "Não foi possível solicitar a permissão"; }
    });
    const accountThemeButton = $("accountThemeToggle");
    if (accountThemeButton) accountThemeButton.addEventListener("click", () => {
        $("themeToggle")?.click();
        const icon = accountThemeButton.querySelector(".setting-icon i");
        if (icon) icon.className = document.documentElement.getAttribute("data-theme") === "light" ? "fa-solid fa-sun" : "fa-solid fa-moon";
    });

    function renderRooms() {
        const body = $("roomsBody");
        body.replaceChildren();
        STORE.rooms.forEach((room, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `<td><input class="admin-input" value="${esc(room.id)}" aria-label="ID da sala" /></td><td><input class="admin-input" value="${esc(room.name)}" aria-label="Nome da sala" /></td><td class="row-actions"><button class="btn-ghost btn-sm" data-act="save" aria-label="Guardar sala"><i class="fa-solid fa-check"></i></button><button class="btn-ghost btn-sm danger" data-act="del" aria-label="Remover sala"><i class="fa-solid fa-trash"></i></button></td>`;
            row.querySelector('[data-act="save"]').addEventListener("click", () => {
                const [id, name] = [...row.querySelectorAll("input")].map(input => input.value.trim());
                if (!id || !name) return toast("Preenche o identificador e o nome da sala.");
                if (STORE.rooms.some((item, position) => position !== index && item.id === id)) return toast("Já existe uma sala com esse ID.");
                const oldId = STORE.rooms[index].id;
                STORE.rooms[index] = { id, name };
                if (oldId !== id) Object.values(STORE.schedule).forEach(list => list.forEach(lesson => { if (lesson.room === oldId) lesson.room = id; }));
                persist("Sala guardada.");
            });
            row.querySelector('[data-act="del"]').addEventListener("click", () => {
                if (!confirm(`Remover a sala ${room.name}?`)) return;
                STORE.rooms.splice(index, 1);
                persist("Sala removida.");
            });
            body.appendChild(row);
        });
    }

    function renderPcs() {
        const body = $("pcsBody");
        body.replaceChildren();
        const options = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        STORE.pcs.forEach((pc, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `<td><input class="admin-input" value="${esc(pc.id)}" aria-label="ID do computador" /></td><td><input class="admin-input" value="${esc(pc.name)}" aria-label="Nome do computador" /></td><td><input class="admin-input" value="${esc(pc.ip)}" aria-label="Endereço IP" /></td><td><select class="admin-input" aria-label="Sala">${options}</select></td><td class="row-actions"><button class="btn-ghost btn-sm" data-act="save" aria-label="Guardar computador"><i class="fa-solid fa-check"></i></button><button class="btn-ghost btn-sm danger" data-act="del" aria-label="Remover computador"><i class="fa-solid fa-trash"></i></button></td>`;
            row.querySelector("select").value = pc.roomId;
            row.querySelector('[data-act="save"]').addEventListener("click", () => {
                const fields = row.querySelectorAll("input,select");
                STORE.pcs[index] = { id: fields[0].value.trim(), name: fields[1].value.trim(), ip: fields[2].value.trim(), roomId: fields[3].value };
                persist("Registo local guardado neste navegador. A descoberta automática da API continua ativa.");
            });
            row.querySelector('[data-act="del"]').addEventListener("click", () => { if (confirm(`Remover ${pc.name}?`)) { STORE.pcs.splice(index, 1); persist("Computador removido."); } });
            body.appendChild(row);
        });
    }

    function renderSchedule() {
        const wrap = $("scheduleAdmin");
        wrap.replaceChildren();
        const options = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        [1, 2, 3, 4, 5].forEach(dayNumber => {
            const day = document.createElement("section");
            day.className = "day-block";
            day.innerHTML = `<div class="day-head"><h3><i class="fa-solid fa-calendar-day"></i> ${DAYS[dayNumber]}</h3><button class="btn-ghost btn-sm add-class"><i class="fa-solid fa-plus"></i> Aula</button></div><div class="day-rows"></div>`;
            const rows = day.querySelector(".day-rows");
            (STORE.schedule[dayNumber] || []).forEach((lesson, index) => {
                const row = document.createElement("div");
                row.className = "class-row admin-class-row";
                row.innerHTML = `<input class="admin-input" value="${esc(lesson.subject)}" placeholder="Disciplina" /><input class="admin-input" value="${esc(lesson.group || "")}" placeholder="Turma" /><input class="admin-input" value="${esc(lesson.teacher || "")}" placeholder="Docente" /><select class="admin-input">${options}</select><input type="time" class="admin-input" value="${esc(lesson.start)}" /><input type="time" class="admin-input" value="${esc(lesson.end)}" /><button class="btn-ghost btn-sm" data-act="save"><i class="fa-solid fa-check"></i></button><button class="btn-ghost btn-sm danger" data-act="del"><i class="fa-solid fa-trash"></i></button>`;
                row.querySelector("select").value = lesson.room;
                row.querySelector('[data-act="save"]').addEventListener("click", () => {
                    const fields = row.querySelectorAll("input,select");
                    if (fields[4].value >= fields[5].value) return toast("A hora de fim tem de ser posterior à hora de início.");
                    STORE.schedule[dayNumber][index] = { ...lesson, subject: fields[0].value.trim(), group: fields[1].value.trim(), teacher: fields[2].value.trim(), room: fields[3].value, start: fields[4].value, end: fields[5].value, updatedAt: new Date().toISOString(), updatedBy: "Wellstate" };
                    persist("Aula guardada.");
                });
                row.querySelector('[data-act="del"]').addEventListener("click", () => { STORE.schedule[dayNumber].splice(index, 1); persist("Aula removida."); });
                rows.appendChild(row);
            });
            day.querySelector(".add-class").addEventListener("click", () => {
                STORE.schedule[dayNumber] ||= [];
                STORE.schedule[dayNumber].push({ subject: "Nova aula", group: "Turma por definir", teacher: "Docente por definir", room: STORE.rooms[0]?.id || "", start: "08:15", end: "09:15" });
                persist("Aula adicionada.");
            });
            wrap.appendChild(day);
        });
    }

    $("addRoomBtn").addEventListener("click", () => {
        let number = 1;
        while (STORE.rooms.some(room => room.id === `NOVA.${String(number).padStart(2, "0")}`)) number++;
        STORE.rooms.push({ id: `NOVA.${String(number).padStart(2, "0")}`, name: "Nova sala" });
        persist("Sala adicionada.");
    });
    $("addPcBtn").addEventListener("click", () => {
        STORE.pcs.push({ id: `PC-NOVO-${STORE.pcs.length + 1}`, name: "Novo computador", ip: "", roomId: STORE.rooms[0]?.id || "" });
        persist("Computador adicionado.");
    });
    $("resetBtn").addEventListener("click", () => {
        if (!confirm("Repor salas, computadores e horários para os valores de demonstração?")) return;
        STORE = window.WellstateStore.reset();
        persist("Configuração de demonstração reposta.");
    });
    $("exportBtn").addEventListener("click", () => {
        const blob = new Blob([JSON.stringify(STORE, null, 2)], { type: "application/json" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "wellstate-config.json";
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    });
    $("importBtn").addEventListener("click", () => $("importFile").click());
    $("importFile").addEventListener("change", async event => {
        const file = event.target.files[0];
        if (!file) return;
        try {
            const data = JSON.parse(await file.text());
            if (!Array.isArray(data.rooms) || !Array.isArray(data.pcs) || !data.schedule || typeof data.schedule !== "object") throw new Error("Ficheiro inválido: são necessários salas, PCs e horários.");
            STORE = data;
            persist("Configuração importada.");
        } catch (error) { alert(error.message); }
        event.target.value = "";
    });

    function persist(message) {
        window.WellstateStore.save(STORE);
        STORE = window.WELLSTATE_STORE;
        renderAll();
        toast(message);
    }
    function renderAll() { renderRooms(); renderPcs(); renderSchedule(); }
    function toast(message) {
        let host = $("wellstate-toast-host");
        if (!host) { host = document.createElement("div"); host.id = "wellstate-toast-host"; host.className = "toast-host"; document.body.appendChild(host); }
        const element = document.createElement("div");
        element.className = "toast success";
        element.textContent = message;
        host.appendChild(element);
        setTimeout(() => element.classList.add("show"), 10);
        setTimeout(() => { element.classList.remove("show"); setTimeout(() => element.remove(), 400); }, 2400);
    }
    renderAll();
})();

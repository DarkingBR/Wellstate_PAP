import { apiClient } from "./api-client.js";

(function () {
    const CFG = window.WELLSTATE_CONFIG;
    const grid = document.getElementById("devicesGrid");
    const refresh = document.getElementById("refreshNetwork");
    const badge = document.getElementById("networkBadge");
    const note = document.getElementById("networkNote");
    const cidrInput = document.getElementById("networkCidrInput");
    let timer;
    let loading = false;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);

    const formatTime = value => value
        ? new Intl.DateTimeFormat("pt-BR", {
            timeZone: CFG.TIME_ZONE,
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hourCycle: "h23"
        }).format(new Date(value))
        : "—";

    function setBadge(connected, text) {
        badge.classList.toggle("connected", connected);
        badge.classList.toggle("disconnected", !connected);
        badge.replaceChildren(Object.assign(document.createElement("span"), { className: "pulse-dot" }), document.createTextNode(text));
        badge.title = connected ? `API REST ligada em ${CFG.API_BASE_URL}` : `API esperada em ${CFG.API_BASE_URL}/health. Confirma que o backend C# está ativo na porta 5080.`;
    }

    function updateSummary(pcs, devices, scan) {
        const discovered = Array.isArray(devices) ? devices : [];
        const foundIps = new Set(discovered.map(device => String(device.ip || "").toLowerCase()));
        const onlinePcs = pcs.filter(pc => pc.online || pc.agentOnline || pc.networkOnline || foundIps.has(String(pc.ip || "").toLowerCase()));
        document.getElementById("registeredCount").textContent = pcs.length;
        document.getElementById("onlineCount").textContent = onlinePcs.length;
        document.getElementById("offlineCount").textContent = pcs.length - onlinePcs.length;
        document.getElementById("deviceCount").textContent = discovered.length;
        document.getElementById("scanCidr").textContent = scan?.scanCidr || "—";
        document.getElementById("scanTime").textContent = scan?.scannedAt ? formatTime(scan.scannedAt) : "—";
    }

    function setHardware(id, valueId, detailId, { online, status, value, detail }) {
        const badge = document.getElementById(id);
        if (badge) {
            badge.className = `hardware-status ${online ? "online" : "offline"}`;
            badge.textContent = status;
        }
        const valueNode = document.getElementById(valueId);
        if (valueNode) valueNode.textContent = value;
        const detailNode = document.getElementById(detailId);
        if (detailNode) detailNode.textContent = detail;
    }

    function renderHardware(readings = []) {
        const freshnessMs = Math.max((CFG.POLL_INTERVAL_MS || 10000) * 3, 30000);
        const now = Date.now();
        const fresh = readings.filter(row => {
            const timestamp = Date.parse(row.updatedAt || "");
            return Number.isFinite(timestamp) && now - timestamp >= 0 && now - timestamp <= freshnessMs;
        });
        const pir = fresh.filter(row => typeof row.motion === "boolean");
        const climate = fresh.filter(row => typeof row.temperature === "number" || typeof row.humidity === "number");
        const distance = fresh.filter(row => typeof row.distance === "number" && row.distance >= 0);
        const average = (rows, key, suffix, decimals = 1) => {
            const values = rows.map(row => row[key]).filter(value => typeof value === "number");
            return values.length ? `${(values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(decimals)}${suffix}` : "—";
        };
        const recentText = `${fresh.length} ${fresh.length === 1 ? "sala" : "salas"} com telemetria recente`;
        const pirActive = pir.length > 0;
        const motion = pir.some(row => row.motion);
        setHardware("hwPirStatus", "hwPirValue", "hwPirDetail", { online: pirActive, status: pirActive ? "Ativo" : "Sem leitura", value: pirActive ? (motion ? "Movimento detetado" : "Sem movimento") : "—", detail: pirActive ? `${pir.length} ${pir.length === 1 ? "sensor" : "sensores"} com estado PIR válido` : "Nenhuma leitura PIR recente." });
        setHardware("hwDhtStatus", "hwDhtValue", "hwDhtDetail", { online: climate.length > 0, status: climate.length ? "Ativo" : "Sem leitura", value: climate.length ? `${average(climate, "temperature", "°C")} · ${average(climate, "humidity", "%", 0)}` : "—", detail: climate.length ? `${climate.length} ${climate.length === 1 ? "sala" : "salas"} com leitura ambiental` : "Nenhuma leitura DHT11 recente." });
        setHardware("hwDistanceStatus", "hwDistanceValue", "hwDistanceDetail", { online: distance.length > 0, status: distance.length ? "Ativo" : "Sem leitura", value: distance.length ? average(distance, "distance", " cm") : "—", detail: distance.length ? `${distance.length} ${distance.length === 1 ? "sala" : "salas"} com distância válida` : "Nenhuma leitura ultrassónica recente." });
        setHardware("hwBoardStatus", "hwBoardValue", "hwBoardDetail", { online: fresh.length > 0, status: fresh.length ? "Online" : "Sem telemetria", value: fresh.length ? recentText : "—", detail: fresh.length ? `Atualizada às ${formatTime(fresh.map(row => row.updatedAt).sort().at(-1))}` : "O estado depende da receção de telemetria do firmware." });
    }

    function createCard({ title, code, ip, online, detail, extra, deviceType = "unknown", discoveryMethod = "" }) {
        const card = document.createElement("article");
        card.className = "pc-card device-card";
        const badgeClass = online ? "online" : "offline";
        const statusText = online ? "Ligado" : "Desligado";
        const kinds = {
            computer: ["PC / computador", "fa-desktop", "computer"],
            mobile: ["Telemóvel / tablet", "fa-mobile-screen-button", "mobile"],
            network: ["Equipamento de rede", "fa-network-wired", "network"],
            unknown: ["Tipo não identificado", "fa-circle-question", "unknown"]
        };
        const [kindLabel, kindIcon, kindClass] = kinds[deviceType] || kinds.unknown;
        const methodLabel = discoveryMethod === "arp" ? "Tabela ARP · ping não necessário" : discoveryMethod === "icmp" ? "Resposta ICMP" : "Inventário registado";
        card.innerHTML = `
            <div class="device-card-head">
                <div class="device-icon" aria-hidden="true"><i class="fa-solid ${kindIcon}"></i></div>
                <span class="status-badge ${badgeClass}">${statusText}</span>
            </div>
            <div class="device-main">
                <span class="pc-code">${esc(code)}</span>
                <h3>${esc(title)}</h3>
                <span class="device-kind ${kindClass}"><i class="fa-solid ${kindIcon}" aria-hidden="true"></i>${kindLabel}</span>
                <div class="ip">${esc(ip || "IP não configurado")}</div>
            </div>
            <div class="device-latency">${esc(detail)}</div>
            <div class="device-extra">${esc(extra)}${methodLabel ? ` · ${esc(methodLabel)}` : ""}</div>`;
        return card;
    }

    function displayDeviceName(device) {
        const dnsName = String(device?.hostname || device?.name || "").trim();
        if (dnsName) return dnsName;
        const ip = String(device?.ip || "").trim();
        const suffix = ip.split(".").pop();
        return /^\d+$/.test(suffix) ? `Dispositivo-${suffix.padStart(2, "0")}` : "Dispositivo sem nome";
    }

    function classifyDevice(device) {
        const reported = String(device?.deviceType || "").toLowerCase();
        if (["computer", "pc", "desktop", "laptop"].includes(reported)) return "computer";
        if (["mobile", "phone", "tablet"].includes(reported)) return "mobile";
        if (["network", "router", "printer", "iot"].includes(reported)) return "network";
        const name = String(device?.hostname || device?.name || "").toLowerCase();
        if (/(iphone|ipad|android|mobile|phone|pixel|galaxy|redmi|xiaomi|huawei|oneplus|oppo|vivo)/.test(name)) return "mobile";
        if (/(desktop|workstation|laptop|notebook|pc[-_0-9]|win[-_0-9]|macbook|imac)/.test(name)) return "computer";
        return "unknown";
    }

    function render(pcs, devices) {
        const foundByIp = new Map(devices.map(device => [String(device.ip || "").toLowerCase(), device]));
        const knownIps = new Set(pcs.map(pc => String(pc.ip || "").toLowerCase()));
        const cards = [];

        for (const pc of pcs) {
            const found = foundByIp.get(String(pc.ip || "").toLowerCase());
            const agentOnline = Boolean(pc.agentOnline);
            const networkOnline = Boolean(pc.networkOnline || found);
            const online = Boolean(pc.online || agentOnline || networkOnline);
            const proof = agentOnline
                ? "Agente Wellstate conectado"
                : networkOnline
                    ? `Resposta na rede${pc.responseMs != null ? ` · ${esc(pc.responseMs)} ms` : ""}`
                    : "Sem resposta de rede ou heartbeat";
            const lastSeen = pc.lastSeenAt ? `Último heartbeat: ${formatTime(pc.lastSeenAt)}` : "Agente sem heartbeat";
            cards.push(createCard({
                title: pc.name || pc.id || "PC cadastrado",
                code: `PC ${pc.id || "—"}`,
                ip: pc.ip,
                online,
                detail: proof,
                extra: lastSeen,
                deviceType: "computer"
            }));
        }

        for (const device of devices) {
            if (knownIps.has(String(device.ip || "").toLowerCase())) continue;
            cards.push(createCard({
                title: displayDeviceName(device),
                code: `LAN · ${device.discoveryMethod === "arp" ? "vizinho" : "ativo"}`,
                ip: device.ip,
                online: true,
                detail: `Resposta na rede${device.responseMs != null ? ` · ${esc(device.responseMs)} ms` : ""}`,
                extra: device.macAddress ? `MAC ${device.macAddress}` : "Encontrado na LAN",
                deviceType: classifyDevice(device),
                discoveryMethod: device.discoveryMethod
            }));
        }

        if (cards.length === 0) {
            const empty = document.createElement("div");
            empty.className = "chip wide";
            empty.textContent = pcs.length === 0
                ? "Nenhum PC registado e nenhum dispositivo respondeu. A API continua a verificar automaticamente a LAN a cada 30 segundos."
                : "Nenhum dispositivo respondeu ao scan. PCs cadastrados aparecem acima mesmo quando estão offline.";
            grid.replaceChildren(empty);
            return;
        }

        grid.replaceChildren(...cards);
    }

    async function loadNetwork(force = false, quiet = false) {
        if (loading) return;
        loading = true;
        if (!quiet) {
            refresh.disabled = true;
            refresh.textContent = "Verificando…";
        }

        try {
            const [pcsResult, scanResult, readingsResult] = await Promise.allSettled([
                apiClient.getPcs(),
                apiClient.getNetworkDevices({ refresh: force, cidr: cidrInput?.value || "" }),
                apiClient.getLatestRooms()
            ]);
            const pcs = pcsResult.status === "fulfilled" && Array.isArray(pcsResult.value) ? pcsResult.value : [];
            const scan = scanResult.status === "fulfilled" ? scanResult.value : null;
            const devices = Array.isArray(scan?.devices) ? scan.devices : [];
            const readings = readingsResult.status === "fulfilled" && Array.isArray(readingsResult.value) ? readingsResult.value : [];
            renderHardware(readings);

            if (pcsResult.status === "rejected" && scanResult.status === "rejected" && readingsResult.status === "rejected") {
                throw pcsResult.reason || scanResult.reason || readingsResult.reason || new Error("Não foi possível consultar a API.");
            }

            updateSummary(pcs, devices, scan);
            render(pcs, devices);

            if (scan) {
                const mode = scan.automaticallyDetected ? "automática" : "configurada";
                const limitNote = scan.scanLimited ? ` · scan limitado a ${scan.hostsScanned} de ${scan.hostsAvailable} endereços` : "";
                const inventoryWarning = pcsResult.status === "rejected"
                    ? ` O inventário cadastrado falhou: ${pcsResult.reason?.message || "erro desconhecido"}.`
                    : "";
                setBadge(true, inventoryWarning ? "LAN ligada · inventário com erro" : "API e rede ligadas");
                note.textContent = `Sub-rede ${mode}: ${scan.scanCidr} · interface ${scan.interfaceName || "—"} · servidor ${scan.serverAddress || "—"}${limitNote}. O scan ocorre na LAN/VPN do servidor; ICMP bloqueado pode exigir o agente Wellstate.${inventoryWarning}`;
            } else {
                setBadge(pcsResult.status === "fulfilled", "API ligada · scan LAN indisponível");
                note.textContent = scanResult.reason?.message || "A API respondeu, mas não foi possível descobrir uma rede privada no servidor. Confira Wi-Fi, VPN ou configure o CIDR manualmente.";
            }
        } catch (error) {
            renderHardware([]);
            setBadge(false, "API indisponível");
            grid.innerHTML = `<div class="chip wide">${esc(error?.message || "Não foi possível verificar a API.")}</div>`;
            note.textContent = `${error?.message || "Confirma se o backend C# está ativo e se o navegador alcança a porta 5080."} Testa ${CFG.API_BASE_URL}/health.`;
        } finally {
            loading = false;
            if (!quiet) {
                refresh.disabled = false;
                refresh.textContent = "Atualizar agora";
            }
        }
    }

    refresh.addEventListener("click", () => loadNetwork(true, false));
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) loadNetwork(false, true);
    });
    loadNetwork(false);
    timer = window.setInterval(() => {
        if (!document.hidden) loadNetwork(false, true);
    }, CFG.NETWORK_POLL_INTERVAL_MS || 30000);
    window.addEventListener("beforeunload", () => clearInterval(timer));
})();

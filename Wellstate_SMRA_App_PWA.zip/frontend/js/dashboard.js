import { apiClient } from "./api-client.js";

const CFG = window.WELLSTATE_CONFIG;
let SCHEDULE = window.SCHEDULE || {};
let STORE = window.WELLSTATE_STORE;
let roomsCache = {};
let presenceHistory = [];
let apiOnline = false;
let pcsLoading = false;
let presenceLoading = false;
let roomsLoading = false;
let roomPollTimer = null;
const setText = (id, value) => { const element = document.getElementById(id); if (element) element.textContent = value; };
const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const fmtHM = date => window.WellstateClock.formatTime(date);
const roomIdFromKey = key => (STORE.rooms || []).find(room => room.id === key)?.id || key;

function updateDashboardClock() {
    setText("dateNow", window.WellstateClock.formatDate());
    setText("clockNow", window.WellstateClock.formatTime());
}
updateDashboardClock();
window.setInterval(updateDashboardClock, 1000);

function setApiBadge(online, label) {
    apiOnline = online;
    const badge = document.getElementById("apiStatus");
    if (!badge) return;
    badge.classList.toggle("is-offline", !online);
    badge.innerHTML = `<span class="pulse-dot"></span> ${esc(label)}`;
    if (online) badge.removeAttribute("title");
}

function isClassNow(lesson) {
    if (!lesson?.start || !lesson?.end) return false;
    const [startHour, startMinute] = lesson.start.split(":").map(Number);
    const [endHour, endMinute] = lesson.end.split(":").map(Number);
    const current = window.WellstateClock.parts();
    return current.minuteOfDay >= startHour * 60 + startMinute && current.minuteOfDay < endHour * 60 + endMinute;
}

function classForRoomNow(roomId) {
    return (SCHEDULE[window.WellstateClock.parts().day] || []).find(lesson => lesson.room === roomId && isClassNow(lesson));
}
function roomLabel(id) { return STORE.rooms.find(room => room.id === id)?.name || `Sala ${id}`; }

const roomList = document.getElementById("roomList");
const pcList = document.getElementById("pcList");

function renderRoomsMini() {
    if (!roomList) return;
    const configured = STORE.rooms || [];
    const ids = [...new Set([...configured.map(room => room.id), ...Object.keys(roomsCache)])];
    if (!ids.length) {
        roomList.innerHTML = '<div class="chip">Ainda não existem salas configuradas.</div>';
        return;
    }
    roomList.replaceChildren();
    ids.forEach(roomId => {
        const sensor = roomsCache[roomId] || {};
        const lesson = classForRoomNow(roomId);
        const occupied = Boolean(sensor.occupied) && Boolean(lesson);
        const hasReading = Boolean(sensor.updatedAt);
        const badge = !hasReading
            ? '<span class="status-badge offline"><i class="fa-solid fa-circle"></i> Sem leitura</span>'
            : occupied
                ? '<span class="status-badge occupied"><i class="fa-solid fa-circle"></i> Ocupada</span>'
                : sensor.motion
                    ? '<span class="status-badge motion"><i class="fa-solid fa-person-walking"></i> Movimento</span>'
                    : '<span class="status-badge free"><i class="fa-solid fa-check"></i> Sem movimento</span>';
        const row = document.createElement("div");
        row.className = "room-item";
        row.innerHTML = `<div class="left"><div class="icon"><i class="fa-solid fa-door-open"></i></div><div><div class="name">${esc(roomLabel(roomId))}</div><div class="sub">${lesson ? `${esc(lesson.subject)} · ${esc(lesson.group || "Turma por definir")}` : "Sem aula prevista"}</div></div></div><div class="metrics"><span class="metric"><strong>${esc(sensor.temperature ?? "—")}</strong>°C</span><span class="metric"><strong>${esc(sensor.humidity ?? "—")}</strong>%</span><span class="metric"><strong>${esc(sensor.distance ?? "—")}</strong> cm</span><span class="metric"><strong>PIR</strong> ${sensor.motion ? "Presença" : "Sem presença"}</span>${badge}</div>`;
        roomList.appendChild(row);
    });
}

async function loadPcs() {
    if (pcsLoading) return;
    pcsLoading = true;
    try {
        const result = await apiClient.get("/network/devices");
        const devices = Array.isArray(result?.devices) ? result.devices : [];
        renderPcsMini(devices);
        setText("kpiPcsOn", devices.filter(device => device.online).length);
        setApiBadge(true, "API REST ligada");
    } catch (error) {
        setText("kpiPcsOn", "—");
        try {
            await apiClient.getHealth();
            setApiBadge(true, "API ligada · scan indisponível");
            if (pcList) pcList.innerHTML = `<div class="chip">A API responde, mas a descoberta de rede falhou: ${esc(error?.message || "verifica a interface de rede ou ICMP.")}</div>`;
            const badge = document.getElementById("apiStatus");
            if (badge) badge.title = `API alcançável em ${CFG.API_BASE_URL}; endpoint de descoberta com erro.`;
        } catch {
            renderPcsMini([], true);
            setApiBadge(false, "API indisponível");
            const badge = document.getElementById("apiStatus");
            if (badge) badge.title = `${error?.message || "Sem resposta do backend."} Endpoint: ${CFG.API_BASE_URL}/health`;
        }
    } finally {
        pcsLoading = false;
        setText("pcsUpdated", `Atualizado ${fmtHM(new Date())}`);
    }
}

function renderPcsMini(devices, localMode = false) {
    if (!pcList) return;
    if (!devices.length) {
        pcList.innerHTML = `<div class="chip">${localMode ? "API indisponível." : "Nenhum dispositivo encontrado."}</div>`;
        return;
    }
    pcList.replaceChildren();
    devices.slice(0, 8).forEach(device => {
        const row = document.createElement("div");
        row.className = "pc-item";
        const deviceLabel = String(device.hostname || device.name || "").trim() || `PC-${String(device.ip || "").split(".").pop()?.padStart(2, "0") || "LAN"}`;
        row.innerHTML = `<div class="left"><div class="icon">●</div><div><div class="name">${esc(deviceLabel)}</div><div class="sub">${esc(device.ip)} · ${esc(device.responseMs ?? "—")} ms</div></div></div><span class="status-badge online">Ligado</span>`;
        pcList.appendChild(row);
    });
}

function computeKpis() {
    const entries = Object.entries(roomsCache);
    const roomIds = [...new Set([...(STORE.rooms || []).map(room => room.id), ...entries.map(([id]) => id)])];
    const totalRooms = roomIds.length;
    const freshAfter = Date.now() - Math.max(300000, (Number(CFG.POLL_INTERVAL_MS) || 15000) * 5);
    const activeRooms = roomIds.filter(roomId => Date.parse(roomsCache[roomId]?.updatedAt) >= freshAfter).length;
    setText("kpiRooms", activeRooms);
    setText("kpiRoomTotal", totalRooms);
    let occupied = 0;
    let temperatureTotal = 0;
    let temperatureCount = 0;
    let humidityTotal = 0;
    let humidityCount = 0;
    entries.forEach(([roomId, sensor]) => {
        if (sensor.occupied && classForRoomNow(roomId)) occupied++;
        if (typeof sensor.temperature === "number") { temperatureTotal += sensor.temperature; temperatureCount++; }
        if (typeof sensor.humidity === "number") { humidityTotal += sensor.humidity; humidityCount++; }
    });
    setText("kpiOccupied", occupied);
    setText("kpiTemp", temperatureCount ? `${(temperatureTotal / temperatureCount).toFixed(1)}°C` : "—");
    setText("kpiHumidity", humidityCount ? `${(humidityTotal / humidityCount).toFixed(0)}%` : "—");
}

function renderScheduleStrip() {
    const lessons = (SCHEDULE[window.WellstateClock.parts().day] || []).slice().sort((first, second) => first.start.localeCompare(second.start));
    const strip = document.getElementById("scheduleStrip");
    if (!strip) return;
    if (!lessons.length) {
        strip.innerHTML = '<div class="chip">Sem aulas hoje.</div>';
        setText("scheduleToday", "0 aulas");
        return;
    }
    setText("scheduleToday", `${lessons.length} aulas`);
    strip.replaceChildren();
    lessons.forEach(lesson => {
        const active = isClassNow(lesson);
        const item = document.createElement("div");
        item.className = `class-card ${active ? "now" : ""}`;
        item.innerHTML = `<span class="time">${esc(lesson.start)} — ${esc(lesson.end)}</span><span class="subject">${esc(lesson.subject)}${active ? ' <span class="now-badge">AGORA</span>' : ""}</span><span class="room"><i class="fa-solid fa-door-open"></i> ${esc(roomLabel(lesson.room))}</span><span class="room">${esc(lesson.group || "Turma por definir")} · ${esc(lesson.teacher || "Docente por definir")}</span>`;
        strip.appendChild(item);
    });
}

function renderPresenceChart() {
    const chart = document.getElementById("presenceChart");
    if (!chart) return;
    const roomIds = [...new Set([...(STORE.rooms || []).map(room => room.id), ...presenceHistory.map(row => row.roomId)])];
    if (!roomIds.length || !presenceHistory.length) {
        chart.innerHTML = '<div class="chart-empty">Sem leituras de histórico nas últimas 24 horas.</div>';
        setText("presenceFoot", "O gráfico aparece quando a API tiver medições registadas.");
        return;
    }
    const stats = roomIds.map(roomId => {
        const rows = presenceHistory.filter(row => row.roomId === roomId);
        return { roomId, occupied: rows.filter(row => Boolean(row.occupied)).length, free: rows.filter(row => !row.occupied).length };
    });
    const max = Math.max(1, ...stats.map(item => item.occupied + item.free));
    chart.replaceChildren();
    stats.forEach(item => {
        const group = document.createElement("div");
        group.className = "chart-column";
        const bars = document.createElement("div");
        bars.className = "chart-bars";
        [[item.occupied, "present", "Leituras ocupadas"], [item.free, "", "Leituras livres / sem ocupação"]].forEach(([count, style, label]) => {
            const bar = document.createElement("span");
            bar.className = `chart-bar ${style}`.trim();
            bar.style.height = `${count ? Math.max(4, (count / max) * 78) : 2}px`;
            bar.title = `${label}: ${count}`;
            bars.appendChild(bar);
        });
        const caption = document.createElement("span");
        caption.className = "chart-label";
        caption.textContent = item.roomId;
        caption.title = roomLabel(item.roomId);
        group.append(bars, caption);
        chart.appendChild(group);
    });
    const total = presenceHistory.length;
    setText("presenceFoot", `${total} leituras · ${roomIds.length} salas · ${window.WellstateClock.zone}`);
}

function renderOccupancySummary() {
    const ids = [...new Set([...(STORE.rooms || []).map(room => room.id), ...Object.keys(roomsCache)])];
    const occupied = ids.filter(roomId => Boolean(roomsCache[roomId]?.occupied) && Boolean(classForRoomNow(roomId))).length;
    const total = ids.length;
    const percent = total ? Math.round((occupied / total) * 100) : 0;
    const ring = document.getElementById("occupancyRing");
    if (ring) ring.style.setProperty("--ring-percent", `${percent}%`);
    setText("occupancyPercent", `${percent}%`);
    setText("occupancyCount", occupied);
    setText("vacantCount", Math.max(0, total - occupied));
    const readings = ids.filter(roomId => Boolean(roomsCache[roomId]?.updatedAt)).length;
    setText("occupancyNote", `${readings} de ${total} salas com leitura. Ocupação considera sensor e aula ativa.`);
}

function renderRecentEvents() {
    const list = document.getElementById("recentEvents");
    if (!list) return;
    const rows = Object.entries(roomsCache)
        .filter(([, reading]) => reading.updatedAt)
        .sort((first, second) => (Date.parse(second[1].updatedAt) || 0) - (Date.parse(first[1].updatedAt) || 0))
        .slice(0, 5);
    if (!rows.length) {
        list.innerHTML = '<div class="chart-empty">Aguardando dados das salas…</div>';
        return;
    }
    list.replaceChildren();
    rows.forEach(([roomId, reading]) => {
        const event = reading.occupied ? "Ocupação detetada" : reading.motion ? "Movimento detetado" : "Leitura ambiental";
        const icon = reading.occupied ? "fa-users" : reading.motion ? "fa-person-walking" : "fa-temperature-half";
        const item = document.createElement("div");
        item.className = "recent-event";
        const stamp = new Date(reading.updatedAt);
        item.innerHTML = `<span class="event-icon"><i class="fa-solid ${icon}"></i></span><span><strong>${esc(event)} · ${esc(roomLabel(roomId))}</strong><small>${esc(reading.temperature ?? "—")} °C · ${esc(reading.humidity ?? "—")} % humidade</small></span><time>${esc(fmtHM(stamp))}</time>`;
        list.appendChild(item);
    });
}

function renderNotificationCount() {
    const count = Object.entries(roomsCache).filter(([roomId, reading]) =>
        (reading.occupied || reading.motion) && !classForRoomNow(roomId)
    ).length;
    document.querySelectorAll(".notification-count").forEach(badge => {
        badge.textContent = String(count);
        badge.hidden = count === 0;
    });
}

async function loadPresenceHistory() {
    if (presenceLoading) return;
    presenceLoading = true;
    try {
        presenceHistory = await apiClient.getHistory({ limit: 600, from: new Date(Date.now() - 24 * 60 * 60 * 1000), to: new Date() });
        renderPresenceChart();
    } catch {
        const chart = document.getElementById("presenceChart");
        if (chart) chart.innerHTML = '<div class="chart-empty">Histórico indisponível. Verifique a ligação à API.</div>';
        setText("presenceFoot", "Não foi possível carregar o histórico.");
    } finally {
        presenceLoading = false;
    }
}

async function refreshRooms() {
    if (roomsLoading) return;
    roomsLoading = true;
    try {
        const readings = await apiClient.getLatestRooms();
        roomsCache = Object.fromEntries(readings.map(reading => [reading.roomId, reading]));
        setApiBadge(true, "API REST ligada");
        renderRoomsMini();
        computeKpis();
        renderOccupancySummary();
        renderRecentEvents();
        renderNotificationCount();
        const newest = readings.reduce((latest, row) => Math.max(latest, Date.parse(row.updatedAt) || 0), 0);
        setText("roomsUpdated", newest ? `Última medição ${fmtHM(new Date(newest))}` : "A aguardar medições");
        if (window.WellstateNotify) readings.forEach(room => window.WellstateNotify.checkRoom(room.roomId, room));
    } catch (error) {
        setApiBadge(false, "API REST indisponível");
        setText("roomsUpdated", "A tentar reconectar");
        renderRoomsMini();
        renderOccupancySummary();
        renderRecentEvents();
        renderNotificationCount();
    } finally {
        roomsLoading = false;
    }
}

async function pollRooms() {
    await refreshRooms();
    roomPollTimer = window.setTimeout(pollRooms, document.hidden ? Math.max(CFG.POLL_INTERVAL_MS, 30000) : CFG.POLL_INTERVAL_MS);
}

document.addEventListener("visibilitychange", () => {
    if (document.hidden) return;
    window.clearTimeout(roomPollTimer);
    pollRooms();
    loadPcs();
    loadPresenceHistory();
});
window.addEventListener("online", () => {
    if (document.hidden) return;
    window.clearTimeout(roomPollTimer);
    pollRooms();
    loadPcs();
    loadPresenceHistory();
});

window.addEventListener("wellstate:store-updated", event => {
    STORE = event.detail;
    SCHEDULE = STORE.schedule;
    renderRoomsMini();
    renderScheduleStrip();
    computeKpis();
    renderOccupancySummary();
    renderNotificationCount();
});

renderScheduleStrip();
renderRoomsMini();
computeKpis();
renderOccupancySummary();
renderRecentEvents();
renderNotificationCount();
loadPcs();
loadPresenceHistory();
window.setInterval(() => { if (!document.hidden) loadPresenceHistory(); }, CFG.HISTORY_POLL_INTERVAL_MS || 30000);
window.setInterval(() => { if (!document.hidden) loadPcs(); }, CFG.NETWORK_POLL_INTERVAL_MS || 30000);
window.setInterval(() => {
    if (document.hidden) return;
    renderScheduleStrip();
    renderRoomsMini();
    computeKpis();
    renderOccupancySummary();
    renderNotificationCount();
}, 10000);
pollRooms();

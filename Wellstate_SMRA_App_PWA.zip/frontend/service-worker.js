/* PWA shell: páginas e recursos offline; chamadas /api nunca são cacheadas. */
const CACHE = "wellstate-pwa-shell-v7";
const STATIC = [
  "./manifest.webmanifest",
  "./assets/icon-192.png",
  "./assets/icon-512.png",
  "./assets/wellstate-smra-logo.png",
  "./assets/portal-hero-circuit.png",
  "./assets/portal-control-preview.png",
  "./css/style.css", "./css/dashboard.css", "./css/admin.css", "./css/auth.css",
  "./css/professional.css", "./css/monochrome-performance.css", "./css/reference-ui.css",
  "./css/portal-blue.css", "./css/wellstate-overhaul.css", "./css/realtime-polish.css",
  "./css/schedule.css", "./css/schedule-refinements.css",
  "./js/theme.js", "./js/clock.js", "./js/data-store.js", "./js/schedule-data.js", "./js/notifications.js",
  "./js/realtime-ui.js",
  "./js/config.js",
  "./js/api-client.js",
  "./js/app-shell.js",
  "./js/dashboard.js",
  "./js/rooms.js",
  "./js/pcs.js",
  "./js/history.js",
  "./js/schedule.js",
  "./js/admin.js"
];
self.addEventListener("install", event => event.waitUntil(caches.open(CACHE).then(async cache => {
  await Promise.all(STATIC.map(async path => { try { await cache.add(path); } catch { /* Recurso opcional ausente não bloqueia a instalação. */ } }));
}).then(() => self.skipWaiting())));
self.addEventListener("activate", event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith("wellstate-") && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener("fetch", event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.pathname.includes("/api/") || url.pathname.startsWith("/auth/") || url.origin !== self.location.origin) return;
  if (request.mode === "navigate") {
    event.respondWith(fetch(request).then(response => {
      return response;
    }).catch(() => new Response('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#111923"><title>Wellstate · Offline</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#111923;color:#e6eef3;font:16px system-ui}main{max-width:30rem;padding:2rem}h1{font-size:1.5rem}p{color:#aabac3;line-height:1.6}a{color:#59d7cb}</style><main><h1>Sem ligação à rede</h1><p>O Wellstate precisa de conexão ao servidor para abrir as páginas e carregar os dados. Verifica a rede local e tenta novamente.</p><a href="./dashboard.html">Tentar abrir o app</a></main></html>', { headers: { "Content-Type": "text/html; charset=utf-8" } })));
    return;
  }
  event.respondWith(caches.match(request).then(cached => {
    const network = fetch(request).then(response => {
      if (response.ok) caches.open(CACHE).then(cache => cache.put(request, response.clone()));
      return response;
    });
    return cached || network;
  }).catch(() => caches.match(request)));
});

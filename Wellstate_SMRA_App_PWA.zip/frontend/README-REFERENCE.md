# Tema visual de referência

`css/portal-blue.css` aplica a nova identidade Wellstate inspirada na referência azul-noite: navegação lateral compacta, marca azul, busca global, acentos elétricos e cartões com contornos azuis. A entrada apresenta um portal com hero de monitorização, atalhos para Salas, PCs, Rede e Ambiente e um painel ilustrativo de operações.

O painel operacional real permanece disponível abaixo em “Painel operacional em tempo real”. Os IDs consumidos pelos scripts de dashboard foram preservados; sensores e métricas só mostram dados recebidos pela API, sem amostras de demonstração. As páginas de salas, horários, dispositivos, relatórios e configurações compartilham o novo tema e mantêm seus filtros, pesquisa e ações existentes. A navegação oferece atalhos sem substituir nem remover as páginas operacionais.

As imagens do hero e da faixa inferior são assets locais em `assets/portal-hero-circuit.png` e `assets/portal-control-preview.png`. O service worker usa um novo cache para entregar a identidade atualizada quando o app for instalado como PWA.

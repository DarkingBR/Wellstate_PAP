# Wellstate SMRA

Portal local de monitorização. O projeto mantém o frontend em HTML/CSS/JavaScript, a API em C#/.NET e o portal/autenticação em PHP.

## Pastas principais

- `frontend/` — páginas HTML, estilos CSS, JavaScript e recursos visuais.
- `backend-csharp/` — API REST, descoberta de rede e telemetria.
- `server/` — router PHP, autenticação e proxy same-origin `/api` para a API C#.
- `firmware/` — firmware de referência dos sensores, se o projeto usar a placa.

Não é necessário abrir nem editar ficheiros de configuração num editor de texto para iniciar o portal. Os endereços padrão já estão configurados automaticamente.

## Iniciar no Windows

Requisitos: .NET 8 SDK e PHP 8.1 ou superior com `pdo_sqlite` ativo.

1. Abre dois terminais na raiz do projeto (por exemplo, os terminais integrados do VS Code).
2. No primeiro, inicia a API C#:

   ```powershell
   dotnet run --project .\backend-csharp\Wellstate.API.csproj --urls http://0.0.0.0:5080
   ```

3. No segundo, inicia o portal PHP:

   ```powershell
   php -S 0.0.0.0:8080 -t . server/router.php
   ```

4. Abre `http://localhost:8080/` no navegador e entra ou cria uma conta.

O portal usa automaticamente o proxy PHP em `/api`, pela mesma origem. Isto evita depender de CORS para as páginas servidas pelo PHP. Se o backend C# parar, o portal mostra o estado de ligação e volta a tentar automaticamente com intervalos progressivos.

## Instalar como app no PC e telemóvel (PWA)

1. Inicia os dois serviços acima no computador/servidor ligado à rede local.
2. No PC ou telemóvel conectado à mesma rede, abre `http://IP-DO-SERVIDOR:8080/` (não use `localhost` no telemóvel).
3. Inicia sessão. No Chrome/Edge usa **Instalar app** ou o menu **Instalar Wellstate**; no iPhone/iPad, Safari → **Partilhar** → **Adicionar ao ecrã principal**.
4. A instalação PWA exige HTTPS, exceto `localhost`; para uso em rede, recomenda-se HTTPS em Apache/Nginx. Recursos estáticos ficam disponíveis em cache, mas as páginas autenticadas e os dados da API exigem rede — por segurança, o app não guarda páginas privadas offline.

## Inventário e limites de descoberta

A descoberta é executada na máquina que hospeda o backend .NET, não no navegador do utilizador. Combina resposta ICMP com a tabela ARP do servidor para alcançar alguns dispositivos que bloqueiam ping. Os cartões mostram computadores/telemóveis quando o nome do host permite inferir o tipo; caso contrário indicam **Tipo não identificado** em vez de adivinhar. Wi-Fi com isolamento entre clientes, firewalls, IPv6, redes guest/VLAN ou uma tabela ARP sem entradas impedem qualquer app comum de garantir uma enumeração completa; para cobertura confiável, reserve IPs e instale um agente/integração no router.

Se a ligação continuar indisponível, teste `http://IP-DO-SERVIDOR:8080/api/health` e `http://IP-DO-SERVIDOR:5080/api/health`; confirme que os dois processos estão ativos e que a firewall permite as portas 8080 e 5080 apenas na LAN.

## Usar o Live Server

Também podes iniciar apenas a API C# com o primeiro comando e abrir `frontend/pcs.html` pelo Live Server. A API é detetada na porta 5080 do mesmo computador; o CORS do backend aceita apenas origens loopback para este modo local. Não abras as páginas com `file://`.

## Verificar a ligação

- Com o portal PHP: `http://localhost:8080/api/health`
- Diretamente na API: `http://localhost:5080/api/health`

O inventário de rede atualiza automaticamente a cada 30 segundos; a descoberta testa a rede ativa do computador onde está a API. A página de salas e o dashboard renovam as leituras a cada 10 segundos. Firewalls podem impedir respostas ICMP de alguns dispositivos.

## Segurança

Mantém a porta 5080 acessível apenas na LAN/VPN necessária; não publiques a API diretamente na Internet. As credenciais reais de sensores e agentes devem ficar em variáveis de ambiente, nunca neste ZIP.

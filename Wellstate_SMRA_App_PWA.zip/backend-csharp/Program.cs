using Wellstate.API.Services;
using System.Net;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<PingService>();
builder.Services.AddSingleton<PcRepository>();
builder.Services.AddSingleton<PcPresenceService>();
builder.Services.AddSingleton<SignalRepository>();
builder.Services.AddSingleton<SignalService>();
builder.Services.AddSingleton<RoomTelemetryRepository>();
builder.Services.AddSingleton<NetworkSubnetResolver>();
builder.Services.AddSingleton<NetworkDiscoveryService>();

builder.Services.AddCors(options => options.AddPolicy("wellstate", policy =>
    policy.SetIsOriginAllowed(origin =>
            Uri.TryCreate(origin, UriKind.Absolute, out var uri) &&
            (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps) &&
            (uri.IsLoopback || (IPAddress.TryParse(uri.Host, out var address) && NetworkSubnet.IsPrivateAddress(address))))
        .AllowAnyMethod()
        .AllowAnyHeader()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("wellstate");
// O portal PHP encaminha /api pela mesma origem; o CORS privado suporta Live Server
// em PC/telemóvel na LAN. Mantém a porta 5080 limitada à rede confiável na firewall.
app.MapControllers();
app.Run("http://0.0.0.0:5080");

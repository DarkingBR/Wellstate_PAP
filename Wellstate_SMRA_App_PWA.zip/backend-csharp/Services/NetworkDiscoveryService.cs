using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using Wellstate.API.Models;

namespace Wellstate.API.Services;

public sealed record NetworkScanResult(
    string ScanCidr,
    DateTimeOffset ScannedAt,
    IReadOnlyList<NetworkDevice> Devices,
    bool AutomaticallyDetected,
    string InterfaceName,
    string? ServerAddress,
    string? Gateway,
    int HostsScanned,
    long HostsAvailable,
    bool ScanLimited);

/// <summary>Descobre apenas hosts de uma sub-rede privada ligada ao servidor; nunca varre a Internet pública.</summary>
public sealed class NetworkDiscoveryService
{
    private readonly NetworkSubnetResolver _subnetResolver;
    private readonly int _timeoutMs;
    private readonly int _maxHosts;
    private readonly int _parallelism;
    private readonly TimeSpan _cacheDuration;
    private readonly SemaphoreSlim _scanLock = new(1, 1);
    private NetworkScanResult? _cached;

    public NetworkDiscoveryService(IConfiguration configuration, NetworkSubnetResolver subnetResolver)
    {
        _subnetResolver = subnetResolver;
        _timeoutMs = Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:PingTimeoutMs") ?? 350, 100, 2000);
        _maxHosts = Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:MaxHosts") ?? 4096, 1, 65534);
        _parallelism = Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:Parallelism") ?? 128, 1, 256);
        _cacheDuration = TimeSpan.FromSeconds(Math.Clamp(configuration.GetValue<int?>("Wellstate:Network:CacheSeconds") ?? 8, 0, 60));
    }

    public async Task<NetworkScanResult> ScanAsync(bool force, string? requestedCidr, CancellationToken cancellationToken)
    {
        var subnet = _subnetResolver.Resolve(requestedCidr);
        if (!force && IsCacheFresh(subnet.Cidr)) return _cached!;

        await _scanLock.WaitAsync(cancellationToken);
        try
        {
            if (!force && IsCacheFresh(subnet.Cidr)) return _cached!;

            var addresses = subnet.EnumerateHosts(_maxHosts).ToArray();
            var devices = new ConcurrentBag<NetworkDevice>();
            var probeFailures = 0;
            using var limiter = new SemaphoreSlim(_parallelism, _parallelism);
            var jobs = addresses.Select(async ip =>
            {
                await limiter.WaitAsync(cancellationToken);
                try
                {
                    using var ping = new Ping();
                    var reply = await ping.SendPingAsync(ip, _timeoutMs);
                    if (reply.Status != IPStatus.Success) return;

                    await AddDeviceAsync(devices, ip, reply.RoundtripTime, cancellationToken);
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception error) when (error is SocketException or PingException or PlatformNotSupportedException)
                {
                    if (OperatingSystem.IsWindows())
                    {
                        var startedAt = Stopwatch.GetTimestamp();
                        var fallbackResult = await TryWindowsPingAsync(ip, cancellationToken);
                        if (fallbackResult.HasValue)
                        {
                            if (fallbackResult.Value)
                            {
                                await AddDeviceAsync(devices, ip, (long)Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds, cancellationToken);
                            }
                            return;
                        }
                    }

                    // Em Windows, tenta ping.exe; só conta como indisponível se também não o conseguir usar.
                    Interlocked.Increment(ref probeFailures);
                }
                catch (InvalidOperationException)
                {
                    // Um host isolado com erro de rede não interrompe o scan.
                }
                finally
                {
                    limiter.Release();
                }
            });

            await Task.WhenAll(jobs);
            // O cache de vizinhos (ARP) também inclui equipamentos que bloqueiam ICMP,
            // por exemplo muitos telemóveis em redes Wi-Fi. Só aceitamos IPs da sub-rede pedida.
            foreach (var neighbor in await ReadNeighborTableAsync(subnet, cancellationToken))
            {
                if (devices.Any(device => device.Ip == neighbor.Ip.ToString())) continue;
                devices.Add(new NetworkDevice
                {
                    Ip = neighbor.Ip.ToString(),
                    Hostname = string.Empty,
                    Online = true,
                    DeviceType = "unknown",
                    DiscoveryMethod = "arp",
                    MacAddress = neighbor.Mac
                });
            }
            if (addresses.Length > 0 && probeFailures == addresses.Length && devices.IsEmpty)
            {
                throw new PlatformNotSupportedException(
                    "O servidor não conseguiu enviar pedidos ICMP. Confirma as permissões ICMP do processo .NET e a configuração de ping_group_range (Linux), ou permite ICMP na firewall.");
            }

            _cached = new NetworkScanResult(
                subnet.Cidr,
                DateTimeOffset.UtcNow,
                devices.OrderBy(device => IpSortKey(device.Ip)).ToArray(),
                subnet.AutomaticallyDetected,
                subnet.InterfaceName,
                subnet.LocalAddress,
                subnet.Gateway,
                addresses.Length,
                subnet.HostCount,
                subnet.HostCount > addresses.Length);
            return _cached;
        }
        finally
        {
            _scanLock.Release();
        }
    }

    private bool IsCacheFresh(string cidr) => _cached is not null &&
        string.Equals(_cached.ScanCidr, cidr, StringComparison.OrdinalIgnoreCase) &&
        DateTimeOffset.UtcNow - _cached.ScannedAt < _cacheDuration;

    private static async Task AddDeviceAsync(ConcurrentBag<NetworkDevice> devices, IPAddress ip, long responseMs, CancellationToken cancellationToken)
    {
        var hostname = await ResolveHostnameAsync(ip, cancellationToken);
        devices.Add(new NetworkDevice
        {
            Ip = ip.ToString(),
            Hostname = hostname,
            Online = true,
            ResponseMs = responseMs,
            DeviceType = GuessDeviceType(hostname),
            DiscoveryMethod = "icmp"
        });
    }

    private static string GuessDeviceType(string hostname)
    {
        var name = hostname.ToLowerInvariant();
        if (Regex.IsMatch(name, @"(iphone|ipad|android|mobile|phone|pixel|galaxy|redmi|xiaomi|huawei|oneplus|oppo|vivo)")) return "mobile";
        if (Regex.IsMatch(name, @"(desktop|workstation|laptop|notebook|pc[-_0-9]|win[-_0-9]|macbook|imac)")) return "computer";
        return "unknown";
    }

    private static async Task<IReadOnlyList<(IPAddress Ip, string? Mac)>> ReadNeighborTableAsync(NetworkSubnet subnet, CancellationToken cancellationToken)
    {
        var result = new List<(IPAddress Ip, string? Mac)>();
        string command;
        string[] args;
        if (OperatingSystem.IsLinux()) { command = "ip"; args = ["neigh", "show"]; }
        else if (OperatingSystem.IsWindows() || OperatingSystem.IsMacOS()) { command = "arp"; args = ["-a"]; }
        else return result;

        using var process = new Process { StartInfo = new ProcessStartInfo
        {
            FileName = command, UseShellExecute = false, RedirectStandardOutput = true,
            RedirectStandardError = true, CreateNoWindow = true
        }};
        foreach (var arg in args) process.StartInfo.ArgumentList.Add(arg);
        try
        {
            if (!process.Start()) return result;
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(1200);
            var output = process.StandardOutput.ReadToEndAsync(timeout.Token);
            await process.WaitForExitAsync(timeout.Token);
            foreach (var line in await output)
            {
                if (line.Contains("FAILED", StringComparison.OrdinalIgnoreCase) || line.Contains("INCOMPLETE", StringComparison.OrdinalIgnoreCase)) continue;
                var match = Regex.Match(line, @"(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)");
                if (!match.Success || !IPAddress.TryParse(match.Value, out var ip) || !IsInSubnet(ip, subnet)) continue;
                var macMatch = Regex.Match(line, @"(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}", RegexOptions.IgnoreCase);
                result.Add((ip, macMatch.Success ? macMatch.Value.Replace('-', ':').ToLowerInvariant() : null));
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch { /* Tabela de vizinhos é uma fonte suplementar; falha não invalida o scan ICMP. */ }
        finally { TryKill(process); }
        return result.DistinctBy(entry => entry.Ip).ToArray();
    }

    private static bool IsInSubnet(IPAddress ip, NetworkSubnet subnet)
    {
        if (ip.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork) return false;
        var value = System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(ip.GetAddressBytes());
        var mask = subnet.PrefixLength == 0 ? 0u : uint.MaxValue << (32 - subnet.PrefixLength);
        return (value & mask) == subnet.NetworkAddressValue;
    }

    /// <summary>Fallback do Windows: usa o ping.exe nativo quando a API ICMP do .NET falha.</summary>
    private async Task<bool?> TryWindowsPingAsync(IPAddress ip, CancellationToken cancellationToken)
    {
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = Path.Combine(Environment.SystemDirectory, "ping.exe"),
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            }
        };
        process.StartInfo.ArgumentList.Add("-n");
        process.StartInfo.ArgumentList.Add("1");
        process.StartInfo.ArgumentList.Add("-w");
        process.StartInfo.ArgumentList.Add(_timeoutMs.ToString(System.Globalization.CultureInfo.InvariantCulture));
        process.StartInfo.ArgumentList.Add(ip.ToString());

        try
        {
            if (!process.Start()) return null;
            var stdout = process.StandardOutput.ReadToEndAsync();
            var stderr = process.StandardError.ReadToEndAsync();
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(_timeoutMs + 1500);
            await process.WaitForExitAsync(timeout.Token);
            await Task.WhenAll(stdout, stderr);
            return process.ExitCode switch
            {
                0 => true,
                1 => false,
                _ => null
            };
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            TryKill(process);
            throw;
        }
        catch
        {
            TryKill(process);
            return null;
        }
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited) process.Kill(entireProcessTree: true);
        }
        catch { /* O processo pode ter terminado entre a verificação e o kill. */ }
    }

    private static async Task<string> ResolveHostnameAsync(IPAddress ip, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            var lookup = Dns.GetHostEntryAsync(ip);
            var completed = await Task.WhenAny(lookup, Task.Delay(120, cancellationToken));
            cancellationToken.ThrowIfCancellationRequested();
            return completed == lookup ? (await lookup).HostName : string.Empty;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch
        {
            return string.Empty;
        }
    }

    private static long IpSortKey(string value) => IPAddress.TryParse(value, out var ip)
        ? System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(ip.GetAddressBytes())
        : long.MaxValue;
}

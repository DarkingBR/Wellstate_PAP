using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

[ApiController]
[Route("api/network/devices")]
public sealed class NetworkDevicesController : ControllerBase
{
    private readonly NetworkDiscoveryService _discovery;

    public NetworkDevicesController(NetworkDiscoveryService discovery) => _discovery = discovery;

    [HttpGet]
    public async Task<ActionResult<NetworkScanResult>> Get(
        [FromQuery] bool refresh = false,
        [FromQuery] string? cidr = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            return Ok(await _discovery.ScanAsync(refresh, cidr, cancellationToken));
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            return Problem("A verificação foi cancelada.", statusCode: 499);
        }
        catch (NetworkUnavailableException error)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new { message = error.Message });
        }
        catch (PlatformNotSupportedException)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                message = "O servidor não conseguiu enviar pedidos ICMP. No Windows, confirma que ping.exe está disponível; em Linux, verifica as permissões ICMP do processo .NET (ping_group_range ou sockets raw). Dispositivos ou firewalls que bloqueiem ping não serão detetados por este método."
            });
        }
        catch (ArgumentException error)
        {
            return BadRequest(new { message = error.Message });
        }
        catch (Exception)
        {
            return Problem("Falha interna ao verificar a rede. Consulte os logs da API.", statusCode: 500);
        }
    }
}

# Referências do redesign de tempo real

O redesign do Wellstate usa princípios operacionais destas referências públicas; não reproduz logótipos, ativos ou layouts proprietários.

- [N-able — Network Operations Center Monitoring Software](https://www.n-able.com/features/network-operations-center-monitoring-software): consolidação do estado da infraestrutura numa vista central, atualização do estado dos sistemas e alertas proativos.
- [Cisco Meraki — Cloud management dashboard](https://www.cisco.com/site/us/en/products/networking/meraki-cloud-management-dashboard/index.html): visibilidade centralizada de dispositivos e dependências, navegação intuitiva e acesso rápido a informação operacional.
- [ManageEngine OpManager — NOC View](https://www.manageengine.com/network-monitoring/help/noc-view.html): vistas continuamente atualizadas, cadência de refresh configurável e apresentação operacional contínua.

Aplicação no Wellstate: hierarquia clara de estado/API, métricas com indicação de atualização, polling com intervalo controlado, abas com estado ativo inequívoco e transições curtas, respeitando a preferência do navegador por movimento reduzido.

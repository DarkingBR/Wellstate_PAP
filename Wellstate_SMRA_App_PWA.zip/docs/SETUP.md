# Configuração rápida · Wellstate

## Requisitos

- PHP 8.1+ com extensões `PDO` e `PDO_SQLite`.
- .NET SDK 8 para a API C#.
- Permissão para o processo .NET enviar ICMP em Linux (`ping_group_range`/sockets raw). No Windows, a API tenta automaticamente o `ping.exe` do sistema se a sonda ICMP do .NET falhar.
- Arduino IDE 2.x e bibliotecas DHT Adafruit se usar o firmware ESP8266.

## Iniciar o projeto

Abre dois terminais na raiz do projeto e executa diretamente os dois serviços:

```bash
# Terminal 1
cd backend-csharp
dotnet run --urls http://0.0.0.0:5080

# Terminal 2, a partir da raiz do projeto
php -S 0.0.0.0:8080 -t . server/router.php
```

Abre `http://localhost:8080/register` para criar a primeira conta. O login encaminha para o dashboard. As contas são armazenadas em `server/data/users.sqlite` e as tabelas são criadas automaticamente. O router PHP encaminha `/api/*` ao C# pela mesma origem.

## API, rede e dispositivos

A API fica em `http://IP-DO-SERVIDOR:5080`; confirma o estado em `/api/health`. O CIDR `auto` descobre a LAN do servidor. Para escolher uma rede específica sem editar ficheiros, define a variável de ambiente `Wellstate__Network__Cidr` antes de iniciares a API. Não encaminhes a porta 5080 para a Internet.

Configura chaves diferentes para hardware e agentes antes do uso real. Por exemplo:

```bash
export Wellstate__DeviceApiKey="<chave-aleatoria-do-sensor>"
export Wellstate__AgentApiKey="<chave-aleatoria-do-agente>"
```

O firmware envia leituras diretamente à API C# com `X-Device-Key`; os agentes Windows usam a chave configurada pelo backend. Estes fluxos não passam pelo login do portal.

## Firmware

Copia `firmware/Wellstate_Firmware/secrets.example.h` para `secrets.h` e preenche credenciais Wi-Fi, a URL da API `:5080`, a URL do portal `:8080/login`, o identificador da sala e a chave do sensor. Nunca partilhes o ficheiro preenchido.

## Firestore

Firestore é NoSQL, não SQL. A versão incluída usa SQLite e não está ligada a um projeto Firebase. O esquema de referência está em [FIREBASE.md](FIREBASE.md); a ativação exige projeto, configuração e credenciais privadas do proprietário.

## Segurança de produção

O `php -S` incluído é apenas servidor de desenvolvimento. Em produção, publica o portal através de Apache/Nginx + PHP-FPM e HTTPS. Mantém a API C# e a porta 5080 numa LAN/VPN de confiança, ou protege-a com gateway/controles de acesso apropriados. Usa palavras-passe fortes, cópias de segurança e não versiona os diretórios `server/data` nem `backend-csharp/Data`.

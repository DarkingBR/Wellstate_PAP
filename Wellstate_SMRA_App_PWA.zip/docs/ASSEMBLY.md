# Montagem física · Wellstate SMRA

## Material

- NodeMCU v2 (ESP8266) e cabo USB de dados;
- protoboard e jumpers;
- DHT11 (módulo ou sensor nu);
- PIR HC-SR501;
- HC-SR04;
- LED, resistor de 220–330 Ω;
- resistores de 1 kΩ e 2 kΩ para o divisor do Echo;
- opcional: resistor pull-up de 4,7–10 kΩ para DHT11 nu.

**Não ligue a placa USB a um circuito alimentado por outra fonte sem confirmar as massas e tensões.** O ESP8266 trabalha com lógica de 3,3 V. Mantenha um GND comum entre placa e módulos.

## Esquema textual

```text
NODEMCU / ESP8266                    MÓDULO
─────────────────                    ──────
3V3  ─────────────────────────────── DHT11 VCC
D4 / GPIO2 ───────────────────────── DHT11 DATA
GND  ─────────────────────────────── DHT11 GND

VIN / 5V ────────────────────────── HC-SR501 VCC (se necessário no seu módulo)
D1 / GPIO5 ───────────────────────── HC-SR501 OUT
GND  ─────────────────────────────── HC-SR501 GND

VIN / 5V ────────────────────────── HC-SR04 VCC
D2 / GPIO4 ───────────────────────── HC-SR04 TRIG
HC-SR04 ECHO ──[ 1 kΩ ]──┬───────── D3 / GPIO0 (junção, não o Echo direto)
                         └─[ 2 kΩ ]─ GND
GND  ─────────────────────────────── HC-SR04 GND

D5 / GPIO14 ──[ 220–330 Ω ]──►|──── GND
                              LED
```

A tensão na junção do divisor de Echo é aproximadamente 3,3 V. Confirme com multímetro se tiver dúvidas. **Nunca conecte ECHO de 5 V diretamente a um pino ESP8266.** O resistor de LED pode ficar antes ou depois do LED; em série, a ordem não muda o funcionamento.

## Passo a passo na protoboard

1. **Desligue o cabo USB.** Escolha uma fileira da protoboard como GND comum e use jumpers a partir de GND do NodeMCU. Não coloque 5 V na linha 3V3.
2. **Instale o DHT11.** Para o módulo pronto, ligue VCC a 3V3, GND a GND e DATA a D4/GPIO2. Para o sensor DHT11 nu, confira a pinagem do fabricante e coloque pull-up 4,7–10 kΩ entre DATA e 3V3. Não confunda a ordem dos terminais dos módulos diferentes.
3. **Instale o PIR.** Ligue GND e OUT. O VCC do HC-SR501 normalmente aceita 5 V; use VIN/5 V se o seu módulo assim exigir. Ligue OUT a D1/GPIO5 e confirme que a saída nunca excede 3,3 V. Ajuste os potenciómetros de sensibilidade/tempo e aguarde o período de estabilização habitual do módulo após energizar.
4. **Instale o HC-SR04.** VCC a VIN/5 V, GND a GND e TRIG a D2/GPIO4. Para Echo, coloque o resistor de 1 kΩ entre ECHO e a junção; da junção siga para D3/GPIO0; coloque 2 kΩ entre essa mesma junção e GND.
5. **Instale o LED.** D5/GPIO14 → resistor de 220–330 Ω → perna comprida (ânodo) do LED; perna curta (cátodo) → GND. O firmware pisca devagar quando está ligado e deixa o LED aceso enquanto presença PIR + distância válida estão confirmadas.
6. **Inspecione a montagem.** Confirme polaridade, VCC/GND, divisor Echo, ausência de fios soltos e GND comum. Não coloque módulos sobre trilhos que dividem a protoboard sem perceber a interrupção elétrica entre as metades.
7. **Ligue apenas pelo USB do NodeMCU**, carregue primeiro o firmware sem ligar o HC-SR04 Echo e observe o arranque; em seguida desligue o USB, ligue o Echo através do divisor e volte a energizar a placa. Teste cada sensor pelo Monitor Série a 115200 baud e pelo painel.

### Nota importante sobre D3/GPIO0

O projeto conserva o mapeamento pedido. No ESP8266, GPIO0/D3 é um pino de seleção do modo de arranque e tem de estar alto durante reset. O Echo do HC-SR04 pode começar baixo e impedir boot confiável. **Se houver bootloader, arranque intermitente ou resets, a correção recomendada é mover apenas Echo/junção para D7/GPIO13 e mudar `#define ECHO_PIN D3` para `#define ECHO_PIN D7`.** Isso mantém o mesmo divisor e evita usar GPIO0 como entrada Echo.

## Bibliotecas e firmware

- Boards Manager: **ESP8266 by ESP8266 Community**, placa **NodeMCU 1.0 (ESP-12E Module)**.
- Library Manager: **DHT sensor library** (Adafruit) e **Adafruit Unified Sensor**.
- `ESP8266WiFi`, `ESP8266HTTPClient`, `WiFiClient` e `ESP8266WebServer` vêm com o pacote de placas ESP8266. Não é necessário software nos PCs monitorizados.
- Abra `firmware/Wellstate_Firmware/Wellstate_Firmware.ino`; copie `secrets.example.h` para `secrets.h` e configure Wi-Fi 2,4 GHz, URL .NET, chave X-Device e ID da sala.

## Testes e URLs

1. Aceda ao Monitor Série a 115200. Quando o Wi-Fi ligar, anote o endereço IP local que o firmware imprime; o router também mostra clientes associados.
2. No mesmo segmento da LAN, abra `http://IP-DO-ESP/`. O ESP redireciona diretamente para o dashboard no endereço `WELLSTATE_API_BASE_URL` configurado; não há login.
3. `http://IP-DO-ESP/api/status` apresenta a última leitura dos sensores em JSON; `http://IP-DO-ESP/api/network` mostra a lista TCP `PC-01`–`PC-11` nos IPs `.10`–`.20` (porta 445).
4. O painel principal lista a descoberta ICMP e PCs cadastrados **na LAN do servidor .NET**. O scan é automático; PCs desligados só aparecem se o servidor receber os seus IDs, nomes e IPs fixos através das definições de ambiente `Wellstate__Pcs__n__Id`, `Wellstate__Pcs__n__Name`, `Wellstate__Pcs__n__Ip` e `Wellstate__Pcs__n__RoomId`.
5. Uma porta TCP 445 fechada não prova que o computador está desligado. O firewall/VLAN pode bloquear a verificação. O servidor principal tenta ICMP; firewalls Windows também podem bloquear ping.

> A API e endpoints locais do ESP destinam-se à LAN/VPN de confiança. O dashboard e APIs de leitura não têm login; não encaminhe a porta 80 ou 5080 para a Internet. A telemetria continua protegida por `X-Device-Key` e as rotas do agente por `X-Agent-Key`.

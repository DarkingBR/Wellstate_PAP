# Arranque · Wellstate SMRA

## 1. Instalar o software

- PHP 8.1+ com `PDO_SQLite` para login/registo e portal.
- .NET SDK 8 para a API REST.
- Arduino IDE 2.x e core ESP8266 apenas se usar a NodeMCU.

## 2. Iniciar o portal

Na raiz do projeto, abre dois terminais e executa:

```bash
dotnet run --project backend-csharp/Wellstate.API.csproj --urls http://0.0.0.0:5080
php -S 0.0.0.0:8080 -t . server/router.php
```

O segundo comando deve ser executado na raiz do projeto. Abre `http://IP-DO-SERVIDOR:8080/register` para criar conta e depois inicia sessão. A interface privada é servida pelo PHP; `http://IP-DO-SERVIDOR:5080/api/health` valida a API.

## 3. Preparar a rede e os computadores

Reserva IPs no router para o servidor, ESP e PCs. O CIDR `auto` usa a LAN do servidor; para escolher outra sub-rede, define `Wellstate__Network__Cidr` no ambiente do processo .NET, sem alterar ficheiros do projeto. A API não deve ser publicada diretamente na Internet.

## 4. Compilar e ligar a NodeMCU

1. Segue [`ASSEMBLY.md`](ASSEMBLY.md) e [`HARDWARE.md`](HARDWARE.md) para montagem, divisor de tensão, pinos e bibliotecas.
2. Copia `firmware/Wellstate_Firmware/secrets.example.h` para `secrets.h`.
3. Configura `WELLSTATE_API_BASE_URL` para `http://IP-DO-SERVIDOR:5080`, a chave do sensor, Wi-Fi e ID da sala.
4. Configura `WELLSTATE_PORTAL_URL` para `http://IP-DO-SERVIDOR:8080/login`.
5. Compila e grava na NodeMCU v2. A placa continua a enviar a telemetria diretamente à API C#.

## 5. Dados e serviços externos

Contas PHP e telemetria usam SQLite local; salas e horários permanecem no `localStorage` do browser. **Firestore é NoSQL, não SQL, e não está ligado nesta cópia** — consulte [`FIREBASE.md`](FIREBASE.md) para o esquema de referência e os pré-requisitos de uma futura ligação. Não invente ou partilhe credenciais de serviço no código público.

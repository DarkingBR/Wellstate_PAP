<?php
declare(strict_types=1);

require_once __DIR__ . '/src/bootstrap.php';
$GLOBALS['config'] = $config;

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');

$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($path === '/api' || str_starts_with($path, '/api/')) {
    require __DIR__ . '/src/api_proxy.php';
    exit;
}

if (str_starts_with($path, '/auth/')) {
    require __DIR__ . '/src/auth.php';
    exit;
}

if ($path === '/' || $path === '/index.html') {
    header('Location: ' . (!empty($_SESSION['user_id']) ? '/frontend/dashboard.html' : '/login'), true, 302);
    exit;
}

if ($path === '/login' || $path === '/register') {
    $file = dirname(__DIR__) . '/frontend/' . ($path === '/login' ? 'login.html' : 'register.html');
    header('Content-Type: text/html; charset=utf-8');
    readfile($file);
    exit;
}

if (str_starts_with($path, '/frontend/')) {
    $relative = substr($path, strlen('/frontend/'));
    $extension = strtolower(pathinfo($relative, PATHINFO_EXTENSION));
    $publicExtensions = ['css', 'js', 'png', 'jpg', 'jpeg', 'webp', 'svg', 'ico', 'webmanifest', 'woff', 'woff2', 'ttf'];
    $frontendRoot = realpath(dirname(__DIR__) . '/frontend');
    $candidate = realpath($frontendRoot . DIRECTORY_SEPARATOR . $relative);
    if (!$candidate || !str_starts_with($candidate, $frontendRoot . DIRECTORY_SEPARATOR) || !is_file($candidate)) {
        http_response_code(404);
        echo 'Não encontrado.';
        exit;
    }

    if ($extension === 'html') {
        if (in_array($relative, ['login.html', 'register.html'], true)) {
            header('Content-Type: text/html; charset=utf-8');
            readfile($candidate);
            exit;
        }
        if (empty($_SESSION['user_id'])) {
            header('Location: /login', true, 302);
            exit;
        }
        header('Cache-Control: no-store, private');
        header('Content-Type: text/html; charset=utf-8');
        $html = file_get_contents($candidate);
        $injection = '<link rel="stylesheet" href="/frontend/css/auth.css"><script src="/frontend/js/auth-guard.js" defer></script>';
        $html = preg_replace('/<\/head>/i', $injection . '</head>', $html, 1) ?? $html;
        echo $html;
        exit;
    }

    if (!in_array($extension, $publicExtensions, true)) {
        http_response_code(404);
        echo 'Não encontrado.';
        exit;
    }
    $mime = [
        'css' => 'text/css; charset=utf-8', 'js' => 'text/javascript; charset=utf-8',
        'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp',
        'svg' => 'image/svg+xml', 'ico' => 'image/x-icon', 'webmanifest' => 'application/manifest+json',
        'woff' => 'font/woff', 'woff2' => 'font/woff2', 'ttf' => 'font/ttf',
    ][$extension] ?? 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Cache-Control: ' . ($extension === 'js' ? 'no-cache, must-revalidate' : 'public, max-age=3600'));
    readfile($candidate);
    exit;
}

if ($path === '/docs/ASSEMBLY.md' || $path === '/docs/SETUP.md') {
    $file = dirname(__DIR__) . $path;
    if (is_file($file)) {
        header('Content-Type: text/markdown; charset=utf-8');
        readfile($file);
        exit;
    }
}

http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
echo 'Rota não encontrada.';

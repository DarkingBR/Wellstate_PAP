<?php
declare(strict_types=1);

$requestUri = $_SERVER['REQUEST_URI'] ?? '/api';
$requestPath = parse_url($requestUri, PHP_URL_PATH);
if (!is_string($requestPath) || ($requestPath !== '/api' && !str_starts_with($requestPath, '/api/'))) {
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'not_found', 'message' => 'Rota da API não encontrada.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$target = 'http://127.0.0.1:5080' . $requestUri;
$headers = [];
$blockedHeaders = ['host', 'connection', 'content-length', 'transfer-encoding', 'upgrade', 'proxy-connection', 'accept-encoding', 'cookie'];

if (function_exists('getallheaders')) {
    foreach (getallheaders() ?: [] as $name => $value) {
        if (!in_array(strtolower((string)$name), $blockedHeaders, true)) {
            $headers[] = $name . ': ' . $value;
        }
    }
}
if (!array_filter($headers, static fn(string $value): bool => stripos($value, 'accept:') === 0)) {
    $headers[] = 'Accept: application/json';
}
$headers[] = 'Accept-Encoding: identity';
$headers[] = 'Connection: close';

$options = [
    'method' => $method,
    'header' => implode("\r\n", $headers),
    'ignore_errors' => true,
    // Scans LAN podem demorar; o cliente espera até 55 segundos.
    'timeout' => 50,
    'protocol_version' => 1.1,
    'follow_location' => 0,
];
if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
    $options['content'] = file_get_contents('php://input') ?: '';
}

@set_time_limit(55);
$context = stream_context_create(['http' => $options]);
$body = @file_get_contents($target, false, $context);
$responseHeaders = $http_response_header ?? [];
$status = 0;
foreach ($responseHeaders as $index => $line) {
    if ($index === 0 && preg_match('~^HTTP/\S+\s+(\d{3})~', $line, $match)) {
        $status = (int)$match[1];
        continue;
    }
    if (preg_match('~^(Content-Type|Content-Disposition|Cache-Control|Retry-After|WWW-Authenticate):\s*(.+)$~i', $line, $match)) {
        header($match[1] . ': ' . trim($match[2]));
    }
}

header('Cache-Control: no-store');
if ($body === false && $status === 0) {
    http_response_code(502);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Wellstate-Proxy-Error: unavailable');
    echo json_encode([
        'status' => 'api_unavailable',
        'message' => 'A API C# não respondeu em 127.0.0.1:5080. Inicia o backend .NET e tenta novamente.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

http_response_code($status ?: 502);
header('X-Wellstate-Proxy: php');
if ($body !== false && $body !== '') {
    echo $body;
}

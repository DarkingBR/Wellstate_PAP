# Firebase · esquema de dados opcional

## Estado nesta versão

O Wellstate SMRA **não usa Firebase Authentication nem Firestore para o funcionamento atual**: o painel abre diretamente, sem login ou registo. A API e o histórico ficam em SQLite (`backend-csharp/Data/wellstate.db`), e os PCs são configurados em `Wellstate:Pcs` no `appsettings.json`.

Este guia preserva a estrutura de coleções/campos solicitada para uma possível migração futura. Não crie credenciais de Firebase nem configure o projeto apenas para executar esta versão. Não há coleção `users` usada pelo app.

## Estrutura Firestore sugerida para migração futura

| Coleção / documento | Campo | Tipo Firestore | Obrigatório | Finalidade |
|---|---|---|---|---|
| `rooms/{roomId}` | `roomId` | string | Sim | ID estável da sala, por exemplo `C1.01` |
| `rooms/{roomId}` | `name` | string | Sim | Nome que aparece no painel |
| `rooms/{roomId}` | `createdAt` | timestamp | Sim | Data de criação |
| `telemetry/{autoId}` | `roomId` | string | Sim | Sala a que a leitura pertence |
| `telemetry/{autoId}` | `temperatureC` | number | Não | Temperatura Celsius; `null` se sem leitura |
| `telemetry/{autoId}` | `humidityPct` | number | Não | Humidade relativa de 0 a 100 |
| `telemetry/{autoId}` | `distanceCm` | number | Não | Distância em centímetros; `null` se sem leitura |
| `telemetry/{autoId}` | `motion` | boolean | Sim | Estado bruto do PIR |
| `telemetry/{autoId}` | `occupied` | boolean | Sim | Presença confirmada pelo firmware |
| `telemetry/{autoId}` | `recordedAt` | timestamp | Sim | Instante da medição |
| `devices/{deviceId}` | `deviceId` | string | Sim | ID estável, por exemplo `PC-01` |
| `devices/{deviceId}` | `name` | string | Sim | Nome visível, por exemplo `PC-01 · Sala` |
| `devices/{deviceId}` | `ip` | string | Sim | IPv4 reservado do equipamento |
| `devices/{deviceId}` | `roomId` | string | Não | Sala onde o equipamento está |
| `devices/{deviceId}` | `online` | boolean | Sim | Último estado calculado pela API |
| `devices/{deviceId}` | `lastSeenAt` | timestamp | Não | Última resposta/heartbeat, ou `null` |
| `devices/{deviceId}` | `source` | string | Sim | `icmp`, `tcp` ou `agent` |

A versão incluída **não escreve** nestas coleções; os dados atuais continuam na API/SQLite e no inventário local configurado. Não copie automaticamente o exemplo sem implementar uma migração coordenada.

## Regras e segurança

`firebase/firestore.rules` nega todas as leituras e escritas, pois esta build não usa Firestore. Se no futuro integrar Firebase, crie regras validadas para a identidade do servidor/dispositivo, aplique least privilege e teste-as antes de publicar. Não utilize `allow read, write: if true`.

O código atual não cria nem apaga contas Firebase ou documentos antigos. A remoção aqui é apenas das telas/fluxos e validação de sessão deste repositório; qualquer conta/dado já existente no seu projeto Firebase permanece no serviço remoto.

## Fontes

- [Firestore: estruturar dados](https://firebase.google.com/docs/firestore/data-model)
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/rules-conditions)

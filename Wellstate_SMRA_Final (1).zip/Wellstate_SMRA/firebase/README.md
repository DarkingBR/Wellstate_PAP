# Firebase (opcional)

A versão atual do Wellstate SMRA não usa Firebase Authentication nem Firestore; o dashboard abre sem conta e a API grava telemetria em SQLite. Nenhuma configuração Firebase é necessária para executar o projeto.

`docs/FIREBASE.md` mantém o esquema futuro solicitado para coleções/campos/tipos caso se planeie uma migração. As regras atuais em `firestore.rules` negam acesso a todas as coleções. Não publique regras permissivas. Esta alteração local não remove dados nem contas existentes no seu projeto Firebase remoto.

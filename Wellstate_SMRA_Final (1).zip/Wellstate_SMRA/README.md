# Wellstate · centro de operações escolar

Painel web para horários, salas, sensores ambientais e inventário de dispositivos da rede local. O painel e o backend ASP.NET partilham uma descoberta LAN controlada. A telemetria e o histórico dos sinais de PCs ficam na mesma base SQLite.

## Arquitetura

```text
NodeMCU ESP8266 ── REST autenticada ─────┐
Painel Web ──────── SSE + REST ──────────┤── ASP.NET Core API ── SQLite/WAL
Dispositivos LAN ── ICMP controlado ─────┘
```

- **Firmware:** Arduino IDE, HTTP REST e chave de dispositivo.
- **Backend:** .NET 8, inicialmente `http://<IP-LOCAL>:5080/api`; SQLite em `backend-csharp/Data/wellstate.db`.
- **Frontend:** o painel encontra a API na mesma máquina por padrão; para outra máquina, configure `window.WELLSTATE_API_BASE_URL` em `frontend/js/config.js`.
- **Dispositivos:** `GET /api/network/devices` verifica a sub-rede privada da interface de saída do servidor, autodetectada por padrão, ou o CIDR privado configurado.
- **PCs cadastrados:** `/api/pcs` combina ping com heartbeat do agente e mantém entradas offline visíveis. Configure IPs fixos/reservados em `Wellstate:Pcs`.
- **Horário:** instantes usam UTC e o painel mostra `Europe/Lisbon`, com ajuste de horário de verão/inverno.
- **Configuração escolar:** horários e salas continuam guardados no navegador atual, não na base central.

## Ligar e executar

1. Instale o .NET SDK 8 e siga [docs/SETUP.md](docs/SETUP.md).
2. Configure uma chave secreta para o dispositivo, se usar os sensores, e inicie a API.
3. Configure e grave a NodeMCU usando Arduino IDE, se utilizar o hardware.
4. Inicie o backend pela raiz com `./start-wellstate.sh` (Linux/macOS) ou `./start-wellstate.ps1` (Windows).
5. Abra `http://IP-DO-SERVIDOR:5080/` ou `http://IP-DO-SERVIDOR:5080/pcs.html`. Não abra os HTML diretamente com `file://`.
6. Consulte `http://IP-DO-SERVIDOR:5080/api/health` para confirmar a API.

Veja [docs/DATABASE.md](docs/DATABASE.md) para persistência e migração de histórico.

## Horário e acesso fora da LAN

Os dez períodos correspondem à tabela de referência incluída. Para aceder por dados móveis ou outra rede, conecte-se à mesma instalação por uma **VPN** com rota para o servidor, ou use um gateway **HTTPS com autenticação**. Trocar o Wi-Fi do celular por dados móveis não torna um servidor privado acessível pela Internet. Todos os clientes — painel, sensores e agentes — precisam alcançar a mesma API. Não encaminhe a porta 5080 diretamente para a Internet.

## Descoberta LAN e estados online/offline

Com `Wellstate:Network:Cidr = "auto"`, a API detecta a rede IPv4 privada da rota ativa no servidor. O CIDR pode ser fixado em `backend-csharp/appsettings.json`. O scan tem limite configurável de hosts e concorrência para não gerar tráfego excessivo; não varre a Internet pública. Em Linux, instale `iputils-ping` para habilitar o ICMP; se estiver ausente, o endpoint devolve um diagnóstico `503` em vez de uma resposta interna sem contexto.

A página de PCs exibe equipamentos que respondem ao ping e PCs cadastrados, mesmo quando offline. Um PC é considerado online se responder ao ping **ou** se o agente Wellstate enviar heartbeat. Firewall, VLANs e redes convidadas podem ocultar equipamentos. Hosts desconhecidos que estão desligados não podem ser identificados sem cadastro prévio; use IP reservado/fixo e registre-os em `Wellstate:Pcs`. Instale o agente quando o ICMP estiver bloqueado.

A autodetecção usa a rede do servidor da API, não a rede local de quem abriu o navegador. Para consultar uma LAN remota, execute a API nessa LAN ou conecte o servidor à rede correta por VPN.

## Conectividade da API

O frontend usa `/api` quando servido pelo backend e, quando executado por um servidor estático na mesma máquina, tenta automaticamente a porta `5080`. O cliente REST tem timeout maior para scans de rede, retry de leituras e mensagens de erro mais claras. Se a API estiver em outro host, defina `window.WELLSTATE_API_BASE_URL = "http://HOST-DA-API:5080/api"` antes de carregar `js/config.js`.

Confira o .NET SDK 8, o backend, a porta TCP 5080 na firewall e se o navegador está na mesma LAN/VPN. Consulte [docs/REST_API.md](docs/REST_API.md), [docs/HARDWARE.md](docs/HARDWARE.md) e [docs/PC_SIGNALS.md](docs/PC_SIGNALS.md) para detalhes.


## Edição SMRA · acesso e instalação

O dashboard abre diretamente sem login/registo; a API de leitura não exige conta. A telemetria e o histórico permanecem em SQLite. Firebase é opcional e não é necessário para executar o projeto; [docs/FIREBASE.md](docs/FIREBASE.md) mantém o esquema de migração futuro. O acesso destina-se à LAN/VPN de confiança: não encaminhe a porta 5080 para a Internet. As chaves `X-Device-Key` e `X-Agent-Key` continuam a proteger, respetivamente, pedidos do hardware e do agente Windows.

A entrada é `http://IP-DO-SERVIDOR:5080/` e abre o dashboard. A porta 80 do ESP redireciona para essa aplicação central e oferece ainda `/api/status` e `/api/network`. A API faz o scan ICMP na LAN do servidor. Os PCs de exemplo `PC-01` a `PC-03` precisam de IPs reservados válidos. Hosts descobertos sem DNS recebem um rótulo estável construído a partir do IP.

- [Arranque completo](docs/QUICKSTART-SMRA.md)
- [Firebase, campos/tipos e regras](docs/FIREBASE.md)
- [Montagem detalhada na protoboard](docs/ASSEMBLY.md)
- [Firmware, pinos e bibliotecas Arduino](docs/HARDWARE.md)

**Atenção elétrica:** ECHO do HC-SR04 precisa de divisor de tensão; o GPIO0/D3 pedido pode impedir o arranque se estiver baixo no reset. O guia de hardware recomenda D7 como alternativa fiável. Instalação PWA requer HTTPS (exceto localhost); HTTP num IP privado continua utilizável no navegador. Não publique segredos, portas da API ou endpoints locais do ESP sem proteção adequada.

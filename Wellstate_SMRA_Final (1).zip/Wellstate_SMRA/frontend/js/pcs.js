import { apiClient } from "./api-client.js";

(function () {
    const CFG = window.WELLSTATE_CONFIG;
    const grid = document.getElementById("devicesGrid");
    const refresh = document.getElementById("refreshNetwork");
    const badge = document.getElementById("networkBadge");
    const note = document.getElementById("networkNote");
    let timer;
    let loading = false;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);

    const formatTime = value => value
        ? new Intl.DateTimeFormat("pt-BR", {
            timeZone: CFG.TIME_ZONE,
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hourCycle: "h23"
        }).format(new Date(value))
        : "—";

    function setBadge(connected, text) {
        badge.classList.toggle("connected", connected);
        badge.classList.toggle("disconnected", !connected);
        badge.replaceChildren(Object.assign(document.createElement("span"), { className: "pulse-dot" }), document.createTextNode(text));
    }

    function updateSummary(pcs, devices, scan) {
        const discovered = Array.isArray(devices) ? devices : [];
        const foundIps = new Set(discovered.map(device => String(device.ip || "").toLowerCase()));
        const onlinePcs = pcs.filter(pc => pc.online || pc.agentOnline || pc.networkOnline || foundIps.has(String(pc.ip || "").toLowerCase()));
        document.getElementById("registeredCount").textContent = pcs.length;
        document.getElementById("onlineCount").textContent = onlinePcs.length;
        document.getElementById("offlineCount").textContent = pcs.length - onlinePcs.length;
        document.getElementById("deviceCount").textContent = discovered.length;
        document.getElementById("scanCidr").textContent = scan?.scanCidr || "—";
        document.getElementById("scanTime").textContent = scan?.scannedAt ? formatTime(scan.scannedAt) : "—";
    }

    function createCard({ title, code, ip, online, detail, extra }) {
        const card = document.createElement("article");
        card.className = "pc-card device-card";
        const badgeClass = online ? "online" : "offline";
        const statusText = online ? "Ligado" : "Desligado";
        card.innerHTML = `
            <div class="device-card-head">
                <div class="device-icon" aria-hidden="true">●</div>
                <span class="status-badge ${badgeClass}">${statusText}</span>
            </div>
            <div class="device-main">
                <span class="pc-code">${esc(code)}</span>
                <h3>${esc(title)}</h3>
                <div class="ip">${esc(ip || "IP não configurado")}</div>
            </div>
            <div class="device-latency">${esc(detail)}</div>
            <div class="device-extra">${esc(extra)}</div>`;
        return card;
    }

    function displayDeviceName(device) {
        const dnsName = String(device?.hostname || device?.name || "").trim();
        if (dnsName) return dnsName;
        const ip = String(device?.ip || "").trim();
        const suffix = ip.split(".").pop();
        return /^\d+$/.test(suffix) ? `PC-${suffix.padStart(2, "0")}` : "PC-LAN-SEM-IP";
    }

    function render(pcs, devices) {
        const foundByIp = new Map(devices.map(device => [String(device.ip || "").toLowerCase(), device]));
        const knownIps = new Set(pcs.map(pc => String(pc.ip || "").toLowerCase()));
        const cards = [];

        for (const pc of pcs) {
            const found = foundByIp.get(String(pc.ip || "").toLowerCase());
            const agentOnline = Boolean(pc.agentOnline);
            const networkOnline = Boolean(pc.networkOnline || found);
            const online = Boolean(pc.online || agentOnline || networkOnline);
            const proof = agentOnline
                ? "Agente Wellstate conectado"
                : networkOnline
                    ? `Resposta na rede${pc.responseMs != null ? ` · ${esc(pc.responseMs)} ms` : ""}`
                    : "Sem resposta de rede ou heartbeat";
            const lastSeen = pc.lastSeenAt ? `Último heartbeat: ${formatTime(pc.lastSeenAt)}` : "Agente sem heartbeat";
            cards.push(createCard({
                title: pc.name || pc.id || "PC cadastrado",
                code: `PC ${pc.id || "—"}`,
                ip: pc.ip,
                online,
                detail: proof,
                extra: lastSeen
            }));
        }

        for (const device of devices) {
            if (knownIps.has(String(device.ip || "").toLowerCase())) continue;
            cards.push(createCard({
                title: displayDeviceName(device),
                code: `PC ${displayDeviceName(device)}`,
                ip: device.ip,
                online: true,
                detail: `Resposta na rede${device.responseMs != null ? ` · ${esc(device.responseMs)} ms` : ""}`,
                extra: "Encontrado pelo scan da LAN"
            }));
        }

        if (cards.length === 0) {
            const empty = document.createElement("div");
            empty.className = "chip wide";
            empty.textContent = pcs.length === 0
                ? "Nenhum PC cadastrado e nenhum dispositivo respondeu. Cadastre os PCs em backend-csharp/appsettings.json para também acompanhar seu estado offline."
                : "Nenhum dispositivo respondeu ao scan. PCs cadastrados aparecem acima mesmo quando estão offline.";
            grid.replaceChildren(empty);
            return;
        }

        grid.replaceChildren(...cards);
    }

    async function loadNetwork(force = false) {
        if (loading) return;
        loading = true;
        refresh.disabled = true;
        refresh.textContent = "Verificando…";

        try {
            const [pcsResult, scanResult] = await Promise.allSettled([
                apiClient.getPcs(),
                apiClient.getNetworkDevices({ refresh: force })
            ]);
            const pcs = pcsResult.status === "fulfilled" && Array.isArray(pcsResult.value) ? pcsResult.value : [];
            const scan = scanResult.status === "fulfilled" ? scanResult.value : null;
            const devices = Array.isArray(scan?.devices) ? scan.devices : [];

            if (pcsResult.status === "rejected" && scanResult.status === "rejected") {
                throw pcsResult.reason || scanResult.reason || new Error("Não foi possível consultar a API.");
            }

            updateSummary(pcs, devices, scan);
            render(pcs, devices);

            if (scan) {
                const mode = scan.automaticallyDetected ? "automática" : "configurada";
                const limitNote = scan.scanLimited ? ` · scan limitado a ${scan.hostsScanned} de ${scan.hostsAvailable} endereços` : "";
                const inventoryWarning = pcsResult.status === "rejected"
                    ? ` O inventário cadastrado falhou: ${pcsResult.reason?.message || "erro desconhecido"}.`
                    : "";
                setBadge(true, inventoryWarning ? "LAN ligada · inventário com erro" : "API e rede ligadas");
                note.textContent = `Sub-rede ${mode}: ${scan.scanCidr} · interface ${scan.interfaceName || "—"} · servidor ${scan.serverAddress || "—"}${limitNote}. O scan ocorre na LAN/VPN do servidor; ICMP bloqueado pode exigir o agente Wellstate.${inventoryWarning}`;
            } else {
                setBadge(pcsResult.status === "fulfilled", "API ligada · scan LAN indisponível");
                note.textContent = scanResult.reason?.message || "A API respondeu, mas não foi possível descobrir uma rede privada no servidor. Confira Wi-Fi, VPN ou configure o CIDR manualmente.";
            }
        } catch (error) {
            setBadge(false, "API indisponível");
            grid.innerHTML = `<div class="chip wide">${esc(error?.message || "Não foi possível verificar a API.")}</div>`;
            note.textContent = "Confirme se o backend está ligado, se o navegador alcança o host da API e se a porta 5080 está acessível na rede/VPN.";
        } finally {
            loading = false;
            refresh.disabled = false;
            refresh.textContent = "Atualizar agora";
        }
    }

    refresh.addEventListener("click", () => loadNetwork(true));
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) loadNetwork(false);
    });
    loadNetwork(false);
    timer = window.setInterval(() => {
        if (!document.hidden) loadNetwork(false);
    }, Math.max(CFG.POLL_INTERVAL_MS || 15000, 10000));
    window.addEventListener("beforeunload", () => clearInterval(timer));
})();

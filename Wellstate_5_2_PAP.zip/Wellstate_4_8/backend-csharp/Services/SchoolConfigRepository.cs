using System.Globalization;
using Microsoft.Data.Sqlite;
using Wellstate.API.Models;

namespace Wellstate.API.Services;

/// <summary>
/// Catálogo de salas e horário semanal em SQLite. Substitui o armazenamento
/// apenas no navegador (localStorage), para que todos os postos vejam os mesmos dados.
/// Todas as escritas usam transações e validam conflitos no servidor.
/// </summary>
public sealed class SchoolConfigRepository
{
    private readonly string _connectionString;
    private readonly Task _initialized;
    private readonly SemaphoreSlim _writeLock = new(1, 1);

    public SchoolConfigRepository(IConfiguration configuration, IHostEnvironment environment)
    {
        var configuredPath = configuration["Wellstate:Database:Path"] ?? "Data/wellstate.db";
        var databasePath = Path.IsPathRooted(configuredPath)
            ? configuredPath
            : Path.Combine(environment.ContentRootPath, configuredPath);
        Directory.CreateDirectory(Path.GetDirectoryName(databasePath)!);
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = databasePath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Cache = SqliteCacheMode.Shared,
            Pooling = true,
            ForeignKeys = true,
            DefaultTimeout = 10
        }.ToString();
        _initialized = InitializeAsync();
    }

    private async Task InitializeAsync()
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            PRAGMA journal_mode = WAL;
            PRAGMA busy_timeout = 10000;
            CREATE TABLE IF NOT EXISTS room_catalog (
                room_id TEXT PRIMARY KEY COLLATE NOCASE,
                name TEXT NOT NULL,
                sort_order INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS schedule_lessons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                day INTEGER NOT NULL CHECK (day BETWEEN 1 AND 5),
                subject TEXT NOT NULL,
                group_name TEXT NOT NULL,
                teacher TEXT NOT NULL,
                room_id TEXT NOT NULL COLLATE NOCASE,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                CHECK (start_time < end_time),
                FOREIGN KEY (room_id) REFERENCES room_catalog(room_id) ON UPDATE CASCADE ON DELETE RESTRICT
            );
            CREATE INDEX IF NOT EXISTS idx_schedule_day ON schedule_lessons(day, start_time);
            CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            """;
        await command.ExecuteNonQueryAsync();
    }

    private async Task<SqliteConnection> OpenAsync(CancellationToken ct)
    {
        await _initialized;
        var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(ct);
        return connection;
    }

    public async Task<bool> IsInitializedAsync(CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT value FROM app_meta WHERE key = 'config_initialized'";
        return await command.ExecuteScalarAsync(ct) is not null;
    }

    public async Task<IReadOnlyList<RoomInfo>> GetRoomsAsync(CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT room_id, name FROM room_catalog ORDER BY sort_order, room_id";
        var rooms = new List<RoomInfo>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) rooms.Add(new RoomInfo(reader.GetString(0), reader.GetString(1)));
        return rooms;
    }

    public async Task<IReadOnlyList<Lesson>> GetLessonsAsync(CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, day, subject, group_name, teacher, room_id, start_time, end_time, updated_at
            FROM schedule_lessons ORDER BY day, start_time, room_id
            """;
        var lessons = new List<Lesson>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) lessons.Add(ReadLesson(reader));
        return lessons;
    }

    private static Lesson ReadLesson(SqliteDataReader r) => new(
        r.GetInt64(0), r.GetInt32(1), r.GetString(2), r.GetString(3), r.GetString(4),
        r.GetString(5), r.GetString(6), r.GetString(7),
        DateTimeOffset.Parse(r.GetString(8), CultureInfo.InvariantCulture));

    // ---------- Salas ----------

    public async Task<RoomInfo> UpsertRoomAsync(string? originalId, RoomUpsertRequest request, CancellationToken ct)
    {
        var id = request.Id.Trim();
        var name = request.Name.Trim();
        await _writeLock.WaitAsync(ct);
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var tx = (SqliteTransaction)await connection.BeginTransactionAsync(ct);
            var now = DateTimeOffset.UtcNow.ToString("O");

            if (originalId is null)
            {
                if (await RoomExistsAsync(connection, tx, id, ct))
                    throw new ConflictException($"Já existe uma sala com o identificador '{id}'.");
                if (await RoomNameExistsAsync(connection, tx, name, null, ct))
                    throw new ConflictException($"Já existe uma sala com o nome '{name}'.");
                await using var insert = connection.CreateCommand();
                insert.Transaction = tx;
                insert.CommandText = """
                    INSERT INTO room_catalog(room_id, name, sort_order, updated_at)
                    VALUES ($id, $name, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM room_catalog), $now)
                    """;
                insert.Parameters.AddWithValue("$id", id);
                insert.Parameters.AddWithValue("$name", name);
                insert.Parameters.AddWithValue("$now", now);
                await insert.ExecuteNonQueryAsync(ct);
            }
            else
            {
                if (!await RoomExistsAsync(connection, tx, originalId, ct))
                    throw new KeyNotFoundException("Sala não encontrada.");
                if (!id.Equals(originalId, StringComparison.OrdinalIgnoreCase) && await RoomExistsAsync(connection, tx, id, ct))
                    throw new ConflictException($"Já existe uma sala com o identificador '{id}'.");
                if (await RoomNameExistsAsync(connection, tx, name, originalId, ct))
                    throw new ConflictException($"Já existe uma sala com o nome '{name}'.");
                await using var update = connection.CreateCommand();
                update.Transaction = tx;
                // ON UPDATE CASCADE atualiza automaticamente as aulas que usam a sala.
                update.CommandText = "UPDATE room_catalog SET room_id = $id, name = $name, updated_at = $now WHERE room_id = $old";
                update.Parameters.AddWithValue("$id", id);
                update.Parameters.AddWithValue("$name", name);
                update.Parameters.AddWithValue("$now", now);
                update.Parameters.AddWithValue("$old", originalId);
                await update.ExecuteNonQueryAsync(ct);
            }
            await MarkInitializedAsync(connection, tx, ct);
            await tx.CommitAsync(ct);
            return new RoomInfo(id, name);
        }
        finally { _writeLock.Release(); }
    }

    public async Task DeleteRoomAsync(string id, CancellationToken ct)
    {
        await _writeLock.WaitAsync(ct);
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var tx = (SqliteTransaction)await connection.BeginTransactionAsync(ct);
            await using (var count = connection.CreateCommand())
            {
                count.Transaction = tx;
                count.CommandText = "SELECT COUNT(*) FROM schedule_lessons WHERE room_id = $id";
                count.Parameters.AddWithValue("$id", id);
                var used = Convert.ToInt32(await count.ExecuteScalarAsync(ct));
                if (used > 0)
                    throw new ConflictException($"A sala tem {used} aula(s) no horário. Mova ou remova essas aulas antes de apagar a sala.");
            }
            await using var delete = connection.CreateCommand();
            delete.Transaction = tx;
            delete.CommandText = "DELETE FROM room_catalog WHERE room_id = $id";
            delete.Parameters.AddWithValue("$id", id);
            if (await delete.ExecuteNonQueryAsync(ct) == 0) throw new KeyNotFoundException("Sala não encontrada.");
            await MarkInitializedAsync(connection, tx, ct);
            await tx.CommitAsync(ct);
        }
        finally { _writeLock.Release(); }
    }

    // ---------- Aulas ----------

    public async Task<Lesson> SaveLessonAsync(long? id, LessonRequest request, CancellationToken ct)
    {
        var normalized = Normalize(request);
        await _writeLock.WaitAsync(ct);
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var tx = (SqliteTransaction)await connection.BeginTransactionAsync(ct);
            if (!await RoomExistsAsync(connection, tx, normalized.Room, ct))
                throw new ValidationFailedException($"A sala '{normalized.Room}' não existe no catálogo.");
            await EnsureNoConflictAsync(connection, tx, id, normalized, ct);

            var now = DateTimeOffset.UtcNow;
            await using var command = connection.CreateCommand();
            command.Transaction = tx;
            if (id is null)
            {
                command.CommandText = """
                    INSERT INTO schedule_lessons(day, subject, group_name, teacher, room_id, start_time, end_time, updated_at)
                    VALUES ($day, $subject, $group, $teacher, $room, $start, $end, $now);
                    SELECT last_insert_rowid();
                    """;
            }
            else
            {
                command.CommandText = """
                    UPDATE schedule_lessons SET day=$day, subject=$subject, group_name=$group, teacher=$teacher,
                        room_id=$room, start_time=$start, end_time=$end, updated_at=$now
                    WHERE id = $id;
                    SELECT CASE WHEN changes() > 0 THEN $id ELSE NULL END;
                    """;
                command.Parameters.AddWithValue("$id", id.Value);
            }
            AddLessonParameters(command, normalized, now);
            var result = await command.ExecuteScalarAsync(ct);
            if (result is null or DBNull) throw new KeyNotFoundException("Aula não encontrada.");
            await MarkInitializedAsync(connection, tx, ct);
            await tx.CommitAsync(ct);
            return new Lesson(Convert.ToInt64(result), normalized.Day, normalized.Subject, normalized.Group!, normalized.Teacher!,
                normalized.Room, normalized.Start, normalized.End, now);
        }
        finally { _writeLock.Release(); }
    }

    public async Task DeleteLessonAsync(long id, CancellationToken ct)
    {
        await _writeLock.WaitAsync(ct);
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM schedule_lessons WHERE id = $id";
            command.Parameters.AddWithValue("$id", id);
            if (await command.ExecuteNonQueryAsync(ct) == 0) throw new KeyNotFoundException("Aula não encontrada.");
        }
        finally { _writeLock.Release(); }
    }

    /// <summary>
    /// Importa a configuração antiga do navegador apenas quando o servidor ainda não foi configurado.
    /// Evita perda de dados na migração para a versão 2.0 e nunca sobrescreve dados existentes.
    /// </summary>
    public async Task<bool> ImportIfEmptyAsync(ConfigImportRequest request, CancellationToken ct)
    {
        await _writeLock.WaitAsync(ct);
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var tx = (SqliteTransaction)await connection.BeginTransactionAsync(ct);
            await using (var check = connection.CreateCommand())
            {
                check.Transaction = tx;
                check.CommandText = "SELECT (SELECT COUNT(*) FROM app_meta WHERE key='config_initialized') + (SELECT COUNT(*) FROM room_catalog)";
                if (Convert.ToInt32(await check.ExecuteScalarAsync(ct)) > 0) return false;
            }

            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var now = DateTimeOffset.UtcNow;
            var order = 0;
            foreach (var room in request.Rooms)
            {
                var id = room.Id.Trim();
                if (!ids.Add(id)) throw new ValidationFailedException($"Sala duplicada na importação: '{id}'.");
                await using var insert = connection.CreateCommand();
                insert.Transaction = tx;
                insert.CommandText = "INSERT INTO room_catalog(room_id, name, sort_order, updated_at) VALUES ($id, $name, $order, $now)";
                insert.Parameters.AddWithValue("$id", id);
                insert.Parameters.AddWithValue("$name", room.Name.Trim());
                insert.Parameters.AddWithValue("$order", ++order);
                insert.Parameters.AddWithValue("$now", now.ToString("O"));
                await insert.ExecuteNonQueryAsync(ct);
            }

            foreach (var raw in request.Lessons)
            {
                var lesson = Normalize(raw);
                if (!ids.Contains(lesson.Room)) throw new ValidationFailedException($"A aula {lesson.Subject} usa a sala inexistente '{lesson.Room}'.");
                await EnsureNoConflictAsync(connection, tx, null, lesson, ct);
                await using var insert = connection.CreateCommand();
                insert.Transaction = tx;
                insert.CommandText = """
                    INSERT INTO schedule_lessons(day, subject, group_name, teacher, room_id, start_time, end_time, updated_at)
                    VALUES ($day, $subject, $group, $teacher, $room, $start, $end, $now)
                    """;
                AddLessonParameters(insert, lesson, now);
                await insert.ExecuteNonQueryAsync(ct);
            }
            await MarkInitializedAsync(connection, tx, ct);
            await tx.CommitAsync(ct);
            return true;
        }
        finally { _writeLock.Release(); }
    }

    // ---------- Auxiliares ----------

    private static LessonRequest Normalize(LessonRequest r)
    {
        var lesson = new LessonRequest
        {
            Day = r.Day,
            Subject = (r.Subject ?? string.Empty).Trim(),
            Group = string.IsNullOrWhiteSpace(r.Group) ? "Turma por definir" : r.Group.Trim(),
            Teacher = string.IsNullOrWhiteSpace(r.Teacher) ? "Professor/a" : r.Teacher.Trim(),
            Room = (r.Room ?? string.Empty).Trim(),
            Start = (r.Start ?? string.Empty).Trim(),
            End = (r.End ?? string.Empty).Trim()
        };
        if (lesson.Day is < 1 or > 5) throw new ValidationFailedException("O dia tem de estar entre segunda e sexta.");
        if (lesson.Subject.Length == 0) throw new ValidationFailedException("A disciplina é obrigatória.");
        if (lesson.Room.Length == 0) throw new ValidationFailedException("A sala é obrigatória.");
        if (!TimeOnly.TryParseExact(lesson.Start, "HH:mm", out var start) || !TimeOnly.TryParseExact(lesson.End, "HH:mm", out var end))
            throw new ValidationFailedException("As horas têm de estar no formato HH:MM.");
        if (start >= end) throw new ValidationFailedException("A hora de fim tem de ser posterior à hora de início.");
        if ((end - start).TotalMinutes < 10) throw new ValidationFailedException("Uma aula tem de durar pelo menos 10 minutos.");
        if (start < new TimeOnly(7, 0) || end > new TimeOnly(23, 0))
            throw new ValidationFailedException("As aulas têm de decorrer entre as 07:00 e as 23:00.");
        return lesson;
    }

    private static async Task EnsureNoConflictAsync(SqliteConnection c, SqliteTransaction tx, long? ignoreId, LessonRequest l, CancellationToken ct)
    {
        await using var command = c.CreateCommand();
        command.Transaction = tx;
        // Conflito: mesma sala OU mesma turma em horários sobrepostos no mesmo dia.
        command.CommandText = """
            SELECT subject, room_id, group_name, start_time, end_time FROM schedule_lessons
            WHERE day = $day AND id <> $ignore
              AND start_time < $end AND end_time > $start
              AND (room_id = $room COLLATE NOCASE OR (group_name = $group COLLATE NOCASE AND group_name <> 'Turma por definir'))
            LIMIT 1
            """;
        command.Parameters.AddWithValue("$day", l.Day);
        command.Parameters.AddWithValue("$ignore", ignoreId ?? -1);
        command.Parameters.AddWithValue("$start", l.Start);
        command.Parameters.AddWithValue("$end", l.End);
        command.Parameters.AddWithValue("$room", l.Room);
        command.Parameters.AddWithValue("$group", l.Group);
        await using var reader = await command.ExecuteReaderAsync(ct);
        if (await reader.ReadAsync(ct))
        {
            var sameRoom = reader.GetString(1).Equals(l.Room, StringComparison.OrdinalIgnoreCase);
            var what = sameRoom ? $"a sala {reader.GetString(1)}" : $"a turma {reader.GetString(2)}";
            throw new ConflictException(
                $"Conflito de horário: {what} já tem {reader.GetString(0)} entre {reader.GetString(3)} e {reader.GetString(4)}.");
        }
    }

    private static void AddLessonParameters(SqliteCommand command, LessonRequest l, DateTimeOffset now)
    {
        command.Parameters.AddWithValue("$day", l.Day);
        command.Parameters.AddWithValue("$subject", l.Subject);
        command.Parameters.AddWithValue("$group", l.Group);
        command.Parameters.AddWithValue("$teacher", l.Teacher);
        command.Parameters.AddWithValue("$room", l.Room);
        command.Parameters.AddWithValue("$start", l.Start);
        command.Parameters.AddWithValue("$end", l.End);
        command.Parameters.AddWithValue("$now", now.ToString("O"));
    }

    private static async Task<bool> RoomExistsAsync(SqliteConnection c, SqliteTransaction tx, string id, CancellationToken ct)
    {
        await using var command = c.CreateCommand();
        command.Transaction = tx;
        command.CommandText = "SELECT 1 FROM room_catalog WHERE room_id = $id";
        command.Parameters.AddWithValue("$id", id);
        return await command.ExecuteScalarAsync(ct) is not null;
    }

    private static async Task<bool> RoomNameExistsAsync(SqliteConnection c, SqliteTransaction tx, string name, string? exceptId, CancellationToken ct)
    {
        await using var command = c.CreateCommand();
        command.Transaction = tx;
        command.CommandText = "SELECT 1 FROM room_catalog WHERE name = $name COLLATE NOCASE AND room_id <> $except";
        command.Parameters.AddWithValue("$name", name);
        command.Parameters.AddWithValue("$except", exceptId ?? "");
        return await command.ExecuteScalarAsync(ct) is not null;
    }

    private static async Task MarkInitializedAsync(SqliteConnection c, SqliteTransaction tx, CancellationToken ct)
    {
        await using var command = c.CreateCommand();
        command.Transaction = tx;
        command.CommandText = "INSERT OR IGNORE INTO app_meta(key, value) VALUES ('config_initialized', $now)";
        command.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
        await command.ExecuteNonQueryAsync(ct);
    }
}

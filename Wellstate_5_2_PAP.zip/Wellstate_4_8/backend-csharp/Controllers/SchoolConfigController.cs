using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Wellstate.API.Models;
using Wellstate.API.Services;

namespace Wellstate.API.Controllers;

/// <summary>
/// Configuração escolar partilhada: catálogo de salas e horário semanal.
/// Leituras são públicas na rede local; escritas exigem o cabeçalho X-Admin-Key
/// quando Wellstate:AdminApiKey (ou a variável WELLSTATE_ADMIN_API_KEY) estiver definida.
/// </summary>
[ApiController]
[Route("api/config")]
public sealed class SchoolConfigController : ControllerBase
{
    private readonly SchoolConfigRepository _repo;
    private readonly IConfiguration _configuration;

    public SchoolConfigController(SchoolConfigRepository repo, IConfiguration configuration)
    {
        _repo = repo;
        _configuration = configuration;
    }

    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct) => Ok(new
    {
        initialized = await _repo.IsInitializedAsync(ct),
        adminKeyRequired = AdminKeyConfigured(),
        rooms = await _repo.GetRoomsAsync(ct),
        lessons = await _repo.GetLessonsAsync(ct)
    });

    [HttpPost("import")]
    public Task<IActionResult> Import(ConfigImportRequest request, CancellationToken ct) => Guarded(async () =>
    {
        if (request.Rooms.Count > 200 || request.Lessons.Count > 1000)
            return BadRequest(new { message = "Importação demasiado grande." });
        var imported = await _repo.ImportIfEmptyAsync(request, ct);
        return Ok(new { imported });
    });

    [HttpPost("rooms")]
    public Task<IActionResult> CreateRoom(RoomUpsertRequest request, CancellationToken ct)
        => Guarded(async () => StatusCode(201, await _repo.UpsertRoomAsync(null, request, ct)));

    [HttpPut("rooms/{id}")]
    public Task<IActionResult> UpdateRoom(string id, RoomUpsertRequest request, CancellationToken ct)
        => Guarded(async () => Ok(await _repo.UpsertRoomAsync(id, request, ct)));

    [HttpDelete("rooms/{id}")]
    public Task<IActionResult> DeleteRoom(string id, CancellationToken ct)
        => Guarded(async () => { await _repo.DeleteRoomAsync(id, ct); return NoContent(); });

    [HttpPost("lessons")]
    public Task<IActionResult> CreateLesson(LessonRequest request, CancellationToken ct)
        => Guarded(async () => StatusCode(201, await _repo.SaveLessonAsync(null, request, ct)));

    [HttpPut("lessons/{id:long}")]
    public Task<IActionResult> UpdateLesson(long id, LessonRequest request, CancellationToken ct)
        => Guarded(async () => Ok(await _repo.SaveLessonAsync(id, request, ct)));

    [HttpDelete("lessons/{id:long}")]
    public Task<IActionResult> DeleteLesson(long id, CancellationToken ct)
        => Guarded(async () => { await _repo.DeleteLessonAsync(id, ct); return NoContent(); });

    private bool AdminKeyConfigured() => !string.IsNullOrWhiteSpace(_configuration["Wellstate:AdminApiKey"]);

    private async Task<IActionResult> Guarded(Func<Task<IActionResult>> action)
    {
        var expected = _configuration["Wellstate:AdminApiKey"];
        if (!string.IsNullOrWhiteSpace(expected))
        {
            var provided = Encoding.UTF8.GetBytes(Request.Headers["X-Admin-Key"].ToString());
            var wanted = Encoding.UTF8.GetBytes(expected);
            if (provided.Length != wanted.Length || !CryptographicOperations.FixedTimeEquals(provided, wanted))
                return Unauthorized(new { message = "Chave de administração inválida ou em falta." });
        }
        try { return await action(); }
        catch (ValidationFailedException e) { return BadRequest(new { message = e.Message }); }
        catch (ConflictException e) { return Conflict(new { message = e.Message }); }
        catch (KeyNotFoundException e) { return NotFound(new { message = e.Message }); }
    }
}

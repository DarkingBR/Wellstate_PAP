using Wellstate.API.Services;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

// Credenciais nunca ficam no código: variáveis de ambiente sobrepõem o appsettings.json.
var deviceKey = Environment.GetEnvironmentVariable("WELLSTATE_DEVICE_API_KEY");
if (!string.IsNullOrWhiteSpace(deviceKey)) builder.Configuration["Wellstate:DeviceApiKey"] = deviceKey;
var adminKey = Environment.GetEnvironmentVariable("WELLSTATE_ADMIN_API_KEY");
if (!string.IsNullOrWhiteSpace(adminKey)) builder.Configuration["Wellstate:AdminApiKey"] = adminKey;

builder.Services.AddControllers().ConfigureApiBehaviorOptions(options =>
{
    // Erros de validação devolvidos com uma mensagem clara em português.
    options.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState
            .Where(entry => entry.Value?.Errors.Count > 0)
            .ToDictionary(
                entry => entry.Key,
                entry => entry.Value!.Errors.Select(e =>
                    string.IsNullOrWhiteSpace(e.ErrorMessage) ? "Valor inválido." : e.ErrorMessage).ToArray());
        var malformed = errors.Keys.Any(k => k == "$" || k.StartsWith("$.")) || errors.ContainsKey("request");
        if (malformed)
        {
            // Não devolver detalhes internos do parser.
            return new BadRequestObjectResult(new { message = "O corpo do pedido não é JSON válido ou contém tipos incorretos." });
        }
        var first = errors.Values.SelectMany(v => v).FirstOrDefault() ?? "Pedido inválido.";
        return new BadRequestObjectResult(new { message = first, errors });
    };
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<PingService>();
builder.Services.AddSingleton<PcRepository>();
builder.Services.AddSingleton<PcPresenceService>();
builder.Services.AddSingleton<SignalRepository>();
builder.Services.AddSingleton<SignalService>();
builder.Services.AddSingleton<RoomTelemetryRepository>();
builder.Services.AddSingleton<SchoolConfigRepository>();
builder.Services.AddSingleton<NetworkSubnetResolver>();
builder.Services.AddSingleton<NetworkDiscoveryService>();

// CORS: por omissão aberto na rede local (compatível com ESP8266 e agente). Pode ser restringido
// com Wellstate:AllowedOrigins = ["http://servidor:5080"].
var allowedOrigins = builder.Configuration.GetSection("Wellstate:AllowedOrigins").Get<string[]>() ?? [];
builder.Services.AddCors(options => options.AddPolicy("wellstate", policy =>
{
    if (allowedOrigins.Length > 0) policy.WithOrigins(allowedOrigins).AllowAnyMethod().AllowAnyHeader();
    else policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
}));

var app = builder.Build();

// Nunca expor stack traces: erros inesperados ficam no log e o cliente recebe uma mensagem genérica.
app.UseExceptionHandler(handler => handler.Run(async context =>
{
    var error = context.Features.Get<IExceptionHandlerFeature>()?.Error;
    app.Logger.LogError(error, "Erro não tratado em {Path}", context.Request.Path);
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new { message = "Erro interno do servidor. Consulte os logs da API." });
}));

app.Use(async (context, next) =>
{
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["Referrer-Policy"] = "same-origin";
    context.Response.Headers["X-Frame-Options"] = "DENY";
    await next();
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("wellstate");
var frontendPath = Path.GetFullPath(Path.Combine(builder.Environment.ContentRootPath, "..", "frontend"));
if (Directory.Exists(frontendPath))
{
    var frontendProvider = new PhysicalFileProvider(frontendPath);
    app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = frontendProvider });
    app.UseStaticFiles(new StaticFileOptions { FileProvider = frontendProvider });
}
app.MapControllers();
app.Run(builder.Configuration["Wellstate:Url"] ?? "http://0.0.0.0:5080");

using System.ComponentModel.DataAnnotations;

namespace Wellstate.API.Models;

/// <summary>
/// Pedido de telemetria de sala (sensor PIR + ultrassónico).
/// </summary>
public sealed class RoomTelemetryRequest
{
    [Range(2, 400)]
    public double? Distance { get; set; }

    public bool Motion { get; set; }
    public bool Occupied { get; set; }

    [StringLength(20)]
    public string? Event { get; set; }
}

public sealed record RoomTelemetry(
    long Id,
    string RoomId,
    double? Distance,
    bool Motion,
    bool Occupied,
    string Event,
    DateTimeOffset UpdatedAt);

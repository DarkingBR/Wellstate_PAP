using System.ComponentModel.DataAnnotations;

namespace Wellstate.API.Models;

/// <summary>Sala do catálogo escolar (configuração persistida em SQLite).</summary>
public sealed record RoomInfo(string Id, string Name);

/// <summary>Aula do horário semanal (persistida em SQLite).</summary>
public sealed record Lesson(
    long Id,
    int Day,
    string Subject,
    string Group,
    string Teacher,
    string Room,
    string Start,
    string End,
    DateTimeOffset UpdatedAt);

public sealed class RoomUpsertRequest
{
    [Required(ErrorMessage = "O identificador da sala é obrigatório.")]
    [StringLength(20, MinimumLength = 2, ErrorMessage = "O identificador deve ter entre 2 e 20 caracteres.")]
    [RegularExpression(@"^[A-Za-z0-9._\-]+$", ErrorMessage = "Use apenas letras, números, ponto, hífen ou underscore no identificador.")]
    public string Id { get; set; } = string.Empty;

    [Required(ErrorMessage = "O nome da sala é obrigatório.")]
    [StringLength(80, MinimumLength = 1, ErrorMessage = "O nome da sala deve ter entre 1 e 80 caracteres.")]
    public string Name { get; set; } = string.Empty;
}

public sealed class LessonRequest
{
    [Range(1, 5, ErrorMessage = "O dia tem de estar entre 1 (segunda) e 5 (sexta).")]
    public int Day { get; set; }

    [Required(ErrorMessage = "A disciplina é obrigatória.")]
    [StringLength(40, MinimumLength = 1, ErrorMessage = "A disciplina deve ter entre 1 e 40 caracteres.")]
    public string Subject { get; set; } = string.Empty;

    [StringLength(40, ErrorMessage = "A turma não pode ter mais de 40 caracteres.")]
    public string? Group { get; set; }

    [StringLength(60, ErrorMessage = "O professor não pode ter mais de 60 caracteres.")]
    public string? Teacher { get; set; }

    [Required(ErrorMessage = "A sala é obrigatória.")]
    public string Room { get; set; } = string.Empty;

    [Required(ErrorMessage = "A hora de início é obrigatória.")]
    [RegularExpression(@"^([01]\d|2[0-3]):[0-5]\d$", ErrorMessage = "Hora de início inválida (HH:MM).")]
    public string Start { get; set; } = string.Empty;

    [Required(ErrorMessage = "A hora de fim é obrigatória.")]
    [RegularExpression(@"^([01]\d|2[0-3]):[0-5]\d$", ErrorMessage = "Hora de fim inválida (HH:MM).")]
    public string End { get; set; } = string.Empty;
}

public sealed class ConfigImportRequest
{
    public List<RoomUpsertRequest> Rooms { get; set; } = [];
    public List<LessonRequest> Lessons { get; set; } = [];
}

public sealed class ConflictException(string message) : Exception(message);
public sealed class ValidationFailedException(string message) : Exception(message);

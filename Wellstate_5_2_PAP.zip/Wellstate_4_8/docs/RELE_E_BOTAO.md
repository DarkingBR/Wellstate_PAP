# Como ligar o relé e o botão

Tens agora duas peças novas no projeto:

- **Módulo de relé** (1 canal): liga uma carga (um candeeiro, por exemplo) quando a sala está ocupada.
- **Botão KY-004**, a placa pequena e preta com um botão e três pinos que mostraste na foto: cada clique liga o projeto, o clique seguinte põe-no em espera. Em espera, o relé e o LED ficam desligados e os sensores param, mas o botão continua a funcionar.

## Ligações (NodeMCU v2)

| Peça | Pino da peça | NodeMCU |
|---|---|---|
| Relé | VCC | VIN (5 V) |
| Relé | GND | GND |
| Relé | IN | D0 (GPIO16) |
| Botão KY-004 | S | D4 (GPIO2) |
| Botão KY-004 | pino do meio | 3V3 |
| Botão KY-004 | − | GND |

O relé e o botão já não usam o D1, o D2 nem o D5 (esses ficam para o LED e para o PIR, como em `HARDWARE.md`). Usam o D0 e o D4. Todos os GND têm de estar ligados entre si.

## Passo a passo

1. Com o NodeMCU desligado do USB, faz as ligações da tabela.
2. No relé, a carga liga-se aos terminais **COM** e **NO** (normalmente aberto). Para testar usa só uma carga de baixa tensão, como um LED com resistência ou uma ventoinha de 5 V. Não ligues nada de 230 V sem o teu professor ver, é perigoso.
3. Abre `firmware/Wellstate_Firmware/Wellstate_Firmware.ino` no Arduino IDE, confirma o `secrets.h` e carrega para a placa.
4. Abre o Monitor Série a 115200. Deve aparecer "Projeto em espera". Carrega no botão: passa a "LIGADO".
5. Passa a mão à frente do PIR, a menos de 2 metros do HC-SR04. O LED acende e o relé faz "clique". O relé só desliga 30 segundos depois de a presença acabar.
6. Na página **Salas** do site aparece o cartão da sala com o estado do relé e a indicação "Em espera" quando o botão desligou o projeto.

## Se algo não bater certo

- **O relé trabalha ao contrário** (liga quando devia desligar): no topo do `.ino`, muda `RELAY_ACTIVE_LOW` para `false`.
- **O botão não responde**: o firmware mede o nível do botão em repouso quando arranca, por isso não carregues nele ao ligar a placa. Se a placa não arranca, tira o fio do D4 antes de ligar a placa e volta a pô-lo depois (o D4 é um pino que a placa lê ao arrancar).
- **Quero que o projeto arranque já ligado**: muda `START_ON` para `true`.
- **O tempo do relé**: `RELAY_HOLD_MS` está em milissegundos.

# Configuração rápida · Wellstate

## 1. Iniciar a API

1. Instale o **.NET SDK 8** e abra a pasta do projeto no VS Code.
   Em Linux, instale também o utilitário ICMP: `sudo apt-get install iputils-ping` (em distribuições Debian/Ubuntu).
2. No terminal, entre em `backend-csharp` e defina uma chave aleatória para os sensores. No PowerShell:

   ```powershell
   $token = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
   $env:Wellstate__DeviceApiKey = $token
   $env:ASPNETCORE_ENVIRONMENT = "Production"
   dotnet restore
   dotnet run
   ```

   A API escuta em `http://0.0.0.0:5080`. A base SQLite, com tabelas indexadas para medições e sinais de PCs, é criada automaticamente em `Data/wellstate.db`.

3. Confirme `http://localhost:5080/api/health`; deve indicar `status: ok`, `database: ok` e `signalStorage: sqlite`.
4. O painel usa o host da API automaticamente quando é servido por ela ou por um servidor estático na mesma máquina. Para outro host, defina `window.WELLSTATE_API_BASE_URL` antes de `js/config.js`.

## 2. Escolher a rede e acompanhar PCs

Por padrão, `Wellstate:Network:Cidr` está em `auto`: a API encontra a interface IPv4 privada da rota principal do servidor e verifica essa sub-rede. O scan fica limitado a 4096 endereços por consulta, usa até 128 verificações simultâneas e guarda o resultado em cache por 8 segundos. O endpoint é apenas para rede local/VPN privada. Sem `iputils-ping` em Linux, a API devolve um erro `503` explicando a dependência.

Para escolher uma sub-rede fixa, edite `backend-csharp/appsettings.json`, por exemplo:

```json
"Network": {
  "Cidr": "192.168.1.0/24",
  "PingTimeoutMs": 350,
  "Parallelism": 128,
  "MaxHosts": 4096,
  "CacheSeconds": 8
}
```

O painel lista automaticamente os equipamentos que respondem ao scan. Para também apresentar um PC desligado, registre-o em `Wellstate:Pcs` com IP reservado/fixo:

```json
"Pcs": [
  { "id": "PC-LAB-01", "name": "Computador do laboratório 1", "ip": "192.168.1.25", "roomId": "C1.01" },
  { "id": "PC-LAB-02", "name": "Computador do laboratório 2", "ip": "192.168.1.26", "roomId": "C1.01" }
]
```

O status do inventário é **online** se o PC responder ao ping ou se o agente Wellstate enviar um heartbeat recente; os dois sinais aparecem separadamente no cartão. Instale o agente Windows para uma confirmação mais confiável quando o firewall bloquear ICMP. Sem um inventário prévio, nenhum scanner consegue saber que endereço corresponde a um PC que está desligado.

## 3. Abrir o painel

Abre `http://IP-DO-SERVIDOR:5080/` ou `http://IP-DO-SERVIDOR:5080/pcs.html`. Não abras os HTML diretamente com `file://`. O painel consulta a API com timeout e nova tentativa automática; uma verificação manual força o scan mesmo quando existe cache.

O stream SSE de `/api/pcs/stream` apresenta a presença do agente. A página de inventário atualiza a cada 15 segundos enquanto está visível.

## 4. Instalar os agentes dos PCs

Em cada PC, inicie o agente com o ID cadastrado no backend. O agente envia heartbeats, recebe apenas notificações de texto e confirma a apresentação da mensagem; não executa comandos remotos.

## 5. Arduino IDE e NodeMCU

1. Instale Arduino IDE 2.x e o pacote de placas ESP8266.
2. Abra `firmware/Wellstate_Firmware/Wellstate_Firmware.ino` e configure `secrets.h` com SSID/senha de Wi-Fi 2,4 GHz, token, URL da API e ID da sala.
3. Compile e grave com a placa NodeMCU 1.0 selecionada.

## Fora da LAN, dados móveis e segurança

A detecção automática verifica a rede conectada ao **servidor da API**, não a rede do navegador/celular. Em outra rede, use VPN com rota para a instalação central. A API não consegue enumerar PCs arbitrários pela Internet; firewalls, ICMP bloqueado, VLANs e redes convidadas também podem ocultar equipamentos. Não encaminhe diretamente a porta 5080 para a Internet. Se usar HTTPS, publique painel e API por um gateway HTTPS protegido e configure a URL da API para evitar conteúdo misto.

## Resolução de problemas

- `/api/health` com 503: confirme acesso de escrita ao diretório `Data` e verifique os logs do backend.
- Painel sem ligação: confirme endereço/porta, firewall TCP 5080, VPN e que o navegador alcança o host da API.
- Descoberta com 503: o servidor não encontrou uma interface IPv4 privada ativa; conecte-o à LAN ou configure `Wellstate:Network:Cidr`.
- Sub-rede errada: defina o CIDR manualmente, por exemplo `10.10.0.0/24`, e confirme que a API está rodando dentro dessa LAN/VPN.
- PC marcado offline: confirme IP reservado/fixo, firewall ICMP e heartbeat do agente; o agente precisa usar o mesmo `PcId` do inventário.
- Erro 409 ao enviar: o agente não comunicou nos últimos 8 segundos; ligue-o antes de voltar a enviar.
- Erro 401 no sensor: compare `Wellstate__DeviceApiKey` e `WELLSTATE_DEVICE_API_KEY`.
- Sem telemetria: verifique a NodeMCU, sensores, Wi-Fi e ligações elétricas.

## Login e registo (PHP + XAMPP)

1. Copie a pasta `frontend` para `C:\xampp\htdocs\wellstate` (o conteúdo fica em `http://localhost/wellstate/`).
2. No painel do XAMPP, inicie **Apache** e **MySQL**.
3. Abra `http://localhost/wellstate/register.html`, crie a conta e entre. A base de dados `wellstate` e a tabela `users` são criadas sozinhas no primeiro registo (ou importe `php/database.sql` no phpMyAdmin).
4. Se o MySQL tiver palavra-passe, altere `DB_PASS` em `frontend/php/config.php`.
5. A API REST (backend C#, porta 5080) continua a receber os dados do NodeMCU programado no Arduino IDE.

## Arranque rápido (só PHP, sem backend C#)

A pasta `frontend` já inclui a API em PHP (`frontend/api/index.php`, SQLite em `data/wellstate-api.db`). Basta servir o painel:

```
cd frontend
php -S localhost:8000
```

ou copiar `frontend` para `htdocs` no XAMPP (o `api/.htaccess` já trata das rotas; ative `mod_rewrite` e `pdo_sqlite`). O painel procura primeiro `/api` no mesmo servidor e só depois o backend C# na porta 5080. Para sensores, defina `WELLSTATE_DEVICE_API_KEY` no ambiente do PHP.

### Dispositivos na rede

A página **Dispositivos** corre um scan da sub-rede do servidor (ping em paralelo + tabela ARP + portas TCP típicas) de 20 em 20 segundos, identifica o fabricante (`frontend/api/data/oui.txt`) e classifica cada equipamento (Computador, Telemóvel, Tablet, Router, Impressora, TV, IoT, Servidor). Só aparece quem responde no momento: quem se desliga desaparece no scan seguinte. O nome e o tipo podem ser corrigidos no lápis de cada cartão.

- Requer `proc_open` ativo no PHP e que o servidor esteja ligado à mesma rede (Wi-Fi/Ethernet/VPN) dos dispositivos.
- Telemóveis com «endereço Wi-Fi privado» não têm fabricante visível; são marcados como «Telemóvel (provável)».
- Em `php -S`, as rotas com ponto no identificador (ex.: `C1.01`) usam `?id=`; para sensores use `POST /api/rooms/telemetry?roomId=C1.01` ou identificadores sem ponto.
- O scan corre num processo em segundo plano (`frontend/api/scan-worker.php`), por isso nunca bloqueia o servidor PHP embutido (que atende um pedido de cada vez). Se não for possível lançar processos, o scan corre dentro do pedido.


## Servidor PHP + NodeMCU (modo `php -S`)

1. Arranque sempre com o router: `iniciar-servidor.bat` (Windows) ou `./iniciar-servidor.sh`
   (equivale a `cd frontend && php -S 0.0.0.0:8000 router.php`).
   **Sem `router.php` o servidor embutido devolve 404** em `/api/rooms`.
2. A chave do sensor está em `frontend/api/config.local.php` (`device_key`) e tem de ser igual a `deviceApiKey` no sketch
   (`firmware/NodeMCU_Telemetria/NodeMCU_Telemetria.ino`). Também pode usar a variável `WELLSTATE_DEVICE_API_KEY`.
3. No Windows, permita o PHP na firewall (rede privada) para a porta 8000, senão a placa não chega ao PC.
4. Teste: `http://IP-DO-PC:8000/api/health` no telemóvel (mesma Wi-Fi) deve responder `status: ok`.

## Scanner da rede (dispositivos)

O servidor embutido do PHP atende um pedido de cada vez, por isso o scan da rede corre à parte. `iniciar-servidor.bat` (Windows) e `iniciar-servidor.sh` abrem o scanner automaticamente, e a API só lê o último resultado, que responde logo. Se abrires o servidor de outra forma, corre também `php api/scan-loop.php` numa segunda janela, dentro da pasta `frontend`.

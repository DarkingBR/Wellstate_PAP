# Segurança e rede (Wellstate)

- **Login**: bcrypt, limite de tentativas por IP (10) e por conta (5) em 15 min guardado na BD, tempo de resposta uniforme, sessão com cookie HttpOnly + SameSite=Strict, expira após 2 h sem atividade e fica presa ao navegador que a criou.
- **CSRF**: todos os POST de `php/` exigem o cabeçalho `X-CSRF-Token` (obtido em `php/csrf.php`) e verificam a origem do pedido.
- **API REST**: CORS só para a própria origem; `/api/network/*` exige sessão iniciada; alterar nomes/tipos de dispositivos exige a chave de administração; limite de 60 pedidos/min por IP (6/min para `refresh`).
- **Rede**: `GET /api/network/devices` devolve os dispositivos online, `serverTime` e `pollEverySeconds: 20`. O painel pede de 20 em 20 s e o servidor refaz o scan quando a cache tem mais de 15 s.
- **Ficheiros sensíveis**: `config.local.php`, `.sql` e bibliotecas internas bloqueados no router do PHP e no Apache.
- **Antes de apresentar**: mude `device_key` e `admin_key` em `api/config.local.php`, ponha palavra-passe no `root` do MySQL (ou use `WELLSTATE_DB_USER` / `WELLSTATE_DB_PASS`). Com HTTPS o cookie passa a `Secure` automaticamente.

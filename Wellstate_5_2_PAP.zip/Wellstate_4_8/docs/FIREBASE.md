# Firebase (Firestore)

O painel guarda uma cópia dos dados no projeto **wellstate-pap**. Quando a API REST falha, as páginas **Salas** e **Dispositivos** mostram a última cópia guardada, em vez de ficarem vazias.

Coleções usadas:

- `rooms/{salaId}`: última leitura de cada sala (distância, movimento, presença, relé, sistema ligado).
- `network/latest`: último inventário de dispositivos da rede.

O código está em `frontend/js/firebase.js`. Escreve de 20 em 20 segundos, no máximo, por página aberta.

## Para funcionar

1. Na consola Firebase, abre **Authentication > Sign-in method** e ativa **Anónimo**.
2. Abre **Firestore Database** e cria a base de dados (se ainda não existir).
3. Em **Regras**, cola o conteúdo de `firestore.rules` (na raiz do projeto) e publica.

Se aparecer "Firestore: sem permissão" na faixa cinzenta do site, é porque falta um destes passos.

A chave que está no código (`apiKey`) só identifica o projeto, não dá acesso por si. Quem decide o que se pode ler e escrever são as regras.

## Se não quiseres ativar o login anónimo

Usa o `firestore-teste.rules` em vez do `firestore.rules`. Funciona sem login, mas qualquer pessoa que conheça o projeto consegue ler e escrever nas coleções `rooms` e `network`. Serve para testar, não para deixar assim.

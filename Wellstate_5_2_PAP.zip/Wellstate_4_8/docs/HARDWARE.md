# Firmware e hardware · Wellstate

## Equipamento e ligações

Projeto para **NodeMCU v2 / ESP8266**, sensores **PIR HC-SR501** e **ultrassónico HC-SR04**, LED e resistência de 220 Ω.

| NodeMCU | Ligação | Observações |
|---|---|---|
| D5 / GPIO14 | PIR OUT | O sensor pode ser alimentado a VIN/5 V; garante que OUT não excede 3,3 V. |
| D6 / GPIO12 | HC-SR04 TRIG | O TRIG recebe 3,3 V da placa. |
| D7 / GPIO13 | Junção do divisor ligado a ECHO | **Não ligues ECHO de 5 V diretamente ao ESP8266.** |
| VIN / 5 V | HC-SR04 VCC | GND comum. |
| D1 / GPIO5 | Resistência 220 Ω → LED → GND | Acende com presença estimada; pisca com movimento sem confirmação de distância. |
| D0 / GPIO16 | Relé, pino IN | Ver `RELE_E_BOTAO.md`. |
| D4 / GPIO2 | Botão KY-004, pino S | Liga e põe em espera o projeto. |
| GND | GND de todos os módulos | Referência elétrica comum. |

Liga ECHO do HC-SR04 a uma resistência de 1 kΩ e depois à junção que segue para D7; da junção usa 2 kΩ para GND (cerca de 3,3 V). O ESP8266 usa lógica de 3,3 V.

## Arduino IDE

1. Instala Arduino IDE 2.x.
2. Adiciona o URL de placas ESP8266 em *Additional boards manager URLs*.
3. Em **Boards Manager**, instala **ESP8266 by ESP8266 Community** e seleciona **NodeMCU 1.0 (ESP-12E Module)**.
4. Abre `firmware/Wellstate_Firmware/Wellstate_Firmware.ino`.
5. Copia `secrets.example.h` para `secrets.h` e preenche Wi-Fi, URL da API e chave do dispositivo.
7. Compila e carrega. Monitor série a 115200 baud.

### Configuração de `secrets.h`

```cpp
#define WIFI_SSID                 "NOME_WIFI_2_4_GHZ"
#define WIFI_PASSWORD             "PALAVRA_PASSE_WIFI"
#define WELLSTATE_API_BASE_URL    "http://IP-RESERVADO-DO-SERVIDOR:5080"
#define WELLSTATE_DEVICE_API_KEY  "MESMO_TOKEN_CONFIGURADO_NO_BACKEND"
#define WELLSTATE_ROOM_ID         "C1.01"
```

O firmware publica a cada 10 segundos em `POST /api/rooms/{roomId}/telemetry` com o cabeçalho `X-Device-Key`. Payload atual:

```json
{ "distance": 120.5, "motion": true, "occupied": true }
```


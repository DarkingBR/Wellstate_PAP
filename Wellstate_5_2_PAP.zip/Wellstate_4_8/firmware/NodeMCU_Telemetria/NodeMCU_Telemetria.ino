/*
  Wellstate · NodeMCU (ESP8266) -> API PHP
  Envia a cada 10 s (ou ao premir o botão) a leitura do HC-SR04 + PIR para:
      POST http://<IP-DO-PC>:8000/api/rooms/telemetry?roomId=<SALA>
  Requer a biblioteca ArduinoJson 7.x.
*/
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <ArduinoJson.h>

// ---------- Configuração ----------
const char* ssid         = "DIGI-R6ah";
const char* password     = "fhFBDc2X";
const char* serverName   = "http://192.168.100.3:8000/api/rooms/telemetry?roomId=C1.01";
const char* deviceApiKey = "chavesecretaAPIKEY";   // igual a 'device_key' em frontend/api/config.local.php

// ---------- Pinos ----------
const int trigPin   = D1;  // HC-SR04 Trig
const int echoPin   = D2;  // HC-SR04 Echo (use divisor de tensão 5V -> 3,3V)
const int pirPin    = D5;  // PIR
const int buttonPin = D6;  // Botão (liga a GND)

#define SOUND_SPEED 0.034            // cm/µs
const unsigned long SEND_EVERY_MS = 10000;
const float NEAR_CM = 100.0;         // abaixo disto conta como presença

unsigned long lastSend = 0;
unsigned long lastButton = 0;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("A ligar ao Wi-Fi");
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) { delay(500); Serial.print("."); }
  if (WiFi.status() == WL_CONNECTED) Serial.println("\nLigado! IP: " + WiFi.localIP().toString());
  else Serial.println("\nSem Wi-Fi (vai tentar de novo).");
}

// Devolve a distância em cm, ou -1 se a leitura for inválida (a API só aceita 2–400 cm ou null)
float readDistanceCm() {
  digitalWrite(trigPin, LOW);  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH); delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH, 30000);   // timeout 30 ms (~5 m)
  if (duration == 0) return -1;
  float cm = duration * SOUND_SPEED / 2.0;
  return (cm < 2.0 || cm > 400.0) ? -1 : cm;
}

void sendTelemetry() {
  connectWiFi();
  if (WiFi.status() != WL_CONNECTED) return;

  bool pir = digitalRead(pirPin) == HIGH;
  float dist = readDistanceCm();
  bool near = (dist > 0 && dist < NEAR_CM);

  // A API só aceita occupied=true com motion=true
  bool occupied = pir || near;
  bool motion = occupied ? true : false;

  Serial.printf("Distância: %s | PIR: %s | Ocupada: %s\n",
                dist > 0 ? String(dist, 1).c_str() : "inválida", pir ? "SIM" : "NÃO", occupied ? "SIM" : "NÃO");

  JsonDocument doc;
  if (dist > 0) doc["distance"] = dist; else doc["distance"] = nullptr;
  doc["motion"] = motion;
  doc["occupied"] = occupied;
  String body; serializeJson(doc, body);

  WiFiClient client;
  HTTPClient http;
  http.setTimeout(8000);
  http.begin(client, serverName);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", deviceApiKey);
  int code = http.POST(body);
  if (code > 0) Serial.printf("API respondeu %d: %s\n", code, http.getString().c_str());
  else Serial.printf("Erro HTTP: %s\n", http.errorToString(code).c_str());
  http.end();
}

void setup() {
  Serial.begin(115200);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(pirPin, INPUT);
  pinMode(buttonPin, INPUT_PULLUP);
  connectWiFi();
}

void loop() {
  if (digitalRead(buttonPin) == LOW && millis() - lastButton > 700) {
    lastButton = millis();
    Serial.println("Botão premido: envio manual.");
    sendTelemetry();
    lastSend = millis();
  }
  if (millis() - lastSend >= SEND_EVERY_MS) {
    lastSend = millis();
    sendTelemetry();
  }
}

/*
 * Wellstate · ESP8266 / NodeMCU v2
 * Sensores: PIR HC-SR501 e ultrassónico HC-SR04.
 * Atuadores: LED de estado e módulo de relé (liga a carga da sala quando há alguém).
 * Botão (KY-004): liga e desliga o projeto inteiro.
 * Envia as medições para a API REST do Wellstate.
 */
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include "secrets.h"

#ifndef WELLSTATE_ROOM_ID
#define WELLSTATE_ROOM_ID "C1.01"
#endif

#define PIR_PIN    D5
#define TRIG_PIN   D6
#define ECHO_PIN   D7
#define LED_PIN    D1
#define RELAY_PIN  D0   // IN do módulo de relé (GPIO16)
#define BUTTON_PIN D4   // pino S do botão KY-004 (GPIO2: não carregues no botão ao ligar a placa)

// A maior parte dos módulos de relé liga com o pino em LOW. Se o teu fizer ao contrário, muda para false.
#define RELAY_ACTIVE_LOW true
// false = ao ligar a corrente o projeto fica em espera até carregares no botão.
#define START_ON false

namespace {
constexpr unsigned long WIFI_RETRY_MS = 15000;
constexpr unsigned long SENSOR_READ_MS = 1000;
constexpr unsigned long TELEMETRY_MS = 10000;
constexpr unsigned long DEBOUNCE_MS = 40;
constexpr unsigned long RELAY_HOLD_MS = 30000;   // o relé fica ligado 30 s depois da última presença
constexpr float PRESENCE_DISTANCE_CM = 200.0f;

float distanceCm = NAN;
bool motionDetected = false;
bool presenceConfirmed = false;
bool systemOn = START_ON;
bool relayOn = false;
bool ledOn = false;
bool configurationReady = false;
bool buttonIdle = HIGH;          // nível do botão em repouso, medido no arranque
bool buttonLast = HIGH;
bool buttonStable = HIGH;
unsigned long buttonChanged = 0;
unsigned long lastPresence = 0;
unsigned long lastWifiAttempt = 0;
unsigned long lastSensorRead = 0;
unsigned long lastTelemetryAttempt = 0;
unsigned long lastLedToggle = 0;

float readDistance() {
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(3);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    const unsigned long duration = pulseIn(ECHO_PIN, HIGH, 25000UL);
    if (duration == 0) return NAN;
    return (duration * 0.0343f) / 2.0f;
}

String encodePathSegment(const String& value) {
    String out;
    out.reserve(value.length() * 3);
    for (size_t i = 0; i < value.length(); i++) {
        const char c = value[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            out += c;
        } else {
            char buf[4];
            snprintf(buf, sizeof(buf), "%%%02X", (unsigned char)c);
            out += buf;
        }
    }
    return out;
}

void setRelay(bool on) {
    if (on == relayOn) return;
    relayOn = on;
    digitalWrite(RELAY_PIN, (on != RELAY_ACTIVE_LOW) ? HIGH : LOW);
    Serial.printf("[Relé] %s\n", on ? "ligado" : "desligado");
}

void ensureWifi() {
    if (WiFi.status() == WL_CONNECTED) return;
    const unsigned long now = millis();
    if (lastWifiAttempt != 0 && now - lastWifiAttempt < WIFI_RETRY_MS) return;
    lastWifiAttempt = now;
    Serial.printf("[Wi-Fi] A ligar a %s...\n", WIFI_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

String telemetryJson() {
    String json = "{\"distance\":";
    json += isnan(distanceCm) ? "null" : String(distanceCm, 1);
    json += ",\"motion\":";
    json += motionDetected ? "true" : "false";
    json += ",\"occupied\":";
    json += presenceConfirmed ? "true" : "false";
    json += ",\"relay\":";
    json += relayOn ? "true" : "false";
    json += ",\"systemOn\":";
    json += systemOn ? "true" : "false";
    json += "}";
    return json;
}

void postTelemetry() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[API] Sem Wi-Fi, volto a tentar no próximo intervalo.");
        return;
    }
    WiFiClient client;
    HTTPClient http;
    http.setTimeout(6000);
    const String url = String(WELLSTATE_API_BASE_URL) + "/api/rooms/" +
        encodePathSegment(String(WELLSTATE_ROOM_ID)) + "/telemetry";
    if (!http.begin(client, url)) {
        Serial.println("[API] Não consegui abrir a ligação HTTP.");
        return;
    }
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Device-Key", WELLSTATE_DEVICE_API_KEY);
    const int status = http.POST(telemetryJson());
    if (status >= 200 && status < 300) {
        Serial.printf("[API] Enviado · sala %s · sistema %s · relé %s\n",
            WELLSTATE_ROOM_ID, systemOn ? "ligado" : "em espera", relayOn ? "ligado" : "desligado");
    } else if (status > 0) {
        Serial.printf("[API ERRO] HTTP %d · %s\n", status, http.getString().c_str());
    } else {
        Serial.printf("[API ERRO] %s\n", http.errorToString(status).c_str());
    }
    http.end();
}

void setSystem(bool on) {
    systemOn = on;
    Serial.printf("[Botão] Projeto %s\n", on ? "LIGADO" : "em espera");
    if (!on) {
        motionDetected = false;
        presenceConfirmed = false;
        digitalWrite(LED_PIN, LOW);
        ledOn = false;
        setRelay(false);
    }
    lastTelemetryAttempt = 0;   // avisa o site já, sem esperar 10 s
}

void readButton() {
    const bool level = digitalRead(BUTTON_PIN);
    const unsigned long now = millis();
    if (level != buttonLast) { buttonLast = level; buttonChanged = now; }
    if (now - buttonChanged >= DEBOUNCE_MS && level != buttonStable) {
        buttonStable = level;
        if (buttonStable != buttonIdle) setSystem(!systemOn);   // conta só quando carregas
    }
}

void readSensors() {
    const unsigned long now = millis();
    motionDetected = digitalRead(PIR_PIN) == HIGH;
    if (now - lastSensorRead >= SENSOR_READ_MS || lastSensorRead == 0) {
        lastSensorRead = now;
        distanceCm = readDistance();
        presenceConfirmed = motionDetected && !isnan(distanceCm) && distanceCm < PRESENCE_DISTANCE_CM;
    }

    if (presenceConfirmed) {
        lastPresence = now;
        digitalWrite(LED_PIN, HIGH);
        ledOn = true;
    } else if (motionDetected) {
        if (now - lastLedToggle >= 180) {
            ledOn = !ledOn;
            digitalWrite(LED_PIN, ledOn ? HIGH : LOW);
            lastLedToggle = now;
        }
    } else {
        digitalWrite(LED_PIN, LOW);
        ledOn = false;
    }

    // Relé: liga com presença confirmada e só desliga passado o tempo de espera.
    const bool recentlyOccupied = lastPresence != 0 && now - lastPresence < RELAY_HOLD_MS;
    setRelay(recentlyOccupied);
}
} // namespace

void setup() {
    Serial.begin(115200);
    delay(250);
    Serial.println();
    Serial.println("Wellstate · presença de sala + relé + botão");
    Serial.printf("Sala: %s\n", WELLSTATE_ROOM_ID);

    pinMode(PIR_PIN, INPUT);
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
    pinMode(LED_PIN, OUTPUT);
    pinMode(RELAY_PIN, OUTPUT);
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    digitalWrite(TRIG_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    digitalWrite(RELAY_PIN, RELAY_ACTIVE_LOW ? HIGH : LOW);   // relé desligado ao arrancar

    delay(50);
    buttonIdle = digitalRead(BUTTON_PIN);   // com o botão solto, é este o nível de repouso
    buttonLast = buttonStable = buttonIdle;

    configurationReady = strlen(WIFI_SSID) > 0 && strlen(WIFI_PASSWORD) > 0 &&
        strlen(WELLSTATE_DEVICE_API_KEY) >= 24 && strlen(WELLSTATE_ROOM_ID) > 0 &&
        strlen(WELLSTATE_API_BASE_URL) > 0 && strstr(WELLSTATE_DEVICE_API_KEY, "CHANGE_ME") == nullptr &&
        strstr(WELLSTATE_API_BASE_URL, "CHANGE_ME") == nullptr &&
        strstr(WIFI_SSID, "CHANGE_ME") == nullptr && strstr(WIFI_PASSWORD, "CHANGE_ME") == nullptr;
    if (!configurationReady) {
        Serial.println("[CONFIG] Copia secrets.example.h para secrets.h e preenche o Wi-Fi, o endereço da API e a chave.");
        return;
    }
    ensureWifi();
}

void loop() {
    readButton();   // o botão responde sempre, mesmo em espera
    if (!configurationReady) {
        delay(20);
        return;
    }
    ensureWifi();
    if (systemOn) readSensors();
    const unsigned long now = millis();
    if (now - lastTelemetryAttempt >= TELEMETRY_MS || lastTelemetryAttempt == 0) {
        lastTelemetryAttempt = now;
        postTelemetry();
    }
    delay(10);
}

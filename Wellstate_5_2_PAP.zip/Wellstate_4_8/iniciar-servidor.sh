#!/usr/bin/env sh
cd "$(dirname "$0")/frontend" || exit 1
php api/scan-loop.php >/dev/null 2>&1 &
SCAN=$!
trap 'kill $SCAN 2>/dev/null' EXIT INT TERM
echo "Wellstate em http://localhost:8000"
PHP_CLI_SERVER_WORKERS=4 php -S 0.0.0.0:8000 router.php

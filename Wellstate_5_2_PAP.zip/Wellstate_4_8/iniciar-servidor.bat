@echo off
chcp 65001 >nul
title Wellstate - servidor
cd /d "%~dp0frontend"
echo.
echo  Wellstate a correr em  http://localhost:8000   (rede: http://IP-DO-PC:8000)
echo  Abriram-se duas janelas: o servidor e o scanner da rede. Feche as duas para parar.
echo.
start "Wellstate - scanner da rede" /min php api\scan-loop.php
php -S 0.0.0.0:8000 router.php
pause

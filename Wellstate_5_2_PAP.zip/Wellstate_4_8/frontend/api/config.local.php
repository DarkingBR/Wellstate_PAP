<?php
/* Wellstate · configuração local da API (não partilhar / não enviar para o Git).
   A chave abaixo tem de ser IGUAL à do cabeçalho X-Device-Key do NodeMCU (deviceApiKey no .ino).
   Em alternativa pode usar as variáveis de ambiente WELLSTATE_DEVICE_API_KEY e WELLSTATE_ADMIN_API_KEY,
   que têm prioridade sobre este ficheiro. */
return [
    'device_key' => 'chavesecretaAPIKEY',
    'admin_key'  => '',   // vazio = escritas de configuração sem chave de administração
];

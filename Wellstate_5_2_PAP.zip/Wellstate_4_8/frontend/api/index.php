<?php
declare(strict_types=1);
/* Wellstate · API REST em PHP (substitui o backend C# quando só o PHP está a correr).
   Funciona com `php -S localhost:8000` na pasta frontend e com Apache/XAMPP (ver api/.htaccess).
   Base de dados: SQLite em ../../data/wellstate-api.db (criada automaticamente, sem MySQL). */

/* Compatibilidade: funciona mesmo sem a extensão mbstring */
if (!function_exists('mb_strlen')) { function mb_strlen($s, $e = null) { return (int)preg_match_all('/./us', (string)$s); } }
if (!function_exists('mb_substr')) { function mb_substr($s, $st, $len = null, $e = null) { preg_match_all('/./us', (string)$s, $m); return implode('', array_slice($m[0], $st, $len)); } }

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header_remove('X-Powered-By');
/* CORS: só aceita a própria origem (o painel). O NodeMCU não usa CORS. */
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && strcasecmp((string)parse_url($origin, PHP_URL_HOST), explode(':', $_SERVER['HTTP_HOST'] ?? '')[0]) === 0) {
    header('Access-Control-Allow-Origin: ' . $origin); header('Access-Control-Allow-Credentials: true'); header('Vary: Origin');
}
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Key, X-Device-Key');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

function out($data, int $status = 200): void { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function fail(string $message, int $status = 400): void { out(['message' => $message], $status); }
function body(): array
{
    $raw = file_get_contents('php://input') ?: '';
    if (strlen($raw) > 1048576) fail('O pedido é demasiado grande.', 413);
    if (trim($raw) === '') return [];
    $d = json_decode($raw, true);
    if (!is_array($d)) fail('Corpo do pedido inválido: JSON esperado.', 400);
    return $d;
}
function iso(string $s): string { return gmdate('Y-m-d\TH:i:s\Z', strtotime($s . ' UTC') ?: time()); }

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'OPTIONS') { http_response_code(204); exit; }

/* ---------- Caminho: tudo o que vem depois de /api/ ---------- */
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$pos = strpos($uri, '/api/');
$path = $pos === false ? '' : substr($uri, $pos + 5);
$path = preg_replace('#^index\.php/?#', '', $path);
$parts = array_values(array_filter(explode('/', trim($path, '/')), 'strlen'));
$parts = array_map('rawurldecode', $parts);
$root = $parts[0] ?? '';

/* ---------- Chaves (variável de ambiente > api/config.local.php) ---------- */
function local_config(): array
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $f = __DIR__ . '/config.local.php';
    $cfg = is_file($f) ? (include $f) : [];
    return is_array($cfg) ? $cfg : ($cfg = []);
}
function device_key(): string { return (string)(getenv('WELLSTATE_DEVICE_API_KEY') ?: (local_config()['device_key'] ?? '')); }
function admin_key(): string { return (string)(getenv('WELLSTATE_ADMIN_API_KEY') ?: (local_config()['admin_key'] ?? '')); }

/* ---------- Base de dados ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    if (!extension_loaded('pdo_sqlite')) {
        fail('A extensão pdo_sqlite do PHP não está ativa.', 503);
        exit;
    }
    
    $dir = dirname(__DIR__, 2) . '/data';
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
        fail('Não foi possível criar a pasta de dados: ' . $dir, 503);
        exit;
    }
    
    try {
        $pdo = new PDO('sqlite:' . $dir . '/wellstate-api.db', null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        $pdo->exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
        $pdo->exec("CREATE TABLE IF NOT EXISTS room_catalog (room_id TEXT PRIMARY KEY COLLATE NOCASE, name TEXT NOT NULL COLLATE NOCASE UNIQUE, sort_order INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS schedule_lessons (id INTEGER PRIMARY KEY AUTOINCREMENT, day INTEGER NOT NULL, subject TEXT NOT NULL, group_name TEXT NOT NULL DEFAULT '', teacher TEXT NOT NULL DEFAULT '', room_id TEXT NOT NULL COLLATE NOCASE, start_time TEXT NOT NULL, end_time TEXT NOT NULL, updated_at TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_schedule_day ON schedule_lessons(day, start_time);
            CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS room_telemetry (id INTEGER PRIMARY KEY AUTOINCREMENT, room_id TEXT NOT NULL COLLATE NOCASE, distance REAL, motion INTEGER NOT NULL, occupied INTEGER NOT NULL, event TEXT NOT NULL, created_at TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_telemetry_room ON room_telemetry(room_id, id);
            CREATE TABLE IF NOT EXISTS device_aliases (device_key TEXT PRIMARY KEY, alias TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL);");
        // Colunas novas do relé e do botão (bases de dados antigas são atualizadas aqui)
        $cols = array_column($pdo->query('PRAGMA table_info(room_telemetry)')->fetchAll(), 'name');
        if (!in_array('relay', $cols, true)) $pdo->exec('ALTER TABLE room_telemetry ADD COLUMN relay INTEGER NOT NULL DEFAULT 0');
        if (!in_array('system_on', $cols, true)) $pdo->exec('ALTER TABLE room_telemetry ADD COLUMN system_on INTEGER NOT NULL DEFAULT 1');
        return $pdo;
    } catch (Throwable $e) { 
        fail('Não foi possível abrir a base de dados SQLite: ' . $e->getMessage(), 503);
        exit; 
    }
}

/* Sessão do painel (mesmo cookie do login PHP). Usada para proteger a rede e a configuração. */
function has_session(): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) { session_name('wellstate_session'); @session_start(['read_and_close' => true]); }
    return !empty($_SESSION['uid']);
}
function require_session(): void { if (!has_session()) fail('Sessão não iniciada. Entre no painel.', 401); }
/* Limite de pedidos por IP (ficheiro em data/), contra abuso e DoS simples. */
function rate_limit(string $bucket, int $max, int $window): void
{
    @mkdir(dirname(__DIR__, 2) . '/data', 0775, true);
    $f = dirname(__DIR__, 2) . '/data/rl-' . md5($bucket . ($_SERVER['REMOTE_ADDR'] ?? '')) . '.json';
    $d = is_file($f) ? (json_decode((string)@file_get_contents($f), true) ?: []) : [];
    $d = array_values(array_filter($d, fn($t) => $t > time() - $window));
    if (count($d) >= $max) { header('Retry-After: ' . $window); fail('Demasiados pedidos. Tente mais tarde.', 429); }
    $d[] = time(); @file_put_contents($f, json_encode($d), LOCK_EX);
}

function now(): string { return gmdate('Y-m-d H:i:s'); }

/* ---------- Validação ---------- */
function room_input(array $d): array
{
    $id = trim((string)($d['id'] ?? '')); $name = trim((string)($d['name'] ?? ''));
    if ($id === '') fail('O identificador da sala é obrigatório.');
    if (mb_strlen($id) < 2 || mb_strlen($id) > 20) fail('O identificador deve ter entre 2 e 20 caracteres.');
    if (!preg_match('/^[A-Za-z0-9._\-]+$/', $id)) fail('Use apenas letras, números, ponto, hífen ou underscore no identificador.');
    if ($name === '') fail('O nome da sala é obrigatório.');
    if (mb_strlen($name) > 80) fail('O nome da sala deve ter entre 1 e 80 caracteres.');
    return [$id, $name];
}
function lesson_input(array $d): array
{
    $day = (int)($d['day'] ?? 0);
    if ($day < 1 || $day > 5) fail('O dia tem de estar entre 1 (segunda) e 5 (sexta).');
    $subject = trim((string)($d['subject'] ?? ''));
    if ($subject === '' || mb_strlen($subject) > 40) fail('A disciplina deve ter entre 1 e 40 caracteres.');
    $group = trim((string)($d['group'] ?? '')); if (mb_strlen($group) > 40) fail('A turma não pode ter mais de 40 caracteres.');
    $teacher = trim((string)($d['teacher'] ?? '')); if (mb_strlen($teacher) > 60) fail('O professor não pode ter mais de 60 caracteres.');
    $room = trim((string)($d['room'] ?? '')); if ($room === '') fail('A sala é obrigatória.');
    $start = (string)($d['start'] ?? ''); $end = (string)($d['end'] ?? '');
    if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $start)) fail('Hora de início inválida (HH:MM).');
    if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $end)) fail('Hora de fim inválida (HH:MM).');
    if ($end <= $start) fail('A hora de fim tem de ser posterior à de início.');
    return [$day, $subject, $group, $teacher, $room, $start, $end];
}
function require_admin(): void
{
    $expected = admin_key();
    if ($expected !== '' && !hash_equals($expected, (string)($_SERVER['HTTP_X_ADMIN_KEY'] ?? '')))
        fail('Chave de administração inválida ou em falta.', 401);
}
function lesson_row(array $r): array
{
    return ['id' => (int)$r['id'], 'day' => (int)$r['day'], 'subject' => $r['subject'], 'group' => $r['group_name'], 'teacher' => $r['teacher'],
        'room' => $r['room_id'], 'start' => $r['start_time'], 'end' => $r['end_time'], 'updatedAt' => iso($r['updated_at'])];
}
function telemetry_row(array $r): array
{
    return ['id' => (int)$r['id'], 'roomId' => $r['room_id'], 'distance' => $r['distance'] === null ? null : (float)$r['distance'],
        'motion' => (bool)$r['motion'], 'occupied' => (bool)$r['occupied'], 'relay' => (bool)($r['relay'] ?? 0), 'systemOn' => (bool)($r['system_on'] ?? 1), 'event' => $r['event'], 'updatedAt' => iso($r['created_at'])];
}
function room_exists(string $id): bool { $s = db()->prepare('SELECT 1 FROM room_catalog WHERE room_id = ?'); $s->execute([$id]); return (bool)$s->fetchColumn(); }

/* ---------- Rotas ---------- */
try {
    switch ($root) {
        case 'health':
            $dataDir = dirname(__DIR__, 2) . '/data';
            $problem = !extension_loaded('pdo_sqlite') ? 'A extensão pdo_sqlite do PHP não está ativa (php.ini).'
                : ((is_dir($dataDir) ? !is_writable($dataDir) : !is_writable(dirname($dataDir))) ? 'Sem permissão para escrever na pasta data/ do projeto.' : null);
            if ($problem) out(['service' => 'Wellstate.API', 'status' => 'degraded', 'database' => 'error', 'detail' => $problem, 'runtime' => 'php', 'now' => gmdate('c')]);
            db()->query('SELECT 1');
            out(['service' => 'Wellstate.API', 'status' => 'ok', 'database' => 'ok', 'signalStorage' => 'sqlite', 'runtime' => 'php', 'now' => gmdate('c')]);

        case 'config':
            $sub = $parts[1] ?? '';
            if ($method === 'GET' && $sub === '') {
                $pdo = db();
                $init = $pdo->query("SELECT value FROM app_meta WHERE key='initialized'")->fetchColumn();
                $rooms = array_map(fn($r) => ['id' => $r['room_id'], 'name' => $r['name']], $pdo->query('SELECT room_id, name FROM room_catalog ORDER BY sort_order, room_id')->fetchAll());
                $lessons = array_map('lesson_row', $pdo->query('SELECT * FROM schedule_lessons ORDER BY day, start_time, room_id')->fetchAll());
                out(['initialized' => $init === '1', 'adminKeyRequired' => (admin_key()) !== '', 'rooms' => $rooms, 'lessons' => $lessons]);
            }
            require_admin();
            $pdo = db();
            if ($method === 'POST' && $sub === 'import') {
                $d = body(); $rooms = $d['rooms'] ?? []; $lessons = $d['lessons'] ?? [];
                if (!is_array($rooms) || !is_array($lessons) || count($rooms) > 200 || count($lessons) > 1000) fail('Importação demasiado grande.');
                $has = (int)$pdo->query('SELECT COUNT(*) FROM room_catalog')->fetchColumn() > 0
                    || $pdo->query("SELECT value FROM app_meta WHERE key='initialized'")->fetchColumn() === '1';
                if ($has) out(['imported' => false]);
                $pdo->beginTransaction();
                $order = 0;
                foreach ($rooms as $r) { [$id, $name] = room_input((array)$r);
                    $pdo->prepare('INSERT OR IGNORE INTO room_catalog(room_id,name,sort_order,updated_at) VALUES(?,?,?,?)')->execute([$id, $name, $order++, now()]); }
                foreach ($lessons as $l) { [$day, $sub2, $g, $t, $room, $s, $e] = lesson_input((array)$l);
                    $pdo->prepare('INSERT INTO schedule_lessons(day,subject,group_name,teacher,room_id,start_time,end_time,updated_at) VALUES(?,?,?,?,?,?,?,?)')->execute([$day, $sub2, $g, $t, $room, $s, $e, now()]); }
                $pdo->exec("INSERT OR REPLACE INTO app_meta(key,value) VALUES('initialized','1')");
                $pdo->commit();
                out(['imported' => true]);
            }
            if ($sub === 'rooms') {
                $id = $parts[2] ?? (isset($_GET['id']) ? (string)$_GET['id'] : null); // ?id= evita o 405 do php -S em URLs com ponto (C1.01)
                if ($method === 'POST' || $method === 'PUT') {
                    [$newId, $name] = room_input(body());
                    $dupName = $pdo->prepare('SELECT room_id FROM room_catalog WHERE name = ? AND room_id <> ?');
                    $dupName->execute([$name, $id ?? '']);
                    if ($dupName->fetchColumn()) fail("Já existe uma sala com o nome '$name'.", 409);
                    if ($method === 'POST') {
                        if (room_exists($newId)) fail("Já existe uma sala com o identificador '$newId'.", 409);
                        $next = (int)$pdo->query('SELECT COALESCE(MAX(sort_order),-1)+1 FROM room_catalog')->fetchColumn();
                        $pdo->prepare('INSERT INTO room_catalog(room_id,name,sort_order,updated_at) VALUES(?,?,?,?)')->execute([$newId, $name, $next, now()]);
                        $pdo->exec("INSERT OR REPLACE INTO app_meta(key,value) VALUES('initialized','1')");
                        out(['id' => $newId, 'name' => $name], 201);
                    }
                    if (!$id || !room_exists($id)) fail('Sala não encontrada.', 404);
                    if (strcasecmp($newId, $id) !== 0 && room_exists($newId)) fail("Já existe uma sala com o identificador '$newId'.", 409);
                    $pdo->beginTransaction();
                    $pdo->prepare('UPDATE room_catalog SET room_id=?, name=?, updated_at=? WHERE room_id=?')->execute([$newId, $name, now(), $id]);
                    $pdo->prepare('UPDATE schedule_lessons SET room_id=? WHERE room_id=?')->execute([$newId, $id]);
                    $pdo->commit();
                    out(['id' => $newId, 'name' => $name]);
                }
                if ($method === 'DELETE' && $id) {
                    $used = $pdo->prepare('SELECT COUNT(*) FROM schedule_lessons WHERE room_id = ?'); $used->execute([$id]);
                    $usedCount = (int)$used->fetchColumn();
                    if ($usedCount > 0) fail('A sala tem ' . $usedCount . ' aula(s) no horário. Mova ou remova essas aulas antes de apagar a sala.', 409);
                    $del = $pdo->prepare('DELETE FROM room_catalog WHERE room_id = ?'); $del->execute([$id]);
                    if ($del->rowCount() === 0) fail('Sala não encontrada.', 404);
                    http_response_code(204); exit;
                }
            }
            if ($sub === 'lessons') {
                $id = isset($parts[2]) ? (int)$parts[2] : null;
                if ($method === 'POST' || $method === 'PUT') {
                    [$day, $subject, $g, $t, $room, $s, $e] = lesson_input(body());
                    if (!room_exists($room)) fail('A sala indicada não existe no catálogo.');
                    if ($method === 'POST') {
                        $pdo->prepare('INSERT INTO schedule_lessons(day,subject,group_name,teacher,room_id,start_time,end_time,updated_at) VALUES(?,?,?,?,?,?,?,?)')->execute([$day, $subject, $g, $t, $room, $s, $e, now()]);
                        $id = (int)$pdo->lastInsertId();
                    } else {
                        $u = $pdo->prepare('UPDATE schedule_lessons SET day=?,subject=?,group_name=?,teacher=?,room_id=?,start_time=?,end_time=?,updated_at=? WHERE id=?');
                        $u->execute([$day, $subject, $g, $t, $room, $s, $e, now(), $id]);
                        if ($u->rowCount() === 0) fail('Aula não encontrada.', 404);
                    }
                    $row = $pdo->prepare('SELECT * FROM schedule_lessons WHERE id=?'); $row->execute([$id]);
                    out(lesson_row($row->fetch()), $method === 'POST' ? 201 : 200);
                }
                if ($method === 'DELETE' && $id) {
                    $del = $pdo->prepare('DELETE FROM schedule_lessons WHERE id=?'); $del->execute([$id]);
                    if ($del->rowCount() === 0) fail('Aula não encontrada.', 404);
                    http_response_code(204); exit;
                }
            }
            fail('Rota não encontrada.', 404);

        case 'rooms':
            $pdo = db(); $sub = $parts[1] ?? '';
            if ($method === 'GET' && $sub === '') {
                $rows = $pdo->query('SELECT t.* FROM room_telemetry t JOIN (SELECT room_id, MAX(id) mid FROM room_telemetry GROUP BY room_id) m ON m.mid = t.id ORDER BY t.room_id COLLATE NOCASE')->fetchAll();
                out(array_map('telemetry_row', $rows));
            }
            if ($method === 'GET' && $sub === 'history') {
                $where = []; $args = [];
                if (!empty($_GET['roomId'])) { $where[] = 'room_id = ?'; $args[] = (string)$_GET['roomId']; }
                foreach (['from' => '>=', 'to' => '<='] as $k => $op) if (!empty($_GET[$k])) {
                    $ts = strtotime((string)$_GET[$k]); if ($ts === false) fail("O parâmetro '$k' é inválido.");
                    $where[] = "created_at $op ?"; $args[] = gmdate('Y-m-d H:i:s', $ts);
                }
                $limit = max(1, min(5000, (int)($_GET['limit'] ?? 500)));
                $st = $pdo->prepare('SELECT * FROM room_telemetry' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY id DESC LIMIT $limit");
                $st->execute($args);
                out(array_map('telemetry_row', $st->fetchAll()));
            }
            if ($method === 'POST' && (($parts[2] ?? '') === 'telemetry' || $sub === 'telemetry')) {
                $roomId = trim($sub === 'telemetry' ? (string)($_GET['roomId'] ?? '') : $sub); // /rooms/telemetry?roomId=C1.01 evita o 404 do php -S com pontos
                if ($roomId === '' || mb_strlen($roomId) > 80) fail('O identificador da sala deve ter entre 1 e 80 caracteres.');
                $expected = device_key();
                if ($expected === '') fail('A API ainda não tem uma chave de dispositivo configurada (variável WELLSTATE_DEVICE_API_KEY).', 503);
                if (!hash_equals($expected, (string)($_SERVER['HTTP_X_DEVICE_KEY'] ?? ''))) fail('Chave do dispositivo inválida.', 401);
                $d = body(); $motion = !empty($d['motion']); $occ = !empty($d['occupied']);
                $relay = !empty($d['relay']); $sysOn = !array_key_exists('systemOn', $d) || !empty($d['systemOn']);
                if ($occ && !$motion) fail('Uma sala só pode ser marcada como ocupada quando há movimento detetado.');
                $dist = isset($d['distance']) && is_numeric($d['distance']) ? (float)$d['distance'] : null;
                if ($dist !== null && ($dist < 2 || $dist > 400)) fail('A distância deve estar entre 2 e 400.');
                $event = $occ ? 'occupied' : ($motion ? 'motion' : 'reading');
                $pdo->prepare('INSERT INTO room_telemetry(room_id,distance,motion,occupied,event,created_at,relay,system_on) VALUES(?,?,?,?,?,?,?,?)')->execute([$roomId, $dist, (int)$motion, (int)$occ, $event, now(), (int)$relay, (int)$sysOn]);
                $row = $pdo->prepare('SELECT * FROM room_telemetry WHERE id=?'); $row->execute([$pdo->lastInsertId()]);
                out(telemetry_row($row->fetch()), 201);
            }
            fail('Rota não encontrada.', 404);

        case 'pcs':
            if (($parts[1] ?? '') === 'stream') {
                header('Content-Type: text/event-stream; charset=utf-8'); header('Cache-Control: no-cache');
                echo "retry: 15000\ndata: []\n\n"; exit;
            }
            if (($parts[1] ?? '') !== '') fail('PC não encontrado.', 404);
            out([]);

        case 'network':
            require_session();
            rate_limit('net', 60, 60);
            require_once __DIR__ . '/network.php';
            if (($parts[1] ?? '') === 'diagnostics') out(['serverTime' => gmdate('c')] + ws_diagnostics());
            if (($parts[1] ?? '') !== 'devices') fail('Rota não encontrada.', 404);
            // PUT /api/network/devices/{chave} -> nome/tipo personalizados; DELETE repõe a deteção automática
            if (isset($parts[2])) {
                $key = strtoupper(trim($parts[2]));
                if (!preg_match('/^([0-9A-F]{2}(:[0-9A-F]{2}){5}|\d{1,3}(\.\d{1,3}){3})$/', $key)) fail('Identificador de dispositivo inválido (use MAC ou IP).');
                $pdo = db();
                if (in_array($method, ['PUT', 'DELETE'], true)) { require_admin(); }
                if ($method === 'DELETE') { $pdo->prepare('DELETE FROM device_aliases WHERE device_key = ?')->execute([$key]); ws_invalidate(); http_response_code(204); exit; }
                if ($method !== 'PUT') fail('Método não permitido.', 405);
                $d = body();
                $alias = trim((string)($d['alias'] ?? '')); $kind = trim((string)($d['kind'] ?? ''));
                if (mb_strlen($alias) > 40) fail('O nome não pode ter mais de 40 caracteres.');
                if ($alias !== '' && !preg_match('/^[\p{L}\p{N} ._\-\/()+]+$/u', $alias)) fail('O nome contém caracteres inválidos.');
                if ($kind !== '' && !isset(WS_KINDS[$kind])) fail('Tipo de dispositivo inválido.');
                if ($alias === '' && $kind === '') { $pdo->prepare('DELETE FROM device_aliases WHERE device_key = ?')->execute([$key]); }
                else $pdo->prepare('INSERT INTO device_aliases(device_key,alias,kind,updated_at) VALUES(?,?,?,?) ON CONFLICT(device_key) DO UPDATE SET alias=excluded.alias, kind=excluded.kind, updated_at=excluded.updated_at')->execute([$key, $alias, $kind, now()]);
                ws_invalidate();
                out(['key' => $key, 'alias' => $alias, 'kind' => $kind]);
            }
            if ($method !== 'GET') fail('Método não permitido.', 405);
            if (!empty($_GET['refresh'])) rate_limit('netrefresh', 6, 60);
            try { out(['serverTime' => gmdate('c'), 'pollEverySeconds' => 20] + ws_scan_get(db(), filter_var($_GET['refresh'] ?? false, FILTER_VALIDATE_BOOLEAN))); }
            catch (RuntimeException $e) { fail($e->getMessage(), 503); }

        default:
            fail('Rota não encontrada.', 404);
    }
} catch (Throwable $e) {
    if ($e instanceof PDOException && stripos($e->getMessage(), 'locked') !== false) fail('Base de dados ocupada. Tente novamente.', 503);
    error_log('Wellstate API: ' . $e->getMessage());
    fail('Erro interno do servidor.', 500);
}

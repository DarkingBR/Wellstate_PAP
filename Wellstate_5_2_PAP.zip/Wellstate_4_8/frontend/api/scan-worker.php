<?php
declare(strict_types=1);
/* Wellstate · worker do scan de rede (corre em segundo plano; ver ws_start_worker em network.php). */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/network.php';

$dir = ws_data_dir();
$lock = fopen($dir . '/scan.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) exit(0);      // já há um scan em curso
@set_time_limit(60);
$pdo = null;
try {
    $pdo = new PDO('sqlite:' . $dir . '/wellstate-api.db', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $pdo->exec('PRAGMA busy_timeout=3000');
} catch (Throwable $e) { $pdo = null; }
try {
    ws_scan_run($pdo, in_array('force', $argv ?? [], true));
    @unlink($dir . '/network-error.txt');
} catch (Throwable $e) {
    @file_put_contents($dir . '/network-error.txt', $e->getMessage());
}
flock($lock, LOCK_UN);

<?php
/* Copie para config.local.php e defina chaves próprias. */
return [
    'device_key' => 'COLOQUE_AQUI_UMA_CHAVE_ALEATORIA',
    'admin_key'  => '',
];

<?php
declare(strict_types=1);
/* Wellstate · scanner permanente da rede. Corre num processo à parte (ver iniciar-servidor.bat / .sh),
   faz um scan de 20 em 20 segundos e guarda o resultado. Assim a API nunca fica à espera do scan. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/network.php';

$dir = ws_data_dir();
$lock = fopen($dir . '/loop.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) { echo "O scanner já está a correr.\n"; exit(0); }
@set_time_limit(0);
echo "Wellstate · scanner de rede ligado (de 20 em 20 segundos). Feche esta janela para parar.\n";

while (true) {
    $t = microtime(true);
    @touch($dir . '/loop-heartbeat.txt');
    $pdo = null;
    try {
        $pdo = new PDO('sqlite:' . $dir . '/wellstate-api.db', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
        $pdo->exec('PRAGMA busy_timeout=3000');
    } catch (Throwable $e) { $pdo = null; }
    try {
        $r = ws_scan_run($pdo, false);
        @unlink($dir . '/network-error.txt');
        echo '[' . date('H:i:s') . '] ' . count($r['devices']) . " dispositivo(s) em " . $r['durationMs'] . " ms\n";
    } catch (Throwable $e) {
        @file_put_contents($dir . '/network-error.txt', $e->getMessage());
        echo '[' . date('H:i:s') . '] ' . $e->getMessage() . "\n";
    }
    @touch($dir . '/loop-heartbeat.txt');
    sleep((int)max(3, ceil(20 - (microtime(true) - $t))));
}

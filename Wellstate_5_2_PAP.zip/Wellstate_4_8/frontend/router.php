<?php
declare(strict_types=1);
/* Wellstate · router do servidor embutido do PHP.
   Arranque (na pasta frontend):  php -S 0.0.0.0:8000 router.php
   - /api/...  -> api/index.php (API REST)
   - ficheiros existentes (html, css, js, php/...) -> servidos normalmente
   - tudo o resto -> 404 */
$uri = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');

if ($uri === '/api' || strpos($uri, '/api/') === 0) {
    require __DIR__ . '/api/index.php';
    return true;
}
if ($uri === '/') { header('Location: /login.html', true, 302); return true; }

/* Ficheiros que nunca devem ser servidos (chaves, SQL, bibliotecas internas). */
if (preg_match('#(^|/)(config\.local[^/]*\.php|database\.sql|\.htaccess|\.git[^/]*|scan-worker\.php|network\.php)$#i', $uri) || strpos($uri, '..') !== false || strpos($uri, "\0") !== false) {
    http_response_code(403); header('Content-Type: text/plain; charset=utf-8'); echo 'Acesso negado.'; return true;
}
if (preg_match('/\.(css|js|png|gif|ico|svg|woff2?)$/i', $uri)) header('Cache-Control: public, max-age=120');
header('X-Content-Type-Options: nosniff'); header('X-Frame-Options: DENY'); header('Referrer-Policy: same-origin');
$file = realpath(__DIR__ . $uri);
if ($file !== false && is_file($file) && strpos($file, realpath(__DIR__)) === 0) {
    return false; // deixa o PHP servir o ficheiro estático / executar php/*.php
}
http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
echo 'Não encontrado: ' . $uri;
return true;

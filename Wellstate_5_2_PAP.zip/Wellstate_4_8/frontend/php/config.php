<?php
declare(strict_types=1);

/* Wellstate · configuração PHP/MySQL (XAMPP). Utilizador padrão do XAMPP: root, sem palavra-passe. */
define('DB_HOST', getenv('WELLSTATE_DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('WELLSTATE_DB_NAME') ?: 'wellstate');
define('DB_USER', getenv('WELLSTATE_DB_USER') ?: 'root');
define('DB_PASS', getenv('WELLSTATE_DB_PASS') ?: '');
const SESSION_IDLE = 7200;      // 2 h sem atividade termina a sessão
const MAX_FAILS_IP = 10;        // falhas por IP em 15 min
const MAX_FAILS_ACCOUNT = 5;    // falhas por conta em 15 min

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'secure' => $https, 'samesite' => 'Strict']);
session_name('wellstate_session');
session_start();

/* Sessão: expira por inatividade e fica presa ao navegador que a criou (mitiga roubo de sessão). */
$ua = hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
if (!empty($_SESSION['uid'])) {
    if (time() - ($_SESSION['last'] ?? 0) > SESSION_IDLE || !hash_equals($_SESSION['ua'] ?? '', $ua)) { $_SESSION = []; session_regenerate_id(true); }
}
$_SESSION['last'] = time();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header_remove('X-Powered-By');

function respond(int $status, array $body)
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

function input(): array
{
    $data = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($data) ? $data : [];
}

function require_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(405, ['message' => 'Método não permitido.']);
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') === false)
        respond(415, ['message' => 'Pedido inválido.']);
    if (!hash_equals($_SESSION['csrf'], (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')))
        respond(403, ['message' => 'Sessão de segurança expirada. Recarregue a página.']);
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '' && strcasecmp((string)parse_url($origin, PHP_URL_HOST) . ':' . (parse_url($origin, PHP_URL_PORT) ?: ''), explode(':', $_SERVER['HTTP_HOST'] ?? '')[0] . ':' . (explode(':', $_SERVER['HTTP_HOST'] ?? '')[1] ?? '')) !== 0)
        respond(403, ['message' => 'Origem não permitida.']);
}

function client_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }

/* Limite de tentativas guardado na BD (não pode ser contornado apagando cookies). */
function attempts_table(): void
{
    db()->exec('CREATE TABLE IF NOT EXISTS login_attempts (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(45) NOT NULL, email VARCHAR(190) NOT NULL, ok TINYINT(1) NOT NULL DEFAULT 0, at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(ip, at), INDEX(email, at)) ENGINE=InnoDB');
}
function recent_fails(string $col, string $val): int
{
    attempts_table();
    $s = db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE $col = ? AND ok = 0 AND at > (NOW() - INTERVAL 15 MINUTE)");
    $s->execute([$val]);
    return (int)$s->fetchColumn();
}
function log_attempt(string $email, bool $ok): void
{
    attempts_table();
    db()->prepare('INSERT INTO login_attempts (ip, email, ok) VALUES (?,?,?)')->execute([client_ip(), $email, (int)$ok]);
    db()->exec('DELETE FROM login_attempts WHERE at < (NOW() - INTERVAL 2 DAY)');
}

/* Liga ao MySQL e cria a base de dados e a tabela na primeira utilização. */
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $opts = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
        $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, $opts);
        $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo->exec('USE `' . DB_NAME . '`');
        $pdo->exec('CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(80) NOT NULL,
            email VARCHAR(190) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        return $pdo;
    } catch (PDOException $e) {
        respond(503, ['message' => 'Não foi possível ligar ao MySQL. Inicie o MySQL no painel do XAMPP.']);
    }
}

function public_user(array $u): array
{
    return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email']];
}

<?php
require __DIR__ . '/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') respond(405, ['message' => 'Método não permitido.']);
respond(200, ['csrf' => $_SESSION['csrf']]);

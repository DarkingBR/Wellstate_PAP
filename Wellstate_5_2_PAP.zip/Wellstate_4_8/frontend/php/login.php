<?php
require __DIR__ . '/config.php';
require_post();

$in = input();
$email = strtolower(trim((string)($in['email'] ?? '')));
$password = (string)($in['password'] ?? '');
if ($email === '' || $password === '') respond(422, ['message' => 'Preencha o e-mail e a palavra-passe.']);
if (strlen($email) > 190 || strlen($password) > 200 || !filter_var($email, FILTER_VALIDATE_EMAIL))
    respond(422, ['message' => 'E-mail ou palavra-passe inválidos.']);

/* Anti força-bruta: por IP e por conta, na base de dados. */
if (recent_fails('ip', client_ip()) >= MAX_FAILS_IP || recent_fails('email', $email) >= MAX_FAILS_ACCOUNT) {
    header('Retry-After: 900');
    respond(429, ['message' => 'Demasiadas tentativas falhadas. Aguarde 15 minutos e tente de novo.']);
}

$stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

/* Verifica sempre um hash (mesmo sem utilizador) para o tempo de resposta não revelar se o e-mail existe. */
$hash = $user['password_hash'] ?? '$2y$10$usesomesillystringforsaltuQ3nQmQ1xKQ0m0m0m0m0m0m0m0m0m0m';
$valid = password_verify($password, $hash) && $user;
if (!$valid) {
    log_attempt($email, false);
    usleep(random_int(150000, 350000));
    respond(401, ['message' => 'E-mail ou palavra-passe incorretos.']);
}
log_attempt($email, true);

if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT))
    db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);

session_regenerate_id(true);
$_SESSION['uid'] = (int)$user['id'];
$_SESSION['ua'] = hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
$_SESSION['csrf'] = bin2hex(random_bytes(32));
respond(200, ['user' => public_user($user), 'csrf' => $_SESSION['csrf']]);

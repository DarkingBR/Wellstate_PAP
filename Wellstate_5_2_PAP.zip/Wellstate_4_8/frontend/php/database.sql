-- Opcional: o PHP cria isto sozinho no primeiro pedido. Útil para importar no phpMyAdmin.
CREATE DATABASE IF NOT EXISTS wellstate CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE wellstate;
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

<?php
require __DIR__ . '/config.php';
require_post();

$in = input();
$name = trim((string)($in['name'] ?? ''));
$email = strtolower(trim((string)($in['email'] ?? '')));
$password = (string)($in['password'] ?? '');
$confirm = (string)($in['confirm'] ?? '');

$errors = [];
$name = preg_replace('/\s+/u', ' ', strip_tags($name));
if (mb_strlen($name) < 2 || mb_strlen($name) > 80 || !preg_match('/^[\p{L}\p{N} .\'-]+$/u', $name)) $errors['name'] = 'Escreva o seu nome (2 a 80 caracteres).';
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) $errors['email'] = 'Introduza um e-mail válido.';
if (strlen($password) < 8 || strlen($password) > 200 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password) || strtolower($password) === $email)
    $errors['password'] = 'Use pelo menos 8 caracteres, com letras e números.';
if ($password !== $confirm) $errors['confirm'] = 'As palavras-passe não coincidem.';
if ($errors) respond(422, ['message' => 'Corrija os campos assinalados.', 'errors' => $errors]);

if (recent_fails('ip', client_ip()) >= MAX_FAILS_IP) respond(429, ['message' => 'Demasiados pedidos. Tente mais tarde.']);
$pdo = db();
$exists = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$exists->execute([$email]);
if ($exists->fetch()) respond(409, ['message' => 'Este e-mail já está registado.', 'errors' => ['email' => 'Este e-mail já tem conta. Inicie sessão.']]);

$pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);

session_regenerate_id(true);
$_SESSION['uid'] = (int)$pdo->lastInsertId();
$_SESSION['ua'] = hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
$_SESSION['csrf'] = bin2hex(random_bytes(32));
respond(201, ['user' => ['id' => $_SESSION['uid'], 'name' => $name, 'email' => $email], 'csrf' => $_SESSION['csrf']]);

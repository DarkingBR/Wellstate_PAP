/* Faixa de estado por baixo do menu e aviso quando a ligação falha. */
import { apiClient } from "./api-client.js";

const header = document.querySelector(".site-header");
if (header) {
    const strip = document.createElement("div");
    strip.className = "ws-strip";
    strip.innerHTML = `<div class="ws-strip-inner">
        <span><i class="fa-solid fa-server"></i><b>API</b> <em id="wsApi" style="font-style:normal">a verificar…</em><i class="ws-dot" id="wsApiDot"></i></span>
        <span><i class="fa-solid fa-cloud"></i><b>Firestore</b> <em id="wsCloud" style="font-style:normal">a ligar…</em><i class="ws-dot" id="wsCloudDot"></i></span>
        <span><i class="fa-solid fa-rotate"></i><b>Atualização</b> de 20 em 20 segundos</span>
        <span><i class="fa-solid fa-microchip"></i><b>Sensores</b> PIR, ultrassónico, relé e botão</span>
    </div>`;
    const notice = document.createElement("div");
    notice.className = "ws-notice";
    notice.hidden = true;
    notice.innerHTML = '<div class="ws-notice-inner"><strong><i class="fa-solid fa-triangle-exclamation"></i> Sem ligação à API</strong><span id="wsWhy">Os dados mostrados podem estar desatualizados.</span> <a href="diagnostico.html" style="text-decoration:underline;font-weight:600">Ver diagnóstico</a></div>';
    header.insertAdjacentElement("afterend", notice);
    header.insertAdjacentElement("afterend", strip);

    const set = (id, text, state) => {
        document.getElementById(id).textContent = text;
        document.getElementById(id + "Dot").className = "ws-dot " + state;
    };
    const check = async () => {
        try {
            const h = await apiClient.getHealth();
            if (h.status === "degraded") { set("wsApi", "com problema", "bad"); document.getElementById("wsWhy").textContent = h.detail; notice.hidden = false; }
            else { set("wsApi", "ligada", "ok"); notice.hidden = true; }
        } catch (error) {
            set("wsApi", "indisponível", "bad");
            document.getElementById("wsWhy").textContent = error.message;
            notice.hidden = false;
        }
    };
    window.addEventListener("wellstate:cloud", e => {
        const s = e.detail;
        set("wsCloud", s === "ok" ? "ligado" : s === "denied" ? "sem permissão (ver docs/FIREBASE.md)" : "indisponível", s === "ok" ? "ok" : "bad");
    });
    check();
    setInterval(check, 20000);
}

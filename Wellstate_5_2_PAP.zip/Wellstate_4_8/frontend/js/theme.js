/* Wellstate 2.0 · identidade visual única (fundo cinza claro, cartões carvão). */
(function () {
    document.documentElement.setAttribute("data-theme", "wellstate");
    try { localStorage.removeItem("wellstate-theme"); } catch (e) { /* ignore */ }
})();

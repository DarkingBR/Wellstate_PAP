/* Wellstate · cópia dos dados no Firebase (Firestore).
   A chave abaixo identifica o projeto, não é secreta. Quem protege os dados são as regras do Firestore (firestore.rules). */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getFirestore, doc, setDoc, getDoc, collection, getDocs, writeBatch } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getAnalytics, isSupported } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-analytics.js";

const firebaseConfig = {
    apiKey: "AIzaSyBCkOKVdEZlkIWhKg_feyde2dvM7YGzbns",
    authDomain: "wellstate-pap.firebaseapp.com",
    projectId: "wellstate-pap",
    storageBucket: "wellstate-pap.firebasestorage.app",
    messagingSenderId: "600103840665",
    appId: "1:600103840665:web:4a653f023fafa2c02c0108",
    measurementId: "G-LGE14T04DP"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
isSupported().then(ok => { if (ok) getAnalytics(app); }).catch(() => {});

const say = state => window.dispatchEvent(new CustomEvent("wellstate:cloud", { detail: state }));
const signedIn = signInAnonymously(getAuth(app)).catch(() => null);
const lastSave = {};
const SAVE_EVERY_MS = 20000;

const fail = error => say(error && error.code === "permission-denied" ? "denied" : "error");

async function save(path, data) {
    if (Date.now() - (lastSave[path] || 0) < SAVE_EVERY_MS) return;
    lastSave[path] = Date.now();
    try {
        await signedIn;
        if (path === "/rooms") {
            const batch = writeBatch(db);
            data.forEach(r => batch.set(doc(db, "rooms", String(r.roomId)), { ...r, savedAt: new Date().toISOString() }));
            await batch.commit();
        } else {
            const devices = (data.devices || []).slice(0, 250).map(d => ({
                ip: d.ip, mac: d.mac || "", hostname: d.hostname || "", vendor: d.vendor || "", kind: d.kind || "", kindLabel: d.kindLabel || "",
                responseMs: d.responseMs ?? null, isGateway: !!d.isGateway, isSelf: !!d.isSelf, key: d.key || d.ip
            }));
            await setDoc(doc(db, "network", "latest"), { scanCidr: data.scanCidr || "", scannedAt: data.scannedAt || null, savedAt: new Date().toISOString(), count: devices.length, devices });
        }
        say("ok");
    } catch (error) { fail(error); }
}

async function load(path) {
    try {
        await signedIn;
        let result = null;
        if (path === "/rooms") {
            const snap = await getDocs(collection(db, "rooms"));
            result = snap.docs.map(d => d.data());
            if (!result.length) result = null;
        } else {
            const snap = await getDoc(doc(db, "network", "latest"));
            if (snap.exists()) {
                const d = snap.data();
                result = { ...d, online: true, fromBackup: true, scanning: false, automaticallyDetected: true,
                    devices: d.devices.map(x => ({ ...x, online: true, confidence: "medium", reasons: ["Última leitura guardada no Firestore"], openPorts: [] })),
                    summary: d.devices.reduce((acc, x) => (acc[x.kind] = (acc[x.kind] || 0) + 1, acc), {}) };
            }
        }
        if (result) { window.WS_FROM_BACKUP = Date.now(); say("ok"); }
        return result;
    } catch (error) { fail(error); return null; }
}

export default { save, load };

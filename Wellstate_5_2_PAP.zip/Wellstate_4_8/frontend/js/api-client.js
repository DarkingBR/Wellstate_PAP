/* Cliente REST partilhado pelo painel, histórico e inventário da rede. */
const CFG = window.WELLSTATE_CONFIG;
const root = () => String(CFG.API_BASE_URL || "").replace(/\/+$/, "");

async function rawRequest(path, options = {}) {
    if (window.WellstateApi) await window.WellstateApi.ready;
    const method = String(options.method || "GET").toUpperCase();
    const retries = method === "GET" ? Math.max(CFG.API_RETRIES ?? 1, 1) : 0;
    let lastError;

    const hasJson = options.body && typeof options.body === "object" && !(options.body instanceof FormData);
    const body = hasJson ? JSON.stringify(options.body) : options.body;
    const headers = { Accept: "application/json", ...(hasJson ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };

    for (let attempt = 0; attempt <= retries; attempt++) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), options.timeoutMs ?? CFG.API_TIMEOUT_MS ?? 12000);
        try {
            const response = await fetch(`${root()}${path}`, {
                ...options,
                body,
                method,
                cache: "no-store",
                credentials: CFG.API_CREDENTIALS || "same-origin",
                headers,
                signal: controller.signal
            });

            if (!response.ok) {
                let message = `A API respondeu HTTP ${response.status}.`;
                try {
                    const body = await response.json();
                    message = body.message || body.title || body.detail || message;
                } catch { /* resposta sem JSON */ }
                const error = new Error(message);
                error.status = response.status;
                if (response.status < 500 || response.status === 503 || attempt === retries) throw error;
                lastError = error;
            } else {
                if (response.status === 204) return null;
                if (!(response.headers.get("content-type") || "").includes("json")) {
                    // Resposta HTML: o endereço aponta para um servidor que não é a API Wellstate.
                    const wrong = new TypeError("wrong-base");
                    wrong.wrongBase = true;
                    throw wrong;
                }
                return await response.json();
            }
        } catch (error) {
            lastError = error.wrongBase
                ? new Error("O endereço configurado não é a API Wellstate (recebeu HTML). Confirme que a pasta api/ está no servidor e que o PHP está a correr.")
                : error.name === "AbortError"
                ? new Error("A API demorou demasiado para responder. Verifique a rede ou tente novamente.")
                : error.name === "TypeError"
                    ? new Error("Não foi possível alcançar a API. Confirme que o backend está ligado e que o endereço do painel aponta para ele.")
                    : error;
            if (error.status && (error.status < 500 || error.status === 503)) throw error;
            if (error.name === "TypeError" && window.WellstateApi) await window.WellstateApi.discover();
            if (attempt === retries) throw lastError;
        } finally {
            clearTimeout(timeout);
        }

        await new Promise(resolve => setTimeout(resolve, 350 * (attempt + 1)));
    }

    throw lastError || new Error("Não foi possível ligar à API.");
}

const cloud = import("./firebase.js").then(m => m.default).catch(() => null);
const BACKED_UP = ["/rooms", "/network/devices"];

/* Pede à API; guarda uma cópia no Firestore e, se a API falhar, devolve a última cópia. */
async function request(path, options = {}) {
    const clean = path.split("?")[0];
    const watched = String(options.method || "GET").toUpperCase() === "GET" && BACKED_UP.includes(clean);
    try {
        const data = await rawRequest(path, options);
        if (watched) cloud.then(c => c && c.save(clean, data));
        return data;
    } catch (error) {
        if (!watched) throw error;
        const c = await cloud;
        const copy = c && await c.load(clean);
        if (!copy) throw error;
        return copy;
    }
}

export const apiClient = Object.freeze({
    get: path => request(path),
    getLatestRooms: () => request("/rooms"),
    getPcs: () => request("/pcs"),
    getNetworkDevices: ({ refresh = false } = {}) => request(`/network/devices${refresh ? "?refresh=true" : ""}`),
    getHistory: ({ roomId, limit = 2000, from, to } = {}) => {
        const params = new URLSearchParams({ limit: String(limit) });
        if (roomId) params.set("roomId", roomId);
        if (from) params.set("from", new Date(from).toISOString());
        if (to) params.set("to", new Date(to).toISOString());
        return request(`/rooms/history?${params.toString()}`);
    },
    getHealth: () => request("/health", { timeoutMs: 6000 }),
    setDeviceAlias: (key, { alias = "", kind = "" } = {}) => request(`/network/devices/${encodeURIComponent(key)}`, { method: "PUT", body: { alias, kind } }),
    resetDeviceAlias: key => request(`/network/devices/${encodeURIComponent(key)}`, { method: "DELETE" })
});

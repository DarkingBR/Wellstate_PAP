
/** Validações de formulário (PAP — rigor profissional) */
function validateRoomId(id) {
    if (!id || typeof id !== "string") return "Identificador da sala é obrigatório.";
    const v = id.trim();
    if (v.length < 2 || v.length > 20) return "O identificador deve ter entre 2 e 20 caracteres.";
    if (!/^[A-Za-z0-9._\-]+$/.test(v)) return "Use apenas letras, números, ponto, hífen ou underscore.";
    return null;
}
function validateIp(ip) {
    if (!ip || !ip.trim()) return "Endereço IP é obrigatório.";
    const parts = ip.trim().split(".");
    if (parts.length !== 4) return "IP deve ter o formato x.x.x.x";
    for (const p of parts) {
        const n = Number(p);
        if (!Number.isInteger(n) || n < 0 || n > 255) return "Cada octeto do IP deve estar entre 0 e 255.";
    }
    return null;
}
function validateName(name, label = "Nome") {
    if (!name || !String(name).trim()) return `${label} é obrigatório.`;
    if (String(name).trim().length > 80) return `${label} demasiado longo (máx. 80).`;
    return null;
}
function validateTime(t) {
    if (!t || !/^\d{1,2}:\d{2}$/.test(t)) return "Hora inválida (use HH:MM).";
    const [h, m] = t.split(":").map(Number);
    if (h < 0 || h > 23 || m < 0 || m > 59) return "Hora fora do intervalo válido.";
    return null;
}
function showToast(msg, type = "success") { window.WellstateUI.toast(msg, type); }

/* Wellstate · administração: salas e horário guardados na API (SQLite); PCs de referência locais. */
(function () {
    let STORE = window.WellstateStore.get();
    const DAYS = { 1: "Segunda", 2: "Terça", 3: "Quarta", 4: "Quinta", 5: "Sexta" };
    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
    const ok = msg => showToast(msg, "success");
    const fail = msg => showToast(msg, "error");

    async function run(button, action, success) {
        try { await window.WellstateUI.withLoading(button, action); if (success) ok(success); }
        catch (error) { fail(error.message); }
    }

    function tabActivate(name) {
        document.querySelectorAll(".tab-btn").forEach(button => button.classList.toggle("active", button.dataset.tab === name));
        document.querySelectorAll(".tab-panel").forEach(panel => panel.classList.toggle("active", panel.dataset.tab === name));
    }
    document.querySelectorAll(".tab-btn").forEach(button => button.addEventListener("click", () => tabActivate(button.dataset.tab)));

    function renderRooms() {
        const body = $("roomsBody");
        body.replaceChildren();
        if (!STORE.rooms.length) body.innerHTML = `<tr><td colspan="3" class="empty-row">Ainda não há salas. Adicione a primeira.</td></tr>`;
        STORE.rooms.forEach(room => {
            const row = document.createElement("tr");
            row.innerHTML = `<td data-label="Identificador"><input class="admin-input" value="${esc(room.id)}" maxlength="20" aria-label="ID da sala" /></td><td data-label="Nome"><input class="admin-input" value="${esc(room.name)}" maxlength="80" aria-label="Nome da sala" /></td><td class="row-actions"><button class="btn-ghost btn-sm" data-act="save" aria-label="Guardar sala"><i class="fa-solid fa-check"></i></button><button class="btn-ghost btn-sm danger" data-act="del" aria-label="Remover sala"><i class="fa-solid fa-trash"></i></button></td>`;
            const saveBtn = row.querySelector('[data-act="save"]');
            saveBtn.addEventListener("click", () => {
                const [id, name] = [...row.querySelectorAll("input")].map(input => input.value.trim());
                const problem = validateRoomId(id) || validateName(name, "Nome da sala");
                if (problem) return fail(problem);
                if (STORE.rooms.some(item => item.id.toLowerCase() === id.toLowerCase() && item.id !== room.id)) return fail("Já existe uma sala com esse identificador.");
                run(saveBtn, () => window.WellstateStore.updateRoom(room.id, { id, name }), "Sala guardada.");
            });
            const delBtn = row.querySelector('[data-act="del"]');
            delBtn.addEventListener("click", async () => {
                if (!await window.WellstateUI.confirm({ title: "Remover sala", message: `A sala ${room.name} será removida do servidor. Esta ação não pode ser anulada.`, confirmLabel: "Remover", danger: true })) return;
                run(delBtn, () => window.WellstateStore.deleteRoom(room.id), "Sala removida.");
            });
            body.appendChild(row);
        });
    }

    function renderPcs() {
        const body = $("pcsBody");
        body.replaceChildren();
        if (!STORE.pcs.length) body.innerHTML = `<tr><td colspan="5" class="empty-row">Sem computadores de referência neste navegador.</td></tr>`;
        const options = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        STORE.pcs.forEach((pc, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `<td data-label="ID"><input class="admin-input" value="${esc(pc.id)}" maxlength="32" aria-label="ID do computador" /></td><td data-label="Nome"><input class="admin-input" value="${esc(pc.name)}" maxlength="80" aria-label="Nome do computador" /></td><td data-label="IP"><input class="admin-input" value="${esc(pc.ip)}" aria-label="Endereço IP" /></td><td data-label="Sala"><select class="admin-input" aria-label="Sala">${options}</select></td><td class="row-actions"><button class="btn-ghost btn-sm" data-act="save" aria-label="Guardar computador"><i class="fa-solid fa-check"></i></button><button class="btn-ghost btn-sm danger" data-act="del" aria-label="Remover computador"><i class="fa-solid fa-trash"></i></button></td>`;
            row.querySelector("select").value = pc.roomId;
            row.querySelector('[data-act="save"]').addEventListener("click", () => {
                const fields = row.querySelectorAll("input,select");
                const next = { id: fields[0].value.trim(), name: fields[1].value.trim(), ip: fields[2].value.trim(), roomId: fields[3].value };
                const problem = (next.id.length < 2 || next.id.length > 32 ? "ID obrigatório (2–32 caracteres)." : null) || validateName(next.name) || validateIp(next.ip);
                if (problem) return fail(problem);
                if (STORE.pcs.some((p, i) => i !== index && (p.id === next.id || p.ip === next.ip))) return fail("Já existe um computador com esse ID ou IP.");
                STORE.pcs[index] = next;
                persistPcs("Computador guardado. Para o servidor o monitorizar, adicione-o também a Wellstate:Pcs no appsettings.json.");
            });
            row.querySelector('[data-act="del"]').addEventListener("click", async () => { if (await window.WellstateUI.confirm({ title: "Remover dispositivo", message: `Remover ${pc.name} (${pc.ip}) da lista de referência?`, confirmLabel: "Remover", danger: true })) { STORE.pcs.splice(index, 1); persistPcs("Computador removido."); } });
            body.appendChild(row);
        });
    }

    function renderSchedule() {
        const wrap = $("scheduleAdmin");
        wrap.replaceChildren();
        const options = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        [1, 2, 3, 4, 5].forEach(dayNumber => {
            const day = document.createElement("section");
            day.className = "day-block";
            day.innerHTML = `<div class="day-head"><h3><i class="fa-solid fa-calendar-day"></i> ${DAYS[dayNumber]}</h3><button class="btn-ghost btn-sm add-class"><i class="fa-solid fa-plus"></i> Aula</button></div><div class="day-rows"></div>`;
            const rows = day.querySelector(".day-rows");
            (STORE.schedule[dayNumber] || []).forEach(lesson => {
                const row = document.createElement("div");
                row.className = "class-row admin-class-row";
                row.innerHTML = `<input class="admin-input" value="${esc(lesson.subject)}" maxlength="40" placeholder="Disciplina" aria-label="Disciplina" /><input class="admin-input" value="${esc(lesson.group || "")}" maxlength="40" placeholder="Turma" aria-label="Turma" /><input class="admin-input" value="${esc(lesson.teacher || "")}" maxlength="60" placeholder="Docente" aria-label="Docente" /><select class="admin-input" aria-label="Sala">${options}</select><input type="time" class="admin-input" value="${esc(lesson.start)}" aria-label="Início" /><input type="time" class="admin-input" value="${esc(lesson.end)}" aria-label="Fim" /><button class="btn-ghost btn-sm" data-act="save" aria-label="Guardar aula"><i class="fa-solid fa-check"></i></button><button class="btn-ghost btn-sm danger" data-act="del" aria-label="Remover aula"><i class="fa-solid fa-trash"></i></button>`;
                row.querySelector("select").value = lesson.room;
                const saveBtn = row.querySelector('[data-act="save"]');
                saveBtn.addEventListener("click", () => {
                    const f = row.querySelectorAll("input,select");
                    const next = { day: dayNumber, subject: f[0].value.trim(), group: f[1].value.trim(), teacher: f[2].value.trim(), room: f[3].value, start: f[4].value, end: f[5].value };
                    if (!next.subject) return fail("A disciplina é obrigatória.");
                    const problem = validateTime(next.start) || validateTime(next.end);
                    if (problem) return fail(problem);
                    if (next.start >= next.end) return fail("A hora de fim tem de ser posterior à hora de início.");
                    run(saveBtn, () => window.WellstateStore.updateLesson(lesson.id, next), "Aula guardada.");
                });
                const delBtn = row.querySelector('[data-act="del"]');
                delBtn.addEventListener("click", async () => {
                    if (!await window.WellstateUI.confirm({ title: "Remover aula", message: `Remover ${lesson.subject} (${lesson.start}–${lesson.end})?`, confirmLabel: "Remover", danger: true })) return;
                    run(delBtn, () => window.WellstateStore.deleteLesson(lesson.id), "Aula removida.");
                });
                rows.appendChild(row);
            });
            if (!(STORE.schedule[dayNumber] || []).length) rows.innerHTML = `<p class="empty-row">Sem aulas neste dia.</p>`;
            const addBtn = day.querySelector(".add-class");
            addBtn.addEventListener("click", () => {
                if (!STORE.rooms.length) return fail("Crie primeiro uma sala.");
                const taken = (STORE.schedule[dayNumber] || []).map(l => l.end).sort();
                const slot = (window.TIME_SLOTS || []).map(s => s.split(" - ")).find(([s]) => !taken.length || s >= taken[taken.length - 1]) || ["17:30", "18:20"];
                run(addBtn, () => window.WellstateStore.createLesson({ day: dayNumber, subject: "Nova aula", group: "", teacher: "", room: STORE.rooms[0].id, start: slot[0], end: slot[1] }), "Aula adicionada — edite os detalhes e guarde.");
            });
            wrap.appendChild(day);
        });
    }

    const addRoomBtn = $("addRoomBtn");
    addRoomBtn.addEventListener("click", async () => {
        const values = await window.WellstateUI.form({
            title: "Adicionar sala",
            submitLabel: "Criar sala",
            fields: [
                { name: "id", label: "Identificador", placeholder: "C1.01", maxlength: 20, hint: "Letras, números, ponto, hífen ou underscore." },
                { name: "name", label: "Nome / bloco", placeholder: "Bloco C · Sala 1.01", maxlength: 80 }
            ],
            validate: v => {
                const e = validateRoomId(v.id); if (e) return { field: "id", message: e };
                if (STORE.rooms.some(r => r.id.toLowerCase() === v.id.toLowerCase())) return { field: "id", message: "Já existe uma sala com este identificador." };
                const n = validateName(v.name, "Nome da sala"); if (n) return { field: "name", message: n };
                return null;
            }
        });
        if (values) run(addRoomBtn, () => window.WellstateStore.createRoom(values), `Sala ${values.id} criada.`);
    });
    $("addPcBtn").addEventListener("click", async () => {
        const values = await window.WellstateUI.form({
            title: "Adicionar dispositivo",
            submitLabel: "Adicionar",
            fields: [
                { name: "id", label: "ID", placeholder: "PC-LAB-01", maxlength: 32 },
                { name: "name", label: "Nome", placeholder: "Computador do laboratório", maxlength: 80 },
                { name: "ip", label: "Endereço IP", placeholder: "192.168.1.50" },
                { name: "roomId", label: "Sala", options: STORE.rooms.map(r => ({ value: r.id, label: r.name })), value: STORE.rooms[0]?.id }
            ],
            validate: v => {
                if (v.id.length < 2 || v.id.length > 32) return { field: "id", message: "ID obrigatório (2–32 caracteres)." };
                if (STORE.pcs.some(p => p.id === v.id)) return { field: "id", message: "Já existe um dispositivo com este ID." };
                const n = validateName(v.name, "Nome"); if (n) return { field: "name", message: n };
                const i = validateIp(v.ip); if (i) return { field: "ip", message: i };
                if (STORE.pcs.some(p => p.ip === v.ip)) return { field: "ip", message: "Já existe um dispositivo com este IP." };
                return null;
            }
        });
        if (!values) return;
        STORE.pcs.push({ id: values.id, name: values.name, ip: values.ip, roomId: values.roomId || "" });
        persistPcs(`Dispositivo ${values.id} adicionado.`);
    });
    $("resetBtn").addEventListener("click", () => run($("resetBtn"), () => window.WellstateStore.sync(), "Dados recarregados do servidor."));
    $("exportBtn").addEventListener("click", () => {
        const blob = new Blob([JSON.stringify(STORE, null, 2)], { type: "application/json" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = `wellstate-config-${new Date().toISOString().slice(0, 10)}.json`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 1000);
        ok("Cópia de segurança exportada.");
    });
    $("importBtn").addEventListener("click", () => $("importFile").click());
    $("importFile").addEventListener("change", async event => {
        const file = event.target.files[0];
        event.target.value = "";
        if (!file) return;
        if (file.size > 1024 * 1024) return fail("Ficheiro demasiado grande (máx. 1 MB).");
        try {
            const data = JSON.parse(await file.text());
            if (!Array.isArray(data.rooms) || !data.schedule || typeof data.schedule !== "object") throw new Error("Ficheiro inválido: são necessárias salas e horário.");
            if (!await window.WellstateUI.confirm({ title: "Importar configuração", message: `Adicionar ao servidor ${data.rooms.length} sala(s) e as aulas deste ficheiro? Registos duplicados ou em conflito serão ignorados.`, confirmLabel: "Importar" })) return;
            let added = 0, skipped = 0;
            for (const room of data.rooms) {
                if (STORE.rooms.some(r => r.id.toLowerCase() === String(room.id).toLowerCase())) { skipped++; continue; }
                try { await window.WellstateStore.createRoom({ id: String(room.id).trim(), name: String(room.name).trim() }); added++; STORE = window.WellstateStore.get(); } catch { skipped++; }
            }
            for (const [day, list] of Object.entries(data.schedule)) for (const l of (list || [])) {
                try { await window.WellstateStore.createLesson({ day: Number(day), subject: l.subject, group: l.group, teacher: l.teacher, room: l.room, start: l.start, end: l.end }); added++; } catch { skipped++; }
            }
            if (Array.isArray(data.pcs)) { STORE = window.WellstateStore.get(); data.pcs.forEach(p => { if (!validateIp(p.ip) && !STORE.pcs.some(x => x.id === p.id || x.ip === p.ip)) STORE.pcs.push(p); }); window.WellstateStore.save(STORE); }
            ok(`Importação concluída: ${added} registo(s) adicionados, ${skipped} ignorados.`);
        } catch (error) { fail(error instanceof SyntaxError ? "O ficheiro não é JSON válido." : error.message); }
    });

    function persistPcs(message) {
        window.WellstateStore.save(STORE);
        STORE = window.WellstateStore.get();
        renderAll();
        ok(message);
    }
    function renderAll() { renderRooms(); renderPcs(); renderSchedule(); }
    window.addEventListener("wellstate:store-updated", () => { STORE = window.WellstateStore.get(); renderAll(); });
    
    renderAll();
})();

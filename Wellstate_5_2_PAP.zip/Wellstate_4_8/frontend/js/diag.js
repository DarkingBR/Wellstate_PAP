import { apiClient } from "./api-client.js";

const esc = v => String(v ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const mark = ok => ok ? '<span class="ok">sim</span>' : '<span class="bad">não</span>';

async function testBase(base) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 3000);
    try {
        const r = await fetch(base + "/health", { cache: "no-store", signal: ctl.signal });
        const type = r.headers.get("content-type") || "";
        const text = await r.text();
        let json = null; try { json = JSON.parse(text); } catch {}
        return { base, ok: Boolean(json && json.service === "Wellstate.API"), note: `HTTP ${r.status} · ${type.split(";")[0] || "sem tipo"}${json && json.detail ? " · " + json.detail : ""}` };
    } catch (e) { return { base, ok: false, note: e.name === "AbortError" ? "sem resposta em 3 s" : "ligação recusada" }; }
    finally { clearTimeout(timer); }
}

(async () => {
    const rows = await Promise.all(window.WellstateApi.candidates().map(testBase));
    document.getElementById("probes").innerHTML = "<tr><th>Endereço</th><th>API Wellstate?</th><th>Resposta</th></tr>" +
        rows.map(r => `<tr><td>${esc(r.base)}</td><td>${mark(r.ok)}</td><td>${esc(r.note)}</td></tr>`).join("");
    const raw = document.getElementById("raw"), table = document.getElementById("server");
    try {
        const d = await apiClient.get("/network/diagnostics");
        const net = d.network;
        const lines = [
            ["Sistema / PHP", `${d.os} · PHP ${d.php}`],
            ["Pode executar comandos (proc_open)", mark(d.procOpen)],
            ["Pode lançar o scan em segundo plano", mark(d.popen && d.phpBinary)],
            ["Pasta data/ gravável", mark(d.dataDirWritable)],
            ["Rede privada encontrada", net ? `${mark(true)} ${esc(net.ip)}/${net.prefix} · gateway ${esc(net.gateway || "?")} · ${esc(net.interface)}` : `${mark(false)} ${esc(d.networkError)}`],
            ["Entradas na tabela ARP", d.arpEntries ?? "—"],
            ["Ping ao gateway", d.gatewayPing ? `${mark(true)} ${d.gatewayPing.ms} ms` : mark(false)],
            ["Último scan", d.lastScanAt ? `${esc(d.lastScanAt)} · ${d.lastDevices} dispositivo(s)` : "ainda nenhum"],
            ["Último erro do scan", d.lastError ? `<span class="bad">${esc(d.lastError)}</span>` : "nenhum"]
        ];
        table.innerHTML = lines.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join("");
        raw.textContent = JSON.stringify(d, null, 2);
    } catch (e) {
        table.innerHTML = `<tr><td class="bad">${esc(e.message)}</td></tr>`;
        raw.textContent = "Sem resposta da API.";
    }
})();

/* Wellstate · salas e horário sincronizados com a API (SQLite); cache local para arranque rápido. */
(function () {
    const CFG = window.WELLSTATE_CONFIG;
    const DEFAULT_STORE = {
        rooms: [
            { id: "C1.01", name: "Bloco C · Sala 1.01" },
            { id: "C0.13", name: "Bloco C · Sala 0.13" },
            { id: "B1.02", name: "Bloco B · Sala 1.02" },
            { id: "D1.4", name: "Bloco D · Sala 1.4" },
            { id: "EF_EB", name: "Ginásio" }
        ],
        pcs: [],
        // Períodos transcritos da imagem HOrаrio.png incluída no projeto.
        schedule: {
            1: [
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "09:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "09:15", end: "10:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:25", end: "11:15" },
                { subject: "EDF", group: "12.º P", teacher: "Professor/a", room: "EF_EB", start: "11:25", end: "12:15" }
            ],
            2: [
                { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "09:05" },
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "09:15", end: "10:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:25", end: "11:15" },
                { subject: "PSI T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:25", end: "12:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "12:25", end: "13:15" },
                { subject: "RDC T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "15:10" },
                { subject: "RDC T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "15:30", end: "16:20" }
            ],
            3: [
                { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "08:15", end: "09:05" },
                { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "09:15", end: "10:05" },
                { subject: "PSI T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "10:25", end: "11:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:25", end: "12:15" }
            ],
            4: [
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "09:05" },
                { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "09:15", end: "10:05" },
                { subject: "PSI T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "10:25", end: "11:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:25", end: "12:15" },
                { subject: "PSI T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "12:25", end: "13:15" },
                { subject: "RDC T1", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "15:10" },
                { subject: "RDC T2", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "15:30", end: "16:20" }
            ],
            5: [
                { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "08:15", end: "09:05" },
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "09:15", end: "10:05" },
                { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "10:25", end: "11:15" },
                { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "11:25", end: "12:15" }
            ]
        }
    };

    // Versão exata do horário de demonstração anterior. Só substituímos quando
    // não há edições do utilizador, para corrigir também os navegadores existentes.
    const LEGACY_DEFAULT_SCHEDULE = {
        1: [
            { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "10:35" },
            { subject: "EDF", group: "12.º P", teacher: "Professor/a", room: "EF_EB", start: "11:15", end: "12:15" }
        ],
        2: [
            { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "10:35" },
            { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:35", end: "12:15" },
            { subject: "PSI", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "12:15", end: "14:15" },
            { subject: "RDC", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "16:20" }
        ],
        3: [
            { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "09:15", end: "10:15" },
            { subject: "PSI", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:15", end: "13:15" }
        ],
        4: [
            { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "08:15", end: "10:35" },
            { subject: "POR", group: "12.º P", teacher: "Professor/a", room: "C1.01", start: "10:35", end: "11:15" },
            { subject: "PSI", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "11:15", end: "13:15" },
            { subject: "RDC", group: "12.º P", teacher: "Professor/a", room: "B1.02", start: "14:20", end: "16:20" }
        ],
        5: [
            { subject: "INGL", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "08:15", end: "10:35" },
            { subject: "MAT", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "10:35", end: "12:15" },
            { subject: "ARI", group: "12.º P", teacher: "Professor/a", room: "C0.13", start: "12:15", end: "13:15" }
        ]
    };

    function purgeDrafts(value) {
        if (Array.isArray(value)) return value
            .filter(item => !(item && typeof item === "object" && (item.isDraft || item.draft === true || ["draft", "rascunho"].includes(String(item.status || "").toLowerCase()))))
            .map(purgeDrafts);
        if (!value || typeof value !== "object") return value;
        for (const key of Object.keys(value)) {
            if (/^(drafts?|rascunhos?)$/i.test(key)) delete value[key];
            else value[key] = purgeDrafts(value[key]);
        }
        return value;
    }

    function clearLegacyDraftKeys() {
        for (let index = localStorage.length - 1; index >= 0; index--) {
            const key = localStorage.key(index);
            if (key && /(^|[-_:])(drafts?|rascunhos?)([-_:]|$)/i.test(key)) localStorage.removeItem(key);
        }
    }

    function normalize(store) {
        const cleaned = purgeDrafts(store);
        cleaned.rooms ||= structuredClone(DEFAULT_STORE.rooms);
        cleaned.pcs ||= structuredClone(DEFAULT_STORE.pcs);
        cleaned.schedule ||= structuredClone(DEFAULT_STORE.schedule);
        Object.values(cleaned.schedule).forEach(day => Array.isArray(day) && day.forEach(lesson => {
            lesson.group ||= "Turma por definir";
            lesson.teacher ||= "Professor/a";
        }));
        return cleaned;
    }

    function load() {
        try {
            const raw = localStorage.getItem(CFG.STORE_KEY);
            if (!raw) return structuredClone(DEFAULT_STORE);
            const parsed = JSON.parse(raw);
            const cleaned = normalize(parsed);
            if (JSON.stringify(cleaned.schedule) === JSON.stringify(LEGACY_DEFAULT_SCHEDULE))
                cleaned.schedule = structuredClone(DEFAULT_STORE.schedule);
            return cleaned;
        } catch {
            return structuredClone(DEFAULT_STORE);
        }
    }

    function publish(store) {
        const cleaned = normalize(store);
        try { localStorage.setItem(CFG.STORE_KEY, JSON.stringify(cleaned)); } catch { /* armazenamento cheio ou bloqueado */ }
        window.WELLSTATE_STORE = cleaned;
        window.SCHEDULE = cleaned.schedule;
        window.ROOM_MAP = Object.fromEntries(cleaned.rooms.map(room => [room.id, room.name]));
        window.dispatchEvent(new CustomEvent("wellstate:store-updated", { detail: cleaned }));
        return cleaned;
    }

    clearLegacyDraftKeys();
    const store = load();
    try { localStorage.setItem(CFG.STORE_KEY, JSON.stringify(store)); } catch { /* ignore */ }
    window.WELLSTATE_STORE = store;
    window.SCHEDULE = store.schedule;
    window.ROOM_MAP = Object.fromEntries(store.rooms.map(room => [room.id, room.name]));
    window.TIME_SLOTS = [
        "08:15 - 09:05", "09:15 - 10:05", "10:25 - 11:15", "11:25 - 12:15",
        "12:25 - 13:15", "13:20 - 14:10", "14:20 - 15:10", "15:30 - 16:20",
        "16:30 - 17:20", "17:30 - 18:20"
    ];

    /* ---------- Sincronização com a API (SQLite) ----------
       Salas e horário vivem agora no servidor. O localStorage é apenas cache
       para arranque rápido e funcionamento de leitura quando a API falha. */
    const apiRoot = () => String(CFG.API_BASE_URL || "/api").replace(/\/+$/, "");
    const ADMIN_KEY_STORAGE = "wellstate-admin-key";
    let serverState = { synced: false, adminKeyRequired: false, error: null };

    async function call(path, { method = "GET", body } = {}) {
        const headers = { Accept: "application/json" };
        if (body !== undefined) headers["Content-Type"] = "application/json";
        const key = sessionStorage.getItem(ADMIN_KEY_STORAGE);
        if (key && method !== "GET") headers["X-Admin-Key"] = key;
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), CFG.API_TIMEOUT_MS || 30000);
        let response;
        try {
            response = await fetch(`${apiRoot()}${path}`, {
                method, headers, cache: "no-store", signal: controller.signal,
                body: body === undefined ? undefined : JSON.stringify(body)
            });
        } catch (error) {
            throw new Error(error.name === "AbortError"
                ? "A API demorou demasiado a responder."
                : "Sem ligação à API. Confirme que o servidor Wellstate está ligado.");
        } finally { clearTimeout(timer); }
        if (response.status === 204) return null;
        let data = null;
        try { data = await response.json(); } catch { /* sem corpo */ }
        if (!response.ok) {
            if (response.status === 401 && method !== "GET") {
                const entered = window.WellstateUI ? await window.WellstateUI.prompt("Chave de administração", "Esta operação exige a chave de administração do Wellstate.") : prompt("Chave de administração do Wellstate:");
                if (entered) { sessionStorage.setItem(ADMIN_KEY_STORAGE, entered.trim()); return call(path, { method, body }); }
            }
            const error = new Error(data?.message || data?.title || `A API respondeu HTTP ${response.status}.`);
            error.status = response.status;
            throw error;
        }
        return data;
    }

    function fromServer(data, previous) {
        const schedule = { 1: [], 2: [], 3: [], 4: [], 5: [] };
        (data.lessons || []).forEach(lesson => {
            (schedule[lesson.day] ||= []).push({
                id: lesson.id, subject: lesson.subject, group: lesson.group, teacher: lesson.teacher,
                room: lesson.room, start: lesson.start, end: lesson.end, updatedAt: lesson.updatedAt
            });
        });
        return { rooms: (data.rooms || []).map(r => ({ id: r.id, name: r.name })), pcs: previous.pcs || [], schedule };
    }

    function toImport(local) {
        const lessons = [];
        Object.entries(local.schedule || {}).forEach(([day, list]) => (list || []).forEach(l => lessons.push({
            day: Number(day), subject: l.subject, group: l.group, teacher: l.teacher, room: l.room, start: l.start, end: l.end
        })));
        return { rooms: local.rooms || [], lessons };
    }

    async function sync() {
        try {
            let data;
            if (window.WellstateApi) await window.WellstateApi.ready;
            try { data = await call("/config"); }
            catch (first) {
                // Tenta encontrar a API noutro endereço antes de desistir.
                if (!window.WellstateApi || !(await window.WellstateApi.discover())) throw first;
                data = await call("/config");
            }
            if (!data.initialized && (!data.rooms || data.rooms.length === 0)) {
                // Primeira execução da versão 2.0: migra a configuração deste navegador sem perda de dados.
                try { await call("/config/import", { method: "POST", body: toImport(window.WELLSTATE_STORE) }); }
                catch (error) { console.warn("Wellstate: importação inicial recusada —", error.message); }
                data = await call("/config");
            }
            serverState = { synced: true, adminKeyRequired: !!data.adminKeyRequired, error: null };
            publish(fromServer(data, window.WELLSTATE_STORE));
        } catch (error) {
            serverState = { synced: false, adminKeyRequired: false, error: error.message };
            window.dispatchEvent(new CustomEvent("wellstate:sync-error", { detail: error.message }));
        }
        return serverState;
    }

    async function mutate(path, options) {
        const result = await call(path, options);
        await sync();
        return result;
    }

    // O servidor embutido do PHP recusa PUT/DELETE em URLs com ponto (ex.: C1.01); a API PHP aceita ?id=.
    const roomPath = id => window.WellstateApi?.runtime() === "php" ? `/config/rooms?id=${encodeURIComponent(id)}` : `/config/rooms/${encodeURIComponent(id)}`;

    window.WellstateStore = {
        get: () => structuredClone(window.WELLSTATE_STORE),
        /** Guarda apenas campos locais (lista de PCs de referência). Salas e horário usam a API. */
        save: next => publish({ ...window.WELLSTATE_STORE, pcs: next.pcs || [] }),
        sync,
        status: () => ({ ...serverState }),
        ready: null,
        createRoom: room => mutate("/config/rooms", { method: "POST", body: room }),
        updateRoom: (originalId, room) => mutate(roomPath(originalId), { method: "PUT", body: room }),
        deleteRoom: id => mutate(roomPath(id), { method: "DELETE" }),
        createLesson: lesson => mutate("/config/lessons", { method: "POST", body: lesson }),
        updateLesson: (id, lesson) => mutate(`/config/lessons/${id}`, { method: "PUT", body: lesson }),
        deleteLesson: id => mutate(`/config/lessons/${id}`, { method: "DELETE" })
    };
    window.WellstateStore.ready = sync();

    window.addEventListener("storage", event => {
        if (event.key !== CFG.STORE_KEY || !event.newValue) return;
        try { publish(JSON.parse(event.newValue)); } catch { /* ignora dados inválidos de outra aba */ }
    });
})();

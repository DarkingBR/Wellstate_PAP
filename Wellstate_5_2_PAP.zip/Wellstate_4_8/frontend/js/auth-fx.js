/* Wellstate · login/registo: aviso de Caps Lock. */
(function () {
    "use strict";
    var pass = document.getElementById("password");
    var caps = document.getElementById("capsHint");
    try { var em = document.getElementById("email"), saved = localStorage.getItem("ws-email"), rem = document.getElementById("remember");
        if (em && rem && saved) { em.value = saved; rem.checked = true; pass && pass.focus(); } } catch (e) {}
    if (!pass || !caps) return;
    var check = function (e) { if (e.getModifierState) caps.hidden = !e.getModifierState("CapsLock"); };
    pass.addEventListener("keydown", check);
    pass.addEventListener("keyup", check);
    pass.addEventListener("blur", function () { caps.hidden = true; });
})();

/* Wellstate · identidade operacional da plataforma. */
(function () {
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };
    
    setText("userEmail", "Sistema Ativo");
})();

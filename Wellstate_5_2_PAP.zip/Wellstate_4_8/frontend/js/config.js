/* Configuração central do cliente REST. Defina WELLSTATE_API_BASE_URL antes deste ficheiro para usar outro host. */
(function () {
    const host = window.location.hostname;
    const isHttp = window.location.protocol === "http:" || window.location.protocol === "https:";
    const sameOrigin = "/api";
    const localBackend = isHttp && host && window.location.port !== "5080"
        ? `${window.location.protocol}//${host}:5080/api`
        : sameOrigin;

    // Endereços alternativos testados automaticamente se o principal falhar (ex.: localhost vs 127.0.0.1).
    // Ordem: API PHP no mesmo servidor (/api), depois o backend C# na porta 5080.
    // Pasta onde a página está (ex.: /wellstate). Com o XAMPP a API fica em /wellstate/api, não em /api.
    const dir = isHttp ? new URL("./", window.location.href).pathname.replace(/\/$/, "") : "";
    const candidates = [...new Set([
        window.WELLSTATE_API_BASE_URL,
        isHttp ? `${dir}/api` : null,
        isHttp ? `${dir}/api/index.php` : null,
        isHttp ? sameOrigin : null,
        isHttp && host ? `${window.location.protocol}//${host}:8000/api` : null,
        isHttp && host ? `${window.location.protocol}//${host}/wellstate/api` : null,
        isHttp && host ? `${window.location.protocol}//${host}:5080/api` : null,
        "http://127.0.0.1:5080/api",
        "http://localhost:5080/api",
        sameOrigin
    ].filter(Boolean))];
    let active = candidates[0];

    async function probe(base) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 4000);
        try {
            const r = await fetch(`${base}/health`, { cache: "no-store", signal: controller.signal });
            if (!(r.headers.get("content-type") || "").includes("json")) return false; // HTML = servidor errado
            const body = await r.json();
            if (body && body.service === "Wellstate.API") { runtime = body.runtime || "csharp"; return true; }
            return false;
        } catch { return false; } finally { clearTimeout(timer); }
    }

    let ready = null;
    let runtime = "csharp";
    window.WellstateApi = {
        /** Promessa partilhada: a primeira procura de API termina antes dos pedidos do painel. */
        get ready() { return ready || (ready = window.WellstateApi.discover().then(b => { if (!b) ready = null; return b; })); },
        candidates: () => [...candidates],
        base: () => active,
        runtime: () => runtime,
        /** Procura um endereço de API que responda e memoriza-o. */
        async discover() {
            const list = [active, ...candidates.filter(c => c !== active)];
            const oks = await Promise.all(list.map(probe));   // todos ao mesmo tempo; fica o primeiro que responder
            const i = oks.indexOf(true);
            if (i < 0) return null;
            active = list[i];
            return active;
        }
    };

    window.WELLSTATE_CONFIG = Object.freeze({
        get API_BASE_URL() { return active; },
        get API_CREDENTIALS() { return runtime === "php" && /^https?:/.test(active) ? "include" : "same-origin"; },
        API_TIMEOUT_MS: 12000,
        API_RETRIES: 1,
        POLL_INTERVAL_MS: 20000,
        TIME_ZONE: "Europe/Lisbon",
        STORE_KEY: "wellstate-store"
    });
})();

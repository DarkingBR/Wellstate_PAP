import { apiClient } from "./api-client.js";

const CFG = window.WELLSTATE_CONFIG || { POLL_INTERVAL_MS: 20000 };
let SCHEDULE = window.SCHEDULE || {};
let STORE = window.WELLSTATE_STORE || { rooms: [] };
let roomsCache = {};
let apiOnline = false;

const setText = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
};

const fmtHM = date => window.WellstateClock ? window.WellstateClock.formatTime(date) : new Date(date).toLocaleTimeString();

if (window.WellstateClock) {
    const dateNowEl = document.getElementById("dateNow");
    if (dateNowEl) {
        dateNowEl.textContent = window.WellstateClock.formatDate() + " · " + window.WellstateClock.zone;
    }
}

function setApiBadge(online, label) {
    apiOnline = online;
    const badge = document.getElementById("apiStatus");
    if (!badge) return;
    badge.classList.toggle("is-offline", !online);

    badge.replaceChildren();
    const dot = document.createElement("span");
    dot.className = "pulse-dot";
    badge.appendChild(dot);
    badge.appendChild(document.createTextNode(" " + label));
}

function isClassNow(lesson) {
    if (!lesson || !lesson.start || !lesson.end || !window.WellstateClock) return false;
    const partsStart = lesson.start.split(":");
    const partsEnd = lesson.end.split(":");
    const startHour = Number(partsStart[0]);
    const startMinute = Number(partsStart[1]);
    const endHour = Number(partsEnd[0]);
    const endMinute = Number(partsEnd[1]);
    const current = window.WellstateClock.parts();
    return current.minuteOfDay >= startHour * 60 + startMinute && current.minuteOfDay < endHour * 60 + endMinute;
}

function classForRoomNow(roomId) {
    if (!window.WellstateClock) return null;
    const day = window.WellstateClock.parts().day;
    const daySchedule = SCHEDULE[day] ? SCHEDULE[day] : [];
    return daySchedule.find(function(lesson) {
        return lesson.room === roomId && isClassNow(lesson);
    });
}

function roomLabel(id) {
    const rooms = STORE.rooms ? STORE.rooms : [];
    const found = rooms.find(function(room) { return room.id === id; });
    return found ? found.name : "Sala " + id;
}

const roomList = document.getElementById("roomList");
const pcList = document.getElementById("pcList");

function renderRoomsMini() {
    if (!roomList) return;
    const configured = STORE.rooms ? STORE.rooms : [];
    const configuredIds = configured.map(function(room) { return room.id; });
    const cachedIds = Object.keys(roomsCache);
    const ids = Array.from(new Set(configuredIds.concat(cachedIds)));

    roomList.replaceChildren();
    if (!ids.length) {
        const chip = document.createElement("div");
        chip.className = "chip";
        chip.textContent = "Ainda não existem salas configuradas.";
        roomList.appendChild(chip);
        return;
    }

    ids.forEach(function(roomId) {
        const sensor = roomsCache[roomId] ? roomsCache[roomId] : {};
        const lesson = classForRoomNow(roomId);
        const occupied = Boolean(sensor.occupied) && Boolean(lesson);
        const hasReading = Boolean(sensor.updatedAt);

        const badge = document.createElement("span");
        const iconI = document.createElement("i");

        if (!hasReading) {
            badge.className = "status-badge offline";
            iconI.className = "fa-solid fa-circle";
            badge.appendChild(iconI);
            badge.appendChild(document.createTextNode(" Sem leitura"));
        } else if (occupied) {
            badge.className = "status-badge occupied";
            iconI.className = "fa-solid fa-circle";
            badge.appendChild(iconI);
            badge.appendChild(document.createTextNode(" Ocupada"));
        } else if (sensor.motion) {
            badge.className = "status-badge motion";
            iconI.className = "fa-solid fa-person-walking";
            badge.appendChild(iconI);
            badge.appendChild(document.createTextNode(" Movimento"));
        } else {
            badge.className = "status-badge free";
            iconI.className = "fa-solid fa-check";
            badge.appendChild(iconI);
            badge.appendChild(document.createTextNode(" Sem movimento"));
        }

        const row = document.createElement("div");
        row.className = "room-item";

        const leftDiv = document.createElement("div");
        leftDiv.className = "left";

        const iconDiv = document.createElement("div");
        iconDiv.className = "icon";
        const doorIcon = document.createElement("i");
        doorIcon.className = "fa-solid fa-door-open";
        iconDiv.appendChild(doorIcon);

        const infoDiv = document.createElement("div");
        const nameDiv = document.createElement("div");
        nameDiv.className = "name";
        nameDiv.textContent = roomLabel(roomId);

        const subDiv = document.createElement("div");
        subDiv.className = "sub";
        subDiv.textContent = lesson ? (lesson.subject + " · " + (lesson.group ? lesson.group : "Turma por definir")) : "Sem aula prevista";

        infoDiv.appendChild(nameDiv);
        infoDiv.appendChild(subDiv);
        leftDiv.appendChild(iconDiv);
        leftDiv.appendChild(infoDiv);

        const metricsDiv = document.createElement("div");
        metricsDiv.className = "metrics";

        const distanceMetric = document.createElement("span");
        distanceMetric.className = "metric";
        const distStrong = document.createElement("strong");
        distStrong.textContent = typeof sensor.distance === "number" ? Math.round(sensor.distance) + " cm" : "—";
        distanceMetric.appendChild(distStrong);
        distanceMetric.appendChild(document.createTextNode(" distância"));

        const seenMetric = document.createElement("span");
        seenMetric.className = "metric";
        const seenStrong = document.createElement("strong");
        seenStrong.textContent = hasReading ? fmtHM(new Date(sensor.updatedAt)) : "—";
        seenMetric.appendChild(seenStrong);
        seenMetric.appendChild(document.createTextNode(" leitura"));

        metricsDiv.appendChild(distanceMetric);
        metricsDiv.appendChild(seenMetric);
        metricsDiv.appendChild(badge);

        row.appendChild(leftDiv);
        row.appendChild(metricsDiv);
        roomList.appendChild(row);
    });
}

async function loadPcs() {
    try {
        const result = await apiClient.get("/network/devices");
        const devices = Array.isArray(result && result.devices) ? result.devices : [];
        renderPcsMini(devices);
        setText("kpiPcsOn", devices.filter(function(device) { return device.online; }).length);
        setApiBadge(true, "API REST ligada");
    } catch (e) {
        renderPcsMini([], true);
        setText("kpiPcsOn", "—");
    }
    setText("pcsUpdated", "Atualizado " + fmtHM(new Date()));
}

const KIND_ICONS = {
    pc: "fa-desktop",
    phone: "fa-mobile-screen",
    tablet: "fa-tablet-screen-button",
    router: "fa-tower-broadcast",
    printer: "fa-print",
    tv: "fa-tv",
    iot: "fa-microchip",
    server: "fa-server",
    console: "fa-gamepad"
};

function renderPcsMini(devices, localMode) {
    if (!pcList) return;
    pcList.replaceChildren();

    if (!devices.length) {
        const chip = document.createElement("div");
        chip.className = "chip";
        chip.textContent = localMode ? "API indisponível." : "Nenhum dispositivo encontrado.";
        pcList.appendChild(chip);
        return;
    }

    devices.slice(0, 8).forEach(function(device) {
        const row = document.createElement("div");
        row.className = "pc-item";

        const leftDiv = document.createElement("div");
        leftDiv.className = "left";

        const iconDiv = document.createElement("div");
        iconDiv.className = "icon";
        const kindIcon = document.createElement("i");
        kindIcon.className = "fa-solid " + (KIND_ICONS[device.kind] ? KIND_ICONS[device.kind] : "fa-circle-question");
        iconDiv.appendChild(kindIcon);

        const infoDiv = document.createElement("div");
        const nameDiv = document.createElement("div");
        nameDiv.className = "name";
        nameDiv.textContent = device.hostname ? device.hostname : "Dispositivo sem nome";

        const subDiv = document.createElement("div");
        subDiv.className = "sub";
        const kindLbl = device.kindLabel ? device.kindLabel : "Dispositivo";
        const respMs = device.responseMs ? " · " + device.responseMs + " ms" : "";
        subDiv.textContent = kindLbl + " · " + device.ip + respMs;

        infoDiv.appendChild(nameDiv);
        infoDiv.appendChild(subDiv);
        leftDiv.appendChild(iconDiv);
        leftDiv.appendChild(infoDiv);

        const badge = document.createElement("span");
        badge.className = "status-badge online";
        badge.textContent = "Online";

        row.appendChild(leftDiv);
        row.appendChild(badge);
        pcList.appendChild(row);
    });
}

function computeKpis() {
    const entries = Object.entries(roomsCache);
    const roomsArr = STORE.rooms ? STORE.rooms : [];
    const roomsIds = roomsArr.map(function(room) { return room.id; });
    const entryIds = entries.map(function(item) { return item[0]; });
    const totalRooms = new Set(roomsIds.concat(entryIds)).size;

    setText("kpiRooms", totalRooms);
    let occupied = 0;
    let recent = 0;
    const freshWindow = 15 * 60 * 1000;

    entries.forEach(function(pair) {
        const roomId = pair[0];
        const sensor = pair[1];
        if (sensor.occupied && classForRoomNow(roomId)) occupied++;
        const t = Date.parse(sensor.updatedAt);
        if (Number.isFinite(t) && Date.now() - t <= freshWindow) recent++;
    });

    setText("kpiOccupied", occupied);
    setText("kpiReadings", entries.length ? recent + "/" + entries.length : "0");
}

function renderScheduleStrip() {
    const strip = document.getElementById("scheduleStrip");
    if (!strip || !window.WellstateClock) return;

    const day = window.WellstateClock.parts().day;
    const dayLessons = SCHEDULE[day] ? SCHEDULE[day] : [];
    const lessons = dayLessons.slice().sort(function(first, second) {
        return first.start.localeCompare(second.start);
    });

    strip.replaceChildren();
    if (!lessons.length) {
        const chip = document.createElement("div");
        chip.className = "chip";
        chip.textContent = "Sem aulas hoje.";
        strip.appendChild(chip);
        setText("scheduleToday", "0 aulas");
        return;
    }

    setText("scheduleToday", lessons.length + " aulas");

    lessons.forEach(function(lesson) {
        const active = isClassNow(lesson);
        const item = document.createElement("div");
        item.className = "class-card " + (active ? "now" : "");

        const timeSpan = document.createElement("span");
        timeSpan.className = "time";
        timeSpan.textContent = lesson.start + " — " + lesson.end;

        const subjectSpan = document.createElement("span");
        subjectSpan.className = "subject";
        subjectSpan.textContent = lesson.subject;
        if (active) {
            const nowBadge = document.createElement("span");
            nowBadge.className = "now-badge";
            nowBadge.textContent = " AGORA";
            subjectSpan.appendChild(nowBadge);
        }

        const roomSpan = document.createElement("span");
        roomSpan.className = "room";
        const doorIcon = document.createElement("i");
        doorIcon.className = "fa-solid fa-door-open";
        roomSpan.appendChild(doorIcon);
        roomSpan.appendChild(document.createTextNode(" " + roomLabel(lesson.room)));

        const detailsSpan = document.createElement("span");
        detailsSpan.className = "room";
        const groupLbl = lesson.group ? lesson.group : "Turma por definir";
        const teacherLbl = lesson.teacher ? lesson.teacher : "Docente por definir";
        detailsSpan.textContent = groupLbl + " · " + teacherLbl;

        item.appendChild(timeSpan);
        item.appendChild(subjectSpan);
        item.appendChild(roomSpan);
        item.appendChild(detailsSpan);
        strip.appendChild(item);
    });
}

async function refreshRooms() {
    try {
        const readings = await apiClient.getLatestRooms();
        roomsCache = Object.fromEntries(readings.map(function(reading) {
            return [reading.roomId, reading];
        }));
        setApiBadge(true, "API REST ligada");
        renderRoomsMini();
        computeKpis();
        const newest = readings.reduce(function(latest, row) {
            return Math.max(latest, Date.parse(row.updatedAt) || 0);
        }, 0);
        setText("roomsUpdated", newest ? "Última medição " + fmtHM(new Date(newest)) : "A aguardar medições");
        if (window.WellstateNotify) {
            readings.forEach(function(room) {
                window.WellstateNotify.checkRoom(room.roomId, room);
            });
        }
    } catch (error) {
        setApiBadge(false, "API REST indisponível");
        setText("roomsUpdated", "A tentar reconectar");
        renderRoomsMini();
    }
}

async function pollRooms() {
    await refreshRooms();
    const interval = CFG.POLL_INTERVAL_MS ? CFG.POLL_INTERVAL_MS : 20000;
    window.setTimeout(pollRooms, document.hidden ? Math.max(interval, 30000) : interval);
}

window.addEventListener("wellstate:store-updated", function(event) {
    STORE = event.detail;
    SCHEDULE = STORE.schedule ? STORE.schedule : {};
    renderRoomsMini();
    renderScheduleStrip();
    computeKpis();
});

renderScheduleStrip();
renderRoomsMini();
computeKpis();
loadPcs();

window.setInterval(function() {
    if (!document.hidden) loadPcs();
}, Math.max(CFG.POLL_INTERVAL_MS ? CFG.POLL_INTERVAL_MS : 20000, 10000));

pollRooms();
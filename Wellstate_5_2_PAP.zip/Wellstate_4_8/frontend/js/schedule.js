/* Horários escolares alinhados com os períodos de referência. */
(function () {
    const body = document.getElementById("scheduleBody");
    let STORE = window.WELLSTATE_STORE;
    const days = [1, 2, 3, 4, 5];
    const dialog = document.getElementById("lessonDialog");
    const form = document.getElementById("lessonForm");
    const addBtn = document.getElementById("addLessonBtn");
    addBtn.hidden = false;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
    const roomName = id => STORE.rooms.find(room => room.id === id)?.name || id || "Sala por definir";

    function render() {
        body.replaceChildren();
        const timeSlots = window.TIME_SLOTS || [];
        timeSlots.forEach(slot => {
            const [start, end] = slot.split(" - ");
            const row = document.createElement("tr");
            const timeCell = document.createElement("td");
            timeCell.className = "cell-slot";
            timeCell.textContent = slot;
            row.appendChild(timeCell);
            days.forEach(day => {
                const cell = document.createElement("td");
                const lesson = (STORE.schedule[day] || []).find(item => item.start < end && item.end > start);
                if (!lesson) {
                    cell.textContent = "—";
                    cell.className = "empty-slot";
                } else {
                    const index = (STORE.schedule[day] || []).indexOf(lesson);
                    cell.className = "has-class";
                    cell.innerHTML = `<div class="lesson-cell"><strong>${esc(lesson.subject)}</strong><span class="lesson-group">${esc(lesson.group || "Turma por definir")}</span><span class="lesson-room"><i class="fa-solid fa-location-dot"></i> ${esc(roomName(lesson.room))}</span><span class="lesson-time">${esc(lesson.start)}–${esc(lesson.end)}</span><button class="lesson-edit" type="button" data-edit-day="${day}" data-edit-index="${index}" aria-label="Editar aula"><i class="fa-solid fa-pen"></i><span>Editar</span></button></div>`;
                }
                row.appendChild(cell);
            });
            body.appendChild(row);
        });
        fillRooms();
    }

    function fillRooms(selected) {
        const select = document.getElementById("lessonRoom");
        select.innerHTML = STORE.rooms.map(room => `<option value="${esc(room.id)}">${esc(room.name)}</option>`).join("");
        if (selected) select.value = selected;
    }

    function openEditor(day = "1", index = "") {
        form.reset();
        document.getElementById("lessonFormError").textContent = "";
        document.getElementById("lessonIndex").value = index;
        const isEdit = index !== "";
        document.getElementById("lessonDialogTitle").textContent = isEdit ? "Editar aula / sala" : "Adicionar aula";
        document.getElementById("lessonDay").value = day;
        document.getElementById("lessonDay").dataset.originalDay = isEdit ? day : "";
        document.getElementById("deleteLessonBtn").hidden = !isEdit;
        fillRooms();
        if (isEdit) {
            const lesson = STORE.schedule[day][Number(index)];
            document.getElementById("lessonSubject").value = lesson.subject || "";
            document.getElementById("lessonGroup").value = lesson.group || "";
            document.getElementById("lessonTeacher").value = lesson.teacher || "";
            document.getElementById("lessonRoom").value = lesson.room || "";
            document.getElementById("lessonStart").value = lesson.start || "";
            document.getElementById("lessonEnd").value = lesson.end || "";
        } else {
            document.getElementById("lessonStart").value = "08:15";
            document.getElementById("lessonEnd").value = "09:05";
        }
        dialog.showModal();
    }

    function closeEditor() { dialog.close(); }
    addBtn.addEventListener("click", () => openEditor());
    body.addEventListener("click", event => {
        const button = event.target.closest("[data-edit-day]");
        if (button) openEditor(button.dataset.editDay, button.dataset.editIndex);
    });
    document.getElementById("closeLessonDialog").addEventListener("click", closeEditor);
    document.getElementById("cancelLessonBtn").addEventListener("click", closeEditor);

    const submitBtn = form.querySelector('button[type="submit"]');
    function validateLesson(next) {
        if (!next.subject) return "A disciplina é obrigatória.";
        if (next.subject.length > 40) return "A disciplina não pode ter mais de 40 caracteres.";
        if (next.group.length > 40) return "A turma não pode ter mais de 40 caracteres.";
        if (next.teacher.length > 60) return "O nome do professor não pode ter mais de 60 caracteres.";
        if (!next.room) return "Escolha uma sala.";
        if (!/^\d{2}:\d{2}$/.test(next.start) || !/^\d{2}:\d{2}$/.test(next.end)) return "Indique as horas no formato HH:MM.";
        if (next.start >= next.end) return "A hora de fim tem de ser posterior à hora de início.";
        if (next.start < "07:00" || next.end > "23:00") return "As aulas têm de decorrer entre as 07:00 e as 23:00.";
        return null;
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        const day = Number(document.getElementById("lessonDay").value);
        const indexValue = document.getElementById("lessonIndex").value;
        const editing = indexValue === "" ? null : STORE.schedule[document.getElementById("lessonDay").dataset.originalDay || day]?.[Number(indexValue)];
        const next = {
            day,
            subject: document.getElementById("lessonSubject").value.trim(),
            group: document.getElementById("lessonGroup").value.trim(),
            teacher: document.getElementById("lessonTeacher").value.trim(),
            room: document.getElementById("lessonRoom").value,
            start: document.getElementById("lessonStart").value,
            end: document.getElementById("lessonEnd").value
        };
        const error = document.getElementById("lessonFormError");
        const problem = validateLesson(next);
        if (problem) { error.textContent = problem; return; }
        // Pré-verificação local; o servidor volta a validar e é a fonte de verdade.
        const conflict = (STORE.schedule[day] || []).find(lesson => lesson !== editing
            && next.start < lesson.end && next.end > lesson.start && lesson.room === next.room);
        if (conflict) { error.textContent = `Conflito: a sala já tem ${conflict.subject} entre ${conflict.start} e ${conflict.end}.`; return; }

        submitBtn.disabled = true;
        error.textContent = "";
        try {
            if (editing?.id) await window.WellstateStore.updateLesson(editing.id, next);
            else await window.WellstateStore.createLesson(next);
            closeEditor();
            toast(editing ? "Aula atualizada." : "Aula adicionada ao horário.");
        } catch (failure) {
            error.textContent = failure.message;
        } finally { submitBtn.disabled = false; }
    });

    document.getElementById("deleteLessonBtn").addEventListener("click", async () => {
        const day = document.getElementById("lessonDay").dataset.originalDay || document.getElementById("lessonDay").value;
        const lesson = STORE.schedule[day]?.[Number(document.getElementById("lessonIndex").value)];
        if (!lesson?.id) return;
        if (!await window.WellstateUI.confirm({ title: "Remover aula", message: `Remover ${lesson.subject} (${lesson.start}–${lesson.end}) do horário?`, confirmLabel: "Remover", danger: true })) return;
        try {
            await window.WellstateStore.deleteLesson(lesson.id);
            closeEditor();
            toast("Aula removida.");
        } catch (failure) {
            document.getElementById("lessonFormError").textContent = failure.message;
        }
    });

    window.addEventListener("wellstate:store-updated", event => { STORE = event.detail; render(); });
    function toast(message, type = "success") { window.WellstateUI.toast(message, type); }
    render();
})();

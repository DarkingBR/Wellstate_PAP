/* Login e registo: valida no cliente e fala com php/login.php e php/register.php. */
const form = document.getElementById("authForm");
const mode = form.dataset.mode;
const alertBox = document.getElementById("formAlert");
const button = form.querySelector(".btn-submit");
const labelText = button.querySelector("span").textContent;

const setError = (id, message) => {
    const box = form.querySelector(`[data-field="${id}"]`);
    if (!box) return;
    box.classList.toggle("invalid", Boolean(message));
    box.querySelector(".field-error").textContent = message || "";
};
const clearErrors = () => { alertBox.classList.remove("show"); form.querySelectorAll("[data-field]").forEach(f => setError(f.dataset.field, "")); };

document.querySelectorAll(".toggle-pass").forEach(btn => btn.addEventListener("click", () => {
    const input = document.getElementById(btn.dataset.toggle);
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    btn.querySelector("i").className = show ? "fa-solid fa-eye-slash" : "fa-solid fa-eye";
    btn.setAttribute("aria-label", show ? "Esconder palavra-passe" : "Mostrar palavra-passe");
}));

const strength = document.getElementById("strength");
if (strength) {
    const names = ["Use letras, números e símbolos.", "Fraca", "Razoável", "Boa", "Forte"];
    document.getElementById("password").addEventListener("input", e => {
        const v = e.target.value;
        const level = v ? Math.min(4, [v.length >= 8, /[A-Z]/.test(v) && /[a-z]/.test(v), /\d/.test(v), /[^A-Za-z0-9]/.test(v) || v.length >= 12].filter(Boolean).length) : 0;
        strength.dataset.level = level;
        document.getElementById("strengthLabel").textContent = names[level];
    });
}

function validate(data) {
    let ok = true;
    const fail = (id, msg) => { setError(id, msg); ok = false; };
    if (mode === "register" && data.name.trim().length < 2) fail("name", "Escreva o seu nome.");
    if (!/^\S+@\S+\.\S+$/.test(data.email)) fail("email", "Introduza um e-mail válido.");
    if (mode === "login" && !data.password) fail("password", "Escreva a palavra-passe.");
    if (mode === "register") {
        if (data.password.length < 8 || !/[A-Za-z]/.test(data.password) || !/\d/.test(data.password)) fail("password", "Use pelo menos 8 caracteres, com letras e números.");
        if (data.password !== data.confirm) fail("confirm", "As palavras-passe não coincidem.");
    }
    return ok;
}

form.addEventListener("submit", async event => {
    event.preventDefault();
    clearErrors();
    const data = Object.fromEntries(new FormData(form).entries());
    data.email = String(data.email || "").trim().toLowerCase();
    if (!validate(data)) return;

    if (button.disabled) return;
    button.disabled = true;
    button.querySelector("span").textContent = mode === "login" ? "A entrar…" : "A criar conta…";
    try {
        const csrf = (await (await fetch("php/csrf.php", { credentials: "same-origin", cache: "no-store" })).json()).csrf;
        const response = await fetch(`php/${mode}.php`, {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json", Accept: "application/json", "X-CSRF-Token": csrf },
            body: JSON.stringify(data)
        });
        const raw = await response.text();
        let body = {};
        try { body = JSON.parse(raw); } catch { /* resposta sem JSON */ }
        if (!response.ok || !body.user) {
            Object.entries(body.errors || {}).forEach(([id, msg]) => setError(id, msg));
            alertBox.textContent = body.message || (location.protocol === "file:" || !raw.trim().startsWith("{")
                ? "O PHP não está a responder. Abra esta página por http://localhost/wellstate/ (Apache do XAMPP ligado), e não pelo Live Server ou ao clicar no ficheiro."
                : "Não foi possível concluir. Tente novamente.");
            alertBox.classList.add("show");
            return;
        }
        try { if (mode === "login") { const r = document.getElementById("remember"); r && r.checked ? localStorage.setItem("ws-email", data.email) : localStorage.removeItem("ws-email"); } } catch {}
        window.location.replace("dashboard.html");
    } catch {
        alertBox.textContent = "Servidor PHP indisponível. Abra o painel por http://localhost/wellstate/ com o Apache do XAMPP ligado.";
        alertBox.classList.add("show");
    } finally {
        button.disabled = false;
        button.querySelector("span").textContent = labelText;
    }
});

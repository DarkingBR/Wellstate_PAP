#pragma once

/*
 * Copia este ficheiro para secrets.h, que é ignorado no Git.
 * Usa o mesmo token configurado no backend em Wellstate__DeviceApiKey.
 * Substitui CHANGE_ME_SERVER_HOST por um IP reservado ou nome DNS do servidor.
 */
#define WIFI_SSID                 "CHANGE_ME_WIFI_2_4_GHZ"
#define WIFI_PASSWORD             "CHANGE_ME_WIFI_PASSWORD"
#define WELLSTATE_API_BASE_URL    "http://CHANGE_ME_SERVER_HOST:5080"
#define WELLSTATE_PORTAL_URL      "http://CHANGE_ME_SERVER_HOST:8080/login"
#define WELLSTATE_DEVICE_API_KEY "CHANGE_ME_USE_A_RANDOM_SECRET_OF_AT_LEAST_24_CHARS"
#define WELLSTATE_ROOM_ID         "C1.01"
#define DHT_PIN                   D4

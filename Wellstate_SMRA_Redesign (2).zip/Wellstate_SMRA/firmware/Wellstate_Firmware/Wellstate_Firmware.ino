/*
 * Wellstate SMRA · ESP8266 / NodeMCU v2
 * Sensores: DHT11 + PIR HC-SR501 + ultrassónico HC-SR04.
 * Publica medições na API REST Wellstate, que as guarda em SQLite.
 * Não identifica pessoas; a presença é apenas uma estimativa dos sensores.
 */
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <DHT.h>
#include <ESP8266WebServer.h>
#include "secrets.h"

#ifndef WELLSTATE_PORTAL_URL
#define WELLSTATE_PORTAL_URL "http://CHANGE_ME_SERVER_HOST:8080/login"
#endif

#ifndef DHT_PIN
#define DHT_PIN D4
#endif
#ifndef WELLSTATE_ROOM_ID
#define WELLSTATE_ROOM_ID "C1.01"
#endif
#define DHT_TYPE DHT11
#define PIR_PIN D1     // GPIO5
#define TRIG_PIN D2    // GPIO4
#define ECHO_PIN D3    // GPIO0: usar divisor de tensão no ECHO 5 V
#define LED_PIN D5     // GPIO14

namespace {
constexpr unsigned long WIFI_RETRY_MS = 15000;
constexpr unsigned long SENSOR_READ_MS = 1000;
constexpr unsigned long DHT_READ_MS = 2500;
constexpr unsigned long TELEMETRY_MS = 10000;
constexpr float PRESENCE_DISTANCE_CM = 200.0f;

DHT dht(DHT_PIN, DHT_TYPE);
ESP8266WebServer localServer(80);

// Teste TCP (porta SMB 445) sem instalar software nos computadores alvo.
// A resposta positiva significa que a porta testada respondeu; firewall/VLAN pode
// impedir a deteção mesmo quando o computador está ligado.
struct NetworkHost { uint8_t lastOctet; const char* name; bool online; bool checked; };
NetworkHost networkHosts[] = {
    {10, "PC-01", false, false}, {11, "PC-02", false, false}, {12, "PC-03", false, false},
    {13, "PC-04", false, false}, {14, "PC-05", false, false}, {15, "PC-06", false, false},
    {16, "PC-07", false, false}, {17, "PC-08", false, false}, {18, "PC-09", false, false},
    {19, "PC-10", false, false}, {20, "PC-11", false, false}
};
constexpr size_t NETWORK_HOST_COUNT = sizeof(networkHosts) / sizeof(networkHosts[0]);
constexpr uint16_t NETWORK_TEST_PORT = 445;
constexpr unsigned long NETWORK_SCAN_STEP_MS = 1200;
size_t networkScanCursor = 0;
unsigned long lastNetworkProbe = 0;
unsigned long lastNetworkScan = 0;
float temperatureC = NAN;
String telemetryJson(); // declarado antes dos handlers HTTP locais
float humidityPct = NAN;
float distanceCm = NAN;
bool motionDetected = false;
bool presenceConfirmed = false;
bool ledOn = false;
bool configurationReady = false;
bool wifiWasConnected = false;
unsigned long lastWifiAttempt = 0;
unsigned long lastSensorRead = 0;
unsigned long lastDhtRead = 0;
unsigned long lastTelemetryAttempt = 0;
unsigned long lastLedToggle = 0;

void handleRoot() {
    // O portal autenticado é servido pelo PHP, separado da API REST C#.
    const String target = String(WELLSTATE_PORTAL_URL);
    if (target.indexOf("CHANGE_ME") >= 0 || target.indexOf("SEU_SERVIDOR") >= 0) {
        localServer.send(503, "text/plain; charset=utf-8",
            "Configure WELLSTATE_PORTAL_URL no secrets.h para abrir o portal Wellstate SMRA.");
        return;
    }
    localServer.sendHeader("Location", target, true);
    localServer.send(302, "text/plain; charset=utf-8", "A abrir o painel Wellstate SMRA…");
}

void handleLocalStatus() {
    localServer.send(200, "application/json; charset=utf-8", telemetryJson());
}

void handleLocalNetwork() {
    String json = "{\"subnet\":\"" + WiFi.localIP().toString() + "\",\"testPort\":" + String(NETWORK_TEST_PORT) + ",\"devices\":[";
    for (size_t i = 0; i < NETWORK_HOST_COUNT; ++i) {
        if (i) json += ',';
        IPAddress ip = WiFi.localIP();
        ip[3] = networkHosts[i].lastOctet;
        json += "{\"id\":\"" + String(networkHosts[i].name) + "\",\"name\":\"" +
            String(networkHosts[i].name) + "\",\"ip\":\"" + ip.toString() + "\",\"online\":" +
            (networkHosts[i].online ? "true" : "false") + ",\"checked\":" +
            (networkHosts[i].checked ? "true" : "false") + "}";
    }
    json += "]}";
    localServer.send(200, "application/json; charset=utf-8", json);
}

void beginLocalWebServer() {
    localServer.on("/", HTTP_GET, handleRoot);
    localServer.on("/api/status", HTTP_GET, handleLocalStatus);
    localServer.on("/api/network", HTTP_GET, handleLocalNetwork);
    localServer.onNotFound([]() { localServer.send(404, "text/plain; charset=utf-8", "Rota Wellstate SMRA não encontrada."); });
    localServer.begin();
    Serial.println("[HTTP local] Servidor iniciado na porta 80 (/, /api/status, /api/network). ");
}

void scanOneNetworkHost() {
    if (WiFi.status() != WL_CONNECTED) return;
    const unsigned long now = millis();
    if (lastNetworkProbe != 0 && now - lastNetworkProbe < NETWORK_SCAN_STEP_MS) return;
    lastNetworkProbe = now;
    NetworkHost &host = networkHosts[networkScanCursor];
    IPAddress target = WiFi.localIP();
    target[3] = host.lastOctet; // faixa IPv4 /24: ajuste a gama em networkHosts[] se necessário.
    if (target == WiFi.localIP()) {
        host.online = false; // o endereço da própria placa não é um PC.
        host.checked = true;
    } else {
        WiFiClient probe;
        probe.setTimeout(150);
        host.online = probe.connect(target, NETWORK_TEST_PORT);
        host.checked = true;
        probe.stop();
        Serial.printf("[LAN] %s %s:%u -> %s (TCP)\n", host.name, target.toString().c_str(),
            NETWORK_TEST_PORT, host.online ? "LIGADO" : "sem resposta");
    }
    networkScanCursor = (networkScanCursor + 1) % NETWORK_HOST_COUNT;
    if (networkScanCursor == 0) lastNetworkScan = now;
}

float readDistance() {
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(3);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    const unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
    if (duration == 0) return NAN;
    const float cm = (static_cast<float>(duration) * 0.0343f) / 2.0f;
    if (cm < 2.0f || cm > 400.0f) return NAN;
    return cm;
}

void maintainWiFi() {
    if (WiFi.status() == WL_CONNECTED) return;
    const unsigned long now = millis();
    if (lastWifiAttempt != 0 && now - lastWifiAttempt < WIFI_RETRY_MS) return;
    lastWifiAttempt = now;
    Serial.printf("[Wi-Fi] A ligar a %s\n", WIFI_SSID);
    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

String encodePathSegment(const String &value) {
    String encoded;
    const char hex[] = "0123456789ABCDEF";
    for (size_t i = 0; i < value.length(); ++i) {
        const uint8_t c = static_cast<uint8_t>(value[i]);
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.') {
            encoded += static_cast<char>(c);
        } else {
            encoded += '%';
            encoded += hex[c >> 4];
            encoded += hex[c & 0x0F];
        }
    }
    return encoded;
}

String telemetryJson() {
    String json = "{";
    bool hasField = false;
    if (!isnan(temperatureC)) {
        json += "\"temperature\":" + String(temperatureC, 1);
        hasField = true;
    }
    if (!isnan(humidityPct)) {
        if (hasField) json += ',';
        json += "\"humidity\":" + String(humidityPct, 1);
        hasField = true;
    }
    if (hasField) json += ',';
    json += "\"distance\":";
    json += isnan(distanceCm) ? "null" : String(distanceCm, 1);
    json += ",\"motion\":";
    json += motionDetected ? "true" : "false";
    json += ",\"occupied\":";
    json += presenceConfirmed ? "true" : "false";
    json += "}";
    return json;
}

void postTelemetry() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[API] Sem Wi-Fi; a leitura será tentada novamente no próximo intervalo.");
        return;
    }

    WiFiClient client;
    HTTPClient http;
    http.setTimeout(6000);
    const String url = String(WELLSTATE_API_BASE_URL) + "/api/rooms/" +
        encodePathSegment(String(WELLSTATE_ROOM_ID)) + "/telemetry";
    if (!http.begin(client, url)) {
        Serial.println("[API] Não foi possível iniciar a ligação HTTP.");
        return;
    }
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Device-Key", WELLSTATE_DEVICE_API_KEY);
    const String payload = telemetryJson();
    const int status = http.POST(payload);
    if (status >= 200 && status < 300) {
        Serial.printf("[API] Medição guardada · sala %s · T=%s°C · H=%s%% · movimento=%s · presença=%s\n",
            WELLSTATE_ROOM_ID,
            isnan(temperatureC) ? "—" : String(temperatureC, 1).c_str(),
            isnan(humidityPct) ? "—" : String(humidityPct, 1).c_str(),
            motionDetected ? "sim" : "não", presenceConfirmed ? "sim" : "não");
    } else if (status > 0) {
        Serial.printf("[API ERRO] HTTP %d · %s\n", status, http.getString().c_str());
    } else {
        Serial.printf("[API ERRO] %s\n", http.errorToString(status).c_str());
    }
    http.end();
}

void readSensors() {
    const unsigned long now = millis();
    motionDetected = digitalRead(PIR_PIN) == HIGH;
    if (now - lastSensorRead >= SENSOR_READ_MS || lastSensorRead == 0) {
        lastSensorRead = now;
        distanceCm = readDistance();
        presenceConfirmed = motionDetected && !isnan(distanceCm) && distanceCm < PRESENCE_DISTANCE_CM;
    }
    if (now - lastDhtRead >= DHT_READ_MS || lastDhtRead == 0) {
        lastDhtRead = now;
        const float newTemperature = dht.readTemperature();
        const float newHumidity = dht.readHumidity();
        if (!isnan(newTemperature)) temperatureC = newTemperature;
        if (!isnan(newHumidity)) humidityPct = newHumidity;
        if (isnan(newTemperature) || isnan(newHumidity))
            Serial.println("[Sensor] Leitura DHT11 inválida; será mantida a última leitura válida.");
    }

    if (presenceConfirmed) {
        digitalWrite(LED_PIN, HIGH);
        ledOn = true;
    } else if (now - lastLedToggle >= 1000) {
        ledOn = !ledOn; // piscar lento: placa em execução sem presença confirmada.
        digitalWrite(LED_PIN, ledOn ? HIGH : LOW);
        lastLedToggle = now;
    }
}
} // namespace

void setup() {
    Serial.begin(115200);
    delay(250);
    Serial.println();
    Serial.println("Wellstate SMRA · sensores, portal HTTP e telemetria REST");
    Serial.printf("Sala configurada: %s\n", WELLSTATE_ROOM_ID);

    pinMode(PIR_PIN, INPUT);
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
    pinMode(LED_PIN, OUTPUT);
    digitalWrite(TRIG_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    dht.begin();
    beginLocalWebServer();

    configurationReady = strlen(WIFI_SSID) > 0 && strlen(WIFI_PASSWORD) > 0 &&
        strlen(WELLSTATE_DEVICE_API_KEY) >= 24 && strlen(WELLSTATE_ROOM_ID) > 0 &&
        strlen(WELLSTATE_API_BASE_URL) > 0 && strlen(WELLSTATE_PORTAL_URL) > 0 &&
        strstr(WELLSTATE_DEVICE_API_KEY, "CHANGE_ME") == nullptr &&
        strstr(WELLSTATE_API_BASE_URL, "CHANGE_ME") == nullptr &&
        strstr(WELLSTATE_PORTAL_URL, "CHANGE_ME") == nullptr &&
        strstr(WIFI_SSID, "CHANGE_ME") == nullptr && strstr(WIFI_PASSWORD, "CHANGE_ME") == nullptr;
    if (!configurationReady) {
        Serial.println("[CONFIG] Copia secrets.example.h para secrets.h e preenche Wi-Fi, endereço da API e chave do dispositivo.");
        return;
    }

    WiFi.mode(WIFI_STA);
    WiFi.persistent(false);
    WiFi.setAutoReconnect(true);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.println("[Wi-Fi] Ligação iniciada; o dispositivo continuará a tentar reconectar.");
}

void loop() {
    readSensors();
    localServer.handleClient();
    if (!configurationReady) {
        delay(20);
        return;
    }
    maintainWiFi();
    const bool wifiConnected = WiFi.status() == WL_CONNECTED;
    if (wifiConnected && !wifiWasConnected) {
        wifiWasConnected = true;
        Serial.printf("[Wi-Fi] Ligada · IP local da placa: %s\n", WiFi.localIP().toString().c_str());
    } else if (!wifiConnected) {
        wifiWasConnected = false;
    }
    scanOneNetworkHost();
    const unsigned long now = millis();
    if (now - lastTelemetryAttempt >= TELEMETRY_MS || lastTelemetryAttempt == 0) {
        lastTelemetryAttempt = now;
        postTelemetry();
    }
    delay(20);
}

using Wellstate.API.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<PingService>();
builder.Services.AddSingleton<PcRepository>();
builder.Services.AddSingleton<PcPresenceService>();
builder.Services.AddSingleton<SignalRepository>();
builder.Services.AddSingleton<SignalService>();
builder.Services.AddSingleton<RoomTelemetryRepository>();
builder.Services.AddSingleton<NetworkSubnetResolver>();
builder.Services.AddSingleton<NetworkDiscoveryService>();

builder.Services.AddCors(options => options.AddPolicy("wellstate", policy =>
    policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("wellstate");
// A interface é servida pelo portal PHP; esta aplicação expõe apenas a API REST.
// Restrinja a porta 5080 à LAN/VPN e configure as chaves de sensores e agentes.
app.MapControllers();
app.Run("http://0.0.0.0:5080");

/* Cache limitada a recursos estáticos. API e navegações do painel nunca são guardadas. */
const CACHE = "wellstate-smra-shell-v4";
const STATIC = [
  "./manifest.webmanifest",
  "./assets/icon-192.png",
  "./assets/icon-512.png",
  "./assets/wellstate-smra-logo.png",
  "./assets/portal-hero-circuit.png",
  "./assets/portal-control-preview.png",
  "./css/style.css",
  "./css/dashboard.css",
  "./css/reference-ui.css",
  "./css/portal-blue.css",
  "./css/refined-system.css"
];
self.addEventListener("install", event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(STATIC)).then(() => self.skipWaiting())));
self.addEventListener("activate", event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener("fetch", event => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.pathname.includes("/api/") || url.pathname.startsWith("/auth/") || url.origin !== self.location.origin) return;
  if (event.request.mode === "navigate") return;
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok && url.origin === self.location.origin) {
      const copy = response.clone();
      caches.open(CACHE).then(cache => cache.put(event.request, copy));
    }
    return response;
  }).catch(() => caches.match(event.request)));
});

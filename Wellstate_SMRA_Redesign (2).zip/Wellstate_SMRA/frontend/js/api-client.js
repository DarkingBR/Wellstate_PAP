/* Cliente REST partilhado pelo painel, histórico e inventário da rede.
   Repetimos apenas GETs falhados por rede/timeout, 408, 429 ou 5xx; nunca
   repetimos automaticamente operações que possam criar dados duplicados. */
const CFG = window.WELLSTATE_CONFIG || {};
const API_ROOT = String(CFG.API_BASE_URL || "").replace(/\/+$/, "");
const DEFAULT_TIMEOUT = Number(CFG.API_TIMEOUT_MS) || 20000;
const DEFAULT_RETRIES = Math.max(0, Number(CFG.API_RETRIES ?? 2));

function retryDelay(response, attempt) {
    const retryAfter = response?.headers?.get("Retry-After");
    if (retryAfter) {
        const seconds = Number(retryAfter);
        const dateDelay = Number.isNaN(seconds) ? Date.parse(retryAfter) - Date.now() : seconds * 1000;
        if (Number.isFinite(dateDelay) && dateDelay >= 0) return Math.min(dateDelay, 10000);
    }
    const exponential = Math.min(6000, 400 * (2 ** attempt));
    return exponential + Math.floor(Math.random() * 180);
}

async function parseResponse(response) {
    if (response.status === 204) return null;
    const text = await response.text();
    if (!text) return null;
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("json")) {
        try { return JSON.parse(text); } catch { /* converter abaixo */ }
    }
    return text;
}

function errorMessage(payload, status) {
    if (payload && typeof payload === "object") {
        return payload.message || payload.title || payload.detail || `A API respondeu HTTP ${status}.`;
    }
    if (typeof payload === "string" && payload.trim()) return payload.slice(0, 400);
    return `A API respondeu HTTP ${status}.`;
}

async function request(path, options = {}) {
    if (!API_ROOT) throw new Error("A URL da API não foi configurada. Defina WELLSTATE_API_BASE_URL ou verifique js/config.js.");
    const method = String(options.method || "GET").toUpperCase();
    const retryable = method === "GET";
    const retries = retryable ? Math.max(0, Number(options.retries ?? DEFAULT_RETRIES)) : 0;
    const timeoutMs = Math.max(1000, Number(options.timeoutMs) || DEFAULT_TIMEOUT);
    let lastError;

    for (let attempt = 0; attempt <= retries; attempt++) {
        const controller = new AbortController();
        const externalSignal = options.signal;
        const abortFromCaller = () => controller.abort(externalSignal?.reason);
        if (externalSignal?.aborted) abortFromCaller();
        else externalSignal?.addEventListener("abort", abortFromCaller, { once: true });
        const timeout = setTimeout(() => controller.abort(new DOMException("Tempo limite excedido", "TimeoutError")), timeoutMs);
        let response;
        try {
            const { timeoutMs: _timeoutMs, retries: _retries, ...fetchOptions } = options;
            response = await fetch(`${API_ROOT}${path}`, {
                ...fetchOptions,
                method,
                cache: "no-store",
                credentials: CFG.API_CREDENTIALS || "same-origin",
                headers: { Accept: "application/json", ...(options.headers || {}) },
                signal: controller.signal
            });
            const payload = await parseResponse(response);
            if (response.ok) return payload;

            const error = new Error(errorMessage(payload, response.status));
            error.status = response.status;
            error.payload = payload;
            const shouldRetryStatus = response.status === 408 || response.status === 429 || response.status >= 500;
            if (!retryable || !shouldRetryStatus || attempt === retries) throw error;
            lastError = error;
        } catch (error) {
            if (error.status) {
                if (error.status < 500 && error.status !== 408 && error.status !== 429) throw error;
                if (!retryable || attempt === retries) throw error;
                lastError = error;
            } else if (error.name === "AbortError" || error.name === "TimeoutError") {
                lastError = new Error(externalSignal?.aborted
                    ? "Pedido cancelado."
                    : `A API não respondeu em ${Math.round(timeoutMs / 1000)} segundos. Verifique a rede e o servidor.`);
                if (externalSignal?.aborted || attempt === retries) throw lastError;
            } else if (error instanceof TypeError) {
                lastError = new Error("Não foi possível alcançar a API. Confirme se o backend está ativo, se a URL está correta e se CORS/HTTPS permitem a ligação.");
                if (attempt === retries) throw lastError;
            } else {
                throw error;
            }
        } finally {
            clearTimeout(timeout);
            externalSignal?.removeEventListener("abort", abortFromCaller);
        }

        await new Promise(resolve => setTimeout(resolve, retryDelay(response, attempt)));
    }
    throw lastError || new Error("Não foi possível ligar à API.");
}

export const apiClient = Object.freeze({
    get: path => request(path),
    getLatestRooms: () => request("/rooms"),
    getPcs: () => request("/pcs"),
    getNetworkDevices: ({ refresh = false, signal } = {}) => request(`/network/devices${refresh ? "?refresh=true" : ""}`, {
        signal,
        timeoutMs: refresh ? 60000 : undefined
    }),
    getHistory: ({ roomId, limit = 2000, from, to, signal } = {}) => {
        const params = new URLSearchParams({ limit: String(limit) });
        if (roomId) params.set("roomId", roomId);
        if (from) params.set("from", new Date(from).toISOString());
        if (to) params.set("to", new Date(to).toISOString());
        return request(`/rooms/history?${params.toString()}`, { signal });
    },
    getHealth: ({ signal } = {}) => request("/health", { signal, retries: 1 })
});

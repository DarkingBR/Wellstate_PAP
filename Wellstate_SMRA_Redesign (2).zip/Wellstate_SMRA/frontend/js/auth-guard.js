(() => {
  const api = async (url, options = {}) => fetch(url, {
    credentials: 'same-origin', cache: 'no-store', ...options,
  });

  (async () => {
    try {
      const response = await api('/auth/me');
      if (!response.ok) {
        location.replace('/login');
        return;
      }
      const { user } = await response.json();
      const name = document.getElementById('userName');
      const email = document.getElementById('userEmail');
      if (name) name.textContent = user.name;
      if (email) email.textContent = user.email;
      const accountHeading = document.querySelector('.account-hero h2');
      const accountDescription = document.querySelector('.account-hero p');
      const accountStatus = document.querySelector('.account-access');
      if (accountHeading) accountHeading.textContent = user.name;
      if (accountDescription) accountDescription.textContent = 'A tua conta Wellstate está autenticada. As definições de salas e horários continuam guardadas neste navegador.';
      if (accountStatus) accountStatus.textContent = 'Conta autenticada · sessão protegida';

      const sideFoot = document.querySelector('.side-foot');
      if (sideFoot && !document.getElementById('logoutButton')) {
        const button = document.createElement('button');
        button.id = 'logoutButton';
        button.className = 'auth-logout';
        button.type = 'button';
        button.innerHTML = '<span aria-hidden="true">↪</span> Terminar sessão';
        button.addEventListener('click', async () => {
          button.disabled = true;
          try {
            const tokenResponse = await api('/auth/csrf');
            const { csrfToken } = await tokenResponse.json();
            await api('/auth/logout', {
              method: 'POST',
              headers: { 'X-CSRF-Token': csrfToken },
            });
          } finally {
            location.replace('/login');
          }
        });
        sideFoot.append(button);
      }
    } catch {
      location.replace('/login');
    }
  })();
})();

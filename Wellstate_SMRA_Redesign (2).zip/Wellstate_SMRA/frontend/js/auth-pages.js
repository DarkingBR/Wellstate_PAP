(() => {
  const form = document.getElementById('authForm');
  if (!form) return;
  const mode = document.body.dataset.authMode;
  const message = document.getElementById('authMessage');
  const submit = form.querySelector('button[type="submit"]');
  let csrfToken = '';

  async function loadCsrf() {
    const response = await fetch('/auth/csrf', { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) throw new Error('Não foi possível iniciar a sessão segura.');
    csrfToken = (await response.json()).csrfToken;
  }

  function showMessage(text, isError = true) {
    message.textContent = text;
    message.classList.toggle('is-error', isError);
    message.classList.toggle('is-success', !isError);
  }

  (async () => {
    try {
      const response = await fetch('/auth/me', { credentials: 'same-origin', cache: 'no-store' });
      if (response.ok) location.replace('/frontend/dashboard.html');
      await loadCsrf();
    } catch (error) {
      showMessage(error.message);
      submit.disabled = true;
    }
  })();

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const values = Object.fromEntries(new FormData(form).entries());
    if (mode === 'register' && values.password !== values.confirmPassword) {
      showMessage('As palavras-passe não coincidem.');
      return;
    }
    submit.disabled = true;
    submit.classList.add('is-loading');
    message.textContent = '';
    try {
      const response = await fetch(`/auth/${mode}`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify(values),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Não foi possível concluir a operação.');
      location.replace('/frontend/dashboard.html');
    } catch (error) {
      showMessage(error.message || 'Erro de ligação. Tenta novamente.');
      if (error instanceof TypeError) showMessage('Não foi possível contactar o servidor PHP.');
      try { await loadCsrf(); } catch { /* A mensagem original é mais útil. */ }
      submit.disabled = false;
      submit.classList.remove('is-loading');
    }
  });
})();

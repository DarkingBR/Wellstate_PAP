/* Configuração central do cliente REST. Defina WELLSTATE_API_BASE_URL antes deste ficheiro para usar outro host. */
(function () {
    const host = window.location.hostname;
    const isHttp = window.location.protocol === "http:" || window.location.protocol === "https:";
    const sameOrigin = "/api";
    const localBackend = isHttp && host && window.location.port !== "5080"
        ? `${window.location.protocol}//${host}:5080/api`
        : sameOrigin;

    window.WELLSTATE_CONFIG = Object.freeze({
        API_BASE_URL: window.WELLSTATE_API_BASE_URL || localBackend,
        API_TIMEOUT_MS: 20000,
        API_RETRIES: 2,
        POLL_INTERVAL_MS: 15000,
        TIME_ZONE: "Europe/Lisbon",
        STORE_KEY: "wellstate-store"
    });
})();

# Início rápido · Wellstate SMRA

## Requisitos

- PHP 8.1+ com `PDO` e `PDO_SQLite` para login/portal.
- .NET SDK 8 para a API REST.
- Arduino IDE 2.x/core ESP8266 apenas se usar o firmware NodeMCU.
- Windows Firewall ou firewall local configurada para permitir somente a LAN/VPN de confiança.

## Iniciar os serviços manualmente

A pasta `server/` foi preservada. Sem scripts auxiliares na raiz, abra **dois terminais** no diretório raiz do ZIP extraído:

```bash
# Terminal 1: backend da API REST
dotnet run --project backend-csharp/Wellstate.API.csproj --urls http://0.0.0.0:5080

# Terminal 2: frontend e servidor PHP de autenticação
php -S 0.0.0.0:8080 -t . server/router.php
```

Ambos os comandos devem ser executados na raiz do projeto. Em Windows PowerShell, os mesmos comandos funcionam se PHP e .NET estiverem no `PATH`.

1. Abra `http://localhost:8080/register` e crie a conta inicial.
2. Inicie sessão em `http://localhost:8080/login`.
3. Verifique a API em `http://localhost:5080/api/health`: resposta esperada inclui `status: ok`, `database: ok` e `signalStorage: sqlite`.
4. Para outro dispositivo na LAN, troque `localhost` pelo IP reservado do servidor e limite o acesso de firewall à rede confiável.

## API e dados

- O frontend descobre por padrão a API no mesmo hostname, porta `5080`, prefixo `/api`. Para outra topologia, defina `window.WELLSTATE_API_BASE_URL` antes de carregar `frontend/js/config.js`; use uma URL HTTPS se o portal também estiver em HTTPS.
- A interface faz polling periódico, apresenta a condição de conexão e informa quando não alcança a API. Os GETs podem ser repetidos automaticamente em falhas temporárias; operações de escrita nunca são repetidas automaticamente.
- Telemetria exige uma chave privada no servidor (`Wellstate__DeviceApiKey`) e a mesma chave no firmware. Não coloque chaves no JavaScript público.
- Cada sala deve ter um ID estável; configure IPs reais/estáveis em `backend-csharp/appsettings.json` antes de depender do inventário de PCs.
- API, histórico e descoberta são serviços de rede privada. **Não encaminhe a porta 5080 diretamente para a Internet.**

## O que foi removido e o que continua disponível

- Foram removidos da raiz os itens visíveis na captura enviada, exceto `server/`: agente Windows `pc-agent/`, scripts auxiliares, `README.md`, `.gitignore` e a captura/mockup `APP.png`.
- Frontend, API .NET, servidor PHP em `server/`, firmware, documentação e exemplos Firebase permanecem.
- Os endpoints de presença/sinais dos agentes continuam no backend, mas o executável PowerShell local foi removido conforme a solicitação. Para voltar a usar essas funções, reinstale um agente Windows confiável compatível com os endpoints e a autenticação documentados em `PC_SIGNALS.md`; não use um arquivo de agente de origem desconhecida.

## SQLite e Firebase

A aplicação cria e usa SQLite local para contas, telemetria e sinais. Salas, PCs e horários de interface permanecem no `localStorage` deste browser. Firestore é NoSQL e **não está ligado nesta versão**. Leia [`FIREBASE-SQL-GUIDE.md`](FIREBASE-SQL-GUIDE.md) para os esquemas SQLite reais, os documentos/campos Firestore propostos e o processo seguro de uma futura integração.

## Hardware (opcional)

Consulte [`ASSEMBLY.md`](ASSEMBLY.md) e [`HARDWARE.md`](HARDWARE.md). Copie `firmware/Wellstate_Firmware/secrets.example.h` para um arquivo privado `secrets.h`, configure Wi‑Fi, URL da API, ID da sala e chave do dispositivo; nunca publique o arquivo preenchido.

# Guia detalhado de banco de dados — Wellstate SMRA

> **Resumo importante:** Firebase Firestore **não é SQL**. Firestore armazena coleções/documentos NoSQL. Esta versão do Wellstate **não está conectada ao Firebase**: contas e telemetria/sinais são persistidos em dois bancos SQLite locais; salas/PCs/horários/configurações de interface ficam no `localStorage` do navegador. Portanto, **não crie tabelas SQL dentro do Firebase nem cole uma chave de service account no frontend**. O Firestore descrito abaixo é o modelo recomendado para uma integração futura, não uma conexão já ativa.

## 1. Qual banco preencher?

| Necessidade | Banco desta versão | Ação necessária |
|---|---|---|
| Criar contas para entrar no portal | SQLite local `server/data/users.sqlite` | Nada manual: o servidor cria diretório e tabela no primeiro registo. Use `/register`. |
| Guardar leituras dos sensores | SQLite local `backend-csharp/Data/wellstate.db` | Nada manual: a API cria tabelas e índices ao iniciar; o sensor envia `POST /api/rooms/{roomId}/telemetry`. |
| Guardar sinais para PCs | SQLite local `backend-csharp/Data/wellstate.db` | Nada manual: a API cria a tabela; os sinais entram pelos endpoints da API. |
| Compartilhar salas, PCs e horários entre navegadores | Hoje `localStorage` | Não há sincronização cloud nesta versão. Uma migração precisa de uma API e autenticação/autorização próprias. |
| Usar Firebase | Firestore, NoSQL | Criar projeto/Firestore e seguir a secção 4 **apenas para preparar uma futura integração**. Criar coleções sozinho não conecta o painel. |

**Não preencha nomes, senhas, leituras ou sinais diretamente no arquivo SQLite enquanto o servidor estiver em operação.** A aplicação inicializa os esquemas e grava pelas rotas próprias. Para dados iniciais de sala, use a tela de configuração do portal; os registros de telemetria só chegam quando o sensor tem conectividade e a chave correta.

## 2. SQL que a aplicação cria automaticamente (SQLite)

O SQL abaixo documenta o estado real do código. A API PHP/.NET executa esses `CREATE TABLE IF NOT EXISTS` automaticamente; não é uma instrução para executar dentro do Console Firebase. Arquivos criados:

- `server/data/users.sqlite` — contas do portal.
- `backend-csharp/Data/wellstate.db` — salas conhecidas, telemetria e sinais.

### 2.1 Contas PHP

```sql
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

- O registo aceita nome, e-mail e senha; o PHP aplica `password_hash()` e nunca grava a senha aberta.
- O e-mail é único, sem diferenciar maiúsculas/minúsculas.
- Não crie/importa manualmente `password_hash`; migração de contas exige migração de autenticação segura.
- Banco e pasta têm permissões locais restritas pelo servidor. Proteja o diretório `server/data` contra download público.

### 2.2 Salas e telemetria ambiental .NET

```sql
CREATE TABLE IF NOT EXISTS rooms (
  room_id TEXT PRIMARY KEY COLLATE NOCASE,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS room_telemetry (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id TEXT NOT NULL COLLATE NOCASE,
  temperature REAL NULL,
  humidity REAL NULL,
  distance REAL NULL,
  motion INTEGER NOT NULL CHECK (motion IN (0, 1)),
  occupied INTEGER NOT NULL CHECK (occupied IN (0, 1)),
  event TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_room_telemetry_room_time
  ON room_telemetry(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_room_telemetry_time
  ON room_telemetry(created_at DESC);
```

Valores: temperaturas em °C, humidade em %, distância em cm; os campos de sensor podem ser `NULL` quando ausentes. `motion` e `occupied` são `0/1`; `event` é `occupied`, `motion` ou `reading`. A API registra `created_at` em UTC e remove medições com mais de 90 dias. Não invente leituras nem use `0` como sinônimo de ausente.

### 2.3 Sinais dos PCs

```sql
CREATE TABLE IF NOT EXISTS pc_signals (
  id TEXT PRIMARY KEY,
  pc_id TEXT NOT NULL COLLATE NOCASE,
  type TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL,
  result_message TEXT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  claimed_at TEXT NULL,
  received_at TEXT NULL,
  returned_at TEXT NULL
);

CREATE INDEX IF NOT EXISTS idx_pc_signals_pc_created
  ON pc_signals(pc_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pc_signals_pending
  ON pc_signals(pc_id, status, created_at);
```

Os estados atuais incluem `pending`, `claimed`, `received`, `failed` e `returned`. Os tempos são ISO-8601 UTC. O backend controla reivindicação, confirmação e expiração; não altere estados diretamente no banco.

### 2.4 Princípios operacionais SQLite

- O backend ativa WAL, chave estrangeira e `busy_timeout`; preserve esses valores.
- Não crie tabelas/índices em outro arquivo com o mesmo nome esperando que sejam detectados: a aplicação usa os caminhos acima, relativos ao processo/configuração.
- Faça backup consistente com o escritor parado ou usando a API de backup SQLite. Um simples copiar/colar com o banco aberto pode omitir dados ainda no WAL.
- Não coloque arquivos `.sqlite`, `.db`, `-wal`, `-shm`, tokens de sensor ou credenciais no site/ZIP público.

## 3. O que o app espera do ambiente para a API funcionar

1. Instale PHP 8.1+ com `PDO` e `PDO_SQLite`, .NET SDK 8 e inicie os dois serviços conforme `SETUP.md`.
2. Verifique `http://localhost:5080/api/health`; o JSON deve indicar `status: ok` e `database: ok`.
3. O portal servido em `http://localhost:8080` determina por padrão o backend no mesmo hostname, porta `5080`, prefixo `/api` (`frontend/js/config.js`). Para endereço diferente, antes do `config.js`, defina `window.WELLSTATE_API_BASE_URL = "http://HOST:5080/api"` em uma configuração local própria.
4. Não abra o HTML via `file://`: sirva através do PHP/servidor HTTP. Se o portal usa HTTPS, a API também deve usar HTTPS para evitar conteúdo misto do navegador.
5. Em rede local, libere as portas 8080 e 5080 só para a LAN/VPN confiável. Não exponha a API diretamente à Internet.
6. Configure chaves fortes distintas `Wellstate__DeviceApiKey` e `Wellstate__AgentApiKey` no ambiente do servidor. O sensor deve enviar a chave correspondente no header `X-Device-Key`; nunca embuta essa chave no JavaScript do navegador.
7. Confira sala/ID, IPs de PCs e CIDR em `backend-csharp/appsettings.json`; os valores existentes são exemplos e devem ser conferidos pelo administrador.

O navegador agora repete pedidos **GET** transitórios (rede, timeout, HTTP 408/429/5xx) com espera progressiva; nunca repete automaticamente POST/ações de escrita. Um 401/403/404 indica configuração/permissão/rota e não será escondido por tentativas. O teste `/api/health` valida o serviço e o SQLite local — **não** valida Firebase.

## 4. Preparar Firebase Firestore (opcional, integração futura)

### 4.1 Pré-requisitos e limites

- Crie um projeto Firebase sob a conta/propriedade da instituição, escolha uma região adequada e configure faturamento/limites conforme a política da escola.
- Ative Firestore Database em produção, não em modo de teste, e faça cópia/controle do projeto.
- Escolha uma integração backend → Firestore Admin SDK, com segredos em variáveis seguras/Secret Manager. O projeto atual ainda não contém SDK, Project ID nem credenciais.
- A aplicação continua usando SQLite até que se implemente e teste o acesso Firestore no backend. **Não há botão/configuração de Console que faça essa troca automaticamente.**
- `firebase/firestore.rules` nega leitura e escrita por padrão. Isso é intencional. O Admin SDK do servidor ignora Security Rules e, por isso, sua API exige controles próprios e proteção de rede.

### 4.2 Coleções raiz e o que cadastrar

O modelo definitivo, com dicionários de campo, tipos nativos, documentos de exemplo, índices e regras, está em [`FIREBASE.md`](FIREBASE.md). Resumo:

| Coleção | O que cadastrar | ID do documento |
|---|---|---|
| `rooms` | Identidade/estado estável da sala (`roomId`, `name`, `active`; bloco/piso se conhecidos) | ID real da sala, por exemplo `C1.01` |
| `telemetry` | Uma medição real por documento, ligada a `roomId`, com valores numéricos/booleanos e Timestamp UTC | Auto-ID; não reutilize o ID da sala |
| `devices` | Cadastro estável de cada PC configurado; IP real reservado, sala ou null e estado calculado pelo servidor | ID estável, ex. `PC-01` |
| `schedules` | Uma aula por documento; dia ISO, início/fim local e fuso horário | UUID/Auto-ID estável |
| `signals` | Fila/histórico de sinal para PC, incluindo estado e tempos de ciclo | GUID/UUID atual ou ID estável |
| `appConfig/main` | Só parâmetros globais não secretos (fuso e retenção) se realmente utilizados | `main` |
| `users/{uid}` | Perfil mínimo somente depois de implementar Firebase Authentication | UID emitido pelo Firebase Auth |

Crie primeiro as salas e só depois cadastros que as referenciam. Não crie uma coleção por sala, não coloque histórico inteiro num array de sala, não invente salas/PCs/medições e não preencha exemplos com dados falsos apresentados como reais. Campos de data devem ser **Timestamp**, não texto ISO ou o marcador literal `TIMESTAMP_FIRESTORE_UTC`.

### 4.3 Passos seguros no Console

1. Console Firebase → projeto correto → **Firestore Database** → **Criar banco** → região escolhida pela instituição → modo de produção.
2. Abra **Rules** e mantenha a negação por padrão. Antes de adicionar regra de leitura, defina quem autentica, papéis, quais campos podem ser lidos e o mecanismo de revogação. Não habilite escrita de sensores/sinais pelo cliente.
3. Abra **Dados**. Para preparar a integração, crie `rooms` e cadastre apenas salas existentes, usando o ID de sala como ID do documento. Adicione campos pelos tipos nativos indicados na documentação principal.
4. Se e quando o backend Firestore for implementado, habilite `telemetry`, `devices`, `schedules` e `signals` pela API/Admin SDK. Evite popular fila de sinais ou telemetria manual no Console como operação real.
5. Publique índices compostos só quando uma consulta implementada precisar deles. Veja `firebase/firestore.indexes.json` e a tabela de índices em `FIREBASE.md`.
6. Guarde Project ID e credenciais no ambiente de servidor aprovado. Nunca copie chave privada para `frontend/`, `appsettings.json` público, firmware, documentação ou ZIP.
7. Teste em projeto de desenvolvimento: leituras, escritas autorizadas, bloqueio de não autorizados, validação de IDs, expiração/retentativa, quota, backup e restauração.
8. Implemente a camada de repositório no .NET, migração SQLite→Firestore controlada e autenticação/controle de acesso; só depois altere os endpoints consumidos pelo navegador.

### 4.4 Tipos, validações e índices que não podem ser omitidos

- Timestamp UTC gerado no servidor (`serverTimestamp()`), número sem unidade, boolean verdadeiro/falso nativo e `null` apenas em campo anulável.
- `roomId` de cada medição deve existir em `rooms`; `roomId` de aula e PC também deve referenciar cadastro válido. Firestore não cria foreign keys automaticamente, então o backend deve validar.
- `temperature`: −40..85 °C; `humidity`: 0..100%; `distance`: 2..400 cm ou null; `occupied=true` implica `motion=true`.
- Telemetria ordenada por sala/horário precisa de índice `roomId ASC + recordedAt DESC`. Os demais índices para sinais/horários estão descritos em `FIREBASE.md`.
- Configure retenção por TTL (campo Timestamp `expireAt`) ou limpeza pelo servidor, se a política de 90 dias for aprovada. TTL é assíncrona.
- Nunca grave senha/hash local do portal como perfil Firebase e não use e-mail como ID de usuário.

## 5. Não confundir migração com preenchimento manual

Criar coleções no Console **não transfere** os bancos SQLite e não liga a UI. Antes de migrar:

1. Faça backup consistente dos dois arquivos SQLite e exporte o `localStorage` de cada navegador que contenha salas/horários relevantes.
2. Revise e normalize IDs, nomes, sala de cada dispositivo, timezone e ano letivo com o responsável pelos dados.
3. Faça um script de migração idempotente (rodar duas vezes não duplica medições/sinais), com relatório de contagens e erros; timestamps convertidos para UTC/Timestamp e nulos preservados.
4. Compare quantidades, intervalos/ordenação e amostras entre origem e destino; teste leitura/escrita da API e restauração antes da troca de produção.
5. Mantenha backup e plano de retorno ao SQLite até aprovar a nova fonte oficial.

## 6. Referências oficiais

- [Firestore: estrutura de dados](https://firebase.google.com/docs/firestore/data-model)
- [Tipos Firestore](https://firebase.google.com/docs/firestore/manage-data/data-types)
- [Adicionar dados](https://firebase.google.com/docs/firestore/manage-data/add-data)
- [Índices](https://firebase.google.com/docs/firestore/query-data/indexing)
- [Regras de segurança](https://firebase.google.com/docs/firestore/security/get-started)
- [Firebase Admin SDK](https://firebase.google.com/docs/admin/setup)
- Esquema completo do projeto: [`FIREBASE.md`](FIREBASE.md)

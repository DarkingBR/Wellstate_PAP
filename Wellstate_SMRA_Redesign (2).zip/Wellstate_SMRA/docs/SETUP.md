# Configuração rápida · Wellstate

## Requisitos

- PHP 8.1+ com extensões `PDO` e `PDO_SQLite`.
- .NET SDK 8 para a API C#.
- `iputils-ping` em Linux se usar descoberta de computadores por ICMP.
- Arduino IDE 2.x e bibliotecas DHT Adafruit se usar o firmware ESP8266.

## Iniciar os serviços (sem scripts auxiliares)

Abra dois terminais na raiz extraída do projeto. O servidor PHP da pasta `server/` é mantido; estes comandos executam os serviços diretamente:

```bash
# Terminal 1 — API .NET (requer .NET SDK 8)
dotnet run --project backend-csharp/Wellstate.API.csproj --urls http://0.0.0.0:5080

# Terminal 2 — portal PHP (requer PHP 8.1+, PDO e PDO_SQLite)
php -S 0.0.0.0:8080 -t . server/router.php
```

Abra `http://localhost:8080/register` para criar a primeira conta e depois `http://localhost:8080/login`. Confirme a API em `http://localhost:5080/api/health`. Em Windows, use PowerShell com os mesmos comandos (o executável `php` e o `dotnet` devem estar no `PATH`). Para aceder por outro dispositivo da LAN, substitua `localhost` pelo IP LAN do computador servidor e permita as portas 8080 e 5080 na firewall **apenas para a rede confiável**.

## API, rede e dispositivos

A API fica em `http://IP-DO-SERVIDOR:5080`; confirma o estado em `/api/health`. O CIDR `auto` descobre a LAN do servidor; para fixar uma rede, edita `Wellstate:Network:Cidr` em `backend-csharp/appsettings.json`. Não encaminhes a porta 5080 para a Internet.

Configura chaves diferentes para hardware e agentes antes do uso real. Por exemplo:

```bash
export Wellstate__DeviceApiKey="<chave-aleatoria-do-sensor>"
export Wellstate__AgentApiKey="<chave-aleatoria-do-agente>"
```

O firmware envia leituras diretamente à API C# com `X-Device-Key`; os agentes Windows usam a chave configurada pelo backend. Estes fluxos não passam pelo login do portal.

## Firmware

Copia `firmware/Wellstate_Firmware/secrets.example.h` para `secrets.h` e preenche credenciais Wi-Fi, a URL da API `:5080`, a URL do portal `:8080/login`, o identificador da sala e a chave do sensor. Nunca partilhes o ficheiro preenchido.

## Firestore

Firestore é NoSQL, não SQL. A versão incluída usa SQLite e não está ligada a um projeto Firebase. Consulte o [guia detalhado SQL/Firestore](FIREBASE-SQL-GUIDE.md) e o [esquema Firestore](FIREBASE.md); criar coleções não liga o painel ao Firebase.

## Segurança de produção

O `php -S` incluído é apenas servidor de desenvolvimento. Em produção, publica o portal através de Apache/Nginx + PHP-FPM e HTTPS. Mantém a API C# e a porta 5080 numa LAN/VPN de confiança, ou protege-a com gateway/controles de acesso apropriados. Usa palavras-passe fortes, cópias de segurança e não versiona os diretórios `server/data` nem `backend-csharp/Data`.

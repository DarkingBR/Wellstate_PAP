# Referências técnicas

- [Arduino IDE — documentação](https://docs.arduino.cc/software/ide/)
- [ESP8266 Arduino Core — instalação de boards](https://arduino-esp8266.readthedocs.io/en/latest/installing.html)
- [ESP8266 Arduino Core — HTTPClient](https://arduino-esp8266.readthedocs.io/en/latest/esp8266wifi/client-examples.html)
- [Adafruit DHT sensor library](https://github.com/adafruit/DHT-sensor-library)
- [Adafruit Unified Sensor](https://github.com/adafruit/Adafruit_Sensor)
- [ASP.NET Core Web API](https://learn.microsoft.com/aspnet/core/web-api/)
- [Microsoft.Data.Sqlite](https://learn.microsoft.com/dotnet/standard/data/sqlite/)
- [HC-SR04 com ESP8266 NodeMCU](https://randomnerdtutorials.com/esp8266-nodemcu-hc-sr04-ultrasonic-arduino/) — protege ECHO com divisor de tensão ou level shifter.

O firmware usa o ESP8266 Arduino Core, `ESP8266HTTPClient` e a biblioteca DHT da Adafruit para publicar medições na API REST local. Não usa PlatformIO nem Firebase no fluxo atual.


## Inspiração de UX para o portal

A interface foi reorganizada a partir de padrões, não de cópia de marca/elementos proprietários:

- [IoT For All — Designing Shared IoT Dashboards for Commercial Buildings](https://www.iotforall.com/iot-dashboards-commercial-buildings): informação operacional prioritária, níveis de alerta e estados de conectividade/staleness visíveis.
- [TagoIO — What a Good IoT Dashboard for Facility Management Actually Looks Like](https://tago.io/blog/iot-dashboard-facility-management): status antes de números, navegação por edifício/zona/sistema e detalhe progressivo.
- [Synergy Codes — Smart Building Management Tool](https://sub.synergycodes.com/our-work/smart-building-management-tool/): contexto de utilização para monitorização ambiental, ocupação e ações de operação.

Aplicação ao Wellstate: hierarquia de estado → contexto da sala → diagnóstico; cards de navegação com nomes funcionais; conectividade e dados indisponíveis identificados; componentes responsivos e foco visível. As referências orientam padrões de produto e não indicam integração com serviços desses sites.


## Textura aplicada a partir das imagens do pacote

A identidade tecnológica foi aplicada usando os próprios assets enviados: `frontend/assets/portal-hero-circuit.png` (circuitos e brilho azul para fundo de contexto) e `frontend/assets/portal-control-preview.png` (visualização de monitorização nas superfícies de destaque). O recorte do campus permanece como recurso contextual disponível, mas não é esticado como banner devido à baixa resolução. As imagens originais de captura/maquete não são necessárias para a execução da interface.

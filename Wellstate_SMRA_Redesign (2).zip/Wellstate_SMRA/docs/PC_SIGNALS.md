# Sinais do servidor para PCs

## Estado nesta entrega

O backend C# preserva as rotas REST/SSE, a presença temporária e o armazenamento SQLite de sinais. Conforme a solicitação de remover os itens que apareciam na captura, a pasta `pc-agent/` e o cliente PowerShell que consumia essas rotas **não fazem parte deste ZIP**. Portanto, a fila/API permanece disponível, mas não há cliente Wellstate incluído para buscar, mostrar ou confirmar sinais no PC destinatário. Não anuncie um sinal como mostrado no desktop sem ACK do agente.

A ligação do painel com a API e o diagnóstico geral estão em [`REST_API.md`](REST_API.md). Os sinais usam os campos e estados descritos em [`FIREBASE.md`](FIREBASE.md) e [`DATABASE.md`](DATABASE.md).

## Contrato mantido no backend

| Endpoint | Função |
|---|---|
| `GET /api/pcs/stream` | Server-Sent Events com presença recente dos agentes |
| `GET /api/pcs` | Estado agregado: ping ou heartbeat recente; inclui `networkOnline` e `agentOnline` |
| `POST /api/pcs/{pcId}/signals` | Registra sinal; devolve `409` se o agente estiver offline |
| `GET /api/pcs/{pcId}/signals` | Histórico persistente de sinais |
| `POST /api/pcs/{pcId}/agent/heartbeat` | Atualiza presença do agente autenticado |
| `GET /api/pcs/{pcId}/agent/signals/next` | Cliente autenticado solicita o próximo sinal |
| `POST /api/pcs/{pcId}/agent/signals/{id}/ack` | Cliente autenticado confirma apresentação/resultado |

Estados gravados: `pending`, `claimed`, `received`, `failed` ou `returned`. O servidor grava o sinal antes da entrega, expira a fila segundo a configuração e não deve reentregar silenciosamente mensagens expiradas.

## Para integrar novamente um agente Windows

1. Obtenha ou desenvolva um agente em origem confiável e faça revisão de código/assinatura antes de instalá-lo. O cliente deve executar apenas a função permitida (exibir notificações) e jamais aceitar comandos arbitrários, URLs ou arquivos do servidor.
2. Implemente autenticação com uma chave de agente privada enviada no mecanismo de header esperado pelo backend. Gere uma chave aleatória distinta da chave dos sensores e armazene-a em cofre/variável segura no host; nunca a coloque no frontend ou em Git.
3. Configure o endereço LAN/VPN da API, o ID estável do PC, heartbeat dentro da janela online configurada e consulta/ACK idempotentes.
4. Consuma o endpoint `next`, valide conteúdo e tamanho de mensagem, mostre a notificação local e só envie ACK após o resultado real. Use timeouts/backoff com limites e trate `401`, `409`, `404` e falha de rede explicitamente.
5. Teste com PC de teste e chave revogável; audite logs, expiração e reinícios antes de ativar nos demais PCs.
6. Mantenha a porta 5080 em LAN/VPN privada. Não publique a porta diretamente na Internet.

## Configurar o backend

Na raiz do projeto, use um terminal para iniciar o .NET:

```bash
dotnet run --project backend-csharp/Wellstate.API.csproj --urls http://0.0.0.0:5080
```

Configure `Wellstate__AgentApiKey` como segredo de ambiente do servidor, sem gravá-lo no JSON distribuído. Para telemetria, `Wellstate__DeviceApiKey` é uma chave separada. Verifique `http://localhost:5080/api/health`. A presença do agente em memória reinicia quando o backend reinicia; a tabela `pc_signals` guarda o histórico.

> As descrições do contrato são para o backend preservado; não implicam que o agente cliente removido esteja incluído ou que as notificações estejam sendo apresentadas nos PCs.

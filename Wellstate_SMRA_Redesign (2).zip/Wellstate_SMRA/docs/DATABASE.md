# Dados e persistência · Wellstate

| Dados | Localização | Persistência |
|---|---|---|
| Utilizadores e palavras-passe protegidas | `server/data/users.sqlite` | SQLite criado pelo PHP; palavra-passe armazenada apenas como hash |
| Medições ambientais | `backend-csharp/Data/wellstate.db` | SQLite, tabelas/indexes, WAL e retenção de 90 dias |
| Sinais de PCs | `backend-csharp/Data/wellstate.db` | Tabela SQLite `pc_signals` |
| Estado temporário de agentes | Memória do backend C# | Reiniciar a API reinicia a presença, não o histórico persistido |
| Salas, computadores configurados, horário e preferências | `localStorage` (`wellstate-store`) | Local ao browser atual; não sincroniza entre utilizadores/dispositivos |
| Firestore | Não configurado | Existe documentação de esquema, mas a aplicação não lê nem grava nesta cloud |

## SQLite

O módulo PHP cria `server/data/users.sqlite` ao registar a primeira conta. A API C# cria `backend-csharp/Data/wellstate.db` ao iniciar e gerir telemetria/sinais. Ambas as bases são locais e separadas por responsabilidade.

- O registo usa consultas PDO parametrizadas, índice/constraint de unicidade para e-mail e `password_hash`/`password_verify`.
- Telemetria e sinais usam transações, modo WAL, índices e timestamps UTC.
- As medições com mais de 90 dias são limpas pelo backend; consulte os serviços em `backend-csharp/Services/`.
- Faça cópias de segurança com a aplicação parada ou usando o mecanismo de backup SQLite. Inclua os ficheiros `-wal`/`-shm` apenas segundo procedimento consistente.

## Firestore versus SQL

Firestore é NoSQL, com coleções/documentos; não é uma base SQL. O esquema proposto, tipos, regras e passos de migração estão em [FIREBASE.md](FIREBASE.md). Nenhuma credencial Firebase foi fornecida neste pacote e o acesso cliente Firestore é negado pelas regras atuais. Para uma integração cloud real é necessário configurar um projeto Firebase e um fluxo de credenciais do servidor; não coloque uma chave de service account no browser.

## Segurança

O login protege as páginas servidas pelo portal PHP. A API C# e os endpoints de leitura continuam independentes da sessão de utilizador para permitir a integração de sensores e agentes. Restrinja a porta 5080 à LAN/VPN e use as chaves de serviço previstas em `appsettings.json`/variáveis de ambiente. Não exponha a API diretamente à Internet.

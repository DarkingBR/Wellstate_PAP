<?php
declare(strict_types=1);

return [
    'database_path' => __DIR__ . '/data/users.sqlite',
    'session_name' => 'wellstate_session',
    'session_lifetime' => 0,
    'secure_cookies' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
];

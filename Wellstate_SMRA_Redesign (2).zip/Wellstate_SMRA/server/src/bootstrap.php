<?php
declare(strict_types=1);

$config = require dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/UserRepository.php';

ini_set('display_errors', '0');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name($config['session_name']);
session_set_cookie_params([
    'lifetime' => $config['session_lifetime'],
    'path' => '/',
    'secure' => $config['secure_cookies'],
    'httponly' => true,
    'samesite' => 'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function jsonResponse(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '{}', true);
    return is_array($decoded) ? $decoded : [];
}

function requireCsrf(): void
{
    $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $expected = $_SESSION['csrf_token'] ?? '';
    if (!is_string($provided) || !is_string($expected) || $expected === '' || !hash_equals($expected, $provided)) {
        jsonResponse(['ok' => false, 'message' => 'Sessão expirada. Atualize a página e tente novamente.'], 419);
    }
}

function publicUser(array $user): array
{
    return [
        'id' => (int) $user['id'],
        'name' => (string) $user['name'],
        'email' => (string) $user['email'],
        'createdAt' => (string) ($user['created_at'] ?? ''),
    ];
}

function requireLogin(): array
{
    if (empty($_SESSION['user_id'])) {
        jsonResponse(['ok' => false, 'message' => 'Inicie sessão para continuar.'], 401);
    }
    $repository = new UserRepository($GLOBALS['config']['database_path']);
    $user = $repository->findById((int) $_SESSION['user_id']);
    if (!$user) {
        $_SESSION = [];
        session_regenerate_id(true);
        jsonResponse(['ok' => false, 'message' => 'A conta já não está disponível.'], 401);
    }
    return $user;
}

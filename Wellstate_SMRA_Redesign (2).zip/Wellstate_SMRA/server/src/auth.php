<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
$GLOBALS['config'] = $config;

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

if ($path === '/auth/csrf' && $method === 'GET') {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    jsonResponse(['csrfToken' => $_SESSION['csrf_token']]);
}

if ($path === '/auth/me' && $method === 'GET') {
    if (empty($_SESSION['user_id'])) {
        jsonResponse(['authenticated' => false], 401);
    }
    $user = (new UserRepository($config['database_path']))->findById((int) $_SESSION['user_id']);
    if (!$user) {
        $_SESSION = [];
        session_regenerate_id(true);
        jsonResponse(['authenticated' => false], 401);
    }
    jsonResponse(['authenticated' => true, 'user' => publicUser($user)]);
}

if ($path === '/auth/register' && $method === 'POST') {
    requireCsrf();
    $body = requestBody();
    $name = trim((string) ($body['name'] ?? ''));
    $email = strtolower(trim((string) ($body['email'] ?? '')));
    $password = (string) ($body['password'] ?? '');

    if (preg_match('/^.{2,100}$/us', $name) !== 1) {
        jsonResponse(['ok' => false, 'message' => 'O nome deve ter entre 2 e 100 caracteres.'], 422);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) {
        jsonResponse(['ok' => false, 'message' => 'Introduza um endereço de e-mail válido.'], 422);
    }
    if (strlen($password) < 8 || strlen($password) > 200) {
        jsonResponse(['ok' => false, 'message' => 'A palavra-passe deve ter pelo menos 8 caracteres.'], 422);
    }

    $repository = new UserRepository($config['database_path']);
    if ($repository->findByEmail($email)) {
        jsonResponse(['ok' => false, 'message' => 'Já existe uma conta com esse e-mail.'], 409);
    }
    try {
        $user = $repository->create($name, $email, $password);
    } catch (PDOException $exception) {
        if (str_contains(strtolower($exception->getMessage()), 'unique')) {
            jsonResponse(['ok' => false, 'message' => 'Já existe uma conta com esse e-mail.'], 409);
        }
        throw $exception;
    }
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    jsonResponse(['ok' => true, 'user' => publicUser($user)], 201);
}

if ($path === '/auth/login' && $method === 'POST') {
    requireCsrf();
    $body = requestBody();
    $email = strtolower(trim((string) ($body['email'] ?? '')));
    $password = (string) ($body['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        jsonResponse(['ok' => false, 'message' => 'E-mail ou palavra-passe incorretos.'], 401);
    }
    $user = (new UserRepository($config['database_path']))->findByEmail($email);
    if (!$user || !password_verify($password, $user['password_hash'])) {
        jsonResponse(['ok' => false, 'message' => 'E-mail ou palavra-passe incorretos.'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    jsonResponse(['ok' => true, 'user' => publicUser($user)]);
}

if ($path === '/auth/logout' && $method === 'POST') {
    requireCsrf();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]);
    }
    session_destroy();
    jsonResponse(['ok' => true]);
}

jsonResponse(['ok' => false, 'message' => 'Rota de autenticação não encontrada.'], 404);

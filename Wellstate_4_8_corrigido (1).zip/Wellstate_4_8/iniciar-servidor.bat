@echo off
chcp 65001 >nul
title Wellstate - servidor
cd /d "%~dp0frontend"
echo.
echo  Wellstate a correr em  http://localhost:8000   (rede: http://IP-DO-PC:8000)
echo  Feche esta janela para parar.
echo.
php -S 0.0.0.0:8000 router.php
pause

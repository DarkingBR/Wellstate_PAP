<?php
declare(strict_types=1);
/* Wellstate · router do servidor embutido do PHP.
   Arranque (na pasta frontend):  php -S 0.0.0.0:8000 router.php
   - /api/...  -> api/index.php (API REST)
   - ficheiros existentes (html, css, js, php/...) -> servidos normalmente
   - tudo o resto -> 404 */
$uri = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');

if ($uri === '/api' || strpos($uri, '/api/') === 0) {
    require __DIR__ . '/api/index.php';
    return true;
}
if ($uri === '/') { header('Location: /login.html', true, 302); return true; }

$file = realpath(__DIR__ . $uri);
if ($file !== false && is_file($file) && strpos($file, realpath(__DIR__)) === 0) {
    return false; // deixa o PHP servir o ficheiro estático / executar php/*.php
}
http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
echo 'Não encontrado: ' . $uri;
return true;

<?php
require __DIR__ . '/config.php';
require_post();

$in = input();
$email = strtolower(trim((string)($in['email'] ?? '')));
$password = (string)($in['password'] ?? '');
if ($email === '' || $password === '') respond(422, ['message' => 'Preencha o e-mail e a palavra-passe.']);
if (strlen($email) > 190 || strlen($password) > 200) respond(422, ['message' => 'E-mail ou palavra-passe demasiado longos.']);

/* Limite simples: 5 falhas por sessão, bloqueio de 60 s. */
$_SESSION['fails'] = $_SESSION['fails'] ?? 0;
if ($_SESSION['fails'] >= 5 && time() < ($_SESSION['locked_until'] ?? 0))
    respond(429, ['message' => 'Demasiadas tentativas. Aguarde um minuto e tente de novo.']);

$stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    if (++$_SESSION['fails'] >= 5) $_SESSION['locked_until'] = time() + 60;
    respond(401, ['message' => 'E-mail ou palavra-passe incorretos.']);
}

if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT))
    db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);

session_regenerate_id(true);
$_SESSION['uid'] = (int)$user['id'];
$_SESSION['fails'] = 0;
respond(200, ['user' => public_user($user)]);

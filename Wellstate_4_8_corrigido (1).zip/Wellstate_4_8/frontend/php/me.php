<?php
require __DIR__ . '/config.php';
if (empty($_SESSION['uid'])) respond(401, ['message' => 'Sessão não iniciada.']);
$stmt = db()->prepare('SELECT id, name, email FROM users WHERE id = ?');
$stmt->execute([$_SESSION['uid']]);
$user = $stmt->fetch();
if (!$user) { session_destroy(); respond(401, ['message' => 'Sessão inválida.']); }
respond(200, ['user' => public_user($user)]);

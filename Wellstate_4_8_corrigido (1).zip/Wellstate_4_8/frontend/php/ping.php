<?php
/* Diagnóstico: abra http://localhost/wellstate/php/ping.php no navegador. */
require __DIR__ . '/config.php';
$out = ['php' => PHP_VERSION, 'apache' => true, 'mysql' => false];
try { db(); $out['mysql'] = true; } catch (Throwable $e) {}
respond(200, $out);

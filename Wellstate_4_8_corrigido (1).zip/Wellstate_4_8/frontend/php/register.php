<?php
require __DIR__ . '/config.php';
require_post();

$in = input();
$name = trim((string)($in['name'] ?? ''));
$email = strtolower(trim((string)($in['email'] ?? '')));
$password = (string)($in['password'] ?? '');
$confirm = (string)($in['confirm'] ?? '');

$errors = [];
if (mb_strlen($name) < 2 || mb_strlen($name) > 80) $errors['name'] = 'Escreva o seu nome (2 a 80 caracteres).';
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) $errors['email'] = 'Introduza um e-mail válido.';
if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password))
    $errors['password'] = 'Use pelo menos 8 caracteres, com letras e números.';
if ($password !== $confirm) $errors['confirm'] = 'As palavras-passe não coincidem.';
if ($errors) respond(422, ['message' => 'Corrija os campos assinalados.', 'errors' => $errors]);

$pdo = db();
$exists = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$exists->execute([$email]);
if ($exists->fetch()) respond(409, ['message' => 'Este e-mail já está registado.', 'errors' => ['email' => 'Este e-mail já tem conta. Inicie sessão.']]);

$pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);

session_regenerate_id(true);
$_SESSION['uid'] = (int)$pdo->lastInsertId();
respond(201, ['user' => ['id' => $_SESSION['uid'], 'name' => $name, 'email' => $email]]);

<?php
declare(strict_types=1);

/* Wellstate · configuração PHP/MySQL (XAMPP). Utilizador padrão do XAMPP: root, sem palavra-passe. */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'wellstate';
const DB_USER = 'root';
const DB_PASS = '';

session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_name('wellstate_session');
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(int $status, array $body)
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

function input(): array
{
    $data = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($data) ? $data : [];
}

function require_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(405, ['message' => 'Método não permitido.']);
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') === false)
        respond(415, ['message' => 'Pedido inválido.']);
}

/* Liga ao MySQL e cria a base de dados e a tabela na primeira utilização. */
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $opts = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
        $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, $opts);
        $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo->exec('USE `' . DB_NAME . '`');
        $pdo->exec('CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(80) NOT NULL,
            email VARCHAR(190) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        return $pdo;
    } catch (PDOException $e) {
        respond(503, ['message' => 'Não foi possível ligar ao MySQL. Inicie o MySQL no painel do XAMPP.']);
    }
}

function public_user(array $u): array
{
    return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email']];
}

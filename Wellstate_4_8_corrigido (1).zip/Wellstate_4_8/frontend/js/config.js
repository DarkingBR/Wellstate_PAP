/* Configuração central do cliente REST. Defina WELLSTATE_API_BASE_URL antes deste ficheiro para usar outro host. */
(function () {
    const host = window.location.hostname;
    const isHttp = window.location.protocol === "http:" || window.location.protocol === "https:";
    const sameOrigin = "/api";
    const localBackend = isHttp && host && window.location.port !== "5080"
        ? `${window.location.protocol}//${host}:5080/api`
        : sameOrigin;

    // Endereços alternativos testados automaticamente se o principal falhar (ex.: localhost vs 127.0.0.1).
    // Ordem: API PHP no mesmo servidor (/api), depois o backend C# na porta 5080.
    const candidates = [...new Set([
        window.WELLSTATE_API_BASE_URL,
        isHttp ? sameOrigin : null,
        isHttp && host ? `${window.location.protocol}//${host}:5080/api` : null,
        "http://127.0.0.1:5080/api",
        "http://localhost:5080/api",
        sameOrigin
    ].filter(Boolean))];
    let active = candidates[0];

    async function probe(base) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 2500);
        try {
            const r = await fetch(`${base}/health`, { cache: "no-store", signal: controller.signal });
            if (!(r.headers.get("content-type") || "").includes("json")) return false; // HTML = servidor errado
            const body = await r.json();
            if (body && body.service === "Wellstate.API") { runtime = body.runtime || "csharp"; return true; }
            return false;
        } catch { return false; } finally { clearTimeout(timer); }
    }

    let ready = null;
    let runtime = "csharp";
    window.WellstateApi = {
        /** Promessa partilhada: a primeira procura de API termina antes dos pedidos do painel. */
        get ready() { return ready || (ready = window.WellstateApi.discover()); },
        base: () => active,
        runtime: () => runtime,
        /** Procura um endereço de API que responda e memoriza-o. */
        async discover() {
            for (const base of [active, ...candidates.filter(c => c !== active)]) {
                if (await probe(base)) {
                    active = base;
                    return base;
                }
            }
            return null;
        }
    };

    window.WELLSTATE_CONFIG = Object.freeze({
        get API_BASE_URL() { return active; },
        API_TIMEOUT_MS: 30000,
        API_RETRIES: 1,
        POLL_INTERVAL_MS: 15000,
        TIME_ZONE: "Europe/Lisbon",
        STORE_KEY: "wellstate-store"
    });
})();

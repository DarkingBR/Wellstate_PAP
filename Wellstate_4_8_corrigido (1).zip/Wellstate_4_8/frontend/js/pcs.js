import { apiClient } from "./api-client.js";

/* Dispositivos · descoberta da LAN com atualização automática de 20 em 20 segundos. */
(function () {
    const CFG = window.WELLSTATE_CONFIG;
    const SCAN_EVERY_MS = 20000;
    const $ = id => document.getElementById(id);
    const grid = $("devicesGrid"), regGrid = $("registeredGrid"), refreshBtn = $("refreshNetwork");

    const KINDS = {
        pc: { label: "Computador", icon: "fa-desktop", plural: "Computadores" },
        phone: { label: "Telemóvel", icon: "fa-mobile-screen", plural: "Telemóveis" },
        tablet: { label: "Tablet", icon: "fa-tablet-screen-button", plural: "Tablets" },
        router: { label: "Router / Rede", icon: "fa-tower-broadcast", plural: "Rede" },
        printer: { label: "Impressora", icon: "fa-print", plural: "Impressoras" },
        tv: { label: "TV / Media", icon: "fa-tv", plural: "TV / Media" },
        iot: { label: "IoT / Sensor", icon: "fa-microchip", plural: "IoT" },
        server: { label: "Servidor", icon: "fa-server", plural: "Servidores" },
        console: { label: "Consola", icon: "fa-gamepad", plural: "Consolas" },
        unknown: { label: "Desconhecido", icon: "fa-circle-question", plural: "Desconhecidos" }
    };
    const PORT_NAMES = { 22: "SSH", 80: "HTTP", 135: "RPC", 139: "NetBIOS", 443: "HTTPS", 445: "SMB", 515: "LPD", 548: "AFP", 631: "IPP", 3389: "RDP", 5555: "ADB", 8008: "Cast", 8009: "Cast", 9100: "Impressão", 62078: "iOS" };

    const state = { devices: new Map(), registered: [], filter: "all", search: "", sort: "ip", firstLoad: true, loading: false,
        nextAt: 0, timer: null, tick: null, scan: null, editing: null, fresh: new Map() };

    const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
    const fmtTime = v => v ? new Intl.DateTimeFormat("pt-PT", { timeZone: CFG.TIME_ZONE, hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).format(new Date(v)) : "—";
    const kindOf = d => KINDS[d.kind] || KINDS.unknown;
    const toast = (m, t = "success") => window.WellstateUI?.toast?.(m, t);

    /* ---------- Estado visual da ligação ---------- */
    function setBadge(mode, text) {
        const badge = $("networkBadge");
        badge.classList.toggle("connected", mode === "ok");
        badge.classList.toggle("disconnected", mode === "down");
        badge.classList.toggle("warn", mode === "warn");
        badge.replaceChildren(Object.assign(document.createElement("span"), { className: "pulse-dot" }), document.createTextNode(text));
    }
    function setNet(mode, title, subtitle) {
        $("netStatus").dataset.state = mode;
        $("netTitle").textContent = title;
        $("netSubtitle").textContent = subtitle;
    }

    /* ---------- Contagem decrescente ---------- */
    function startCountdown() {
        clearInterval(state.tick);
        const bar = $("netProgress"), label = $("nextScan");
        const update = () => {
            if (document.hidden) { label.textContent = "em pausa"; return; }
            if (state.loading) { label.textContent = "a verificar…"; bar.style.width = "100%"; return; }
            const left = Math.max(0, state.nextAt - Date.now());
            label.textContent = `${Math.ceil(left / 1000)} s`;
            bar.style.width = `${100 - (left / SCAN_EVERY_MS) * 100}%`;
        };
        update();
        state.tick = setInterval(update, 250);
    }
    function schedule(ms = SCAN_EVERY_MS) {
        clearTimeout(state.timer);
        state.nextAt = Date.now() + ms;
        state.timer = setTimeout(() => { if (document.hidden) schedule(); else load(false); }, ms);
    }

    /* ---------- Filtros ---------- */
    function renderFilters() {
        const counts = {}; for (const d of state.devices.values()) counts[d.kind] = (counts[d.kind] || 0) + 1;
        const total = state.devices.size;
        const items = [["all", "Todos", total], ...Object.keys(KINDS).filter(k => counts[k]).map(k => [k, KINDS[k].plural, counts[k]])];
        if (state.filter !== "all" && !counts[state.filter]) state.filter = "all";
        $("typeFilters").innerHTML = items.map(([k, l, n]) =>
            `<button type="button" role="tab" class="type-pill${state.filter === k ? " active" : ""}" data-kind="${esc(k)}" aria-selected="${state.filter === k}">${k !== "all" ? `<i class="fa-solid ${KINDS[k].icon}" aria-hidden="true"></i>` : ""}${esc(l)} <b>${n}</b></button>`).join("");
    }
    function visibleDevices() {
        const q = state.search.trim().toLowerCase();
        let list = [...state.devices.values()].filter(d => state.filter === "all" || d.kind === state.filter);
        if (q) list = list.filter(d => [d.hostname, d.ip, d.mac, d.vendor, d.alias, kindOf(d).label].join(" ").toLowerCase().includes(q));
        const ipNum = d => d.ip.split(".").reduce((a, b) => a * 256 + Number(b), 0);
        const sorters = {
            ip: (a, b) => ipNum(a) - ipNum(b),
            name: (a, b) => a.hostname.localeCompare(b.hostname, "pt", { sensitivity: "base" }) || ipNum(a) - ipNum(b),
            kind: (a, b) => kindOf(a).label.localeCompare(kindOf(b).label, "pt") || ipNum(a) - ipNum(b),
            latency: (a, b) => (a.responseMs ?? 9e9) - (b.responseMs ?? 9e9)
        };
        return list.sort(sorters[state.sort] || sorters.ip);
    }

    /* ---------- Cartões ---------- */
    function cardHtml(d) {
        const k = kindOf(d);
        const tags = [];
        if (d.isSelf) tags.push(["Este servidor", "self"]);
        if (d.isGateway) tags.push(["Gateway", "gw"]);
        if (state.fresh.has(d.key)) tags.push(["Novo", "new"]);
        if (d.randomMac) tags.push(["MAC privado", ""]);
        if (d.alias) tags.push(["Personalizado", ""]);
        const ports = (d.openPorts || []).slice(0, 5).map(p => PORT_NAMES[p] ? `${PORT_NAMES[p]}` : String(p));
        const latency = d.isSelf ? "local" : d.responseMs != null ? `${d.responseMs} ms` : "sem eco ICMP";
        const conf = d.confidence === "high" ? "" : d.confidence === "medium" ? " · provável" : "";
        return `
            <div class="device-card-head">
                <div class="device-icon kind-${esc(d.kind)}" aria-hidden="true"><i class="fa-solid ${k.icon}"></i></div>
                <div class="device-tags">${tags.map(([t, c]) => `<span class="dtag ${c}">${esc(t)}</span>`).join("")}<span class="status-badge online">Online</span></div>
            </div>
            <div class="device-main"><div class="device-title">
                <span class="pc-code">${esc(k.label)}${esc(conf)}</span>
                <h3 title="${esc(d.hostname)}">${esc(d.hostname)}</h3>
                <div class="ip">${esc(d.ip)}</div>
            </div></div>
            <dl class="device-facts">
                <div><dt>MAC</dt><dd>${esc(d.mac || "—")}</dd></div>
                <div><dt>Fabricante</dt><dd title="${esc(d.vendor || "")}">${esc(d.vendor || "—")}</dd></div>
                <div><dt>Latência</dt><dd>${esc(latency)}</dd></div>
                <div><dt>Serviços</dt><dd>${esc(ports.join(", ") || "—")}</dd></div>
            </dl>
            <div class="device-foot">
                <span class="why" title="${esc((d.reasons || []).join(" · "))}">${esc((d.reasons || [])[0] || "Sem pistas suficientes")}</span>
                <button type="button" class="icon-btn edit-device" data-key="${esc(d.key)}" aria-label="Editar ${esc(d.hostname)}" title="Editar nome e tipo"><i class="fa-solid fa-pen"></i></button>
            </div>`;
    }
    function renderGrid() {
        const list = visibleDevices();
        $("listCount").textContent = list.length === state.devices.size ? `${list.length} online` : `${list.length} de ${state.devices.size}`;
        if (!list.length) {
            const msg = state.devices.size ? "Nenhum dispositivo corresponde ao filtro." : (state.scan ? "Nenhum dispositivo respondeu ao scan." : "Sem dados de rede.");
            grid.replaceChildren(Object.assign(document.createElement("div"), { className: "chip wide", textContent: msg }));
            return;
        }
        grid.querySelector(".chip.wide, .skeleton")?.remove();
        const wanted = new Map(list.map(d => [d.key, d]));
        for (const el of [...grid.children]) {            // remove os que desapareceram
            if (!wanted.has(el.dataset.key) && !el.classList.contains("leaving")) {
                el.classList.add("leaving"); setTimeout(() => el.remove(), 320);
            }
        }
        const existing = new Map([...grid.children].filter(c => c.dataset.key && !c.classList.contains("leaving")).map(c => [c.dataset.key, c]));
        let ref = grid.firstElementChild;
        for (const d of list) {                            // cria/atualiza e mantém a ordem
            const html = cardHtml(d);
            let el = existing.get(d.key);
            if (!el) { el = document.createElement("article"); el.dataset.key = d.key; el.className = "pc-card device-card online"; el.innerHTML = html; el.dataset.sig = html; }
            else if (el.dataset.sig !== html) { el.innerHTML = html; el.dataset.sig = html; }
            if (el === ref) ref = ref.nextElementSibling; else grid.insertBefore(el, ref);
        }
    }
    function renderRegistered(pcs) {
        const foundIps = new Set([...state.devices.values()].map(d => d.ip));
        const offline = pcs.filter(pc => !(pc.agentOnline || pc.networkOnline || pc.online || foundIps.has(pc.ip)));
        $("registeredCount").textContent = pcs.length;
        $("onlineCount").textContent = pcs.length - offline.length;
        $("offlineCount").textContent = offline.length;
        $("registeredPanel").hidden = offline.length === 0;
        $("registeredChip").textContent = `${offline.length} offline`;
        regGrid.innerHTML = offline.map(pc => `
            <article class="pc-card device-card offline"><div class="device-card-head"><div class="device-icon kind-pc"><i class="fa-solid fa-desktop"></i></div><span class="status-badge offline">Offline</span></div>
            <div class="device-main"><div class="device-title"><span class="pc-code">PC ${esc(pc.id || "—")}</span><h3>${esc(pc.name || pc.id)}</h3><div class="ip">${esc(pc.ip || "IP não configurado")}</div></div></div>
            <div class="device-latency">${pc.lastSeenAt ? `Último heartbeat: ${esc(fmtTime(pc.lastSeenAt))}` : "Sem resposta de rede nem heartbeat"}</div></article>`).join("");
    }
    function renderKpis() {
        const c = k => [...state.devices.values()].filter(d => d.kind === k).length;
        $("deviceCount").textContent = state.devices.size;
        $("pcCount").textContent = c("pc");
        $("phoneCount").textContent = c("phone") + c("tablet");
    }

    /* ---------- Atualização ---------- */
    function applyScan(scan) {
        const incoming = new Map((scan.devices || []).filter(d => d && d.ip).map(d => [d.key || d.mac || d.ip, { ...d, key: d.key || d.mac || d.ip, hostname: d.hostname || d.ip }]));
        if (!state.firstLoad) {
            const added = [...incoming.values()].filter(d => !state.devices.has(d.key));
            const gone = [...state.devices.values()].filter(d => !incoming.has(d.key));
            added.forEach(d => state.fresh.set(d.key, Date.now()));
            if (added.length) toast(added.length === 1 ? `Novo dispositivo: ${added[0].hostname} (${added[0].ip})` : `${added.length} novos dispositivos na rede.`);
            if (gone.length) toast(gone.length === 1 ? `${gone[0].hostname} desligou-se da rede.` : `${gone.length} dispositivos desligaram-se da rede.`, "error");
        }
        for (const [k, t] of state.fresh) if (Date.now() - t > 60000 || !incoming.has(k)) state.fresh.delete(k);
        state.devices = incoming; state.firstLoad = false; state.scan = scan;
        $("scanCidr").textContent = scan.scanCidr || "—";
        $("serverIp").textContent = scan.serverAddress || "—";
        $("gatewayIp").textContent = scan.gateway || "—";
        $("scanTime").textContent = fmtTime(scan.scannedAt);
    }
    async function load(force) {
        if (state.loading) return;
        state.loading = true; refreshBtn.disabled = true; refreshBtn.textContent = "A verificar…";
        $("netStatus").classList.add("is-scanning");
        setBadge("warn", "A verificar…");
        let latency = null;
        try {
            const t0 = performance.now();
            await apiClient.getHealth();
            latency = Math.round(performance.now() - t0);
            $("apiLatency").textContent = `${latency} ms`;
        } catch (error) {
            state.devices = new Map(); state.scan = null; state.firstLoad = true;
            $("apiLatency").textContent = "—";
            ["scanCidr", "serverIp", "gatewayIp", "scanTime"].forEach(i => { $(i).textContent = "—"; });
            setBadge("down", "API indisponível");
            setNet("down", "API indisponível", error?.message || "Não foi possível contactar a API.");
            $("networkNote").textContent = "Confirme que o servidor está a correr e que abriu o painel pelo endereço do servidor (ex.: http://localhost:8000).";
            renderKpis(); renderFilters(); renderGrid(); finish(); return;
        }
        const [pcsR, scanR] = await Promise.allSettled([apiClient.getPcs(), apiClient.getNetworkDevices({ refresh: force })]);
        let quick = false; // o scan corre em segundo plano: volta a perguntar em 1,5 s até estar concluído
        if (scanR.status === "fulfilled" && scanR.value?.pending) {
            quick = true;
            setBadge("warn", `API ligada · ${latency} ms · a procurar…`);
            setNet("warn", "A procurar dispositivos na rede…", "O primeiro scan demora alguns segundos.");
            $("networkNote").textContent = "A procurar equipamentos ligados à rede…";
        } else if (scanR.status === "fulfilled" && Array.isArray(scanR.value?.devices)) {
            quick = Boolean(scanR.value.scanning);
            applyScan(scanR.value);
            const n = state.devices.size, s = scanR.value;
            setBadge("ok", `API ligada · ${latency} ms`);
            setNet("ok", `${n} dispositivo${n === 1 ? "" : "s"} ligado${n === 1 ? "" : "s"} à rede`,
                `${s.scanning ? "A atualizar…" : `Verificação concluída em ${((s.durationMs || 0) / 1000).toFixed(1)} s`} · interface ${s.interfaceName || "—"}${s.scanLimited ? ` · scan limitado a ${s.hostsScanned} endereços` : ""}`);
            $("networkNote").textContent = "Só aparecem equipamentos que responderam agora. Quando um dispositivo se desliga, desaparece no scan seguinte. Telemóveis com ‘MAC privado’ são identificados de forma provável.";
        } else {
            const reason = scanR.reason?.message || "Não foi possível descobrir a rede.";
            state.devices = new Map(); state.scan = null;
            setBadge("warn", `API ligada · ${latency} ms · scan indisponível`);
            setNet("warn", "API ligada, mas o scan da rede falhou", reason);
            $("networkNote").textContent = reason;
        }
        renderRegistered(pcsR.status === "fulfilled" && Array.isArray(pcsR.value) ? pcsR.value : []);
        renderKpis(); renderFilters(); renderGrid(); finish(quick);
    }
    function finish(quick = false) {
        state.loading = false; refreshBtn.disabled = false; refreshBtn.textContent = "Atualizar agora";
        $("netStatus").classList.toggle("is-scanning", quick);
        schedule(quick ? 1500 : SCAN_EVERY_MS); startCountdown();
    }

    /* ---------- Editar nome/tipo ---------- */
    const dlg = $("deviceDialog");
    $("dlgKind").innerHTML = `<option value="">Automático</option>` + Object.entries(KINDS).filter(([k]) => k !== "unknown").map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("") + `<option value="unknown">Desconhecido</option>`;
    const ALIAS_RE = /^[\p{L}\p{N} ._\-\/()+]*$/u;
    function dlgError(msg) { const e = $("dlgError"); e.hidden = !msg; e.textContent = msg || ""; }
    grid.addEventListener("click", ev => {
        const btn = ev.target.closest(".edit-device"); if (!btn) return;
        const d = state.devices.get(btn.dataset.key); if (!d) return;
        state.editing = d; dlgError("");
        $("dlgSub").textContent = `${d.ip}${d.mac ? " · " + d.mac : ""}`;
        $("dlgAlias").value = d.alias || ""; $("dlgKind").value = d.alias || d.reasons?.[0] === "Definido por si" ? d.kind : "";
        $("dlgReset").hidden = !(d.alias || d.reasons?.[0] === "Definido por si");
        dlg.showModal(); $("dlgAlias").focus();
    });
    $("dlgCancel").addEventListener("click", () => dlg.close());
    $("dlgReset").addEventListener("click", async () => {
        try { await apiClient.resetDeviceAlias(state.editing.key); dlg.close(); toast("Deteção automática reposta."); load(true); }
        catch (e) { dlgError(e.message); }
    });
    $("deviceForm").addEventListener("submit", async ev => {
        ev.preventDefault();
        const alias = $("dlgAlias").value.trim(), kind = $("dlgKind").value;
        if (alias.length > 40) return dlgError("O nome não pode ter mais de 40 caracteres.");
        if (!ALIAS_RE.test(alias)) return dlgError("O nome só pode ter letras, números, espaços e . _ - / ( ) +");
        if (!alias && !kind) return dlgError("Indique um nome ou escolha um tipo (ou use ‘Repor automático’).");
        const save = $("dlgSave"); save.disabled = true;
        try { await apiClient.setDeviceAlias(state.editing.key, { alias, kind }); dlg.close(); toast("Dispositivo atualizado."); await load(true); }
        catch (e) { dlgError(e.message); } finally { save.disabled = false; }
    });

    /* ---------- Eventos ---------- */
    $("typeFilters").addEventListener("click", ev => { const b = ev.target.closest(".type-pill"); if (!b) return; state.filter = b.dataset.kind; renderFilters(); renderGrid(); });
    $("deviceSearch").addEventListener("input", ev => { state.search = ev.target.value.slice(0, 60); renderGrid(); });
    $("deviceSort").addEventListener("change", ev => { state.sort = ev.target.value; renderGrid(); });
    refreshBtn.addEventListener("click", () => load(true));
    document.addEventListener("visibilitychange", () => { if (!document.hidden && Date.now() >= state.nextAt) load(false); });
    window.addEventListener("beforeunload", () => { clearTimeout(state.timer); clearInterval(state.tick); });

    startCountdown();
    load(false);
})();

/* Wellstate · login/registo: aviso de Caps Lock. */
(function () {
    "use strict";
    var pass = document.getElementById("password");
    var caps = document.getElementById("capsHint");
    if (!pass || !caps) return;
    var check = function (e) { if (e.getModifierState) caps.hidden = !e.getModifierState("CapsLock"); };
    pass.addEventListener("keydown", check);
    pass.addEventListener("keyup", check);
    pass.addEventListener("blur", function () { caps.hidden = true; });
})();

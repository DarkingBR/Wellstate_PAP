#!/usr/bin/env sh
cd "$(dirname "$0")/frontend" && echo "Wellstate em http://localhost:8000" && php -S 0.0.0.0:8000 router.php

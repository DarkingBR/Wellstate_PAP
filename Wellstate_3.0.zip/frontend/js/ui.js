/* Wellstate · camada de interface partilhada:
   toasts, diálogos de confirmação/formulário, menu móvel, paleta de comandos (Ctrl/⌘+K),
   atalhos de teclado (G + letra) e aviso de API desligada. */
(function () {
    const PAGES = [
        { href: "dashboard.html", label: "Dashboard", icon: "fa-gauge-high", key: "d" },
        { href: "rooms.html", label: "Salas", icon: "fa-door-open", key: "s" },
        { href: "pcs.html", label: "Dispositivos", icon: "fa-network-wired", key: "p" },
        { href: "schedule.html", label: "Horários", icon: "fa-calendar-days", key: "h" },
        { href: "history.html", label: "Histórico", icon: "fa-clock-rotate-left", key: "r" },
        { href: "admin.html", label: "Configuração", icon: "fa-sliders", key: "c" }
    ];
    const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
    const current = (location.pathname.split("/").pop() || "dashboard.html").toLowerCase();

    /* ---------- Toasts ---------- */
    function toast(message, type = "success", title) {
        let host = document.getElementById("toastContainer");
        if (!host) {
            host = document.createElement("div");
            host.id = "toastContainer";
            host.className = "toast-container";
            host.setAttribute("aria-live", "polite");
            document.body.appendChild(host);
        }
        const el = document.createElement("div");
        el.className = `toast ${type}`;
        el.setAttribute("role", type === "error" ? "alert" : "status");
        el.innerHTML = title ? `<strong class="toast-title">${esc(title)}</strong><span class="toast-body">${esc(message)}</span>` : esc(message);
        el.addEventListener("click", () => dismiss());
        host.appendChild(el);
        while (host.children.length > 4) host.firstElementChild.remove();
        let gone = false;
        function dismiss() { if (gone) return; gone = true; el.classList.add("leaving"); setTimeout(() => el.remove(), 300); }
        setTimeout(dismiss, type === "error" ? 6000 : 3800);
    }

    /* ---------- Diálogos ---------- */
    function buildDialog(inner, cls = "ws-dialog") {
        const dialog = document.createElement("dialog");
        dialog.className = cls;
        dialog.innerHTML = inner;
        document.body.appendChild(dialog);
        dialog.addEventListener("close", () => setTimeout(() => dialog.remove(), 50));
        dialog.addEventListener("click", e => { if (e.target === dialog) dialog.close("cancel"); });
        return dialog;
    }

    function confirmDialog({ title = "Confirmar ação", message = "", confirmLabel = "Confirmar", danger = false } = {}) {
        return new Promise(resolve => {
            const d = buildDialog(`<form method="dialog">
                <div class="ws-dialog-head"><h2>${esc(title)}</h2><button class="icon-btn" value="cancel" aria-label="Fechar"><i class="fa-solid fa-xmark"></i></button></div>
                <div class="ws-dialog-body">${esc(message)}</div>
                <div class="ws-dialog-foot"><button class="btn-ghost" value="cancel">Cancelar</button><button class="${danger ? "btn-primary btn-danger" : "btn-primary"}" value="ok" autofocus>${esc(confirmLabel)}</button></div>
            </form>`);
            d.addEventListener("close", () => resolve(d.returnValue === "ok"));
            d.showModal();
        });
    }

    /**
     * Formulário modal com validação.
     * fields: [{ name, label, value, placeholder, type, options:[{value,label}], maxlength, span }]
     * validate(values) -> mensagem de erro ou null. Resolve com os valores ou null se cancelado.
     */
    function formDialog({ title, fields, submitLabel = "Guardar", validate }) {
        return new Promise(resolve => {
            const html = fields.map(f => {
                const id = `wsf-${f.name}`;
                const control = f.options
                    ? `<select id="${id}" name="${f.name}">${f.options.map(o => `<option value="${esc(o.value)}"${o.value === f.value ? " selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`
                    : `<input id="${id}" name="${f.name}" type="${f.type || "text"}" value="${esc(f.value || "")}" placeholder="${esc(f.placeholder || "")}"${f.maxlength ? ` maxlength="${f.maxlength}"` : ""} autocomplete="off" />`;
                return `<label class="${f.span ? "span-2" : ""}" for="${id}">${esc(f.label)}${control}${f.hint ? `<span class="field-hint">${esc(f.hint)}</span>` : ""}</label>`;
            }).join("");
            const d = buildDialog(`<form novalidate>
                <div class="ws-dialog-head"><h2>${esc(title)}</h2><button type="button" class="icon-btn" data-close aria-label="Fechar"><i class="fa-solid fa-xmark"></i></button></div>
                <div class="ws-form-grid">${html}<p class="form-error" role="alert"></p></div>
                <div class="ws-dialog-foot"><button type="button" class="btn-ghost" data-close>Cancelar</button><button type="submit" class="btn-primary"><i class="fa-solid fa-check"></i> ${esc(submitLabel)}</button></div>
            </form>`);
            const form = d.querySelector("form");
            const errorEl = d.querySelector(".form-error");
            let result = null;
            d.querySelectorAll("[data-close]").forEach(b => b.addEventListener("click", () => d.close()));
            form.addEventListener("input", () => { errorEl.textContent = ""; form.querySelectorAll("[aria-invalid]").forEach(i => i.removeAttribute("aria-invalid")); });
            form.addEventListener("submit", e => {
                e.preventDefault();
                const values = Object.fromEntries([...new FormData(form)].map(([k, v]) => [k, String(v).trim()]));
                const problem = validate ? validate(values) : null;
                if (problem) {
                    const [field, msg] = typeof problem === "object" ? [problem.field, problem.message] : [null, problem];
                    errorEl.textContent = msg;
                    if (field) { const input = form.elements[field]; input?.setAttribute("aria-invalid", "true"); input?.focus(); }
                    return;
                }
                result = values;
                d.close();
            });
            d.addEventListener("close", () => resolve(result));
            d.showModal();
            form.querySelector("input,select")?.focus();
        });
    }

    async function promptDialog(title, label, value = "") {
        const r = await formDialog({ title, fields: [{ name: "value", label, value, type: "password", span: true }], submitLabel: "Continuar", validate: v => v.value ? null : "Campo obrigatório." });
        return r ? r.value : null;
    }

    /* ---------- Loading em botões ---------- */
    async function withLoading(button, fn) {
        if (button) { button.disabled = true; button.classList.add("is-loading"); }
        try { return await fn(); }
        finally { if (button) { button.disabled = false; button.classList.remove("is-loading"); } }
    }

    /* ---------- Shell: menu móvel, navegação ativa ---------- */
    function enhanceShell() {
        document.querySelectorAll(".nav-link").forEach(link => {
            const href = (link.getAttribute("href") || "").toLowerCase();
            link.classList.toggle("active", href === current);
            if (href === current) link.setAttribute("aria-current", "page");
            const page = PAGES.find(p => p.href === href);
            if (page && !link.querySelector(".nav-kbd")) link.insertAdjacentHTML("beforeend", `<span class="nav-kbd" aria-hidden="true">G ${page.key.toUpperCase()}</span>`);
        });

        const sidebar = document.querySelector(".sidebar");
        const brand = sidebar?.querySelector(".brand");
        if (brand && !sidebar.querySelector(".search-trigger")) {
            brand.insertAdjacentHTML("afterend", `<button type="button" class="search-trigger" data-cmdk><i class="fa-solid fa-magnifying-glass"></i> Procurar… <kbd>${/Mac|iPhone|iPad/.test(navigator.platform) ? "⌘" : "Ctrl"} K</kbd></button>`);
        }
        if (sidebar && !document.querySelector(".sidebar-scrim")) {
            const scrim = document.createElement("div");
            scrim.className = "sidebar-scrim";
            scrim.addEventListener("click", () => document.body.classList.remove("nav-open"));
            sidebar.after(scrim);
        }
        const topLeft = document.querySelector(".topbar > div:first-child");
        if (topLeft && !topLeft.querySelector(".menu-toggle")) {
            topLeft.insertAdjacentHTML("afterbegin", `<button type="button" class="btn-ghost btn-sm menu-toggle" aria-label="Abrir menu" aria-expanded="false"><i class="fa-solid fa-bars"></i> Menu</button>`);
            topLeft.querySelector(".menu-toggle").addEventListener("click", e => {
                const open = document.body.classList.toggle("nav-open");
                e.currentTarget.setAttribute("aria-expanded", String(open));
            });
        }
        document.addEventListener("click", e => { if (e.target.closest("[data-cmdk]")) openPalette(); });

        // Brilho que segue o rato nos KPIs
        document.addEventListener("pointermove", e => {
            const card = e.target.closest?.(".kpi-card");
            if (!card) return;
            const r = card.getBoundingClientRect();
            card.style.setProperty("--mx", `${e.clientX - r.left}px`);
            card.style.setProperty("--my", `${e.clientY - r.top}px`);
        }, { passive: true });
    }

    /* ---------- Paleta de comandos ---------- */
    let paletteOpen = false;
    function openPalette() {
        if (paletteOpen) return;
        paletteOpen = true;
        const store = window.WELLSTATE_STORE || { rooms: [], schedule: {} };
        const DAYS = { 1: "Segunda", 2: "Terça", 3: "Quarta", 4: "Quinta", 5: "Sexta" };
        const items = [
            ...PAGES.map(p => ({ group: "Páginas", label: p.label, icon: p.icon, hint: `G ${p.key.toUpperCase()}`, run: () => location.href = p.href })),
            ...(store.rooms || []).map(r => ({ group: "Salas", label: `${r.name}`, sub: r.id, icon: "fa-door-open", hint: r.id, run: () => location.href = `rooms.html#${encodeURIComponent(r.id)}` })),
            ...Object.entries(store.schedule || {}).flatMap(([d, list]) => (list || []).map(l => ({ group: "Aulas", label: `${l.subject} · ${DAYS[d] || d}`, icon: "fa-book-open", hint: `${l.start}–${l.end} · ${l.room}`, run: () => location.href = "schedule.html" }))),
            { group: "Ações", label: "Recarregar dados do servidor", icon: "fa-rotate", run: async () => { await window.WellstateStore?.sync(); toast(window.WellstateStore?.status().synced ? "Dados sincronizados." : "Servidor indisponível.", window.WellstateStore?.status().synced ? "success" : "error"); } },
            { group: "Ações", label: "Ativar notificações do navegador", icon: "fa-bell", run: async () => { if (!("Notification" in window)) return toast("Este navegador não suporta notificações.", "error"); const p = await Notification.requestPermission(); toast(p === "granted" ? "Notificações ativadas." : "Notificações não autorizadas.", p === "granted" ? "success" : "info"); } }
        ];
        const d = buildDialog(`<div class="cmdk-input-wrap"><i class="fa-solid fa-magnifying-glass"></i><input type="text" placeholder="Procurar páginas, salas, aulas ou ações…" aria-label="Procurar" /><kbd>Esc</kbd></div><div class="cmdk-list" role="listbox"></div><div class="cmdk-foot"><span><kbd>↑</kbd> <kbd>↓</kbd> navegar</span><span><kbd>Enter</kbd> abrir</span></div>`, "ws-dialog cmdk");
        const input = d.querySelector("input");
        const list = d.querySelector(".cmdk-list");
        let filtered = items, index = 0;
        const norm = s => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        function render() {
            const q = norm(input.value.trim());
            filtered = q ? items.filter(i => norm(`${i.label} ${i.hint || ""} ${i.group}`).includes(q)) : items.slice(0, 40);
            index = Math.min(index, Math.max(0, filtered.length - 1));
            if (!filtered.length) { list.innerHTML = `<div class="cmdk-empty">Nenhum resultado para “${esc(input.value)}”.</div>`; return; }
            let html = "", group = "";
            filtered.forEach((it, i) => {
                if (it.group !== group) { group = it.group; html += `<div class="cmdk-group">${esc(group)}</div>`; }
                html += `<div class="cmdk-item" role="option" data-i="${i}" aria-selected="${i === index}"><i class="fa-solid ${it.icon}"></i><span>${esc(it.label)}</span>${it.hint ? `<span class="hint">${esc(it.hint)}</span>` : ""}</div>`;
            });
            list.innerHTML = html;
            list.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: "nearest" });
        }
        function choose(i) { const it = filtered[i]; if (!it) return; d.close(); it.run(); }
        input.addEventListener("input", () => { index = 0; render(); });
        input.addEventListener("keydown", e => {
            if (e.key === "ArrowDown") { e.preventDefault(); index = (index + 1) % Math.max(1, filtered.length); render(); }
            else if (e.key === "ArrowUp") { e.preventDefault(); index = (index - 1 + filtered.length) % Math.max(1, filtered.length); render(); }
            else if (e.key === "Enter") { e.preventDefault(); choose(index); }
        });
        list.addEventListener("click", e => { const item = e.target.closest(".cmdk-item"); if (item) choose(Number(item.dataset.i)); });
        list.addEventListener("mousemove", e => { const item = e.target.closest(".cmdk-item"); if (item && Number(item.dataset.i) !== index) { index = Number(item.dataset.i); list.querySelectorAll(".cmdk-item").forEach(el => el.setAttribute("aria-selected", String(Number(el.dataset.i) === index))); } });
        d.addEventListener("close", () => { paletteOpen = false; });
        render();
        d.showModal();
        input.focus();
    }

    /* ---------- Atalhos ---------- */
    let gPressed = 0;
    document.addEventListener("keydown", e => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); return; }
        const typing = /^(input|textarea|select)$/i.test(e.target.tagName) || e.target.isContentEditable || document.querySelector("dialog[open]");
        if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.key === "Escape") document.body.classList.remove("nav-open");
        if (e.key === "/") { e.preventDefault(); openPalette(); return; }
        if (e.key.toLowerCase() === "g") { gPressed = Date.now(); return; }
        if (Date.now() - gPressed < 1200) {
            const page = PAGES.find(p => p.key === e.key.toLowerCase());
            if (page) { gPressed = 0; location.href = page.href; }
        }
    });

    /* ---------- Aviso de API desligada ---------- */
    function offlineBanner(message) {
        const main = document.querySelector(".content");
        if (!main || main.querySelector(".offline-banner")) return;
        const api = window.WELLSTATE_CONFIG?.API_BASE_URL || "/api";
        const banner = document.createElement("div");
        banner.className = "offline-banner";
        banner.setAttribute("role", "status");
        banner.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i><span>Servidor Wellstate indisponível em <code>${esc(api)}</code>. A mostrar a última cópia guardada neste navegador.</span><button type="button" class="btn-ghost btn-sm"><i class="fa-solid fa-rotate"></i> Tentar novamente</button>`;
        banner.title = message || "";
        banner.querySelector("button").addEventListener("click", async ev => {
            await withLoading(ev.currentTarget, () => window.WellstateStore?.sync());
            if (window.WellstateStore?.status().synced) { banner.remove(); toast("Ligação ao servidor restabelecida."); location.reload(); }
            else toast("O servidor continua indisponível.", "error");
        });
        main.querySelector(".topbar")?.after(banner);
    }
    window.addEventListener("wellstate:sync-error", e => offlineBanner(e.detail));

    window.WellstateUI = { toast, confirm: confirmDialog, form: formDialog, prompt: promptDialog, withLoading, openPalette, esc };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", enhanceShell);
    else enhanceShell();
})();

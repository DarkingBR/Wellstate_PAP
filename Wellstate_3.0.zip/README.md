# Wellstate · Centro de operações escolar (PAP)

Painel web profissional para **horários**, **salas com sensores de presença** (PIR + ultrassónico), **inventário de dispositivos da rede local** e histórico.  
O **DHT11 (temperatura/humidade) foi completamente removido** deste projeto.

## Arquitetura

```text
NodeMCU ESP8266 (PIR + HC-SR04) ── REST autenticada ─────┐
Painel Web ──────────────────── SSE + REST ──────────────┤── ASP.NET Core API ── SQLite/WAL
Dispositivos LAN ────────────── ICMP controlado ─────────┘
```

- **Firmware:** Arduino IDE, HTTP REST, chave de dispositivo. Apenas presença (movimento + distância).
- **Backend:** .NET 8, `http://<IP-LOCAL>:5080/api`; SQLite em `backend-csharp/Data/wellstate.db`.
- **Frontend:** design profissional (fundo off-white, cards azuis, rodapé preto). Servido pelo backend.
- **PCs:** ping + heartbeat do agente Wellstate.
- **Horário:** UTC no servidor; painel em `Europe/Lisbon`.

## O que foi removido

- Sensor **DHT11** e todas as leituras de temperatura e humidade no firmware, API e interface.
- KPI de temperatura média e gráficos ambientais de temp/humidade (substituídos por distância e ocupação).

## Ligar e executar

1. Instale o .NET SDK 8 ([docs/SETUP.md](docs/SETUP.md)).
2. Configure a chave do dispositivo (se usar sensores) e inicie a API.
3. Grave o firmware NodeMCU (sem DHT) com Arduino IDE.
4. Na raiz: `./start-wellstate.sh` ou `./start-wellstate.ps1`.
5. Abra `http://IP-DO-SERVIDOR:5080/`.
6. Confirme `http://IP-DO-SERVIDOR:5080/api/health`.

## Abrir com o VS Code + Live Server

1. Abra a pasta `frontend` no VS Code.
2. Clique com o botão direito em `dashboard.html` → **Open with Live Server**.
3. O painel tenta ligar à API em `http://<host>:5080/api`. Sem o backend ligado, aparece um aviso e o painel usa a cópia guardada no navegador (salas e horário de demonstração).

Atalhos: `Ctrl/⌘ + K` ou `/` abre a pesquisa · `G` + `D/S/P/H/R/C` navega entre páginas.

## Design (PAP) — versão 3.0

- Fundo branco/cinza quente, menu lateral, KPIs, separadores e rodapé em tinta (quase-preto), acento lima.
- Tipografia Geist + Geist Mono. Um único ficheiro de estilos: `frontend/css/wellstate.css`.
- Janelas de confirmação e formulários com validação no lugar dos pop-ups do navegador (`frontend/js/ui.js`).
- Menu adaptado a telemóvel, paleta de comandos, notificações elegantes, estados de carregamento.

## Design (PAP) — notas anteriores

- Fundo do site: branco levemente escuro (`#e8ecf1`).
- Cards de KPI e salas: fundo azul profissional.
- Rodapé: preto com texto branco.
- Validação de formulários em Configuração (ID de sala, IP, nomes, horários).
- Tema claro/escuro, toasts, estados vazios e badges de estado.

## Firebase / Firestore

O backend atual usa **SQLite**. Se pretender migrar ou espelhar dados no **Firebase Firestore**, consulte o documento incluído:

`docs/FIRESTORE_MODELO_DADOS.docx` (ou o ficheiro equivalente no ZIP).

Configuração de exemplo do projeto Firebase:

```js
const firebaseConfig = {
  apiKey: "AIzaSyBCkOKVdEZlkIWhKg_feyde2dvM7YGzbns",
  authDomain: "wellstate-pap.firebaseapp.com",
  projectId: "wellstate-pap",
  storageBucket: "wellstate-pap.firebasestorage.app",
  messagingSenderId: "600103840665",
  appId: "1:600103840665:web:4a653f023fafa2c02c0108",
  measurementId: "G-LGE14T04DP"
};
```

## Documentação

- [docs/SETUP.md](docs/SETUP.md)
- [docs/REST_API.md](docs/REST_API.md)
- [docs/HARDWARE.md](docs/HARDWARE.md) — atualizado sem DHT11
- [docs/DATABASE.md](docs/DATABASE.md)
- [docs/PC_SIGNALS.md](docs/PC_SIGNALS.md)

## Nota PAP

Projeto de Aptidão Profissional — monitorização escolar com presença por sensores, inventário de rede e horários, com interface profissional e validações.

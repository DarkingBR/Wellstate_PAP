# Wellstate 2.0 — alterações

## Design
- Nova identidade única em todas as páginas: fundo #E8E8E8, cartões/painéis #171717, texto branco, azul só em detalhes (`frontend/css/wellstate-2.css`).
- Tipografia Manrope, animações discretas, respeita "reduzir movimento".
- Versão telemóvel: barra de navegação superior compacta, tabelas em cartões, diálogo em coluna única.
- Removido o botão de tema claro/escuro (identidade visual obrigatória única).

## Funcional
- Salas e horário agora guardados na **SQLite** através da API (antes: só no navegador de cada posto).
  Na primeira abertura, a configuração existente no navegador é importada automaticamente (sem perda de dados).
- Horários: criar/editar/remover aulas com validação e deteção de conflitos (sala e turma) no frontend **e** backend.
- Configuração: salas e aulas gravadas no servidor; importar/exportar cópia de segurança; duplicados ignorados.

## Erros corrigidos (já existiam no ZIP original)
- `dashboard.js` estava corrompido (linhas cortadas) → o Dashboard não carregava. Reescrito.
- `pcs.html` não tinha os elementos que `pcs.js` usa → página Dispositivos falhava. Estrutura reposta.
- `schedule.html` não tinha a tabela nem o formulário que `schedule.js` usa → Horários não funcionava. Reposto.
- `history.html` faltava o adaptador de datas do Chart.js → gráfico do Histórico dava erro. Adicionado.
- Pedidos com JSON inválido devolviam detalhes internos do parser → agora mensagem limpa.

## Segurança
- Chave de administração opcional (`WELLSTATE_ADMIN_API_KEY`) para escritas; comparação em tempo constante.
- Erros inesperados nunca expõem stack traces; cabeçalhos `nosniff`, `X-Frame-Options`, `Referrer-Policy`.
- CORS configurável (`Wellstate:AllowedOrigins`).

## Limitações (não simuladas)
- **Temperatura e humidade**: o sensor DHT11 foi removido do firmware no projeto original; a API aceita os campos mas o hardware atual não os envia. Para voltar a ter estes valores é preciso reinstalar o sensor e o código no ESP8266.
- **Lista de PCs monitorizados** continua em `backend-csharp/appsettings.json` (`Wellstate:Pcs`); a lista na página Configuração é apenas de referência local.
- ESP8266 e agente Windows não puderam ser testados fisicamente; os endpoints que usam não foram alterados (telemetria testada por pedido HTTP).

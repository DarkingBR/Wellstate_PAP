/*
 * Wellstate · ESP8266 / NodeMCU v2
 * Sensores: PIR HC-SR501 + ultrassónico HC-SR04 (presença).
 * DHT11 removido — o projeto já não utiliza temperatura/humidade.
 * Publica medições na API REST Wellstate (SQLite no backend).
 * Não identifica pessoas; a presença é apenas uma estimativa dos sensores.
 */
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include "secrets.h"

#ifndef WELLSTATE_ROOM_ID
#define WELLSTATE_ROOM_ID "C1.01"
#endif
#define PIR_PIN D5
#define TRIG_PIN D6
#define ECHO_PIN D7
#define LED_PIN D1

namespace {
constexpr unsigned long WIFI_RETRY_MS = 15000;
constexpr unsigned long SENSOR_READ_MS = 1000;
constexpr unsigned long TELEMETRY_MS = 10000;
constexpr float PRESENCE_DISTANCE_CM = 200.0f;

float distanceCm = NAN;
bool motionDetected = false;
bool presenceConfirmed = false;
bool ledOn = false;
bool configurationReady = false;
unsigned long lastWifiAttempt = 0;
unsigned long lastSensorRead = 0;
unsigned long lastTelemetryAttempt = 0;
unsigned long lastLedToggle = 0;

float readDistance() {
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(3);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    const unsigned long duration = pulseIn(ECHO_PIN, HIGH, 25000UL);
    if (duration == 0) return NAN;
    return (duration * 0.0343f) / 2.0f;
}

String encodePathSegment(const String& value) {
    String out;
    out.reserve(value.length() * 3);
    for (size_t i = 0; i < value.length(); i++) {
        const char c = value[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            out += c;
        } else {
            char buf[4];
            snprintf(buf, sizeof(buf), "%%%02X", (unsigned char)c);
            out += buf;
        }
    }
    return out;
}

void ensureWifi() {
    if (WiFi.status() == WL_CONNECTED) return;
    const unsigned long now = millis();
    if (lastWifiAttempt != 0 && now - lastWifiAttempt < WIFI_RETRY_MS) return;
    lastWifiAttempt = now;
    Serial.printf("[Wi-Fi] A ligar a %s...\n", WIFI_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

String telemetryJson() {
    String json = "{";
    json += "\"distance\":";
    json += isnan(distanceCm) ? "null" : String(distanceCm, 1);
    json += ",\"motion\":";
    json += motionDetected ? "true" : "false";
    json += ",\"occupied\":";
    json += presenceConfirmed ? "true" : "false";
    json += "}";
    return json;
}

void postTelemetry() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[API] Sem Wi-Fi; a leitura será tentada novamente no próximo intervalo.");
        return;
    }

    WiFiClient client;
    HTTPClient http;
    http.setTimeout(6000);
    const String url = String(WELLSTATE_API_BASE_URL) + "/api/rooms/" +
        encodePathSegment(String(WELLSTATE_ROOM_ID)) + "/telemetry";
    if (!http.begin(client, url)) {
        Serial.println("[API] Não foi possível iniciar a ligação HTTP.");
        return;
    }
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Device-Key", WELLSTATE_DEVICE_API_KEY);
    const String payload = telemetryJson();
    const int status = http.POST(payload);
    if (status >= 200 && status < 300) {
        Serial.printf("[API] Medição guardada · sala %s · dist=%s cm · movimento=%s · presença=%s\n",
            WELLSTATE_ROOM_ID,
            isnan(distanceCm) ? "—" : String(distanceCm, 1).c_str(),
            motionDetected ? "sim" : "não",
            presenceConfirmed ? "sim" : "não");
    } else if (status > 0) {
        Serial.printf("[API ERRO] HTTP %d · %s\n", status, http.getString().c_str());
    } else {
        Serial.printf("[API ERRO] %s\n", http.errorToString(status).c_str());
    }
    http.end();
}

void readSensors() {
    const unsigned long now = millis();
    motionDetected = digitalRead(PIR_PIN) == HIGH;
    if (now - lastSensorRead >= SENSOR_READ_MS || lastSensorRead == 0) {
        lastSensorRead = now;
        distanceCm = readDistance();
        presenceConfirmed = motionDetected && !isnan(distanceCm) && distanceCm < PRESENCE_DISTANCE_CM;
    }

    if (presenceConfirmed) {
        digitalWrite(LED_PIN, HIGH);
        ledOn = true;
    } else if (motionDetected) {
        if (now - lastLedToggle >= 180) {
            ledOn = !ledOn;
            digitalWrite(LED_PIN, ledOn ? HIGH : LOW);
            lastLedToggle = now;
        }
    } else {
        digitalWrite(LED_PIN, LOW);
        ledOn = false;
    }
}
} // namespace

void setup() {
    Serial.begin(115200);
    delay(250);
    Serial.println();
    Serial.println("Wellstate · Monitor de presença de sala · Arduino IDE / REST");
    Serial.printf("Sala configurada: %s\n", WELLSTATE_ROOM_ID);
    Serial.println("Sensores: PIR + ultrassónico (DHT11 removido)");

    pinMode(PIR_PIN, INPUT);
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
    pinMode(LED_PIN, OUTPUT);
    digitalWrite(TRIG_PIN, LOW);
    digitalWrite(LED_PIN, LOW);

    configurationReady = strlen(WIFI_SSID) > 0 && strlen(WIFI_PASSWORD) > 0 &&
        strlen(WELLSTATE_DEVICE_API_KEY) >= 24 && strlen(WELLSTATE_ROOM_ID) > 0 &&
        strlen(WELLSTATE_API_BASE_URL) > 0 && strstr(WELLSTATE_DEVICE_API_KEY, "CHANGE_ME") == nullptr &&
        strstr(WELLSTATE_API_BASE_URL, "CHANGE_ME") == nullptr &&
        strstr(WIFI_SSID, "CHANGE_ME") == nullptr && strstr(WIFI_PASSWORD, "CHANGE_ME") == nullptr;
    if (!configurationReady) {
        Serial.println("[CONFIG] Copia secrets.example.h para secrets.h e preenche Wi-Fi, endereço da API e chave do dispositivo.");
        return;
    }
    ensureWifi();
}

void loop() {
    if (!configurationReady) {
        delay(2000);
        return;
    }
    ensureWifi();
    readSensors();
    const unsigned long now = millis();
    if (now - lastTelemetryAttempt >= TELEMETRY_MS || lastTelemetryAttempt == 0) {
        lastTelemetryAttempt = now;
        postTelemetry();
    }
    delay(40);
}

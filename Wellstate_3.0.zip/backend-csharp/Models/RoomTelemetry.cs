using System.ComponentModel.DataAnnotations;

namespace Wellstate.API.Models;

/// <summary>
/// Pedido de telemetria de sala. Temperatura e humidade (DHT11) foram removidos do projeto.
/// Mantêm-se campos opcionais apenas para compatibilidade com dados históricos na base SQLite.
/// </summary>
public sealed class RoomTelemetryRequest
{
    /// <summary>Campo legado — DHT11 removido. Ignorado se enviado.</summary>
    [Range(-40, 85)]
    public double? Temperature { get; set; }

    /// <summary>Campo legado — DHT11 removido. Ignorado se enviado.</summary>
    [Range(0, 100)]
    public double? Humidity { get; set; }

    [Range(2, 400)]
    public double? Distance { get; set; }

    public bool Motion { get; set; }
    public bool Occupied { get; set; }

    [StringLength(20)]
    public string? Event { get; set; }
}

public sealed record RoomTelemetry(
    long Id,
    string RoomId,
    double? Temperature,
    double? Humidity,
    double? Distance,
    bool Motion,
    bool Occupied,
    string Event,
    DateTimeOffset UpdatedAt);

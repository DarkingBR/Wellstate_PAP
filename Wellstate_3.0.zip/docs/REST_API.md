# API REST · Wellstate

O backend .NET liga o firmware ESP8266, o dashboard e as ferramentas de gestão. Os exemplos usam `http://IP-DO-SERVIDOR:5080`; todos os clientes precisam alcançar a mesma instalação central.

## Endpoints

| Método | Rota | Acesso | Resultado |
|---|---|---|---|
| `GET` | `/api/health` | LAN | Estado da API e do SQLite |
| `GET` | `/api/network/devices` | LAN/VPN | Hosts que respondem na sub-rede privada do servidor |
| `GET` | `/api/network/devices?refresh=true` | LAN/VPN | Força uma nova verificação, ignorando o cache |
| `GET` | `/api/rooms` | LAN | Última leitura de cada sala com sensor |
| `GET` | `/api/rooms/history?roomId=C1.01&limit=500` | LAN | Leituras recentes; `roomId` é opcional, limite de 1–2000 |
| `GET` | `/api/rooms/history?from=2026-09-28T00:00:00Z&to=2026-09-29T00:00:00Z` | LAN | Filtrar por intervalo UTC |
| `POST` | `/api/rooms/{roomId}/telemetry` | LAN + chave | Guardar uma leitura ambiental |
| `GET` | `/api/pcs` e `/api/pcs/{id}` | LAN | Inventário configurado e status agregado dos PCs |
| `GET` | `/api/pcs/stream` | LAN | Presença dos agentes via Server-Sent Events |
| `POST` | `/api/pcs/{pcId}/agent/heartbeat` | LAN | Heartbeat do agente Windows |

As respostas usam JSON em *camelCase*. Datas são devolvidas em ISO-8601 UTC.

## Descoberta da rede

`Wellstate:Network:Cidr` é `auto` por padrão. A API escolhe a sub-rede IPv4 privada da rota ativa no servidor; se não encontrar uma LAN/VPN privada, responde `503` com orientação. Para fixar uma sub-rede, defina um CIDR privado como `192.168.1.0/24` em `backend-csharp/appsettings.json`. Por segurança, intervalos IPv4 públicos não são aceitos.

A resposta inclui `scanCidr`, `scannedAt`, `automaticallyDetected`, `interfaceName`, `serverAddress`, `gateway`, `hostsScanned`, `hostsAvailable`, `scanLimited` e a lista `devices`. O scan tem concorrência limitada e cache de 8 segundos por padrão. Se `scanLimited` for `true`, aumente `Wellstate:Network:MaxHosts` conforme a dimensão da LAN.

O scan lista apenas dispositivos que respondem. Para mostrar PCs desligados, configure seus IDs, nomes e IPs reservados/fixos em `Wellstate:Pcs`; um host desconhecido desligado não pode ser inferido só pela rede. `online` é `true` quando ping ou heartbeat recente confirma o PC, e `networkOnline`/`agentOnline` distinguem os dois sinais. O agente é necessário para confirmação quando ICMP é bloqueado.

## Registrar telemetria

Pedido:

```http
POST /api/rooms/C1.01/telemetry HTTP/1.1
Content-Type: application/json
X-Device-Key: <MESMA_CHAVE_CONFIGURADA_NO_BACKEND_E_NO_SENSOR>
```

```json
{
  "temperature": 22.6,
  "humidity": 48.0,
  "distance": 134.2,
  "motion": true,
  "occupied": true
}
```

`distance` pode ser `null` quando o sensor ultrassónico não obteve leitura válida. Temperatura aceite: −40 a 85 °C; humidade: 0 a 100%; distância: 2 a 400 cm ou `null`. `occupied` só pode ser verdadeiro quando `motion` também é verdadeiro. O servidor determina o evento e carimba a data/hora.

Resposta: `201 Created` com o registo guardado. Chave ausente/incorreta recebe `401`; se a chave não estiver configurada, a API responde `503`. O painel não recebe o segredo do sensor.

## Configurar a chave do dispositivo

Gere um segredo aleatório com pelo menos 32 bytes e configure-o **fora do repositório**. Exemplo no PowerShell:

```powershell
$token = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
$env:Wellstate__DeviceApiKey = $token
$env:ASPNETCORE_ENVIRONMENT = "Development"
dotnet run
```

Copie o mesmo valor para `WELLSTATE_DEVICE_API_KEY` em `firmware/Wellstate_Firmware/secrets.h`. Não envie esse token no frontend nem publique o ficheiro local. `appsettings.json` contém deliberadamente um placeholder.

## Rede e segurança

O CORS está aberto para facilitar o Live Server do VS Code na LAN. A aplicação não tem contas de utilizador; endpoints de leitura e sinais de PCs não estão autenticados. Mantenha API, dashboard e placas numa rede privada/VPN, limite a porta 5080 na firewall e não faça encaminhamento público. HTTP não cifra a chave; numa rede não confiável, use HTTPS e revise a autenticação dos endpoints.

## Wellstate 2.0 — Configuração escolar (SQLite)

Salas e horário deixaram de viver só no navegador e passaram para a base SQLite (`room_catalog`, `schedule_lessons`).

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/config` | Salas + aulas + estado (`initialized`, `adminKeyRequired`) |
| POST | `/api/config/import` | Migração única da configuração antiga do navegador (só se a base estiver vazia) |
| POST | `/api/config/rooms` | Criar sala (`{id, name}`) — 409 se ID ou nome duplicado |
| PUT | `/api/config/rooms/{id}` | Editar/renomear sala (aulas atualizadas em cascata) |
| DELETE | `/api/config/rooms/{id}` | Apagar sala — 409 se tiver aulas |
| POST | `/api/config/lessons` | Criar aula (`{day 1–5, subject, group, teacher, room, start, end}`) |
| PUT | `/api/config/lessons/{id}` | Editar aula |
| DELETE | `/api/config/lessons/{id}` | Apagar aula |

Validação no servidor: campos obrigatórios, formato HH:MM, fim > início, duração ≥ 10 min, entre 07:00 e 23:00,
sala existente, e **deteção de conflitos** (mesma sala ou mesma turma em horários sobrepostos → HTTP 409).

Segurança: defina `WELLSTATE_ADMIN_API_KEY` para exigir o cabeçalho `X-Admin-Key` em todas as escritas
(o painel pede a chave uma vez por sessão). `WELLSTATE_DEVICE_API_KEY` continua a proteger a telemetria dos ESP8266.
Opcional: `Wellstate:AllowedOrigins` restringe o CORS.

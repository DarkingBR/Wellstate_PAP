/* Ligação ao Firebase (Auth anónimo + Firestore). O SDK é carregado sob demanda:
   se a rede ou o CDN falharem, o resto do app continua a funcionar com a API C#. */
const CFG = window.WELLSTATE_CONFIG;
const BASE = "https://www.gstatic.com/firebasejs/10.14.1/";
const state = { online: false, error: null };
const FRIENDLY = {
    "auth/operation-not-allowed": "Ative o início de sessão Anónimo em Firebase → Authentication → Método de início de sessão.",
    "permission-denied": "O Firestore recusou o acesso. Publique as regras de firebase/firestore.rules.",
    "unavailable": "Sem ligação ao Firebase neste momento."
};
function emit(online, error) {
    const code = error?.code?.replace("firestore/", "");
    state.online = online;
    state.error = online ? null : (FRIENDLY[code] || error?.message || null);
    window.dispatchEvent(new CustomEvent("wellstate:firebase-status", { detail: { ...state } }));
}

let sdkPromise = null;
function load() {
    return sdkPromise ||= (async () => {
        const [A, Au, F] = await Promise.all([import(BASE + "firebase-app.js"), import(BASE + "firebase-auth.js"), import(BASE + "firebase-firestore.js")]);
        const app = A.initializeApp(CFG.FIREBASE);
        const db = F.initializeFirestore(app, { localCache: F.persistentLocalCache({ tabManager: F.persistentMultipleTabManager() }) });
        const auth = Au.getAuth(app);
        await new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(new Error("Tempo esgotado a iniciar sessão no Firebase.")), 9000);
            const off = Au.onAuthStateChanged(auth, user => { if (user) { clearTimeout(timer); off(); resolve(user); } });
            Au.signInAnonymously(auth).catch(error => { clearTimeout(timer); reject(error); });
        });
        return { F, db };
    })().catch(error => { sdkPromise = null; emit(false, error); throw error; });
}

const toReading = (id, d) => {
    const at = d.recordedAt?.toDate?.();
    return {
        id, roomId: String(d.roomId || "").trim(),
        temperature: d.temperature ?? null, humidity: d.humidity ?? null, distance: d.distance ?? null,
        motion: Boolean(d.motion), occupied: Boolean(d.occupied), event: d.event || "",
        updatedAt: at ? at.toISOString() : null
    };
};
const valid = r => r.roomId && r.updatedAt;

/* Telemetria em tempo real: um listener único mantém as últimas leituras em memória. */
let live = null, latest = new Map();
function listenTelemetry() {
    return live ||= load().then(({ F, db }) => new Promise((resolve, reject) => {
        let first = true;
        F.onSnapshot(F.query(F.collection(db, "telemetry"), F.orderBy("recordedAt", "desc"), F.limit(300)), snap => {
            latest = new Map();
            snap.docs.map(d => toReading(d.id, d.data())).filter(valid).forEach(r => { if (!latest.has(r.roomId)) latest.set(r.roomId, r); });
            emit(true);
            if (first) { first = false; resolve(); }
        }, error => { emit(false, error); if (first) { first = false; live = null; reject(error); } });
    })).catch(error => { live = null; throw error; });
}

export const fb = {
    get status() { return { ...state }; },
    async latestRooms() { await listenTelemetry(); return [...latest.values()]; },
    async history({ roomId, limit = 2000, from, to } = {}) {
        const { F, db } = await load();
        const rules = [];
        if (from) rules.push(F.where("recordedAt", ">=", F.Timestamp.fromDate(new Date(from))));
        if (to) rules.push(F.where("recordedAt", "<=", F.Timestamp.fromDate(new Date(to))));
        const snap = await F.getDocs(F.query(F.collection(db, "telemetry"), ...rules, F.orderBy("recordedAt", "desc"), F.limit(Math.min(limit, 2000))));
        emit(true);
        return snap.docs.map(d => toReading(d.id, d.data())).filter(valid).filter(r => !roomId || r.roomId === roomId);
    }
};
window.WellstateFirebase = fb;

/* Horários: Firestore é a cópia partilhada; o localStorage continua a servir o app. */
const lessonId = (day, l) => `d${day}_${String(l.start).replace(":", "")}_${String(l.room).replace(/[^\w.-]/g, "_")}`;
function flatten(schedule) {
    const out = {};
    for (const [day, list] of Object.entries(schedule || {})) (list || []).forEach(l => {
        if (!l?.start || !l?.end || !l?.room || !l?.subject) return;
        out[lessonId(day, l)] = { dayOfWeek: Number(day), startTime: l.start, endTime: l.end, subject: l.subject, group: l.group || "", teacher: l.teacher || "", roomId: l.room, timeZone: CFG.TIME_ZONE, active: true };
    });
    return out;
}
const signature = flat => Object.keys(flat).sort().map(k => k + JSON.stringify(flat[k])).join("|");
function fromDocs(docs) {
    const schedule = { 1: [], 2: [], 3: [], 4: [], 5: [] };
    docs.forEach(d => {
        if (d.active === false || !d.roomId || !d.subject || !d.startTime || !d.endTime || !(d.dayOfWeek >= 1 && d.dayOfWeek <= 5)) return;
        schedule[d.dayOfWeek].push({ subject: d.subject, group: d.group || "Turma por definir", teacher: d.teacher || "Professor/a", room: d.roomId, start: d.startTime, end: d.endTime });
    });
    Object.values(schedule).forEach(list => list.sort((a, b) => a.start.localeCompare(b.start)));
    return schedule;
}

async function syncSchedules() {
    const { F, db } = await load();
    const col = F.collection(db, "schedules");
    let remoteIds = new Set(), remoteSig = null, seeded = false, timer = null;
    const localSig = () => signature(flatten(window.WELLSTATE_STORE.schedule));

    async function push() {
        const flat = flatten(window.WELLSTATE_STORE.schedule);
        if (signature(flat) === remoteSig) return;
        const batch = F.writeBatch(db);
        Object.entries(flat).forEach(([id, data]) => batch.set(F.doc(col, id), { ...data, updatedAt: F.serverTimestamp() }));
        remoteIds.forEach(id => { if (!(id in flat)) batch.delete(F.doc(col, id)); });
        try { await batch.commit(); emit(true); } catch (error) { emit(false, error); }
    }

    F.onSnapshot(col, snap => {
        remoteIds = new Set(snap.docs.map(d => d.id));
        const remote = fromDocs(snap.docs.map(d => d.data()));
        remoteSig = signature(flatten(remote));
        if (!remoteSig) { if (!seeded) { seeded = true; push(); } return; }
        if (snap.metadata.hasPendingWrites || remoteSig === localSig()) return;
        const next = structuredClone(window.WELLSTATE_STORE);
        next.schedule = remote;
        window.WellstateStore.save(next);
    }, error => emit(false, error));

    window.addEventListener("wellstate:store-updated", () => { clearTimeout(timer); timer = setTimeout(push, 700); });
}

async function seedRooms() {
    const { F, db } = await load();
    const col = F.collection(db, "rooms");
    const snap = await F.getDocs(col);
    if (snap.docs.some(d => String(d.data().roomId || "").trim())) return;
    const batch = F.writeBatch(db);
    window.WELLSTATE_STORE.rooms.forEach(room => {
        const m = /^([A-Z])(\d)/.exec(room.id);
        batch.set(F.doc(col, room.id), { roomId: room.id, name: room.name, block: m ? m[1] : "", floor: m ? Number(m[2]) : 0, active: true, sensorId: "", createdAt: F.serverTimestamp(), updatedAt: F.serverTimestamp() });
    });
    await batch.commit();
}

if (window.WellstateStore) {
    load().then(() => { syncSchedules().catch(e => emit(false, e)); seedRooms().catch(e => emit(false, e)); }).catch(() => { /* já sinalizado */ });
}
